import { useMemo, useState } from "react";
import { createFileRoute, Link } from "@tanstack/react-router";
import { Search, Plus, ChevronDown } from "lucide-react";


export const Route = createFileRoute("/athletes/")({
  head: () => ({
    meta: [
      { title: "Athletes · PXF Hockey" },
      { name: "description", content: "Manage athletes, track sessions and dryland progress." },
    ],
  }),
  component: Page,
});

type Athlete = {
  id: string;
  firstName: string;
  lastName: string;
  age: number;
  position: string;
  teams: string[];
  sessions: number;
  dryland: { current: number; total: number };
};

const ATHLETES: Athlete[] = [
  {
    id: "1",
    firstName: "Emma",
    lastName: "Wilson",
    age: 14,
    position: "Forward",
    teams: ["U15 AA Elite"],
    sessions: 2,
    dryland: { current: 3, total: 5 },
  },
  {
    id: "2",
    firstName: "Jake",
    lastName: "Thompson",
    age: 15,
    position: "Defense",
    teams: ["U15 AA Elite", "House League"],
    sessions: 1,
    dryland: { current: 1, total: 5 },
  },
  {
    id: "3",
    firstName: "Olivia",
    lastName: "Chen",
    age: 13,
    position: "Forward",
    teams: ["U13 AA"],
    sessions: 1,
    dryland: { current: 5, total: 5 },
  },
  {
    id: "4",
    firstName: "Noah",
    lastName: "Williams",
    age: 14,
    position: "Goalie",
    teams: ["U15 AA Elite"],
    sessions: 0,
    dryland: { current: 0, total: 5 },
  },
  {
    id: "5",
    firstName: "Liam",
    lastName: "Brown",
    age: 12,
    position: "Defense",
    teams: ["U13 AA"],
    sessions: 1,
    dryland: { current: 2, total: 5 },
  },
  {
    id: "6",
    firstName: "Sofia",
    lastName: "Martinez",
    age: 15,
    position: "Forward",
    teams: ["U15 AA Elite", "Elite Camp"],
    sessions: 2,
    dryland: { current: 4, total: 5 },
  },
];

type FilterTab = "All" | "Teams" | "Camps" | "Privates" | "Dryland";
const TABS: FilterTab[] = ["All", "Teams", "Camps", "Privates", "Dryland"];

function initials(first: string, last: string) {
  return `${first[0]}${last[0]}`.toUpperCase();
}

function Page() {
  const [query, setQuery] = useState("");
  const [tab, setTab] = useState<FilterTab>("All");
  const [teamFilter, setTeamFilter] = useState("All Teams");

  const filtered = useMemo(() => {
    return ATHLETES.filter((a) => {
      const matchesQuery =
        `${a.firstName} ${a.lastName}`.toLowerCase().includes(query.toLowerCase()) ||
        a.position.toLowerCase().includes(query.toLowerCase()) ||
        a.teams.some((t) => t.toLowerCase().includes(query.toLowerCase()));
      if (!matchesQuery) return false;
      if (tab === "All") return true;
      if (tab === "Teams") return a.teams.some((t) => !t.includes("Camp"));
      if (tab === "Camps") return a.teams.some((t) => t.includes("Camp"));
      if (tab === "Privates") return a.sessions > 0;
      if (tab === "Dryland") return a.dryland.current > 0;
      return true;
    });
  }, [query, tab]);

  return (
    <div className="space-y-5">
      <div className="flex flex-col gap-4 lg:flex-row lg:items-start lg:justify-between">
        <div>
          <div className="text-[11px] font-semibold uppercase tracking-[0.18em] text-muted-foreground">Roster</div>
          <h1 className="mt-1 text-2xl font-semibold tracking-tight">Athletes</h1>
          <p className="mt-1 text-sm text-muted-foreground">Manage players, sessions and dryland progress.</p>
        </div>
        <button className="inline-flex items-center gap-1.5 rounded-lg bg-gradient-to-r from-teal-500 to-cyan-500 px-3 py-2 text-xs font-semibold text-white shadow hover:opacity-90">
          <Plus className="h-3.5 w-3.5" /> Add Athlete
        </button>
      </div>

      <div className="flex flex-col gap-3 md:flex-row md:items-center md:justify-between">
        <div className="flex flex-wrap items-center gap-2">
          {TABS.map((t) => (
            <button
              key={t}
              onClick={() => setTab(t)}
              className={`rounded-full border px-3 py-1 text-xs font-medium transition ${
                tab === t
                  ? "border-teal-400/60 bg-teal-500/15 text-teal-100"
                  : "border-border bg-card text-muted-foreground hover:text-foreground"
              }`}
            >
              {t}
            </button>
          ))}
        </div>
        <div className="flex items-center gap-3">
          <div className="relative">
            <Search className="absolute left-2.5 top-1/2 h-3.5 w-3.5 -translate-y-1/2 text-muted-foreground" />
            <input
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              placeholder="Search athletes..."
              className="h-8 w-full rounded-lg border border-border bg-card pl-8 pr-3 text-xs text-foreground placeholder:text-muted-foreground focus:border-teal-400/60 focus:outline-none md:w-64"
            />
          </div>
          <div className="relative">
            <select
              value={teamFilter}
              onChange={(e) => setTeamFilter(e.target.value)}
              className="h-8 appearance-none rounded-lg border border-border bg-card pl-3 pr-8 text-xs text-foreground focus:border-teal-400/60 focus:outline-none"
            >
              <option>All Teams</option>
              <option>U15 AA Elite</option>
              <option>U13 AA</option>
              <option>House League</option>
              <option>Elite Camp</option>
            </select>
            <ChevronDown className="pointer-events-none absolute right-2.5 top-1/2 h-3.5 w-3.5 -translate-y-1/2 text-muted-foreground" />
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-3">
        {filtered.map((a) => (
          <Link
            key={a.id}
            to="/athletes/$athleteId"
            params={{ athleteId: a.id }}
            className="block rounded-xl border border-border bg-card p-4 transition hover:border-teal-400/30 hover:bg-card/80"
          >

            <div className="flex items-start gap-3">
              <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-full bg-teal-500 text-xs font-semibold text-white">
                {initials(a.firstName, a.lastName)}
              </div>
              <div className="min-w-0 flex-1">
                <div className="flex items-center justify-between gap-2">
                  <div className="truncate text-sm font-semibold">
                    {a.firstName} {a.lastName}
                  </div>
                  {a.sessions > 0 && (
                    <span className="shrink-0 rounded-full bg-teal-500/15 px-2 py-0.5 text-[10px] font-semibold text-teal-100">
                      {a.sessions} sessions
                    </span>
                  )}
                </div>
                <div className="mt-0.5 text-xs text-muted-foreground">
                  {a.age} yrs · {a.position}
                </div>
                <div className="mt-2 text-xs text-muted-foreground">
                  {a.teams.join(" · ")}
                </div>
              </div>
            </div>

            <div className="mt-4">
              <div className="flex items-center justify-between text-xs">
                <span className="text-muted-foreground">Dryland</span>
                <span className="font-medium text-teal-100">
                  {a.dryland.current}/{a.dryland.total} sessions
                </span>
              </div>
              <div className="mt-1.5 h-1.5 w-full overflow-hidden rounded-full bg-muted">
                <div
                  className="h-full rounded-full bg-teal-500 transition-all"
                  style={{ width: `${(a.dryland.current / a.dryland.total) * 100}%` }}
                />
              </div>
            </div>
          </Link>

        ))}
      </div>
    </div>
  );
}
