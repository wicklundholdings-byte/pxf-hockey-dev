import { createFileRoute, Link, notFound } from "@tanstack/react-router";
import { useEffect, useMemo, useState } from "react";
import {
  Star, Clock, Users, ChevronRight, Mail, Calendar, Award, Shield, Trophy, Medal,
  Instagram, Youtube, Facebook, Music2, Play, ZoomIn, Quote,
} from "lucide-react";
import { getCoachPage, type CoachPage, type BookingCamp, type TeamListing } from "@/lib/booking-data";
import { loadCoachOverrides, mergePage, parseVideoSource } from "@/lib/booking-storage";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";

export const Route = createFileRoute("/book/$username/")({
  head: ({ params }) => ({
    meta: [
      { title: `Book with ${params.username} · PXF Hockey` },
      { name: "description", content: "Public booking page powered by PXF Hockey." },
    ],
  }),
  loader: ({ params }) => {
    const page = getCoachPage(params.username);
    if (!page) throw notFound();
    return { page };
  },
  component: PublicCoachPage,
  notFoundComponent: () => (
    <div className="flex min-h-screen items-center justify-center bg-[#080d18] p-8 text-center text-white">
      <div>
        <h1 className="text-2xl font-bold">Coach not found</h1>
        <p className="mt-2 text-slate-400">This booking page doesn't exist.</p>
      </div>
    </div>
  ),
});

const BG_A = "bg-[#080d18]";
const BG_B = "bg-[#0d1526]";
const CARD_BG = "bg-[#131f35]";
const MUTED = "text-[#94a3b8]";

function daysUntil(iso?: string) {
  if (!iso) return null;
  const d = Math.ceil((new Date(iso).getTime() - Date.now()) / 86400000);
  return d > 0 ? d : null;
}

function SectionLabel({ children }: { children: React.ReactNode }) {
  return (
    <div className="text-[11px] font-bold uppercase tracking-[0.22em] text-teal-400">
      {children}
    </div>
  );
}

function SectionTitle({ children }: { children: React.ReactNode }) {
  return (
    <h2 className="mt-2 text-[32px] font-black leading-tight tracking-tight text-white sm:text-[40px]">
      {children}
    </h2>
  );
}

function Section({
  bg, label, title, children, id,
}: { bg: string; label?: string; title?: string; id?: string; children: React.ReactNode }) {
  return (
    <section id={id} className={cn(bg, "px-4 py-12 sm:px-6 sm:py-20")}>
      <div className="mx-auto max-w-[1200px]">
        {(label || title) && (
          <div className="mb-8">
            {label && <SectionLabel>{label}</SectionLabel>}
            {title && <SectionTitle>{title}</SectionTitle>}
          </div>
        )}
        {children}
      </div>
    </section>
  );
}

function PublicCoachPage() {
  const { page: seed } = Route.useLoaderData() as { page: CoachPage };
  const [page, setPage] = useState<CoachPage>(seed);
  

  useEffect(() => {
    const overrides = loadCoachOverrides(seed.username);
    if (overrides) setPage(mergePage(seed, overrides));
  }, [seed]);

  const avgStars = useMemo(
    () => page.reviews.reduce((s, r) => s + r.stars, 0) / Math.max(page.reviews.length, 1),
    [page.reviews]
  );

  const videoSrc = parseVideoSource(page.video ?? "");

  const hasAbout = !!page.bio?.trim();
  const hasPhilosophy = !!page.philosophy?.trim();
  const hasStaff = page.staff?.length > 0;
  const hasGallery = page.gallery?.length >= 4;
  const hasTestimonials = page.testimonials?.length > 0;
  const hasSocial = page.social && Object.values(page.social).some(Boolean);

  const credIcons = [Award, Shield, Trophy, Medal];

  return (
    <div className={cn("min-h-screen text-white", BG_A)} style={{ scrollBehavior: "smooth" }}>
      {/* 1. HERO */}
      <header className="relative h-[85vh] min-h-[600px] w-full overflow-hidden">
        <img src={page.banner} alt={page.name} className="absolute inset-0 h-full w-full object-cover" />
        {/* Left-stronger overlay */}
        <div className="absolute inset-0 bg-gradient-to-r from-black/85 via-black/60 to-black/20" />
        {/* Bottom fade into page */}
        <div className="absolute inset-x-0 bottom-0 h-40 bg-gradient-to-b from-transparent to-[#080d18]" />

        <div className="relative z-10 mx-auto flex h-full max-w-[1200px] flex-col justify-center px-4 sm:px-6">
          <img
            src={page.avatar}
            alt={page.name}
            className="h-20 w-20 rounded-full border-4 border-white object-cover shadow-2xl"
          />
          <h1 className="mt-6 max-w-3xl text-[36px] font-black leading-[1.05] tracking-tight text-white sm:text-[56px] lg:text-[64px]">
            {page.name}
          </h1>
          {page.tagline && (
            <p className="mt-4 max-w-2xl text-base font-light text-white/70 sm:text-xl">
              {page.tagline}
            </p>
          )}
          <div className="mt-8 flex flex-wrap gap-3">
            <a
              href="#camps"
              className="inline-flex items-center gap-1.5 rounded-md bg-teal-500 px-6 py-3 text-sm font-bold text-white shadow-lg transition hover:bg-teal-400"
            >
              View Camps <ChevronRight className="h-4 w-4" />
            </a>
            <a
              href="#privates"
              className="inline-flex items-center gap-1.5 rounded-md border-2 border-white px-6 py-3 text-sm font-bold text-white transition hover:bg-white hover:text-slate-900"
            >
              Private Sessions
            </a>
            <a
              href="#teams"
              className="inline-flex items-center gap-1.5 rounded-md border-2 border-white px-6 py-3 text-sm font-bold text-white transition hover:bg-white hover:text-slate-900"
            >
              Teams
            </a>
          </div>
        </div>
      </header>

      {/* 2. VIDEO */}
      {videoSrc && (
        <Section bg={BG_B} label="See us in action" title="Highlight Reel">
          <div
            className="relative overflow-hidden rounded-2xl bg-black shadow-2xl"
            style={{ boxShadow: "0 0 0 1px rgba(20,184,166,0.2), 0 25px 60px -15px rgba(0,0,0,0.7)" }}
          >
            <div className="aspect-video w-full">
              {videoSrc.kind === "embed" ? (
                <iframe
                  src={videoSrc.src}
                  title="Highlight video"
                  allow="autoplay; encrypted-media; picture-in-picture"
                  allowFullScreen
                  className="h-full w-full"
                />
              ) : (
                <video
                  src={videoSrc.src}
                  autoPlay muted loop playsInline controls
                  className="h-full w-full object-cover"
                  poster={page.banner}
                />
              )}
            </div>
          </div>
        </Section>
      )}

      {/* 3. ABOUT + PHILOSOPHY */}
      {(hasAbout || hasPhilosophy) && (
        <Section bg={BG_A}>
          <div className="grid gap-6 lg:grid-cols-2">
            {hasAbout && (
              <div className={cn(CARD_BG, "rounded-xl border-l-[3px] border-teal-500 p-8")}>
                <SectionLabel>Who we are</SectionLabel>
                <h3 className="mt-2 text-[28px] font-black leading-tight text-white">About Us</h3>
                <p className={cn("mt-4 text-[16px] leading-[1.6]", MUTED)}>{page.bio}</p>
              </div>
            )}
            {hasPhilosophy && (
              <div className={cn(CARD_BG, "rounded-xl border-l-[3px] border-teal-500 p-8")}>
                <SectionLabel>How we train</SectionLabel>
                <h3 className="mt-2 text-[28px] font-black leading-tight text-white">Our Philosophy</h3>
                <p className={cn("mt-4 text-[16px] leading-[1.6]", MUTED)}>{page.philosophy}</p>
              </div>
            )}
          </div>
        </Section>
      )}

      {/* 4. CREDENTIALS */}
      {page.credentials?.length > 0 && (
        <Section bg={BG_B} label="Trust the resume" title="Credentials & Experience">
          <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
            {page.credentials.map((c, i) => {
              const Icon = credIcons[i % credIcons.length];
              return (
                <div key={c} className={cn(CARD_BG, "flex items-center gap-4 rounded-xl p-5")}>
                  <div className="flex h-11 w-11 shrink-0 items-center justify-center rounded-lg bg-teal-500/15 ring-1 ring-teal-500/30">
                    <Icon className="h-5 w-5 text-teal-400" />
                  </div>
                  <div className="text-sm font-semibold text-white">{c}</div>
                </div>
              );
            })}
          </div>
        </Section>
      )}

      {/* 5. STAFF */}
      {hasStaff && (
        <Section bg={BG_A} label="The team" title="Our Staff">
          <div className="grid grid-cols-2 gap-5 lg:grid-cols-4">
            {page.staff.map((s) => (
              <div
                key={s.id}
                className={cn(
                  CARD_BG,
                  "group overflow-hidden rounded-xl border border-transparent transition duration-300",
                  "hover:-translate-y-1 hover:border-teal-500/40 hover:shadow-[0_15px_40px_-10px_rgba(20,184,166,0.35)]"
                )}
              >
                <div className="aspect-[4/5] w-full overflow-hidden bg-slate-800">
                  <img
                    src={s.photo}
                    alt={s.name}
                    className="h-full w-full object-cover transition duration-500 group-hover:scale-105"
                  />
                </div>
                <div className="p-4">
                  <div className="font-bold text-white">{s.name}</div>
                  <div className={cn("mt-1 text-xs", MUTED)}>{s.role}</div>
                </div>
              </div>
            ))}
          </div>
        </Section>
      )}

      {/* 6. CAMPS */}
      {page.camps?.length > 0 && (
        <Section bg={BG_B} id="camps" label="Train with us" title="Upcoming Camps & Events">
          <div className="grid gap-6 md:grid-cols-2">
            {page.camps.map((c) => (
              <CampCard key={c.id} camp={c} username={page.username} />
            ))}
          </div>
        </Section>
      )}

      {/* 7. TEAMS */}
      {page.teams && page.teams.length > 0 && (
        <Section bg={BG_A} id="teams" label="Join a program" title="Teams & Tryouts">
          <div className="grid gap-6 md:grid-cols-2">
            {page.teams.map((t) => (
              <TeamCard key={t.id} team={t} />
            ))}
          </div>
        </Section>
      )}

      {/* 8. PRIVATES */}
      {page.sessions?.length > 0 && (
        <Section bg={BG_B} id="privates" label="One-on-one" title="Privates & Series">
          <div className="grid gap-5 lg:grid-cols-[1fr_360px]">
            <div className="space-y-3">
              {page.sessions.map((s) => (
                <div key={s.id} className={cn(CARD_BG, "rounded-xl p-6")}>
                  <div className="grid grid-cols-[minmax(0,1fr)_auto] items-start gap-4">
                    <div className="min-w-0">
                      <h3 className="text-lg font-bold text-white">{s.name}</h3>
                      <p className={cn("text-xs", MUTED)}>{s.duration}</p>
                      <p className={cn("mt-2 text-sm", MUTED)}>{s.description}</p>
                    </div>
                    <div className="shrink-0 text-right">
                      <div className="text-2xl font-black text-white">${s.price}</div>
                    </div>
                  </div>
                  <Button className="mt-4 bg-teal-500 text-white hover:bg-teal-400">Book Now</Button>
                </div>
              ))}
            </div>
            <div className={cn(CARD_BG, "rounded-xl p-6")}>
              <div className="flex items-center gap-2 text-sm font-bold text-white">
                <Calendar className="h-4 w-4 text-teal-400" /> Open Slots
              </div>
              <div className="mt-4 space-y-4">
                {page.openSlots.map((d) => (
                  <div key={d.date}>
                    <div className="text-[11px] font-bold uppercase tracking-wider text-teal-400">{d.date}</div>
                    <div className="mt-2 flex flex-wrap gap-1.5">
                      {d.times.map((t) => (
                        <button key={t} className="rounded-md border border-white/10 bg-[#080d18] px-2.5 py-1 text-xs font-semibold text-white hover:border-teal-500 hover:text-teal-400">
                          {t}
                        </button>
                      ))}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </Section>
      )}

      {/* 8. GALLERY */}
      {hasGallery && (
        <Section bg={BG_A} label="From the ice" title="Gallery">
          <div className="columns-2 gap-3 sm:columns-3 lg:columns-4 [&>a]:mb-3">
            {page.gallery.map((p, i) => (
              <a
                key={p.id}
                href={p.url}
                target="_blank"
                rel="noreferrer"
                className="group relative block overflow-hidden rounded-xl bg-slate-800 break-inside-avoid"
              >
                <img
                  src={p.url}
                  alt={p.caption ?? ""}
                  className="w-full transition duration-500 group-hover:scale-105"
                  style={{ aspectRatio: i % 3 === 0 ? "3/4" : i % 3 === 1 ? "1/1" : "4/3" }}
                />
                <div className="absolute inset-0 flex items-center justify-center bg-teal-500/0 opacity-0 transition group-hover:bg-teal-500/30 group-hover:opacity-100">
                  <ZoomIn className="h-8 w-8 text-white drop-shadow-lg" />
                </div>
              </a>
            ))}
          </div>
        </Section>
      )}

      {/* 9. TESTIMONIALS */}
      {hasTestimonials && (
        <Section bg={BG_B} label="Parent reviews" title="What Parents Say">
          {page.reviews.length > 0 && (
            <div className="mb-10 flex flex-col items-center justify-center gap-2 text-center">
              <div className="text-[56px] font-black leading-none text-white">{avgStars.toFixed(1)}</div>
              <Stars value={avgStars} size="lg" />
              <div className={cn("text-sm", MUTED)}>{page.reviews.length} verified reviews</div>
            </div>
          )}
          <div className="grid gap-5 md:grid-cols-3">
            {page.testimonials.map((t) => (
              <div key={t.id} className={cn(CARD_BG, "relative overflow-hidden rounded-xl p-7")}>
                <Quote className="absolute -left-1 -top-2 h-20 w-20 text-teal-500/15" fill="currentColor" />
                <div className="relative">
                  <Stars value={t.stars} />
                  <p className="mt-4 text-[15px] leading-[1.65] text-white/90">"{t.quote}"</p>
                  <div className="mt-5 border-t border-white/5 pt-4">
                    <div className="text-sm font-bold text-white">{t.parent}</div>
                    <div className={cn("text-xs", MUTED)}>{t.childLevel}</div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </Section>
      )}

      {/* 10. CONTACT */}
      <Section bg={BG_A}>
        <div className="mx-auto max-w-2xl text-center">
          <SectionLabel>Get in touch</SectionLabel>
          <h2 className="mt-3 text-[40px] font-black leading-tight text-white sm:text-[52px]">Ready to train?</h2>
          <p className={cn("mx-auto mt-4 max-w-md text-base", MUTED)}>
            Reach out — we usually reply within a day.
          </p>
          <a
            href={`mailto:${page.contactEmail}`}
            className="mt-8 inline-flex items-center gap-2 rounded-md bg-teal-500 px-8 py-4 text-base font-bold text-white shadow-lg transition hover:bg-teal-400"
          >
            <Mail className="h-5 w-5" /> Contact {page.school}
          </a>
          {hasSocial && (
            <div className="mt-8 flex justify-center gap-3">
              {page.social.instagram && <SocialBtn href={page.social.instagram} icon={Instagram} label="Instagram" />}
              {page.social.youtube && <SocialBtn href={page.social.youtube} icon={Youtube} label="YouTube" />}
              {page.social.tiktok && <SocialBtn href={page.social.tiktok} icon={Music2} label="TikTok" />}
              {page.social.facebook && <SocialBtn href={page.social.facebook} icon={Facebook} label="Facebook" />}
            </div>
          )}
        </div>
      </Section>

      <Footer />
    </div>
  );
}

function SocialBtn({ href, icon: Icon, label }: { href: string; icon: typeof Instagram; label: string }) {
  return (
    <a
      href={href} target="_blank" rel="noreferrer" aria-label={label}
      className="inline-flex h-11 w-11 items-center justify-center rounded-full border border-white/15 bg-[#131f35] text-white transition hover:border-teal-500 hover:text-teal-400"
    >
      <Icon className="h-4 w-4" />
    </a>
  );
}

function CampCard({ camp, username }: { camp: BookingCamp; username: string }) {
  const remaining = camp.spotsTotal - camp.spotsTaken;
  const full = remaining <= 0;
  const ebDays = daysUntil(camp.earlyBirdDeadline);
  const displayPrice = ebDays && camp.earlyBirdPrice ? camp.earlyBirdPrice : camp.price;

  const cardInner = (
    <div className="group relative h-[400px] overflow-hidden rounded-2xl border border-white/5 transition hover:border-teal-500/40 hover:shadow-[0_20px_60px_-10px_rgba(20,184,166,0.3)]">
      {/* Background image */}
      <div className="absolute inset-0">
        {camp.banner ? (
          <img src={camp.banner} alt={camp.name} className="h-full w-full object-cover transition duration-700 group-hover:scale-105" />
        ) : (
          <CampPlaceholder />
        )}
      </div>
      {/* Gradient overlay bottom 60% */}
      <div className="absolute inset-0 bg-gradient-to-t from-black via-black/80 via-40% to-transparent" />

      {/* Top-left skill level */}
      <span className="absolute left-4 top-4 rounded-md bg-black/70 px-2.5 py-1 text-[10px] font-bold uppercase tracking-wider text-white backdrop-blur">
        {camp.skillLevel}
      </span>
      {/* Top-right urgency */}
      {!full && remaining <= 5 && (
        <span className="absolute right-4 top-4 rounded-full bg-orange-500 px-3 py-1 text-[10px] font-bold uppercase tracking-wider text-white shadow-lg">
          Only {remaining} left!
        </span>
      )}
      {full && (
        <span className="absolute right-4 top-4 rounded-full bg-red-500 px-3 py-1 text-[10px] font-bold uppercase tracking-wider text-white shadow-lg">
          Full
        </span>
      )}

      {/* Bottom content */}
      <div className="absolute inset-x-0 bottom-0 p-6">
        <h3 className="text-2xl font-black leading-tight text-white">{camp.name}</h3>
        <div className="mt-2 flex flex-wrap gap-x-4 gap-y-1 text-xs text-white/80">
          <span className="inline-flex items-center gap-1"><Calendar className="h-3 w-3" />{camp.dateRange}</span>
          <span className="inline-flex items-center gap-1"><Clock className="h-3 w-3" />{camp.times}</span>
          <span className="inline-flex items-center gap-1">
            <Users className="h-3 w-3" />
            {full ? "Full" : `${remaining} spot${remaining === 1 ? "" : "s"} left`}
          </span>
        </div>
        {ebDays && camp.earlyBirdPrice && (
          <div className="mt-3 inline-block rounded-md bg-emerald-500/20 px-2.5 py-1 text-[11px] font-semibold text-emerald-300 ring-1 ring-emerald-500/40">
            Early bird · ends in {ebDays} day{ebDays === 1 ? "" : "s"}
          </div>
        )}
        <div className="mt-4 flex items-end justify-between gap-3">
          <div>
            <div className="text-3xl font-black text-white">${displayPrice}</div>
            {ebDays && camp.earlyBirdPrice && (
              <div className="text-xs text-white/50 line-through">${camp.price}</div>
            )}
          </div>
          {full ? (
            <Button variant="outline" className="border-white/40 bg-white/10 text-white hover:bg-white/20">Join Waitlist</Button>
          ) : (
            <Button className="bg-teal-500 text-white hover:bg-teal-400 pointer-events-none">
              View & Register <ChevronRight className="h-4 w-4" />
            </Button>
          )}
        </div>
      </div>
    </div>
  );

  if (full) return cardInner;
  return (
    <Link to="/book/$username/camp/$campId" params={{ username, campId: camp.id }} className="block">
      {cardInner}
    </Link>
  );
}


function CampPlaceholder() {
  return (
    <div className="relative flex h-full w-full items-center justify-center bg-gradient-to-br from-slate-900 via-slate-800 to-teal-900/60">
      <div className="absolute inset-0 opacity-30" style={{
        backgroundImage: "radial-gradient(circle at 30% 20%, rgba(20,184,166,0.5), transparent 50%), radial-gradient(circle at 70% 80%, rgba(16,185,129,0.4), transparent 50%)",
      }} />
      <div className="relative text-center">
        <div className="bg-gradient-to-r from-teal-300 to-emerald-300 bg-clip-text text-5xl font-black tracking-tighter text-transparent">
          PXF
        </div>
        <div className="mt-1 text-xs font-bold uppercase tracking-[0.4em] text-white/60">Hockey</div>
      </div>
    </div>
  );
}

function TeamCard({ team }: { team: TeamListing }) {
  const remaining =
    team.spotsTotal != null && team.spotsTaken != null
      ? Math.max(team.spotsTotal - team.spotsTaken, 0)
      : null;
  const full = remaining === 0;

  const kindMeta =
    team.kind === "tryout"
      ? { label: "Tryout", chip: "bg-purple-500 text-white", cta: "Register for Tryout" }
      : team.kind === "open-roster"
      ? { label: "Open Roster", chip: "bg-emerald-500 text-white", cta: "Join Team" }
      : { label: "Coming Soon", chip: "bg-slate-500 text-white", cta: "Notify Me" };

  return (
    <div className="group relative h-[400px] overflow-hidden rounded-2xl border border-white/5 transition hover:border-teal-500/40 hover:shadow-[0_20px_60px_-10px_rgba(20,184,166,0.3)]">
      <div className="absolute inset-0">
        {team.banner ? (
          <img src={team.banner} alt={team.name} className="h-full w-full object-cover transition duration-700 group-hover:scale-105" />
        ) : (
          <CampPlaceholder />
        )}
      </div>
      <div className="absolute inset-0 bg-gradient-to-t from-black via-black/80 via-40% to-transparent" />

      <span className={cn("absolute left-4 top-4 rounded-full px-3 py-1 text-[10px] font-bold uppercase tracking-wider shadow-lg", kindMeta.chip)}>
        {kindMeta.label}
      </span>
      <span className="absolute right-4 top-4 rounded-md bg-black/70 px-2.5 py-1 text-[10px] font-bold uppercase tracking-wider text-white backdrop-blur">
        {team.ageGroup} · {team.division}
      </span>

      <div className="absolute inset-x-0 bottom-0 p-6">
        <h3 className="text-2xl font-black leading-tight text-white">{team.name}</h3>
        <div className="mt-2 flex flex-wrap gap-x-4 gap-y-1 text-xs text-white/80">
          <span className="inline-flex items-center gap-1"><Calendar className="h-3 w-3" />{team.dateLine}</span>
          {team.timeLine && <span className="inline-flex items-center gap-1"><Clock className="h-3 w-3" />{team.timeLine}</span>}
          {team.location && <span className="inline-flex items-center gap-1"><Shield className="h-3 w-3" />{team.location}</span>}
          {team.season && <span className="inline-flex items-center gap-1"><Trophy className="h-3 w-3" />{team.season}</span>}
        </div>
        {team.description && (
          <p className="mt-3 line-clamp-2 text-xs text-white/70">{team.description}</p>
        )}
        <div className="mt-4 flex items-end justify-between gap-3">
          <div>
            {team.fee != null ? (
              <>
                <div className="text-3xl font-black text-white">${team.fee}</div>
                <div className="text-[11px] font-semibold uppercase tracking-wider text-white/50">
                  {team.kind === "tryout" ? "Tryout fee" : "Registration"}
                </div>
              </>
            ) : team.kind === "coming-soon" ? (
              <div className="text-sm font-semibold text-white/80">Get notified when spots open</div>
            ) : (
              <div className="text-sm font-semibold text-white/80">Open Registration</div>
            )}
            {remaining != null && team.kind !== "coming-soon" && (
              <div className={cn(
                "mt-1 text-[11px] font-semibold",
                full ? "text-red-400" : remaining <= 3 ? "text-orange-300" : "text-emerald-300"
              )}>
                {full ? "Full — Waitlist" : `${remaining} spot${remaining === 1 ? "" : "s"} remaining`}
              </div>
            )}
          </div>
          {team.kind === "coming-soon" ? (
            <Button variant="outline" className="border-white/40 bg-white/10 text-white hover:bg-white/20">
              <Mail className="h-4 w-4" /> {kindMeta.cta}
            </Button>
          ) : full ? (
            <Button variant="outline" className="border-white/40 bg-white/10 text-white hover:bg-white/20">Join Waitlist</Button>
          ) : (
            <Button className="bg-teal-500 text-white hover:bg-teal-400">
              {kindMeta.cta} <ChevronRight className="h-4 w-4" />
            </Button>
          )}
        </div>
      </div>
    </div>
  );
}

export function Stars({ value, size = "md" }: { value: number; size?: "md" | "lg" }) {
  const cls = size === "lg" ? "h-5 w-5" : "h-4 w-4";
  return (
    <div className="flex items-center gap-0.5">
      {[1, 2, 3, 4, 5].map((i) => (
        <Star key={i} className={cn(cls, i <= Math.round(value) ? "fill-amber-400 text-amber-400" : "text-white/20")} />
      ))}
    </div>
  );
}

export function Footer() {
  return (
    <footer className="border-t border-white/5 bg-[#050810] px-6 py-6">
      <div className="mx-auto flex max-w-[1200px] items-center justify-between">
        <Link to="/" className="inline-flex items-center gap-2 text-xs text-white/60 hover:text-white">
          Powered by
          <span className="bg-gradient-to-r from-teal-400 to-emerald-400 bg-clip-text text-sm font-black tracking-tight text-transparent">
            PXF HOCKEY
          </span>
        </Link>
        <div className="text-[11px] text-white/40">© {new Date().getFullYear()}</div>
      </div>
    </footer>
  );
}
