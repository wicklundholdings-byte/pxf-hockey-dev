import { createFileRoute } from "@tanstack/react-router";
import { AssociationRegistrations } from "@/components/association-registrations";

export const Route = createFileRoute("/registrations")({
  head: () => ({
    meta: [
      { title: "Registrations · PXF Hockey" },
      { name: "description", content: "Registrations management for PXF Hockey Association Admin portal." },
    ],
  }),
  component: AssociationRegistrations,
});
