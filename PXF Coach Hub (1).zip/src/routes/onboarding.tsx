import { createFileRoute, Link } from "@tanstack/react-router";
import { useState } from "react";
import { ArrowRight, CheckCircle2 } from "lucide-react";
import { PricingPlans } from "@/components/pricing-plans";
import { cn } from "@/lib/utils";

export const Route = createFileRoute("/onboarding")({
  head: () => ({
    meta: [
      { title: "Choose your plan · PXF Hockey" },
      { name: "description", content: "Select the PXF Hockey plan that fits your coaching business." },
      { name: "robots", content: "noindex" },
    ],
  }),
  component: OnboardingPricingPage,
});

const steps = ["Create account", "Choose plan", "Set up profile"];

function OnboardingPricingPage() {
  const [selectedPlan, setSelectedPlan] = useState<string | null>("elite");

  return (
    <div className="min-h-screen bg-black text-white">
      {/* Top bar */}
      <header className="sticky top-0 z-50 border-b border-white/10 bg-black/80 backdrop-blur-md">
        <div className="mx-auto flex max-w-7xl items-center justify-between px-4 py-3 sm:px-6 lg:px-8">
          <Link to="/" className="flex items-center gap-2">
            <div className="flex h-8 w-8 items-center justify-center rounded-md bg-gradient-to-br from-emerald-400 to-teal-500 text-xs font-black text-white">
              PXF
            </div>
            <span className="text-sm font-black tracking-widest text-white">PXF HOCKEY</span>
          </Link>
          <a href="/dashboard" className="text-sm font-medium text-white/70 hover:text-white">
            Already have an account? Sign in
          </a>
        </div>
      </header>

      <main className="mx-auto max-w-6xl px-4 py-12 sm:px-6 lg:px-8">
        {/* Stepper */}
        <div className="mb-10">
          <div className="text-center text-xs font-bold uppercase tracking-[0.2em] text-teal-400">
            Step 2 of 3
          </div>
          <div className="mt-2 text-center text-2xl font-black text-white md:text-3xl">
            Choose your plan
          </div>
          <div className="mt-6 flex items-center justify-center gap-2">
            {steps.map((s, i) => {
              const active = i === 1;
              const completed = i < 1;
              return (
                <div key={s} className="flex items-center gap-2">
                  <div
                    className={cn(
                      "flex h-8 w-8 items-center justify-center rounded-full text-xs font-bold",
                      completed
                        ? "bg-emerald-500 text-white"
                        : active
                        ? "bg-gradient-to-r from-emerald-500 to-teal-500 text-white"
                        : "border border-white/10 bg-white/5 text-white/40"
                    )}
                  >
                    {completed ? <CheckCircle2 className="h-4 w-4" /> : i + 1}
                  </div>
                  <span
                    className={cn(
                      "hidden text-xs font-semibold sm:inline",
                      completed || active ? "text-white" : "text-white/40"
                    )}
                  >
                    {s}
                  </span>
                  {i < steps.length - 1 && (
                    <div className="mx-1 h-px w-6 bg-white/10 sm:mx-2 sm:w-10" />
                  )}
                </div>
              );
            })}
          </div>
        </div>

        <PricingPlans className="py-6" />

        {/* Selection helper + continue */}
        <div className="mt-10 flex flex-col items-center justify-center gap-4">
          <div className="text-sm text-white/60">
            {selectedPlan ? (
              <span>
                Selected: <span className="font-semibold text-teal-400">{plansMeta[selectedPlan].name}</span>
              </span>
            ) : (
              "Select a plan to continue"
            )}
          </div>
          <a
            href="/dashboard"
            className="inline-flex items-center justify-center gap-2 rounded-md bg-gradient-to-r from-emerald-500 to-teal-500 px-6 py-3 text-sm font-bold text-white shadow-lg transition hover:opacity-95"
          >
            Continue with {selectedPlan ? plansMeta[selectedPlan].name : "selected plan"}
            <ArrowRight className="h-4 w-4" />
          </a>
        </div>
      </main>

      <footer className="border-t border-white/10 bg-black py-6 text-center text-xs text-white/40">
        © 2026 PXF Hockey · 14-day free trial · No credit card required
      </footer>
    </div>
  );
}

const plansMeta: Record<string, { name: string }> = {
  team: { name: "Team Coach" },
  elite: { name: "Elite Coach" },
};
