import { createFileRoute, Link } from "@tanstack/react-router";
import { useEffect, useRef, useState } from "react";
import { toast } from "sonner";
import {
  Copy, Check, ExternalLink, Share2, Upload, Image as ImageIcon, Video, X, Plus,
  Instagram, Youtube, Facebook, Music2, Star, Quote, PlayCircle,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { coachPages, type TeamListing, type TeamListingKind } from "@/lib/booking-data";
import { loadCoachOverrides, saveCoachOverrides, parseVideoSource } from "@/lib/booking-storage";
import { cn } from "@/lib/utils";

export const Route = createFileRoute("/booking-page")({
  head: () => ({
    meta: [
      { title: "My Booking Page · PXF Hockey" },
      { name: "description", content: "Your public-facing booking page." },
    ],
  }),
  component: BookingPageSettings,
});

const CERT_OPTIONS = [
  "Hockey Canada Level 1", "Hockey Canada Level 2", "Hockey Canada Level 3", "Hockey Canada Level 4",
  "NCCP Certified", "USA Hockey Level 1-5", "Former Pro", "Former CHL", "Former NCAA", "Former AHL",
];

function BookingPageSettings() {
  const seed = coachPages["coach-maddox"];
  const username = seed.username;
  const url = `${typeof window !== "undefined" ? window.location.origin : ""}/book/${username}`;
  const [copied, setCopied] = useState(false);

  // Local editor state
  const [hero, setHero] = useState({
    banner: seed.banner, avatar: seed.avatar, name: seed.name, school: seed.school, tagline: seed.tagline,
  });
  const [video, setVideo] = useState(seed.video ?? "");
  /** When user uploaded a file in this session, we store the dataUrl separately so we can persist it. */
  const [videoFileName, setVideoFileName] = useState<string | null>(null);
  const [about, setAbout] = useState(seed.bio);
  const [philosophy, setPhilosophy] = useState(seed.philosophy);
  const [playing, setPlaying] = useState(seed.playingBackground);
  const [years, setYears] = useState(seed.yearsCoaching);
  const [creds, setCreds] = useState<string[]>(seed.credentials);
  const [gallery, setGallery] = useState(seed.gallery);
  const [testimonials, setTestimonials] = useState(seed.testimonials);
  const [autoTestimonials, setAutoTestimonials] = useState(false);
  const [social, setSocial] = useState(seed.social);
  const [teams, setTeams] = useState<TeamListing[]>(seed.teams);
  const [dirty, setDirty] = useState(false);
  const [saving, setSaving] = useState(false);

  // Load overrides from localStorage on mount
  useEffect(() => {
    const o = loadCoachOverrides(username);
    if (!o) return;
    if (o.banner || o.avatar || o.name || o.school || o.tagline) {
      setHero({
        banner: o.banner ?? seed.banner,
        avatar: o.avatar ?? seed.avatar,
        name: o.name ?? seed.name,
        school: o.school ?? seed.school,
        tagline: o.tagline ?? seed.tagline,
      });
    }
    if (o.video !== undefined) setVideo(o.video);
    if (o.bio !== undefined) setAbout(o.bio);
    if (o.philosophy !== undefined) setPhilosophy(o.philosophy);
    if (o.playingBackground !== undefined) setPlaying(o.playingBackground);
    if (o.yearsCoaching !== undefined) setYears(o.yearsCoaching);
    if (o.credentials) setCreds(o.credentials);
    if (o.gallery) setGallery(o.gallery);
    if (o.testimonials) setTestimonials(o.testimonials);
    if (o.social) setSocial({ ...seed.social, ...o.social });
    if (o.teams) setTeams(o.teams);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  // Mark dirty whenever any field changes (after initial mount)
  const firstRender = useRef(true);
  useEffect(() => {
    if (firstRender.current) { firstRender.current = false; return; }
    setDirty(true);
  }, [hero, video, about, philosophy, playing, years, creds, gallery, testimonials, social, teams]);

  const copy = async () => {
    try {
      await navigator.clipboard.writeText(url);
      setCopied(true);
      setTimeout(() => setCopied(false), 1800);
    } catch {}
  };

  const toggleCred = (c: string) =>
    setCreds((prev) => (prev.includes(c) ? prev.filter((x) => x !== c) : [...prev, c]));

  const handleVideoFile = (file: File) => {
    if (!file.type.startsWith("video/")) {
      toast.error("Please choose a video file.");
      return;
    }
    const sizeMB = file.size / (1024 * 1024);
    if (sizeMB > 8) {
      toast.error(`Video is ${sizeMB.toFixed(1)} MB. Browser storage caps around 8 MB — please upload a shorter clip or paste a YouTube/Vimeo URL instead.`);
      return;
    }
    const reader = new FileReader();
    reader.onload = () => {
      setVideo(String(reader.result));
      setVideoFileName(file.name);
      toast.success(`Loaded ${file.name}. Click Save Changes to publish.`);
    };
    reader.onerror = () => toast.error("Couldn't read the file.");
    reader.readAsDataURL(file);
  };

  const handleSave = async () => {
    setSaving(true);
    const payload = {
      banner: hero.banner, avatar: hero.avatar, name: hero.name, school: hero.school, tagline: hero.tagline,
      video,
      bio: about, philosophy, playingBackground: playing, yearsCoaching: years,
      credentials: creds, gallery, testimonials, social, teams,
    };
    const res = saveCoachOverrides(username, payload);
    setSaving(false);
    if (res.ok) {
      setDirty(false);
      toast.success("Changes saved. Refresh your public page to see them live.");
    } else {
      toast.error(res.error ?? "Save failed.");
    }
  };

  const videoSrc = parseVideoSource(video);

  return (
    <div className="mx-auto max-w-4xl space-y-6 pb-24">
      {/* Top: URL + share */}
      <div>
        <h1 className="text-2xl font-bold">My Booking Page</h1>
        <p className="mt-1 text-sm text-muted-foreground">
          Edit your public booking page. Empty sections are hidden automatically.
        </p>
      </div>

      <div className="rounded-2xl border border-border bg-card p-5">
        <div className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">Your public URL</div>
        <div className="mt-2 flex flex-wrap items-center gap-2">
          <code className="min-w-0 flex-1 truncate rounded-md bg-muted px-3 py-2 text-sm font-mono">{url}</code>
          <Button variant="outline" onClick={copy} className="shrink-0">
            {copied ? <><Check className="h-4 w-4 text-emerald-500" /> Copied</> : <><Copy className="h-4 w-4" /> Copy Link</>}
          </Button>
          <Link to="/book/$username" params={{ username }} target="_blank">
            <Button className="shrink-0 bg-gradient-to-r from-teal-500 to-emerald-500 text-white hover:opacity-90">
              <ExternalLink className="h-4 w-4" /> Preview
            </Button>
          </Link>
        </div>
        <div className="mt-4 grid grid-cols-3 gap-2">
          <ShareBtn label="Instagram" />
          <ShareBtn label="Email" />
          <ShareBtn label="Text" />
        </div>
      </div>

      {/* HERO */}
      <Section title="Hero" subtitle="The top of your booking page — banner, logo, name, tagline.">
        <UploadTile label="Banner image (16:9)" preview={hero.banner} onClear={() => setHero({ ...hero, banner: "" })} aspect="aspect-[16/9]" />
        <div className="grid gap-4 sm:grid-cols-[140px_1fr]">
          <UploadTile label="Logo / Avatar" preview={hero.avatar} onClear={() => setHero({ ...hero, avatar: "" })} aspect="aspect-square" compact />
          <div className="space-y-3">
            <Field label="Display name" value={hero.name} onChange={(v) => setHero({ ...hero, name: v })} />
            <Field label="School name" value={hero.school} onChange={(v) => setHero({ ...hero, school: v })} />
            <Field label="One-line tagline" value={hero.tagline} onChange={(v) => setHero({ ...hero, tagline: v })} />
          </div>
        </div>
      </Section>

      {/* HIGHLIGHT VIDEO */}
      <Section title="Highlight Video" subtitle="This plays at the top of your booking page." icon={Video}>
        <Field
          label="YouTube, Vimeo, or video file URL"
          value={video.startsWith("data:") ? `[Uploaded] ${videoFileName ?? "video file"}` : video}
          onChange={(v) => { setVideo(v); setVideoFileName(null); }}
          placeholder="https://youtube.com/watch?v=..."
        />
        <div className="flex flex-wrap items-center gap-3">
          <VideoFilePicker onPick={handleVideoFile} />
          {video && (
            <button
              onClick={() => { setVideo(""); setVideoFileName(null); }}
              className="text-xs font-semibold text-muted-foreground hover:text-foreground"
            >
              Remove video
            </button>
          )}
        </div>
        {videoSrc && (
          <div className="overflow-hidden rounded-xl border border-border bg-black aspect-video">
            {videoSrc.kind === "embed" ? (
              <iframe
                src={videoSrc.src}
                title="Video preview"
                allow="autoplay; encrypted-media; picture-in-picture"
                allowFullScreen
                className="h-full w-full"
              />
            ) : (
              <video src={videoSrc.src} controls muted className="h-full w-full" />
            )}
          </div>
        )}
        <p className="text-[11px] text-muted-foreground">
          Tip: For large files, upload to YouTube or Vimeo and paste the link — browser storage is limited to ~8 MB for direct uploads.
        </p>
      </Section>

      {/* ABOUT */}
      <Section title="About Us" subtitle="2–4 sentences about your school.">
        <RichText value={about} onChange={setAbout} rows={4} max={400} />
      </Section>

      {/* PHILOSOPHY */}
      <Section title="Our Philosophy" subtitle="What makes your training approach different.">
        <RichText value={philosophy} onChange={setPhilosophy} rows={4} max={400} />
      </Section>

      {/* COACHING EXPERIENCE */}
      <Section title="Coaching Experience" subtitle="Your playing background and credentials.">
        <RichText value={playing} onChange={setPlaying} rows={3} max={300} label="Playing background" />
        <div>
          <label className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">Years coaching</label>
          <input
            type="number"
            min={0}
            value={years}
            onChange={(e) => setYears(Number(e.target.value))}
            className="mt-1 w-32 rounded-md border border-input bg-background px-3 py-2 text-sm"
          />
        </div>
        <div>
          <label className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">Certifications</label>
          <div className="mt-2 flex flex-wrap gap-2">
            {CERT_OPTIONS.map((c) => {
              const active = creds.includes(c);
              return (
                <button
                  key={c}
                  type="button"
                  onClick={() => toggleCred(c)}
                  className={cn(
                    "rounded-full border px-3 py-1.5 text-xs font-semibold transition",
                    active
                      ? "border-emerald-500 bg-emerald-500/10 text-emerald-400"
                      : "border-border bg-background text-muted-foreground hover:text-foreground"
                  )}
                >
                  {active && "✓ "}{c}
                </button>
              );
            })}
          </div>
        </div>
      </Section>

      {/* GALLERY */}
      <Section title="Gallery" subtitle={`Upload 4–12 photos. Currently ${gallery.length}.`}>
        <div className="grid grid-cols-3 gap-3 sm:grid-cols-4">
          {gallery.map((p) => (
            <div key={p.id} className="group relative aspect-square overflow-hidden rounded-lg border border-border">
              <img src={p.url} alt="" className="h-full w-full object-cover" />
              <button
                onClick={() => setGallery(gallery.filter((g) => g.id !== p.id))}
                className="absolute right-1.5 top-1.5 rounded-full bg-black/70 p-1 opacity-0 transition group-hover:opacity-100"
              >
                <X className="h-3 w-3 text-white" />
              </button>
            </div>
          ))}
          {gallery.length < 12 && (
            <button className="flex aspect-square items-center justify-center rounded-lg border-2 border-dashed border-border text-muted-foreground hover:border-emerald-500 hover:text-emerald-500">
              <div className="text-center">
                <Plus className="mx-auto h-5 w-5" />
                <div className="mt-1 text-[10px] font-semibold uppercase">Add photo</div>
              </div>
            </button>
          )}
        </div>
        {gallery.length < 4 && (
          <p className="text-xs text-orange-400">Add at least {4 - gallery.length} more photo{gallery.length === 3 ? "" : "s"} to publish your gallery.</p>
        )}
      </Section>

      {/* TESTIMONIALS */}
      <Section title="Testimonials" subtitle="Auto-pull top reviews, or write your own.">
        <label className="flex items-center gap-3 rounded-lg border border-border bg-background px-3 py-2.5">
          <input
            type="checkbox"
            checked={autoTestimonials}
            onChange={(e) => setAutoTestimonials(e.target.checked)}
            className="h-4 w-4 accent-emerald-500"
          />
          <span className="text-sm">Auto-pull top 3 parent reviews</span>
        </label>
        {!autoTestimonials && (
          <div className="space-y-3">
            {testimonials.map((t, i) => (
              <div key={t.id} className="rounded-xl border border-border bg-background p-4">
                <div className="grid grid-cols-[1fr_auto] items-start gap-3">
                  <Quote className="h-4 w-4 text-emerald-500" />
                  <button onClick={() => setTestimonials(testimonials.filter((x) => x.id !== t.id))}>
                    <X className="h-4 w-4 text-muted-foreground hover:text-foreground" />
                  </button>
                </div>
                <textarea
                  value={t.quote}
                  onChange={(e) => {
                    const next = [...testimonials];
                    next[i] = { ...t, quote: e.target.value };
                    setTestimonials(next);
                  }}
                  rows={2}
                  className="mt-2 w-full resize-none rounded-md border border-input bg-background px-3 py-2 text-sm"
                  placeholder="Quote..."
                />
                <div className="mt-2 grid gap-2 sm:grid-cols-2">
                  <input
                    value={t.parent}
                    onChange={(e) => {
                      const next = [...testimonials];
                      next[i] = { ...t, parent: e.target.value };
                      setTestimonials(next);
                    }}
                    placeholder="Parent name"
                    className="rounded-md border border-input bg-background px-3 py-2 text-sm"
                  />
                  <input
                    value={t.childLevel}
                    onChange={(e) => {
                      const next = [...testimonials];
                      next[i] = { ...t, childLevel: e.target.value };
                      setTestimonials(next);
                    }}
                    placeholder="Child age / level (e.g. U13 Rep)"
                    className="rounded-md border border-input bg-background px-3 py-2 text-sm"
                  />
                </div>
              </div>
            ))}
            {testimonials.length < 3 && (
              <button
                onClick={() =>
                  setTestimonials([
                    ...testimonials,
                    { id: `new-${Date.now()}`, quote: "", parent: "", childLevel: "", stars: 5 },
                  ])
                }
                className="flex w-full items-center justify-center gap-2 rounded-lg border-2 border-dashed border-border py-3 text-sm font-semibold text-muted-foreground hover:border-emerald-500 hover:text-emerald-500"
              >
                <Plus className="h-4 w-4" /> Add testimonial
              </button>
            )}
          </div>
        )}
      </Section>

      {/* TEAMS */}
      <Section title="Teams" subtitle="Tryouts, open rosters, and upcoming teams shown on your booking page.">
        <div className="space-y-3">
          {teams.map((t, i) => (
            <TeamEditor
              key={t.id}
              team={t}
              onChange={(next) => {
                const arr = [...teams];
                arr[i] = next;
                setTeams(arr);
              }}
              onRemove={() => setTeams(teams.filter((x) => x.id !== t.id))}
            />
          ))}
          <button
            onClick={() =>
              setTeams([
                ...teams,
                {
                  id: `team-${Date.now()}`,
                  kind: "tryout",
                  name: "",
                  ageGroup: "U13",
                  division: "AA",
                  season: "",
                  dateLine: "",
                },
              ])
            }
            className="flex w-full items-center justify-center gap-2 rounded-lg border-2 border-dashed border-border py-3 text-sm font-semibold text-muted-foreground hover:border-emerald-500 hover:text-emerald-500"
          >
            <Plus className="h-4 w-4" /> Add team listing
          </button>
        </div>
      </Section>

      {/* SOCIAL */}
      <Section title="Social Links" subtitle="Shown in the Contact section of your page.">
        <SocialField icon={Instagram} label="Instagram" value={social.instagram ?? ""} onChange={(v) => setSocial({ ...social, instagram: v })} />
        <SocialField icon={Youtube} label="YouTube" value={social.youtube ?? ""} onChange={(v) => setSocial({ ...social, youtube: v })} />
        <SocialField icon={Music2} label="TikTok" value={social.tiktok ?? ""} onChange={(v) => setSocial({ ...social, tiktok: v })} />
        <SocialField icon={Facebook} label="Facebook" value={social.facebook ?? ""} onChange={(v) => setSocial({ ...social, facebook: v })} />
      </Section>

      {/* Save bar */}
      <div className="sticky bottom-4 z-20 flex items-center justify-between gap-3 rounded-2xl border border-border bg-card/95 px-4 py-3 shadow-2xl backdrop-blur">
        <div className="text-xs text-muted-foreground">
          {dirty ? "You have unsaved changes." : "All changes saved."}
        </div>
        <div className="flex items-center gap-2">
          <Link to="/book/$username" params={{ username }} target="_blank">
            <Button variant="outline" size="sm">
              <PlayCircle className="h-4 w-4" /> Preview
            </Button>
          </Link>
          <Button
            onClick={handleSave}
            disabled={saving}
            className="bg-gradient-to-r from-teal-500 to-emerald-500 text-white hover:opacity-90 disabled:opacity-60"
          >
            <Check className="h-4 w-4" /> {saving ? "Saving…" : "Save Changes"}
          </Button>
        </div>
      </div>
    </div>
  );
}

function VideoFilePicker({ onPick }: { onPick: (file: File) => void }) {
  const ref = useRef<HTMLInputElement>(null);
  return (
    <>
      <input
        ref={ref}
        type="file"
        accept="video/*"
        className="hidden"
        onChange={(e) => {
          const file = e.target.files?.[0];
          if (file) onPick(file);
          e.target.value = "";
        }}
      />
      <button
        type="button"
        onClick={() => ref.current?.click()}
        className="inline-flex items-center gap-2 rounded-md border border-dashed border-border bg-background px-3 py-2 text-sm font-semibold hover:border-emerald-500 hover:text-emerald-500"
      >
        <Upload className="h-4 w-4" /> Upload video file
      </button>
    </>
  );
}

function Section({
  title, subtitle, children, icon: Icon,
}: {
  title: string; subtitle?: string; children: React.ReactNode; icon?: typeof Star;
}) {
  return (
    <section className="rounded-2xl border border-border bg-card p-6">
      <div className="flex items-start gap-3">
        {Icon && <Icon className="mt-0.5 h-4 w-4 text-emerald-500" />}
        <div className="min-w-0 flex-1">
          <h2 className="text-base font-bold">{title}</h2>
          {subtitle && <p className="mt-0.5 text-xs text-muted-foreground">{subtitle}</p>}
        </div>
      </div>
      <div className="mt-5 space-y-4">{children}</div>
    </section>
  );
}

function Field({
  label, value, onChange, placeholder,
}: {
  label: string; value: string; onChange: (v: string) => void; placeholder?: string;
}) {
  return (
    <div>
      <label className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">{label}</label>
      <input
        value={value}
        onChange={(e) => onChange(e.target.value)}
        placeholder={placeholder}
        className="mt-1 w-full rounded-md border border-input bg-background px-3 py-2 text-sm"
      />
    </div>
  );
}

function RichText({
  label, value, onChange, rows = 4, max,
}: {
  label?: string; value: string; onChange: (v: string) => void; rows?: number; max?: number;
}) {
  return (
    <div>
      {label && <label className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">{label}</label>}
      <textarea
        value={value}
        maxLength={max}
        onChange={(e) => onChange(e.target.value)}
        rows={rows}
        className={cn("w-full resize-none rounded-md border border-input bg-background px-3 py-2 text-sm leading-relaxed", label && "mt-1")}
      />
      {max && (
        <div className="mt-1 text-right text-[10px] text-muted-foreground">
          {value.length} / {max}
        </div>
      )}
    </div>
  );
}

function UploadTile({
  label, preview, onClear, aspect = "aspect-video", compact,
}: {
  label: string; preview?: string; onClear: () => void; aspect?: string; compact?: boolean;
}) {
  return (
    <div>
      <label className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">{label}</label>
      <div className={cn("relative mt-1 overflow-hidden rounded-xl border-2 border-dashed border-border bg-muted/40", aspect)}>
        {preview ? (
          <>
            <img src={preview} alt="" className="h-full w-full object-cover" />
            <button
              onClick={onClear}
              className="absolute right-2 top-2 rounded-full bg-black/70 p-1 text-white hover:bg-black"
              aria-label="Remove"
            >
              <X className="h-3.5 w-3.5" />
            </button>
          </>
        ) : (
          <button className="flex h-full w-full flex-col items-center justify-center gap-2 text-muted-foreground hover:text-emerald-500">
            <ImageIcon className={compact ? "h-5 w-5" : "h-7 w-7"} />
            <span className="text-xs font-semibold">{compact ? "Upload" : "Click to upload"}</span>
          </button>
        )}
      </div>
    </div>
  );
}

function SocialField({
  icon: Icon, label, value, onChange,
}: {
  icon: typeof Instagram; label: string; value: string; onChange: (v: string) => void;
}) {
  return (
    <div className="flex items-center gap-3">
      <div className="grid h-9 w-9 shrink-0 place-items-center rounded-md bg-muted">
        <Icon className="h-4 w-4" />
      </div>
      <input
        value={value}
        onChange={(e) => onChange(e.target.value)}
        placeholder={`${label} URL`}
        className="min-w-0 flex-1 rounded-md border border-input bg-background px-3 py-2 text-sm"
      />
    </div>
  );
}

function ShareBtn({ label }: { label: string }) {
  return (
    <button className="flex items-center justify-center gap-2 rounded-lg border border-border bg-background px-3 py-2 text-sm font-semibold hover:border-emerald-500/40">
      <Share2 className="h-4 w-4" /> {label}
    </button>
  );
}

function TeamEditor({
  team, onChange, onRemove,
}: {
  team: TeamListing;
  onChange: (next: TeamListing) => void;
  onRemove: () => void;
}) {
  const upd = <K extends keyof TeamListing>(k: K, v: TeamListing[K]) => onChange({ ...team, [k]: v });
  const kindOptions: { v: TeamListingKind; label: string; cls: string }[] = [
    { v: "tryout", label: "Tryout", cls: "border-purple-500 bg-purple-500/10 text-purple-300" },
    { v: "open-roster", label: "Open Roster", cls: "border-emerald-500 bg-emerald-500/10 text-emerald-300" },
    { v: "coming-soon", label: "Coming Soon", cls: "border-slate-400 bg-slate-500/10 text-slate-300" },
  ];

  return (
    <div className="rounded-xl border border-border bg-background p-4">
      <div className="flex items-center justify-between gap-3">
        <div className="flex flex-wrap gap-1.5">
          {kindOptions.map((k) => {
            const active = team.kind === k.v;
            return (
              <button
                key={k.v}
                onClick={() => upd("kind", k.v)}
                className={cn(
                  "rounded-full border px-3 py-1 text-[11px] font-bold uppercase tracking-wider transition",
                  active ? k.cls : "border-border text-muted-foreground hover:text-foreground"
                )}
              >
                {k.label}
              </button>
            );
          })}
        </div>
        <button onClick={onRemove} aria-label="Remove team">
          <X className="h-4 w-4 text-muted-foreground hover:text-foreground" />
        </button>
      </div>

      <div className="mt-3 grid gap-2 sm:grid-cols-2">
        <input value={team.name} onChange={(e) => upd("name", e.target.value)} placeholder="Team name (e.g. Maddox U13 AA)" className="rounded-md border border-input bg-background px-3 py-2 text-sm sm:col-span-2" />
        <input value={team.ageGroup} onChange={(e) => upd("ageGroup", e.target.value)} placeholder="Age group (U11, U13, U15…)" className="rounded-md border border-input bg-background px-3 py-2 text-sm" />
        <input value={team.division} onChange={(e) => upd("division", e.target.value)} placeholder="Division (AA, AAA, Select…)" className="rounded-md border border-input bg-background px-3 py-2 text-sm" />
        <input value={team.season ?? ""} onChange={(e) => upd("season", e.target.value)} placeholder="Season (e.g. Spring 2026)" className="rounded-md border border-input bg-background px-3 py-2 text-sm sm:col-span-2" />
        <input
          value={team.dateLine}
          onChange={(e) => upd("dateLine", e.target.value)}
          placeholder={team.kind === "coming-soon" ? "Registration opens ~ Sep 2026" : team.kind === "tryout" ? "Tryout dates (e.g. Aug 22 – Aug 24)" : "Season dates (e.g. Apr 5 – Jun 14)"}
          className="rounded-md border border-input bg-background px-3 py-2 text-sm sm:col-span-2"
        />
        {team.kind !== "coming-soon" && (
          <>
            <input value={team.timeLine ?? ""} onChange={(e) => upd("timeLine", e.target.value)} placeholder="Times (e.g. 6:00 PM – 8:00 PM)" className="rounded-md border border-input bg-background px-3 py-2 text-sm" />
            <input value={team.location ?? ""} onChange={(e) => upd("location", e.target.value)} placeholder="Rink / location" className="rounded-md border border-input bg-background px-3 py-2 text-sm" />
            <input type="number" min={0} value={team.fee ?? ""} onChange={(e) => upd("fee", e.target.value ? Number(e.target.value) : undefined)} placeholder="Fee ($)" className="rounded-md border border-input bg-background px-3 py-2 text-sm" />
            <div className="grid grid-cols-2 gap-2">
              <input type="number" min={0} value={team.spotsTaken ?? ""} onChange={(e) => upd("spotsTaken", e.target.value ? Number(e.target.value) : undefined)} placeholder="Registered" className="rounded-md border border-input bg-background px-3 py-2 text-sm" />
              <input type="number" min={0} value={team.spotsTotal ?? ""} onChange={(e) => upd("spotsTotal", e.target.value ? Number(e.target.value) : undefined)} placeholder="Total spots" className="rounded-md border border-input bg-background px-3 py-2 text-sm" />
            </div>
          </>
        )}
        <input value={team.banner ?? ""} onChange={(e) => upd("banner", e.target.value)} placeholder="Banner image URL (optional)" className="rounded-md border border-input bg-background px-3 py-2 text-sm sm:col-span-2" />
        <textarea value={team.description ?? ""} onChange={(e) => upd("description", e.target.value)} rows={2} placeholder="Short description (optional)" className="resize-none rounded-md border border-input bg-background px-3 py-2 text-sm sm:col-span-2" />
      </div>
    </div>
  );
}
