import { createFileRoute } from "@tanstack/react-router";
import { useAccount } from "@/components/account-provider";
import { AssociationSafety } from "@/components/association-safety";

export const Route = createFileRoute("/safety")({
  head: () => ({
    meta: [
      { title: "Safety & Incidents · PXF Hockey" },
      { name: "description", content: "Incidents, concussion protocol, and confidential Safe Sport reporting for PXF Hockey associations." },
    ],
  }),
  component: Page,
});

function Page() {
  const { account } = useAccount();
  if (account.role === "association-admin") return <AssociationSafety />;
  return (
    <div className="rounded-lg border border-dashed border-border p-12 text-center">
      <h2 className="text-xl font-semibold">Safety & Incidents</h2>
      <p className="mt-2 text-sm text-muted-foreground">Available in the Association Admin view.</p>
    </div>
  );
}
