import { createFileRoute } from "@tanstack/react-router";
import { AssociationFinancials } from "@/components/association-financials";

export const Route = createFileRoute("/financials")({
  head: () => ({
    meta: [
      { title: "Financials · PXF Hockey" },
      { name: "description", content: "Revenue and expense visibility for PXF Hockey associations." },
    ],
  }),
  component: AssociationFinancials,
});
