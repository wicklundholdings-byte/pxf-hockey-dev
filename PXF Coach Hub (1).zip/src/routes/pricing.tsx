import { createFileRoute, Link } from "@tanstack/react-router";
import { Menu, X } from "lucide-react";
import { useState } from "react";
import { PricingPlans } from "@/components/pricing-plans";
import { Instagram, Twitter, Facebook, Youtube, Music2 } from "lucide-react";

export const Route = createFileRoute("/pricing")({
  head: () => ({
    meta: [
      { title: "Pricing · PXF Hockey" },
      { name: "description", content: "Choose the PXF Hockey plan that fits your coaching business. Team Coach or Elite Coach." },
      { property: "og:title", content: "Pricing · PXF Hockey" },
      { property: "og:description", content: "Simple pricing for hockey coaches. 14-day free trial." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: PricingPage,
});

function Nav() {
  const [open, setOpen] = useState(false);
  const links = [
    { label: "Features", href: "/#features" },
    { label: "Pricing", href: "/pricing" },
    { label: "About", href: "/#about" },
    { label: "Blog", href: "/#blog" },
  ];
  return (
    <header className="sticky top-0 z-50 border-b border-white/10 bg-black/80 backdrop-blur-md">
      <div className="mx-auto flex max-w-7xl items-center justify-between px-4 py-3 sm:px-6 lg:px-8">
        <Link to="/" className="flex items-center gap-2">
          <div className="flex h-8 w-8 items-center justify-center rounded-md bg-gradient-to-br from-emerald-400 to-teal-500 text-xs font-black text-white">
            PXF
          </div>
          <span className="text-sm font-black tracking-widest text-white">PXF HOCKEY</span>
        </Link>
        <nav className="hidden items-center gap-8 md:flex">
          {links.map((l) =>
            l.href.startsWith("/") && !l.href.startsWith("/#") ? (
              <Link
                key={l.label}
                to={l.href as never}
                className="text-sm font-medium text-white/70 transition hover:text-white"
              >
                {l.label}
              </Link>
            ) : (
              <a
                key={l.label}
                href={l.href}
                className="text-sm font-medium text-white/70 transition hover:text-white"
              >
                {l.label}
              </a>
            )
          )}
        </nav>
        <div className="hidden items-center gap-2 md:flex">
          <a
            href="/dashboard"
            className="inline-flex items-center justify-center gap-2 rounded-md border border-white/15 bg-white/[0.03] px-4 py-2.5 text-sm font-semibold text-white transition hover:border-teal-400/40 hover:bg-white/[0.06]"
          >
            Log In
          </a>
          <a
            href="/dashboard"
            className="inline-flex items-center justify-center gap-2 rounded-md bg-gradient-to-r from-emerald-500 to-teal-500 px-4 py-2.5 text-sm font-semibold text-white shadow-lg transition hover:opacity-95"
          >
            Start Free Trial
          </a>
        </div>
        <button
          className="rounded-md border border-white/10 p-2 text-white md:hidden"
          onClick={() => setOpen((v) => !v)}
          aria-label="Toggle menu"
        >
          {open ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
        </button>
      </div>
      {open && (
        <div className="border-t border-white/10 bg-black md:hidden">
          <div className="space-y-1 px-4 py-4">
            {links.map((l) =>
              l.href.startsWith("/") && !l.href.startsWith("/#") ? (
                <Link
                  key={l.label}
                  to={l.href as never}
                  onClick={() => setOpen(false)}
                  className="block rounded-md px-3 py-2 text-sm font-medium text-white/80 hover:bg-white/5"
                >
                  {l.label}
                </Link>
              ) : (
                <a
                  key={l.label}
                  href={l.href}
                  onClick={() => setOpen(false)}
                  className="block rounded-md px-3 py-2 text-sm font-medium text-white/80 hover:bg-white/5"
                >
                  {l.label}
                </a>
              )
            )}
            <div className="mt-3 flex flex-col gap-2 pt-3">
              <a href="/dashboard" className="inline-flex items-center justify-center rounded-md border border-white/15 bg-white/[0.03] px-4 py-2.5 text-sm font-semibold text-white transition hover:border-teal-400/40 hover:bg-white/[0.06]">
                Log In
              </a>
              <a href="/dashboard" className="inline-flex items-center justify-center gap-2 rounded-md bg-gradient-to-r from-emerald-500 to-teal-500 px-4 py-2.5 text-sm font-semibold text-white shadow-lg transition hover:opacity-95">
                Start Free Trial
              </a>
            </div>
          </div>
        </div>
      )}
    </header>
  );
}

function Footer() {
  const cols = [
    { title: "Product", links: ["Features", "Pricing", "Mobile App", "Changelog", "Status"] },
    { title: "Company", links: ["About", "Blog", "Careers", "Contact", "Press Kit"] },
    { title: "Support", links: ["Help Center", "Book a Demo", "Privacy Policy", "Terms of Service"] },
  ];
  const socials = [Instagram, Twitter, Facebook, Youtube, Music2];
  return (
    <footer className="border-t border-white/10 bg-black py-14 text-white">
      <div className="mx-auto max-w-6xl px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-2 gap-8 md:grid-cols-4">
          <div className="col-span-2 md:col-span-1">
            <div className="flex items-center gap-2">
              <div className="flex h-8 w-8 items-center justify-center rounded-md bg-gradient-to-br from-emerald-400 to-teal-500 text-xs font-black text-white">
                PXF
              </div>
              <span className="text-sm font-black tracking-widest">PXF HOCKEY</span>
            </div>
            <p className="mt-4 text-sm text-white/60">Built for coaches. Loved by parents.</p>
            <div className="mt-4 flex gap-3">
              {socials.map((Icon, i) => (
                <a
                  key={i}
                  href="#"
                  className="flex h-8 w-8 items-center justify-center rounded-md border border-white/10 text-white/60 transition hover:border-teal-400/40 hover:text-teal-400"
                >
                  <Icon className="h-4 w-4" />
                </a>
              ))}
            </div>
          </div>
          {cols.map((c) => (
            <div key={c.title}>
              <div className="text-xs font-bold uppercase tracking-widest text-white/50">{c.title}</div>
              <ul className="mt-4 space-y-2">
                {c.links.map((l) => (
                  <li key={l}>
                    {l === "Pricing" ? (
                      <Link to="/pricing" className="text-sm text-white/70 transition hover:text-white">
                        {l}
                      </Link>
                    ) : (
                      <a href="#" className="text-sm text-white/70 transition hover:text-white">
                        {l}
                      </a>
                    )}
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>
        <div className="mt-12 flex flex-col items-center justify-between gap-3 border-t border-white/10 pt-6 text-xs text-white/40 md:flex-row">
          <span>© 2026 PXF Hockey. All rights reserved.</span>
          <span>Made for the game.</span>
        </div>
      </div>
    </footer>
  );
}

function PricingPage() {
  return (
    <div className="min-h-screen bg-black text-white">
      <Nav />
      <main className="py-20">
        <PricingPlans />
      </main>
      <Footer />
    </div>
  );
}
