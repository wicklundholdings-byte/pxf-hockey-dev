import { createFileRoute } from "@tanstack/react-router";
import { useAccount } from "@/components/account-provider";
import { AssociationCoaches } from "@/components/association-coaches";

export const Route = createFileRoute("/coaches")({
  head: () => ({
    meta: [
      { title: "Coaches · PXF Hockey" },
      { name: "description", content: "Coaches view for PXF Hockey Association Admin portal." },
    ],
  }),
  component: Page,
});

function Page() {
  const { account } = useAccount();
  if (account.role === "association-admin") return <AssociationCoaches />;
  return (
    <div className="rounded-lg border border-dashed border-border p-12 text-center">
      <h2 className="text-xl font-semibold">Coaches</h2>
      <p className="mt-2 text-sm text-muted-foreground">Available in the Association Admin view.</p>
    </div>
  );
}
