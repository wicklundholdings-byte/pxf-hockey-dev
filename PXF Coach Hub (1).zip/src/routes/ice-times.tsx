import { createFileRoute } from "@tanstack/react-router";
import { useAccount } from "@/components/account-provider";
import { AssociationIceTimes } from "@/components/association-ice-times";

export const Route = createFileRoute("/ice-times")({
  head: () => ({
    meta: [
      { title: "Ice Times · PXF Hockey" },
      { name: "description", content: "Ice Times scheduling and rink management for PXF Hockey." },
    ],
  }),
  component: Page,
});

function Page() {
  const { account } = useAccount();
  if (account.role === "association-admin") return <AssociationIceTimes />;
  return (
    <div className="rounded-lg border border-dashed border-border p-12 text-center">
      <h2 className="text-xl font-semibold">Ice Times</h2>
      <p className="mt-2 text-sm text-muted-foreground">Coming soon for Elite Coach view.</p>
    </div>
  );
}
