import { createFileRoute, Link, useNavigate, useSearch } from "@tanstack/react-router";
import { useState } from "react";
import { supabase } from "@/lib/supabase";
import { getRoleFromDB, pathForRole } from "@/lib/get-role";

type Search = { redirect?: string };
type Mode = "signin" | "forgot";

export const Route = createFileRoute("/login")({
  validateSearch: (s: Record<string, unknown>): Search => ({
    redirect: typeof s.redirect === "string" ? s.redirect : undefined,
  }),
  component: LoginPage,
});

function LoginPage() {
  const navigate = useNavigate();
  const { redirect } = useSearch({ from: "/login" });
  const [mode, setMode] = useState<Mode>("signin");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState<string | null>(null);
  const [notice, setNotice] = useState<string | null>(null);

  async function onSignIn(e: React.FormEvent) {
    e.preventDefault();
    setErr(null);
    setNotice(null);
    setBusy(true);
    try {
      const { data, error } = await supabase.auth.signInWithPassword({ email, password });
      if (error) {
        setErr(error.message);
        return;
      }
      let target = redirect && redirect.startsWith("/") ? redirect : null;
      if (!target && data.user?.id) {
        const role = await getRoleFromDB(data.user.id);
        target = pathForRole(role);
      }
      navigate({ to: target ?? "/dashboard", replace: true });
    } finally {
      setBusy(false);
    }
  }

  async function onForgot(e: React.FormEvent) {
    e.preventDefault();
    setErr(null);
    setNotice(null);
    setBusy(true);
    try {
      const redirectTo =
        typeof window !== "undefined"
          ? `${window.location.origin}/auth/update-password`
          : undefined;
      const { error } = await supabase.auth.resetPasswordForEmail(email, { redirectTo });
      if (error) {
        setErr(error.message);
        return;
      }
      setNotice(`We sent a password reset link to ${email}.`);
    } finally {
      setBusy(false);
    }
  }

  return (
    <div
      className="flex min-h-screen items-center justify-center px-4"
      style={{ background: "#0D1117", color: "#FFFFFF" }}
    >
      <div
        className="w-full max-w-md rounded-2xl p-8 shadow-2xl"
        style={{ background: "#161B22", border: "1px solid #21262D" }}
      >
        <div className="mb-6 text-center">
          <div
            className="mx-auto mb-3 flex h-11 w-11 items-center justify-center rounded-xl text-lg font-black text-black"
            style={{ background: "linear-gradient(135deg,#00C4B4,#3DFF8F)" }}
          >
            P
          </div>
          <h1 className="text-2xl font-bold tracking-tight">
            {mode === "signin" ? "Sign in to PXF" : "Reset your password"}
          </h1>
          <p className="mt-1 text-sm" style={{ color: "#8B949E" }}>
            {mode === "signin"
              ? "Use the same email and password as the PXF mobile app."
              : "Enter your email and we'll send you a link to set a new password."}
          </p>
        </div>

        {mode === "signin" ? (
          <form onSubmit={onSignIn} className="space-y-4">
            <label className="block">
              <span className="mb-1 block text-xs font-medium" style={{ color: "#8B949E" }}>
                Email
              </span>
              <input
                type="email"
                required
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                autoComplete="email"
                className="w-full rounded-md px-3 py-2 text-sm outline-none"
                style={inputStyle}
              />
            </label>
            <label className="block">
              <span className="mb-1 block text-xs font-medium" style={{ color: "#8B949E" }}>
                Password
              </span>
              <input
                type="password"
                required
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                autoComplete="current-password"
                className="w-full rounded-md px-3 py-2 text-sm outline-none"
                style={inputStyle}
              />
            </label>

            {err && <ErrorBox>{err}</ErrorBox>}

            <button
              type="submit"
              disabled={busy}
              className="w-full rounded-md px-4 py-2.5 text-sm font-semibold text-black transition hover:opacity-90 disabled:opacity-60"
              style={{ background: "linear-gradient(90deg,#00C4B4,#3DFF8F)" }}
            >
              {busy ? "Signing in…" : "Sign in"}
            </button>

            <div className="text-center">
              <button
                type="button"
                onClick={() => {
                  setMode("forgot");
                  setErr(null);
                  setNotice(null);
                }}
                className="text-xs font-medium"
                style={{ color: "#00C4B4" }}
              >
                Forgot password?
              </button>
            </div>
          </form>
        ) : (
          <form onSubmit={onForgot} className="space-y-4">
            <label className="block">
              <span className="mb-1 block text-xs font-medium" style={{ color: "#8B949E" }}>
                Email
              </span>
              <input
                type="email"
                required
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                autoComplete="email"
                className="w-full rounded-md px-3 py-2 text-sm outline-none"
                style={inputStyle}
              />
            </label>

            {err && <ErrorBox>{err}</ErrorBox>}
            {notice && (
              <div
                className="rounded-md px-3 py-2 text-xs"
                style={{
                  background: "rgba(0,196,180,0.08)",
                  border: "1px solid rgba(0,196,180,0.35)",
                  color: "#3DFF8F",
                }}
              >
                {notice}
              </div>
            )}

            <button
              type="submit"
              disabled={busy}
              className="w-full rounded-md px-4 py-2.5 text-sm font-semibold text-black transition hover:opacity-90 disabled:opacity-60"
              style={{ background: "linear-gradient(90deg,#00C4B4,#3DFF8F)" }}
            >
              {busy ? "Sending…" : "Send reset link"}
            </button>

            <div className="text-center">
              <button
                type="button"
                onClick={() => {
                  setMode("signin");
                  setErr(null);
                  setNotice(null);
                }}
                className="text-xs font-medium"
                style={{ color: "#8B949E" }}
              >
                ← Back to sign in
              </button>
            </div>
          </form>
        )}

        <div className="mt-5 text-center text-xs" style={{ color: "#8B949E" }}>
          Don't have an account?{" "}
          <Link to="/signup" className="font-semibold" style={{ color: "#00C4B4" }}>
            Create one
          </Link>
        </div>
      </div>
    </div>
  );
}

const inputStyle: React.CSSProperties = {
  background: "#0D1117",
  border: "1px solid #21262D",
  color: "#FFFFFF",
};

function ErrorBox({ children }: { children: React.ReactNode }) {
  return (
    <div
      className="rounded-md px-3 py-2 text-xs"
      style={{
        background: "rgba(239,68,68,0.08)",
        border: "1px solid rgba(239,68,68,0.35)",
        color: "#fca5a5",
      }}
    >
      {children}
    </div>
  );
}
