import { createFileRoute, Link } from "@tanstack/react-router";
import { ChevronLeft } from "lucide-react";

export const Route = createFileRoute("/preview/website")({
  head: () => ({
    meta: [
      { title: "Preview · Jordan Doe — Elite Skating Coach" },
      { name: "description", content: "Public website preview." },
      { name: "robots", content: "noindex" },
    ],
  }),
  component: WebsitePreview,
});

const PRIMARY = "#0d9488";
const SECONDARY = "#10b981";

function WebsitePreview() {
  return (
    <div className="min-h-screen bg-slate-950 text-white">
      {/* Back to portal */}
      <Link
        to="/settings"
        className="fixed left-4 top-4 z-50 inline-flex items-center gap-1.5 rounded-md border border-white/15 bg-black/60 px-3 py-1.5 text-xs font-semibold text-white backdrop-blur hover:bg-black/80"
      >
        <ChevronLeft className="h-3.5 w-3.5" /> Back to Portal
      </Link>

      {/* Nav */}
      <header className="sticky top-0 z-40 border-b border-white/10 bg-slate-950/80 backdrop-blur">
        <div className="mx-auto flex max-w-6xl items-center justify-between px-6 py-4">
          <div className="flex items-center gap-2">
            <div
              className="h-8 w-8 rounded-full"
              style={{ background: `linear-gradient(135deg, ${PRIMARY}, ${SECONDARY})` }}
            />
            <div className="leading-tight">
              <div className="text-sm font-bold">Jordan Doe</div>
              <div className="text-[10px] opacity-70">Elite Skating Coach</div>
            </div>
          </div>
          <nav className="hidden gap-6 text-sm md:flex">
            {["Home", "About", "Camps", "Privates", "Book"].map((n) => (
              <a key={n} href={`#${n.toLowerCase()}`} className="opacity-80 hover:opacity-100">
                {n}
              </a>
            ))}
          </nav>
          <a
            href="#book"
            className="rounded-md px-4 py-1.5 text-sm font-semibold text-white shadow"
            style={{ background: `linear-gradient(135deg, ${PRIMARY}, ${SECONDARY})` }}
          >
            Book
          </a>
        </div>
      </header>

      {/* Hero */}
      <section
        id="home"
        className="relative overflow-hidden"
        style={{
          background: `linear-gradient(135deg, ${PRIMARY} 0%, ${SECONDARY} 100%)`,
        }}
      >
        <div
          className="absolute inset-0 opacity-30"
          style={{ background: "radial-gradient(circle at 30% 40%, rgba(255,255,255,0.25), transparent 60%)" }}
        />
        <div className="relative mx-auto max-w-6xl px-6 py-28 text-center">
          <h1 className="text-4xl font-black tracking-tight sm:text-6xl">
            Skate faster. Play smarter.
          </h1>
          <p className="mx-auto mt-4 max-w-xl text-base opacity-90 sm:text-lg">
            12 years developing elite skaters — edge work, speed, and hockey IQ.
          </p>
          <a
            href="#book"
            className="mt-8 inline-flex rounded-md bg-white px-6 py-3 text-sm font-bold text-slate-900 shadow-lg hover:bg-white/90"
          >
            Book a Session
          </a>
        </div>
      </section>

      {/* Camps */}
      <section id="camps" className="mx-auto max-w-6xl px-6 py-20">
        <div className="mb-8 flex items-end justify-between">
          <div>
            <div className="text-xs font-bold uppercase tracking-wider" style={{ color: PRIMARY }}>
              Upcoming
            </div>
            <h2 className="mt-1 text-3xl font-black">Camps</h2>
          </div>
          <a href="#camps" className="text-sm font-semibold" style={{ color: PRIMARY }}>
            View all →
          </a>
        </div>
        <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
          <div className="overflow-hidden rounded-xl border border-white/10 bg-white/5">
            <div
              className="relative h-32"
              style={{ background: `linear-gradient(135deg, ${PRIMARY}, ${SECONDARY})` }}
            >
              <span className="absolute right-3 top-3 rounded-full bg-white/90 px-2 py-0.5 text-[10px] font-bold uppercase tracking-wider text-slate-900">
                Enrolling
              </span>
            </div>
            <div className="p-5">
              <div className="text-base font-bold">Elite Skating Camp</div>
              <div className="mt-1 text-xs opacity-70">Wed–Fri · 9:00–12:00 PM · Rink A</div>
              <div className="text-xs opacity-70">Ages 10–14 · 12 spots left</div>
              <div className="mt-4 flex items-center justify-between">
                <div className="text-lg font-black">$450</div>
                <button
                  className="rounded-md px-4 py-2 text-xs font-bold text-white"
                  style={{ background: `linear-gradient(135deg, ${PRIMARY}, ${SECONDARY})` }}
                >
                  Register
                </button>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* About */}
      <section id="about" className="border-t border-white/10 bg-slate-900/50">
        <div className="mx-auto grid max-w-6xl gap-10 px-6 py-20 md:grid-cols-[1fr_2fr]">
          <div>
            <div
              className="aspect-square w-full max-w-xs rounded-2xl"
              style={{ background: `linear-gradient(135deg, ${PRIMARY}, ${SECONDARY})` }}
            />
          </div>
          <div>
            <div className="text-xs font-bold uppercase tracking-wider" style={{ color: PRIMARY }}>
              About
            </div>
            <h2 className="mt-1 text-3xl font-black">Jordan Doe</h2>
            <p className="mt-4 text-sm leading-relaxed opacity-80">
              Twelve years developing elite hockey skaters across British Columbia. I focus on
              edge work, explosive first-step speed, and hockey IQ — the details that separate
              good skaters from great ones. My players skate on rosters at every level from
              U13 AAA through NCAA Division I.
            </p>
            <p className="mt-4 text-sm leading-relaxed opacity-80">
              Certifications: Hockey Canada Level 4 · USA Hockey Level 5 · Power Skating Instructor
              Certified.
            </p>
            <div className="mt-6 grid grid-cols-3 gap-4">
              {[
                ["12+", "Years Coaching"],
                ["350+", "Athletes Trained"],
                ["4.9★", "Parent Rating"],
              ].map(([n, l]) => (
                <div key={l} className="rounded-lg border border-white/10 bg-white/5 p-4">
                  <div className="text-2xl font-black" style={{ color: PRIMARY }}>{n}</div>
                  <div className="mt-1 text-[11px] uppercase tracking-wider opacity-70">{l}</div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="border-t border-white/10 bg-slate-950">
        <div className="mx-auto flex max-w-6xl flex-col items-center justify-between gap-4 px-6 py-8 text-xs text-white/60 sm:flex-row">
          <div>© 2026 Jordan Doe Hockey. All rights reserved.</div>
          <div className="flex gap-4">
            <a href="#" className="hover:text-white">Privacy</a>
            <a href="#" className="hover:text-white">Terms</a>
            <a href="#" className="hover:text-white">Contact</a>
          </div>
          <div className="opacity-70">Powered by PXF Hockey</div>
        </div>
      </footer>
    </div>
  );
}
