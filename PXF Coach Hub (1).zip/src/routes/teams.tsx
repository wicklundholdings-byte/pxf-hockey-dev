import { createFileRoute } from "@tanstack/react-router";
import { useState, useMemo } from "react";
import {
  Plus, ChevronLeft, ChevronDown, ChevronRight, ChevronUp, MapPin,
  Phone, Navigation, Upload, Camera, Video, Circle, Search,
} from "lucide-react";
import { cn } from "@/lib/utils";

export const Route = createFileRoute("/teams")({
  head: () => ({
    meta: [
      { title: "Teams · PXF Hockey" },
      { name: "description", content: "Manage teams, rosters, schedules, and tournaments." },
    ],
  }),
  component: TeamsPage,
});

/* ============================================================
   TYPES + MOCK DATA
============================================================ */

const TEAL = "#00D4C8";

type TeamSummary = {
  id: string;
  name: string;
  season: string;
  division: string;
  initials: string;
  record: { w: number; l: number; ot: number };
  nextGame: string;
};

type EventKind = "GAME" | "PRACTICE" | "OTHER" | "TRANSPORT" | "MEAL" | "HOTEL" | "FUNCTION";

type RosterPlayer = {
  id: string;
  name: string;
  number: number;
  position: "F" | "D" | "G";
  status: "Active" | "Injured" | "Pending";
};

type TeamEvent = {
  id: string;
  name: string;
  type: "GAME" | "PRACTICE" | "OTHER";
  date: string; // ISO-ish label
  time: string;
  location: string;
  rsvp: { going: number; pending: number; out: number };
  opponent?: string;
  result?: { us: number; them: number; win: boolean };
};

type Tournament = {
  id: string;
  name: string;
  dates: string;
  location: string;
  status: "UPCOMING" | "IN PROGRESS" | "COMPLETE";
};

type TournamentEvent = {
  id: string;
  day: string; // e.g. "Fri Nov 14"
  time: string;
  kind: EventKind;
  name: string;
  location: string;
  rsvp: { yes: number; maybe: number; no: number; noReply: number };
  result?: { score: string; outcome: "WIN" | "LOSS" | "OT" };
};

const TEAMS: TeamSummary[] = [
  { id: "t1", name: "Elite Demo Team", season: "2026-27", division: "AAA Midget", initials: "ED", record: { w: 7, l: 5, ot: 2 }, nextGame: "Sat Nov 15" },
  { id: "t2", name: "Atom Rep Team", season: "2026-27", division: "A Atom", initials: "AR", record: { w: 4, l: 3, ot: 1 }, nextGame: "Sun Nov 16" },
];

const ROSTER: RosterPlayer[] = [
  { id: "p1", name: "Ethan Carter", number: 9, position: "F", status: "Active" },
  { id: "p2", name: "Liam Brooks", number: 17, position: "F", status: "Active" },
  { id: "p3", name: "Noah Patel", number: 22, position: "F", status: "Injured" },
  { id: "p4", name: "Owen Tremblay", number: 4, position: "D", status: "Active" },
  { id: "p5", name: "Jaxon Lee", number: 7, position: "D", status: "Pending" },
  { id: "p6", name: "Caleb Wright", number: 31, position: "G", status: "Active" },
  { id: "p7", name: "Mason Lévesque", number: 12, position: "F", status: "Active" },
  { id: "p8", name: "Eli Tanaka", number: 24, position: "D", status: "Active" },
];

const UPCOMING_EVENTS: TeamEvent[] = [
  { id: "e1", name: "vs Burnaby Winter Club", type: "GAME", date: "Sat Jul 5", time: "6:00 PM", location: "Cloverdale Arena", rsvp: { going: 9, pending: 2, out: 1 }, opponent: "Burnaby Winter Club" },
  { id: "e2", name: "Team Practice", type: "PRACTICE", date: "Thu Jul 9", time: "7:45 AM", location: "Surrey Sport and Leisure", rsvp: { going: 0, pending: 0, out: 0 } },
  { id: "e3", name: "vs Coquitlam Express", type: "GAME", date: "Sat Jul 12", time: "4:30 PM", location: "Poirier Sport Centre", rsvp: { going: 11, pending: 1, out: 0 }, opponent: "Coquitlam Express" },
];

const PAST_EVENTS: TeamEvent[] = [
  { id: "p1", name: "vs Langley Trappers", type: "GAME", date: "Wed Jun 22", time: "7:30 PM", location: "Langley Events Centre", rsvp: { going: 18, pending: 0, out: 0 }, opponent: "Langley Trappers", result: { us: 4, them: 2, win: true } },
];

const TOURNAMENTS: Tournament[] = [
  { id: "tour1", name: "BC Minor AAA Spring Classic", dates: "Jul 18 – Jul 21, 2026", location: "Langley, BC", status: "IN PROGRESS" },
  { id: "tour2", name: "Lower Mainland Invitational", dates: "Aug 2 – Aug 4, 2026", location: "Burnaby, BC", status: "UPCOMING" },
];

const TOURNAMENT_EVENTS: TournamentEvent[] = [
  { id: "ev1", day: "Fri Jul 18", time: "6:30 AM", kind: "TRANSPORT", name: "Bus Departure", location: "Surrey Sport & Leisure parking lot", rsvp: { yes: 9, maybe: 1, no: 2, noReply: 2 } },
  { id: "ev2", day: "Fri Jul 18", time: "9:00 AM", kind: "GAME", name: "Game 1 vs Burnaby Winter Club", location: "Rink 1 · Langley Events Centre", rsvp: { yes: 12, maybe: 0, no: 0, noReply: 2 }, result: { score: "3-1", outcome: "WIN" } },
  { id: "ev3", day: "Fri Jul 18", time: "12:00 PM", kind: "MEAL", name: "Team Lunch", location: "Boston Pizza Langley", rsvp: { yes: 11, maybe: 2, no: 1, noReply: 0 } },
  { id: "ev4", day: "Fri Jul 18", time: "2:00 PM", kind: "HOTEL", name: "Hotel Check-in", location: "Sandman Hotel Langley", rsvp: { yes: 10, maybe: 0, no: 2, noReply: 2 } },
  { id: "ev5", day: "Fri Jul 18", time: "5:30 PM", kind: "GAME", name: "Optional Skate", location: "Rink 3 · Langley Events Centre", rsvp: { yes: 8, maybe: 3, no: 2, noReply: 1 } },
];


/* ============================================================
   VIEW ROUTER (in-page)
============================================================ */

type View =
  | { kind: "list" }
  | { kind: "team"; teamId: string }
  | { kind: "tournament"; teamId: string; tournamentId: string }
  | { kind: "game"; teamId: string; eventId: string; from: "team" | "tournament"; tournamentId?: string };

function TeamsPage() {
  const [view, setView] = useState<View>({ kind: "list" });

  if (view.kind === "list") return <TeamsList onOpen={(teamId) => setView({ kind: "team", teamId })} />;
  if (view.kind === "team") {
    const team = TEAMS.find((t) => t.id === view.teamId)!;
    return (
      <TeamDetail
        team={team}
        onBack={() => setView({ kind: "list" })}
        onOpenTournament={(tournamentId) => setView({ kind: "tournament", teamId: team.id, tournamentId })}
        onOpenGame={(eventId) => setView({ kind: "game", teamId: team.id, eventId, from: "team" })}
      />
    );
  }
  if (view.kind === "tournament") {
    const team = TEAMS.find((t) => t.id === view.teamId)!;
    const tour = TOURNAMENTS.find((t) => t.id === view.tournamentId)!;
    return (
      <TournamentDetail
        team={team}
        tournament={tour}
        onBack={() => setView({ kind: "team", teamId: team.id })}
        onOpenGame={(eventId) => setView({ kind: "game", teamId: team.id, eventId, from: "tournament", tournamentId: tour.id })}
      />
    );
  }
  // game
  const team = TEAMS.find((t) => t.id === view.teamId)!;
  return (
    <GameDetail
      team={team}
      onBack={() =>
        view.from === "tournament" && view.tournamentId
          ? setView({ kind: "tournament", teamId: team.id, tournamentId: view.tournamentId })
          : setView({ kind: "team", teamId: team.id })
      }
    />
  );
}

/* ============================================================
   PRIMITIVES
============================================================ */

function SectionLabel({ children }: { children: React.ReactNode }) {
  return (
    <div className="text-[11px] font-semibold uppercase tracking-[0.18em] text-muted-foreground">
      {children}
    </div>
  );
}

function Card({ className, children }: { className?: string; children: React.ReactNode }) {
  return (
    <div className={cn("rounded-xl border border-border bg-card p-5", className)}>{children}</div>
  );
}

function TealButton({ children, onClick, variant = "outline" }: { children: React.ReactNode; onClick?: () => void; variant?: "outline" | "solid" }) {
  if (variant === "solid") {
    return (
      <button onClick={onClick} className="inline-flex h-9 items-center gap-1.5 rounded-md bg-[#00D4C8] px-3 text-xs font-semibold text-black hover:opacity-90">
        {children}
      </button>
    );
  }
  return (
    <button onClick={onClick} className="inline-flex h-9 items-center gap-1.5 rounded-md border border-[#00D4C8]/50 bg-transparent px-3 text-xs font-semibold text-[#00D4C8] hover:bg-[#00D4C8]/10">
      {children}
    </button>
  );
}

function StatusBadge({ status }: { status: Tournament["status"] }) {
  const map = {
    UPCOMING: "bg-blue-500/15 text-blue-300 ring-blue-500/30",
    "IN PROGRESS": "bg-[#00D4C8]/15 text-[#00D4C8] ring-[#00D4C8]/30",
    COMPLETE: "bg-muted text-muted-foreground ring-border",
  }[status];
  return <span className={cn("rounded px-2 py-0.5 text-[10px] font-bold uppercase tracking-wider ring-1", map)}>{status}</span>;
}

function TabBar({ tabs, active, onChange }: { tabs: string[]; active: string; onChange: (t: string) => void }) {
  return (
    <div className="border-b border-border">
      <div className="flex gap-6">
        {tabs.map((t) => {
          const on = t === active;
          return (
            <button
              key={t}
              onClick={() => onChange(t)}
              className={cn(
                "relative -mb-px py-3 text-sm font-medium transition",
                on ? "text-foreground" : "text-muted-foreground hover:text-foreground"
              )}
            >
              {t}
              {on && <span className="absolute inset-x-0 -bottom-px h-0.5 bg-[#00D4C8]" />}
            </button>
          );
        })}
      </div>
    </div>
  );
}

function BackLink({ label, onClick }: { label: string; onClick: () => void }) {
  return (
    <button onClick={onClick} className="inline-flex items-center gap-1 text-xs text-muted-foreground hover:text-foreground">
      <ChevronLeft className="h-3.5 w-3.5" /> {label}
    </button>
  );
}

function TeamAvatar({ initials, size = 48 }: { initials: string; size?: number }) {
  return (
    <div
      className="flex items-center justify-center rounded-full font-bold text-black"
      style={{ width: size, height: size, background: TEAL, fontSize: size * 0.36 }}
    >
      {initials}
    </div>
  );
}

function AttendanceDots({ going, pending, out }: { going: number; pending: number; out: number }) {
  return (
    <div className="flex items-center gap-3 text-[11px] text-muted-foreground">
      <span className="inline-flex items-center gap-1"><Circle className="h-2 w-2 fill-[#00D4C8] text-[#00D4C8]" /> {going} going</span>
      <span className="inline-flex items-center gap-1"><Circle className="h-2 w-2 fill-amber-400 text-amber-400" /> {pending} pending</span>
      <span className="inline-flex items-center gap-1"><Circle className="h-2 w-2 fill-red-500 text-red-500" /> {out} out</span>
    </div>
  );
}

const EVENT_BORDER: Record<EventKind, string> = {
  GAME: "border-l-[#00D4C8]",
  PRACTICE: "border-l-blue-400",
  OTHER: "border-l-muted-foreground/40",
  TRANSPORT: "border-l-amber-400",
  MEAL: "border-l-purple-400",
  HOTEL: "border-l-blue-500",
  FUNCTION: "border-l-emerald-400",
};

/* ============================================================
   TEAMS LIST
============================================================ */

function TeamsList({ onOpen }: { onOpen: (id: string) => void }) {
  const [q, setQ] = useState("");
  const rows = useMemo(
    () => TEAMS.filter((t) => t.name.toLowerCase().includes(q.toLowerCase())),
    [q]
  );

  return (
    <div className="space-y-6">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <h1 className="text-2xl font-semibold tracking-tight">Teams</h1>
          <p className="mt-1 text-sm text-muted-foreground">Manage your teams, rosters, and tournaments.</p>
        </div>
        <div className="flex items-center gap-2">
          <div className="relative">
            <Search className="absolute left-2.5 top-1/2 h-3.5 w-3.5 -translate-y-1/2 text-muted-foreground" />
            <input
              value={q}
              onChange={(e) => setQ(e.target.value)}
              placeholder="Search teams…"
              className="h-9 w-56 rounded-md border border-border bg-background pl-8 pr-2 text-xs"
            />
          </div>
          <TealButton variant="solid">
            <Plus className="h-3.5 w-3.5" /> Create Team
          </TealButton>
        </div>
      </div>

      <div className="grid grid-cols-1 gap-4 md:grid-cols-2 xl:grid-cols-3">
        {rows.map((t) => (
          <button
            key={t.id}
            onClick={() => onOpen(t.id)}
            className="group rounded-xl border border-border border-l-2 border-l-[#00D4C8] bg-card p-5 text-left transition hover:border-[#00D4C8]/50 hover:bg-card/80"
          >
            <div className="flex items-start gap-4">
              <TeamAvatar initials={t.initials} />
              <div className="min-w-0 flex-1">
                <div className="truncate text-base font-semibold">{t.name}</div>
                <div className="mt-0.5 text-xs text-muted-foreground">
                  {t.division} · {t.season}
                </div>
              </div>
            </div>
            <div className="mt-5 flex items-center justify-between border-t border-border pt-4">
              <div>
                <div className="text-[10px] font-semibold uppercase tracking-wider text-muted-foreground">Record</div>
                <div className="mt-0.5 text-sm font-semibold">{t.record.w}W · {t.record.l}L · {t.record.ot}OT</div>
              </div>
              <div className="text-right">
                <div className="text-[10px] font-semibold uppercase tracking-wider text-muted-foreground">Next Game</div>
                <div className="mt-0.5 text-sm font-semibold">{t.nextGame}</div>
              </div>
            </div>
          </button>
        ))}
      </div>
    </div>
  );
}

/* ============================================================
   TEAM DETAIL
============================================================ */

function TeamDetail({
  team, onBack, onOpenTournament, onOpenGame,
}: {
  team: TeamSummary;
  onBack: () => void;
  onOpenTournament: (id: string) => void;
  onOpenGame: (id: string) => void;
}) {
  const [tab, setTab] = useState("Overview");
  const tabs = ["Overview", "Schedule", "Roster", "Tournaments", "More"];

  return (
    <div className="space-y-6">
      <BackLink label="Teams" onClick={onBack} />

      <div className="flex items-start gap-4">
        <TeamAvatar initials={team.initials} size={56} />
        <div>
          <h1 className="text-2xl font-semibold tracking-tight">{team.name}</h1>
          <div className="mt-1 text-sm text-muted-foreground">{team.division} · {team.season}</div>
        </div>
      </div>

      <TabBar tabs={tabs} active={tab} onChange={setTab} />

      {tab === "Overview" && <OverviewTab team={team} onOpenGame={onOpenGame} />}
      {tab === "Schedule" && <ScheduleTab onOpenGame={onOpenGame} />}
      {tab === "Roster" && <RosterTab />}
      {tab === "Tournaments" && <TournamentsTab onOpen={onOpenTournament} />}
      {tab === "More" && (
        <Card className="text-sm text-muted-foreground">
          Stats, Settings, and additional team tools will live here.
        </Card>
      )}
    </div>
  );
}

/* ---------- Overview ---------- */

function OverviewTab({ team, onOpenGame }: { team: TeamSummary; onOpenGame: (id: string) => void }) {
  const next = UPCOMING_EVENTS.find((e) => e.type === "GAME")!;
  const last = PAST_EVENTS[0];
  return (
    <div className="grid grid-cols-1 gap-6 lg:grid-cols-[1.6fr_1fr]">
      <div className="space-y-6">
        <div>
          <SectionLabel>Next Game</SectionLabel>
          <Card className="mt-3 border-l-2 border-l-[#00D4C8]">
            <div className="flex items-start justify-between gap-4">
              <div>
                <div className="text-lg font-semibold">{team.name} vs {next.opponent}</div>
                <div className="mt-1 text-sm text-muted-foreground">{next.date} · {next.time}</div>
                <div className="mt-0.5 text-sm text-muted-foreground">{next.location}</div>
                <div className="mt-4"><AttendanceDots {...next.rsvp} /></div>
              </div>
              <TealButton onClick={() => onOpenGame(next.id)}>View Game</TealButton>
            </div>
          </Card>
        </div>

        <div>
          <SectionLabel>Last Result</SectionLabel>
          <Card className="mt-3">
            <div className="flex items-center justify-between">
              <div>
                <div className="text-sm font-semibold">{team.name} vs {last.opponent}</div>
                <div className="mt-1 text-xs text-muted-foreground">{last.date}</div>
              </div>
              <div className="flex items-center gap-4">
                <div className="font-mono text-2xl font-semibold">{last.result!.us}-{last.result!.them}</div>
                <span className={cn(
                  "rounded px-2 py-0.5 text-[10px] font-bold uppercase tracking-wider ring-1",
                  last.result!.win ? "bg-[#00D4C8]/15 text-[#00D4C8] ring-[#00D4C8]/30" : "bg-red-500/15 text-red-300 ring-red-500/30"
                )}>
                  {last.result!.win ? "WIN" : "LOSS"}
                </span>
              </div>
            </div>
          </Card>
        </div>
      </div>

      <div className="space-y-6">
        <div>
          <SectionLabel>Season Record</SectionLabel>
          <Card className="mt-3">
            <div className="grid grid-cols-3 gap-2 text-center">
              <div>
                <div className="text-3xl font-semibold text-[#00D4C8]">{team.record.w}</div>
                <div className="mt-1 text-[10px] font-semibold uppercase tracking-wider text-muted-foreground">Wins</div>
              </div>
              <div>
                <div className="text-3xl font-semibold text-red-400">{team.record.l}</div>
                <div className="mt-1 text-[10px] font-semibold uppercase tracking-wider text-muted-foreground">Losses</div>
              </div>
              <div>
                <div className="text-3xl font-semibold text-amber-400">{team.record.ot}</div>
                <div className="mt-1 text-[10px] font-semibold uppercase tracking-wider text-muted-foreground">OT</div>
              </div>
            </div>
          </Card>
        </div>

        <div>
          <SectionLabel>Upcoming</SectionLabel>
          <div className="mt-3 space-y-3">
            {UPCOMING_EVENTS.slice(0, 3).map((e) => (
              <MiniEventCard key={e.id} event={e} onClick={() => e.type === "GAME" && onOpenGame(e.id)} />
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}

function MiniEventCard({ event, onClick }: { event: TeamEvent; onClick?: () => void }) {
  const kind = event.type as EventKind;
  return (
    <button
      onClick={onClick}
      className={cn("w-full rounded-lg border border-border border-l-2 bg-card p-3 text-left transition hover:bg-card/80", EVENT_BORDER[kind])}
    >
      <div className="flex items-center justify-between gap-2">
        <div className="min-w-0">
          <div className="truncate text-sm font-semibold">{event.name}</div>
          <div className="mt-0.5 text-[11px] text-muted-foreground">{event.date} · {event.time}</div>
        </div>
        <span className="text-[9px] font-bold uppercase tracking-wider text-muted-foreground">{event.type}</span>
      </div>
    </button>
  );
}

/* ---------- Schedule Tab ---------- */

function ScheduleTab({ onOpenGame }: { onOpenGame: (id: string) => void }) {
  const [filter, setFilter] = useState<"All" | "Games" | "Practices">("All");
  const [addOpen, setAddOpen] = useState(false);

  const match = (e: TeamEvent) =>
    filter === "All" || (filter === "Games" && e.type === "GAME") || (filter === "Practices" && e.type === "PRACTICE");

  return (
    <div className="space-y-6">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div className="flex gap-2">
          {(["All", "Games", "Practices"] as const).map((f) => (
            <button
              key={f}
              onClick={() => setFilter(f)}
              className={cn(
                "h-8 rounded-full border px-3 text-xs font-medium transition",
                filter === f ? "border-[#00D4C8] bg-[#00D4C8]/10 text-[#00D4C8]" : "border-border text-muted-foreground hover:text-foreground"
              )}
            >
              {f}
            </button>
          ))}
        </div>
        <div className="relative">
          <TealButton variant="solid" onClick={() => setAddOpen((v) => !v)}>
            <Plus className="h-3.5 w-3.5" /> Add
          </TealButton>
          {addOpen && (
            <div className="absolute right-0 z-10 mt-2 w-40 overflow-hidden rounded-md border border-border bg-popover text-sm shadow-lg">
              {["Game", "Practice", "Other"].map((o) => (
                <button key={o} className="block w-full px-3 py-2 text-left hover:bg-accent">{o}</button>
              ))}
            </div>
          )}
        </div>
      </div>

      <div className="space-y-3">
        <SectionLabel>Upcoming</SectionLabel>
        {UPCOMING_EVENTS.filter(match).map((e) => (
          <EventRow key={e.id} event={e} onClick={() => e.type === "GAME" && onOpenGame(e.id)} />
        ))}
      </div>

      <div className="space-y-3">
        <SectionLabel>Past</SectionLabel>
        {PAST_EVENTS.filter(match).map((e) => (
          <EventRow key={e.id} event={e} onClick={() => e.type === "GAME" && onOpenGame(e.id)} />
        ))}
      </div>
    </div>
  );
}

function EventRow({ event, onClick }: { event: TeamEvent; onClick?: () => void }) {
  const kind = event.type as EventKind;
  return (
    <button
      onClick={onClick}
      className={cn("w-full rounded-lg border border-border border-l-2 bg-card p-4 text-left transition hover:bg-card/80", EVENT_BORDER[kind])}
    >
      <div className="flex flex-wrap items-start justify-between gap-3">
        <div className="min-w-0">
          <div className="flex items-center gap-2">
            <span className="text-sm font-semibold">{event.name}</span>
            <span className="rounded bg-muted px-1.5 py-0.5 text-[9px] font-bold uppercase tracking-wider text-muted-foreground">{event.type}</span>
          </div>
          <div className="mt-1 text-xs text-muted-foreground">{event.date} · {event.time} · {event.location}</div>
          <div className="mt-2"><AttendanceDots {...event.rsvp} /></div>
        </div>
        {event.result && (
          <div className="flex items-center gap-2">
            <span className="font-mono text-sm font-semibold">{event.result.us}-{event.result.them}</span>
            <span className={cn(
              "rounded px-2 py-0.5 text-[10px] font-bold uppercase ring-1",
              event.result.win ? "bg-[#00D4C8]/15 text-[#00D4C8] ring-[#00D4C8]/30" : "bg-red-500/15 text-red-300 ring-red-500/30"
            )}>{event.result.win ? "WIN" : "LOSS"}</span>
          </div>
        )}
      </div>
    </button>
  );
}

/* ---------- Roster Tab ---------- */

function RosterTab() {
  const [sortKey, setSortKey] = useState<keyof RosterPlayer>("number");
  const [dir, setDir] = useState<"asc" | "desc">("asc");
  const sorted = useMemo(() => {
    const arr = [...ROSTER];
    arr.sort((a, b) => {
      const av = a[sortKey], bv = b[sortKey];
      if (av < bv) return dir === "asc" ? -1 : 1;
      if (av > bv) return dir === "asc" ? 1 : -1;
      return 0;
    });
    return arr;
  }, [sortKey, dir]);

  const toggleSort = (k: keyof RosterPlayer) => {
    if (k === sortKey) setDir(dir === "asc" ? "desc" : "asc");
    else { setSortKey(k); setDir("asc"); }
  };

  const th = (label: string, k: keyof RosterPlayer) => (
    <button onClick={() => toggleSort(k)} className="inline-flex items-center gap-1 text-[10px] font-semibold uppercase tracking-wider text-muted-foreground hover:text-foreground">
      {label}
      {sortKey === k && (dir === "asc" ? <ChevronUp className="h-3 w-3" /> : <ChevronDown className="h-3 w-3" />)}
    </button>
  );

  return (
    <div className="space-y-4">
      <div className="flex justify-end">
        <TealButton variant="solid"><Plus className="h-3.5 w-3.5" /> Add Player</TealButton>
      </div>
      <Card className="p-0">
        <table className="w-full text-sm">
          <thead className="border-b border-border bg-muted/20">
            <tr>
              <th className="px-4 py-3 text-left">{th("Player", "name")}</th>
              <th className="px-4 py-3 text-left">{th("#", "number")}</th>
              <th className="px-4 py-3 text-left">{th("Pos", "position")}</th>
              <th className="px-4 py-3 text-left">{th("Status", "status")}</th>
            </tr>
          </thead>
          <tbody>
            {sorted.map((p) => (
              <tr key={p.id} className="border-b border-border last:border-0">
                <td className="px-4 py-3 font-medium">{p.name}</td>
                <td className="px-4 py-3 font-mono text-muted-foreground">{p.number}</td>
                <td className="px-4 py-3 text-muted-foreground">{p.position}</td>
                <td className="px-4 py-3">
                  <span className={cn(
                    "rounded px-2 py-0.5 text-[10px] font-bold uppercase ring-1",
                    p.status === "Active" && "bg-[#00D4C8]/15 text-[#00D4C8] ring-[#00D4C8]/30",
                    p.status === "Injured" && "bg-red-500/15 text-red-300 ring-red-500/30",
                    p.status === "Pending" && "bg-amber-500/15 text-amber-300 ring-amber-500/30",
                  )}>{p.status}</span>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </Card>
    </div>
  );
}

/* ---------- Tournaments Tab ---------- */

function TournamentsTab({ onOpen }: { onOpen: (id: string) => void }) {
  return (
    <div className="space-y-4">
      <div className="flex justify-end">
        <TealButton variant="solid"><Plus className="h-3.5 w-3.5" /> Add Tournament</TealButton>
      </div>
      <div className="space-y-3">
        {TOURNAMENTS.map((t) => (
          <button
            key={t.id}
            onClick={() => onOpen(t.id)}
            className="flex w-full items-center justify-between rounded-lg border border-border bg-card p-4 text-left transition hover:bg-card/80"
          >
            <div>
              <div className="text-sm font-semibold">{t.name}</div>
              <div className="mt-1 text-xs text-muted-foreground">{t.dates} · {t.location}</div>
            </div>
            <div className="flex items-center gap-3">
              <StatusBadge status={t.status} />
              <ChevronRight className="h-4 w-4 text-muted-foreground" />
            </div>
          </button>
        ))}
      </div>
    </div>
  );
}

/* ============================================================
   TOURNAMENT DETAIL
============================================================ */

function TournamentDetail({
  team, tournament, onBack, onOpenGame,
}: {
  team: TeamSummary;
  tournament: Tournament;
  onBack: () => void;
  onOpenGame: (id: string) => void;
}) {
  const [tab, setTab] = useState("Schedule");
  const tabs = ["Overview", "Schedule", "Roster", "Logistics", "Payments"];

  return (
    <div className="space-y-6">
      <BackLink label="Tournaments" onClick={onBack} />

      <div className="flex flex-wrap items-start justify-between gap-4">
        <div>
          <h1 className="text-2xl font-semibold tracking-tight">{tournament.name}</h1>
          <div className="mt-1 text-sm text-muted-foreground">{tournament.dates} · {tournament.location}</div>
          <div className="mt-1 text-xs text-muted-foreground">{team.name}</div>
        </div>
        <StatusBadge status={tournament.status} />
      </div>

      <TabBar tabs={tabs} active={tab} onChange={setTab} />

      {tab === "Overview" && (
        <Card className="text-sm text-muted-foreground">
          Overview of this tournament — record so far, standings, and key info.
        </Card>
      )}
      {tab === "Schedule" && <TournamentSchedule onOpenGame={onOpenGame} />}
      {tab === "Roster" && <RosterTab />}
      {tab === "Logistics" && <TournamentLogistics />}
      {tab === "Payments" && (
        <Card className="text-sm text-muted-foreground">Tournament fees and payment collection will live here.</Card>
      )}
    </div>
  );
}

/* ---------- Tournament Schedule ---------- */

function TournamentSchedule({ onOpenGame }: { onOpenGame: (id: string) => void }) {
  type Filter = "All" | "Games" | "Transport" | "Accommodation" | "Team Functions";
  const [filter, setFilter] = useState<Filter>("All");
  const filters: Filter[] = ["All", "Games", "Transport", "Accommodation", "Team Functions"];

  const match = (e: TournamentEvent) => {
    if (filter === "All") return true;
    if (filter === "Games") return e.kind === "GAME";
    if (filter === "Transport") return e.kind === "TRANSPORT";
    if (filter === "Accommodation") return e.kind === "HOTEL";
    if (filter === "Team Functions") return e.kind === "FUNCTION" || e.kind === "MEAL";
    return true;
  };

  const days = useMemo(() => {
    const filtered = TOURNAMENT_EVENTS.filter(match);
    const groups: Record<string, TournamentEvent[]> = {};
    for (const e of filtered) (groups[e.day] ||= []).push(e);
    return Object.entries(groups);
  }, [filter]);

  const [collapsed, setCollapsed] = useState<Record<string, boolean>>({});

  return (
    <div className="space-y-5">
      <div className="flex flex-wrap items-center gap-2">
        {filters.map((f) => (
          <button
            key={f}
            onClick={() => setFilter(f)}
            className={cn(
              "h-8 rounded-full border px-3 text-xs font-medium transition",
              filter === f ? "border-[#00D4C8] bg-[#00D4C8]/10 text-[#00D4C8]" : "border-border text-muted-foreground hover:text-foreground"
            )}
          >
            {f}
          </button>
        ))}
      </div>

      <div className="flex items-center justify-between">
        <button className="text-xs font-medium text-[#00D4C8] hover:underline">+ Add to Calendar</button>
        <TealButton>Edit Schedule</TealButton>
      </div>

      <div className="space-y-6">
        {days.map(([day, events]) => {
          const isCollapsed = collapsed[day];
          return (
            <div key={day}>
              <button
                onClick={() => setCollapsed((c) => ({ ...c, [day]: !c[day] }))}
                className="flex w-full items-center justify-between border-b border-border pb-2"
              >
                <span className="text-sm font-semibold">{day}</span>
                {isCollapsed ? <ChevronRight className="h-4 w-4 text-muted-foreground" /> : <ChevronDown className="h-4 w-4 text-muted-foreground" />}
              </button>
              {!isCollapsed && (
                <div className="mt-3 space-y-3">
                  {events.map((e) => (
                    <TournamentEventCard key={e.id} event={e} onOpenGame={onOpenGame} />
                  ))}
                </div>
              )}
            </div>
          );
        })}
      </div>
    </div>
  );
}

function TournamentEventCard({ event, onOpenGame }: { event: TournamentEvent; onOpenGame: (id: string) => void }) {
  const clickable = event.kind === "GAME";
  return (
    <div
      onClick={() => clickable && onOpenGame(event.id)}
      className={cn(
        "flex items-start gap-4 rounded-lg border border-border border-l-2 bg-card p-4 transition",
        EVENT_BORDER[event.kind],
        clickable && "cursor-pointer hover:bg-card/80"
      )}
    >
      <div className="w-16 shrink-0">
        <div className="text-sm font-semibold">{event.time}</div>
      </div>
      <div className="min-w-0 flex-1">
        <div className="text-sm font-semibold">{event.name}</div>
        <div className="mt-0.5 text-[10px] font-bold uppercase tracking-wider text-muted-foreground">{event.kind}</div>
        <div className="mt-1 flex items-center gap-1 text-xs text-muted-foreground">
          <MapPin className="h-3 w-3" /> {event.location}
        </div>
        <div className="mt-2 text-[11px] text-muted-foreground">
          <span className="text-[#00D4C8]">✓{event.rsvp.yes}</span>{" "}
          <span className="text-amber-400">~{event.rsvp.maybe}</span>{" "}
          <span className="text-red-400">✗{event.rsvp.no}</span>{" "}
          <span>?{event.rsvp.noReply}</span>
        </div>
      </div>
      <div className="flex shrink-0 flex-col items-end gap-2">
        {event.result ? (
          <div className="inline-flex items-center gap-1.5">
            <span className="font-mono text-sm font-semibold">{event.result.score}</span>
            <span className={cn(
              "rounded px-1.5 py-0.5 text-[10px] font-bold uppercase ring-1",
              event.result.outcome === "WIN" ? "bg-[#00D4C8]/15 text-[#00D4C8] ring-[#00D4C8]/30" : "bg-red-500/15 text-red-300 ring-red-500/30"
            )}>{event.result.outcome}</span>
            <ChevronRight className="h-4 w-4 text-muted-foreground" />
          </div>
        ) : (
          <select className="h-7 rounded border border-border bg-background px-2 text-[11px] text-muted-foreground" defaultValue="no-reply" onClick={(e) => e.stopPropagation()}>
            <option value="no-reply">NO REPLY</option>
            <option value="yes">Going</option>
            <option value="maybe">Maybe</option>
            <option value="no">Out</option>
          </select>
        )}
      </div>
    </div>
  );
}

/* ---------- Tournament Logistics ---------- */

function TournamentLogistics() {
  const [accom, setAccom] = useState<"Hotel" | "Billets" | "Both">("Hotel");
  const [rooms, setRooms] = useState(false);
  const [checklist, setChecklist] = useState(false);

  return (
    <div className="space-y-6">
      <div>
        <SectionLabel>Accommodation</SectionLabel>
        <div className="mt-3 inline-flex rounded-md border border-border bg-card p-1">
          {(["Hotel", "Billets", "Both"] as const).map((o) => (
            <button
              key={o}
              onClick={() => setAccom(o)}
              className={cn(
                "rounded px-4 py-1.5 text-xs font-medium transition",
                accom === o ? "bg-[#00D4C8]/15 text-[#00D4C8]" : "text-muted-foreground hover:text-foreground"
              )}
            >
              {o}
            </button>
          ))}
        </div>
      </div>

      {(accom === "Hotel" || accom === "Both") && (
        <Card className="border-l-2 border-l-blue-500">
          <div className="text-sm font-semibold">Sandman Hotel Langley</div>
          <div className="mt-1 text-xs text-muted-foreground">8765 202 St, Langley BC</div>
          <div className="mt-2 text-xs text-muted-foreground">Check-in: Jul 17 · Check-out: Jul 21</div>
          <div className="mt-4 flex gap-2">
            <button className="inline-flex h-8 items-center gap-1.5 rounded-md border border-border bg-transparent px-3 text-xs font-medium hover:bg-accent">
              <Navigation className="h-3.5 w-3.5" /> Get Directions
            </button>
            <button className="inline-flex h-8 items-center gap-1.5 rounded-md border border-border bg-transparent px-3 text-xs font-medium hover:bg-accent">
              <Phone className="h-3.5 w-3.5" /> Call Hotel
            </button>
          </div>
          <button
            onClick={() => setRooms((v) => !v)}
            className="mt-4 flex w-full items-center justify-between border-t border-border pt-3 text-xs font-semibold uppercase tracking-wider text-muted-foreground hover:text-foreground"
          >
            <span>Room Assignments</span>
            {rooms ? <ChevronDown className="h-4 w-4" /> : <ChevronRight className="h-4 w-4" />}
          </button>
          {rooms && (
            <table className="mt-3 w-full text-xs">
              <thead className="text-[10px] uppercase text-muted-foreground">
                <tr><th className="pb-2 text-left">Room</th><th className="pb-2 text-left">Players</th></tr>
              </thead>
              <tbody>
                <tr className="border-t border-border"><td className="py-2 font-mono">412</td><td className="py-2">Ethan Carter · Liam Brooks</td></tr>
                <tr className="border-t border-border"><td className="py-2 font-mono">414</td><td className="py-2">Owen Tremblay · Jaxon Lee</td></tr>
                <tr className="border-t border-border"><td className="py-2 font-mono">416</td><td className="py-2">Caleb Wright · Mason Lévesque</td></tr>
              </tbody>
            </table>
          )}
        </Card>
      )}

      <Card>
        <button
          onClick={() => setChecklist((v) => !v)}
          className="flex w-full items-center justify-between text-left"
        >
          <div>
            <div className="text-sm font-semibold">Equipment Checklist</div>
            <div className="mt-0.5 text-xs text-muted-foreground">0 of 10 packed</div>
          </div>
          {checklist ? <ChevronDown className="h-4 w-4 text-muted-foreground" /> : <ChevronRight className="h-4 w-4 text-muted-foreground" />}
        </button>
        {checklist && (
          <ul className="mt-4 space-y-2 text-sm">
            {["Skates", "Helmet", "Gloves", "Stick(s)", "Pads", "Jersey — Home", "Jersey — Away", "Water bottle", "Tape", "Mouth guard"].map((i) => (
              <li key={i} className="flex items-center gap-2">
                <input type="checkbox" className="h-4 w-4 rounded border-border" />
                <span>{i}</span>
              </li>
            ))}
          </ul>
        )}
      </Card>

      <Card>
        <div className="flex items-center justify-between">
          <SectionLabel>Tournament Notes</SectionLabel>
          <TealButton>Edit Notes</TealButton>
        </div>
        <p className="mt-3 text-sm text-muted-foreground">
          White jerseys for game 2. Dress sharp for team dinner Friday — no hoodies. Bring your own tape.
        </p>
      </Card>

      <Card>
        <div className="flex items-center justify-between">
          <SectionLabel>Attachments</SectionLabel>
          <button className="inline-flex h-8 items-center gap-1.5 rounded-md border border-border px-3 text-xs font-medium hover:bg-accent">
            <Upload className="h-3.5 w-3.5" /> Upload File
          </button>
        </div>
        <ul className="mt-3 space-y-2 text-sm">
          <li className="flex items-center justify-between rounded-md border border-border bg-background/50 px-3 py-2">
            <span>Tournament_Schedule.pdf</span>
            <span className="text-xs text-muted-foreground">248 KB</span>
          </li>
          <li className="flex items-center justify-between rounded-md border border-border bg-background/50 px-3 py-2">
            <span>Hotel_Confirmation.pdf</span>
            <span className="text-xs text-muted-foreground">112 KB</span>
          </li>
        </ul>
      </Card>
    </div>
  );
}

/* ============================================================
   GAME DETAIL
============================================================ */

function GameDetail({ team, onBack }: { team: TeamSummary; onBack: () => void }) {
  const [mediaFilter, setMediaFilter] = useState<"All" | "Photos" | "Highlights" | "Full Game" | "Tagged">("All");
  const rsvp = { yes: 15, no: 2, maybe: 1, noReply: 2 };

  return (
    <div className="space-y-6">
      <BackLink label="Schedule" onClick={onBack} />

      <div>
        <h1 className="text-2xl font-semibold tracking-tight">{team.name} vs Selkirk Wings</h1>
        <div className="mt-1 text-sm text-muted-foreground">Sat Nov 15 · 7:00 PM · MTS Iceplex — Rink B</div>
      </div>

      <div className="grid grid-cols-2 gap-3 md:grid-cols-4">
        {[
          { l: "Yes", v: rsvp.yes, c: "bg-[#00D4C8]/15 text-[#00D4C8] ring-[#00D4C8]/30" },
          { l: "No", v: rsvp.no, c: "bg-red-500/15 text-red-300 ring-red-500/30" },
          { l: "Maybe", v: rsvp.maybe, c: "bg-amber-500/15 text-amber-300 ring-amber-500/30" },
          { l: "No Reply", v: rsvp.noReply, c: "bg-muted text-muted-foreground ring-border" },
        ].map((p) => (
          <div key={p.l} className={cn("rounded-full px-4 py-2 text-center ring-1", p.c)}>
            <span className="text-sm font-semibold">{p.v}</span>{" "}
            <span className="text-[10px] font-bold uppercase tracking-wider">{p.l}</span>
          </div>
        ))}
      </div>

      <div className="flex gap-2">
        <TealButton variant="solid">Game Prep</TealButton>
        <TealButton>Stats</TealButton>
      </div>

      <div>
        <SectionLabel>Attendance</SectionLabel>
        <Card className="mt-3 p-0">
          <table className="w-full text-sm">
            <thead className="border-b border-border bg-muted/20 text-[10px] uppercase tracking-wider text-muted-foreground">
              <tr>
                <th className="px-4 py-3 text-left">Player</th>
                <th className="px-4 py-3 text-left">#</th>
                <th className="px-4 py-3 text-left">Status</th>
              </tr>
            </thead>
            <tbody>
              {ROSTER.map((p, i) => {
                const status = i % 4 === 0 ? "Maybe" : i % 5 === 0 ? "Out" : "Going";
                return (
                  <tr key={p.id} className="border-b border-border last:border-0">
                    <td className="px-4 py-3 font-medium">{p.name}</td>
                    <td className="px-4 py-3 font-mono text-muted-foreground">{p.number}</td>
                    <td className="px-4 py-3">
                      <span className={cn(
                        "rounded px-2 py-0.5 text-[10px] font-bold uppercase ring-1",
                        status === "Going" && "bg-[#00D4C8]/15 text-[#00D4C8] ring-[#00D4C8]/30",
                        status === "Maybe" && "bg-amber-500/15 text-amber-300 ring-amber-500/30",
                        status === "Out" && "bg-red-500/15 text-red-300 ring-red-500/30",
                      )}>{status}</span>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </Card>
      </div>

      <div>
        <SectionLabel>Post-Game Stats</SectionLabel>
        <Card className="mt-3">
          <div className="grid grid-cols-3 gap-4 text-center md:grid-cols-6">
            {[
              { l: "Shots", v: "32" },
              { l: "Blocks", v: "12" },
              { l: "Hits", v: "18" },
              { l: "PP", v: "1/3" },
              { l: "PK", v: "4/4" },
              { l: "FO%", v: "58" },
            ].map((s) => (
              <div key={s.l}>
                <div className="text-xl font-semibold">{s.v}</div>
                <div className="mt-1 text-[10px] font-bold uppercase tracking-wider text-muted-foreground">{s.l}</div>
              </div>
            ))}
          </div>
        </Card>
      </div>

      <div>
        <SectionLabel>Media</SectionLabel>
        <Card className="mt-3">
          <div className="flex flex-wrap gap-2">
            <button className="inline-flex h-9 items-center gap-1.5 rounded-md border border-border px-3 text-xs font-medium hover:bg-accent">
              <Camera className="h-3.5 w-3.5" /> Photos
            </button>
            <button className="inline-flex h-9 items-center gap-1.5 rounded-md border border-border px-3 text-xs font-medium hover:bg-accent">
              <Video className="h-3.5 w-3.5" /> Videos
            </button>
            <button className="inline-flex h-9 items-center gap-1.5 rounded-md border border-border px-3 text-xs font-medium hover:bg-accent">
              <Upload className="h-3.5 w-3.5" /> Record
            </button>
          </div>
          <div className="mt-4 flex flex-wrap gap-2">
            {(["All", "Photos", "Highlights", "Full Game", "Tagged"] as const).map((f) => (
              <button
                key={f}
                onClick={() => setMediaFilter(f)}
                className={cn(
                  "h-8 rounded-full border px-3 text-xs font-medium transition",
                  mediaFilter === f ? "border-[#00D4C8] bg-[#00D4C8]/10 text-[#00D4C8]" : "border-border text-muted-foreground hover:text-foreground"
                )}
              >
                {f}
              </button>
            ))}
          </div>
          <div className="mt-4 grid grid-cols-2 gap-3 md:grid-cols-4">
            {Array.from({ length: 8 }).map((_, i) => (
              <div key={i} className="aspect-video rounded-md border border-border bg-gradient-to-br from-muted/50 to-muted/20" />
            ))}
          </div>
        </Card>
      </div>
    </div>
  );
}
