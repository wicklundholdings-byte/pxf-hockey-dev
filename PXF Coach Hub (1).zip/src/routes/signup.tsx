import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { supabase } from "@/lib/supabase";
import { getRoleFromDB, pathForRole, type Role } from "@/lib/get-role";

export const Route = createFileRoute("/signup")({
  component: SignupPage,
});

function SignupPage() {
  const navigate = useNavigate();
  const [role, setRole] = useState<Role>("elite");
  const [fullName, setFullName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState<string | null>(null);
  const [awaitingConfirm, setAwaitingConfirm] = useState(false);
  const [resendMsg, setResendMsg] = useState<string | null>(null);
  const [resendBusy, setResendBusy] = useState(false);

  // If the user completes email confirmation in the same tab, route by role.
  useEffect(() => {
    if (!awaitingConfirm) return;
    const { data: sub } = supabase.auth.onAuthStateChange(async (_e, session) => {
      if (!session?.user) return;
      const dbRole = await getRoleFromDB(session.user.id);
      navigate({ to: pathForRole(dbRole ?? role), replace: true });
    });
    return () => sub.subscription.unsubscribe();
  }, [awaitingConfirm, role, navigate]);

  async function onSubmit(e: React.FormEvent) {
    e.preventDefault();
    setErr(null);
    setBusy(true);
    try {
      const { data, error } = await supabase.auth.signUp({
        email,
        password,
        options: {
          data: { full_name: fullName, role },
          emailRedirectTo:
            typeof window !== "undefined" ? `${window.location.origin}/auth` : undefined,
        },
      });
      if (error) {
        setErr(error.message);
        return;
      }
      if (data.session) {
        const dbRole = await getRoleFromDB(data.session.user.id);
        navigate({ to: pathForRole(dbRole ?? role), replace: true });
      } else {
        setAwaitingConfirm(true);
      }
    } finally {
      setBusy(false);
    }
  }

  async function onResend() {
    setResendMsg(null);
    setResendBusy(true);
    try {
      const { error } = await supabase.auth.resend({
        type: "signup",
        email,
        options: {
          emailRedirectTo:
            typeof window !== "undefined" ? `${window.location.origin}/auth` : undefined,
        },
      });
      setResendMsg(error ? error.message : "Confirmation email resent.");
    } finally {
      setResendBusy(false);
    }
  }

  return (
    <div
      className="flex min-h-screen items-center justify-center px-4"
      style={{ background: "#0D1117", color: "#FFFFFF" }}
    >
      <div
        className="w-full max-w-md rounded-2xl p-8 shadow-2xl"
        style={{ background: "#161B22", border: "1px solid #21262D" }}
      >
        <div className="mb-6 text-center">
          <div
            className="mx-auto mb-3 flex h-11 w-11 items-center justify-center rounded-xl text-lg font-black text-black"
            style={{ background: "linear-gradient(135deg,#00C4B4,#3DFF8F)" }}
          >
            P
          </div>
          <h1 className="text-2xl font-bold tracking-tight">
            {awaitingConfirm ? "Check your email" : "Create your PXF account"}
          </h1>
          <p className="mt-1 text-sm" style={{ color: "#8B949E" }}>
            {awaitingConfirm
              ? "Almost there — one click to activate your account."
              : "One account works across web and the PXF mobile app."}
          </p>
        </div>

        {awaitingConfirm ? (
          <div className="space-y-4">
            <div
              className="rounded-md px-4 py-3 text-sm"
              style={{
                background: "rgba(0,196,180,0.08)",
                border: "1px solid rgba(0,196,180,0.35)",
                color: "#3DFF8F",
              }}
            >
              We sent a confirmation link to <strong>{email}</strong>. Click it to activate your
              account.
            </div>

            <button
              type="button"
              onClick={onResend}
              disabled={resendBusy}
              className="w-full rounded-md px-4 py-2.5 text-sm font-semibold transition hover:opacity-90 disabled:opacity-60"
              style={{ background: "#0D1117", border: "1px solid #21262D", color: "#FFFFFF" }}
            >
              {resendBusy ? "Resending…" : "Resend email"}
            </button>

            {resendMsg && (
              <div className="text-center text-xs" style={{ color: "#8B949E" }}>
                {resendMsg}
              </div>
            )}

            <button
              type="button"
              onClick={() => setAwaitingConfirm(false)}
              className="w-full text-center text-xs"
              style={{ color: "#8B949E" }}
            >
              ← Use a different email
            </button>
          </div>
        ) : (
          <form onSubmit={onSubmit} className="space-y-4">
            <div>
              <span className="mb-2 block text-xs font-medium" style={{ color: "#8B949E" }}>
                I am a
              </span>
              <div className="grid grid-cols-3 gap-2">
                {(["elite", "team", "parent"] as const).map((r) => (
                  <button
                    key={r}
                    type="button"
                    onClick={() => setRole(r)}
                    className="rounded-full px-3 py-2 text-xs font-semibold transition"
                    style={{
                      background: role === r ? "rgba(0,196,180,0.12)" : "#0D1117",
                      border: role === r ? "1px solid #00C4B4" : "1px solid #21262D",
                      color: role === r ? "#00C4B4" : "#FFFFFF",
                    }}
                  >
                    {r === "elite" ? "Elite Coach" : r === "team" ? "Team Coach" : "Parent"}
                  </button>
                ))}
              </div>
            </div>

            <Field label="Full name">
              <input
                required
                value={fullName}
                onChange={(e) => setFullName(e.target.value)}
                autoComplete="name"
                className="w-full rounded-md px-3 py-2 text-sm outline-none"
                style={inputStyle}
              />
            </Field>
            <Field label="Email">
              <input
                type="email"
                required
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                autoComplete="email"
                className="w-full rounded-md px-3 py-2 text-sm outline-none"
                style={inputStyle}
              />
            </Field>
            <Field label="Password">
              <input
                type="password"
                required
                minLength={6}
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                autoComplete="new-password"
                className="w-full rounded-md px-3 py-2 text-sm outline-none"
                style={inputStyle}
              />
            </Field>

            {err && (
              <div
                className="rounded-md px-3 py-2 text-xs"
                style={{
                  background: "rgba(239,68,68,0.08)",
                  border: "1px solid rgba(239,68,68,0.35)",
                  color: "#fca5a5",
                }}
              >
                {err}
              </div>
            )}

            <button
              type="submit"
              disabled={busy}
              className="w-full rounded-md px-4 py-2.5 text-sm font-semibold text-black transition hover:opacity-90 disabled:opacity-60"
              style={{ background: "linear-gradient(90deg,#00C4B4,#3DFF8F)" }}
            >
              {busy ? "Creating account…" : "Create account"}
            </button>
          </form>
        )}

        <div className="mt-5 text-center text-xs" style={{ color: "#8B949E" }}>
          Already have an account?{" "}
          <Link to="/login" className="font-semibold" style={{ color: "#00C4B4" }}>
            Sign in
          </Link>
        </div>
      </div>
    </div>
  );
}

const inputStyle: React.CSSProperties = {
  background: "#0D1117",
  border: "1px solid #21262D",
  color: "#FFFFFF",
};

function Field({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <label className="block">
      <span className="mb-1 block text-xs font-medium" style={{ color: "#8B949E" }}>
        {label}
      </span>
      {children}
    </label>
  );
}
