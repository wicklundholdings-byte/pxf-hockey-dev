import { createFileRoute, Link, notFound } from "@tanstack/react-router";
import { useMemo, useState } from "react";
import { ChevronLeft, MapPin, Clock, Calendar, Users, ChevronDown, ChevronUp } from "lucide-react";
import { getCoachPage, type CoachPage, type BookingCamp } from "@/lib/booking-data";
import { Button } from "@/components/ui/button";
import { Stars, Footer } from "./book.$username.index";
import { cn } from "@/lib/utils";
import { RegistrationFlow } from "@/components/registration-flow";

export const Route = createFileRoute("/book/$username/camp/$campId")({
  head: ({ params }) => ({
    meta: [
      { title: `Register · ${params.campId} · PXF Hockey` },
      { name: "description", content: "Camp registration powered by PXF Hockey." },
    ],
  }),
  loader: ({ params }) => {
    const page = getCoachPage(params.username);
    const camp = page?.camps.find((c) => c.id === params.campId);
    if (!page || !camp) throw notFound();
    return { page, camp };
  },
  component: CampDetail,
  notFoundComponent: () => (
    <div className="flex min-h-screen items-center justify-center p-8 text-center">
      <h1 className="text-2xl font-bold">Camp not found</h1>
    </div>
  ),
});

function daysUntil(iso?: string) {
  if (!iso) return null;
  const d = Math.ceil((new Date(iso).getTime() - Date.now()) / 86400000);
  return d > 0 ? d : null;
}

function CampDetail() {
  const { page, camp } = Route.useLoaderData() as { page: CoachPage; camp: BookingCamp };
  const [bringOpen, setBringOpen] = useState(true);
  const [regOpen, setRegOpen] = useState(false);
  const remaining = camp.spotsTotal - camp.spotsTaken;
  const ebDays = daysUntil(camp.earlyBirdDeadline);
  const activePrice = ebDays && camp.earlyBirdPrice ? camp.earlyBirdPrice : camp.price;
  const avgStars = useMemo(() => camp.reviews.reduce((s, r) => s + r.stars, 0) / Math.max(camp.reviews.length, 1), [camp.reviews]);

  return (
    <div className="min-h-screen bg-background pb-28 text-foreground">
      {/* Back */}
      <div className="mx-auto max-w-4xl px-4 pt-4 sm:px-6">
        <Link to="/book/$username" params={{ username: page.username }} className="inline-flex items-center gap-1 text-sm font-semibold text-muted-foreground hover:text-foreground">
          <ChevronLeft className="h-4 w-4" /> Back to {page.school}
        </Link>
      </div>

      {/* Banner */}
      <div className="mx-auto mt-4 max-w-4xl px-4 sm:px-6">
        <div className="relative h-56 overflow-hidden rounded-2xl sm:h-72">
          <img src={camp.banner} alt={camp.name} className="h-full w-full object-cover" />
          <span className="absolute left-4 top-4 rounded-md bg-black/70 px-3 py-1.5 text-xs font-bold uppercase tracking-wider text-white backdrop-blur">
            {camp.skillLevel}
          </span>
        </div>
      </div>

      <div className="mx-auto mt-6 max-w-4xl space-y-6 px-4 sm:px-6">
        {/* Title block */}
        <div>
          <h1 className="text-2xl font-black sm:text-3xl">{camp.name}</h1>
          <div className="mt-2 flex flex-wrap gap-x-4 gap-y-2 text-sm text-muted-foreground">
            <span className="inline-flex items-center gap-1.5"><Calendar className="h-4 w-4" />{camp.dateRange}</span>
            <span className="inline-flex items-center gap-1.5"><Clock className="h-4 w-4" />{camp.times}</span>
            <span className="inline-flex items-center gap-1.5"><Users className="h-4 w-4" />{camp.ageGroup}</span>
          </div>
          <div className="mt-4 flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
            <div className="grid grid-cols-[minmax(0,1fr)_auto] items-center gap-3 sm:flex sm:items-center sm:gap-6">
              <div>
                <div className="text-3xl font-black">${activePrice}</div>
                {ebDays && camp.earlyBirdPrice && (
                  <div className="text-xs text-muted-foreground line-through">${camp.price}</div>
                )}
              </div>
              <div className="text-right sm:text-left">
                <div className={cn("text-sm font-bold", remaining <= 5 ? "text-orange-500" : "text-emerald-500")}>
                  {remaining <= 0 ? "Full" : remaining <= 5 ? `Only ${remaining} spots left` : `${remaining} spots available`}
                </div>
                {ebDays && camp.earlyBirdPrice && (
                  <div className="mt-1 text-xs text-emerald-500">Early bird ends in {ebDays} day{ebDays === 1 ? "" : "s"}</div>
                )}
              </div>
            </div>
            <Button
              onClick={() => setRegOpen(true)}
              className="w-full shrink-0 bg-gradient-to-r from-teal-500 to-emerald-500 px-8 text-white hover:opacity-90 sm:w-auto"
            >
              {remaining > 0 ? "Register Now" : "Join Waitlist"}
            </Button>
          </div>
        </div>

        {/* Description */}
        <div className="rounded-2xl border border-border bg-card p-5">
          <h2 className="text-base font-bold">About this camp</h2>
          <p className="mt-2 text-sm leading-relaxed text-muted-foreground">{camp.description}</p>
        </div>

        {/* Instructors */}
        <div className="rounded-2xl border border-border bg-card p-5">
          <h2 className="text-base font-bold">Instructor{camp.instructors.length > 1 ? "s" : ""}</h2>
          <div className="mt-3 grid gap-3 sm:grid-cols-2">
            {camp.instructors.map((i) => (
              <div key={i.name} className="flex items-start gap-3 rounded-xl border border-border p-3">
                <img src={i.photo} alt={i.name} className="h-14 w-14 shrink-0 rounded-full object-cover" />
                <div className="min-w-0">
                  <div className="font-semibold">{i.name}</div>
                  <div className="text-xs text-emerald-500">{i.credentials}</div>
                  <div className="mt-1 text-xs text-muted-foreground">{i.bio}</div>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* What to bring */}
        <div className="rounded-2xl border border-border bg-card">
          <button
            onClick={() => setBringOpen((v) => !v)}
            className="flex w-full items-center justify-between p-5 text-left"
          >
            <h2 className="text-base font-bold">What to Bring</h2>
            {bringOpen ? <ChevronUp className="h-4 w-4" /> : <ChevronDown className="h-4 w-4" />}
          </button>
          {bringOpen && (
            <ul className="space-y-1.5 px-5 pb-5 text-sm">
              {camp.whatToBring.map((b) => (
                <li key={b} className="flex items-start gap-2"><span className="mt-1.5 h-1.5 w-1.5 shrink-0 rounded-full bg-emerald-500" />{b}</li>
              ))}
            </ul>
          )}
        </div>

        {/* Location */}
        <div className="rounded-2xl border border-border bg-card p-5">
          <h2 className="text-base font-bold">Location</h2>
          <div className="mt-2 flex items-start gap-2 text-sm">
            <MapPin className="mt-0.5 h-4 w-4 shrink-0 text-emerald-500" />
            <div className="min-w-0">
              <div className="font-semibold">{camp.rink.name}</div>
              <div className="text-muted-foreground">{camp.rink.address}</div>
            </div>
          </div>
          <div className="mt-3 overflow-hidden rounded-xl border border-border">
            <iframe
              title="Map"
              className="h-56 w-full"
              loading="lazy"
              src={`https://www.google.com/maps?q=${encodeURIComponent(camp.rink.address)}&output=embed`}
            />
          </div>
          <a
            href={`https://www.google.com/maps/dir/?api=1&destination=${encodeURIComponent(camp.rink.address)}`}
            target="_blank"
            rel="noreferrer"
            className="mt-3 inline-flex text-sm font-semibold text-emerald-500 hover:underline"
          >
            Get Directions →
          </a>
        </div>

        {/* Reviews */}
        <div className="rounded-2xl border border-border bg-card p-5">
          <h2 className="text-base font-bold">Parent Reviews</h2>
          {camp.reviews.length === 0 ? (
            <p className="mt-2 text-sm text-muted-foreground">Be the first to review after attending.</p>
          ) : (
            <>
              <div className="mt-1 flex items-center gap-2 text-sm text-muted-foreground">
                <Stars value={avgStars} /> <span>{avgStars.toFixed(1)} · {camp.reviews.length} reviews</span>
              </div>
              <div className="mt-4 space-y-3">
                {camp.reviews.map((r) => (
                  <div key={r.id} className="rounded-xl border border-border p-4">
                    <Stars value={r.stars} />
                    <p className="mt-2 text-sm">{r.text}</p>
                    <p className="mt-2 text-xs text-muted-foreground">— {r.parent} · {r.date}</p>
                  </div>
                ))}
              </div>
            </>
          )}
        </div>

        {/* Refund policy */}
        <div className="rounded-2xl border border-border bg-muted/30 p-5">
          <h2 className="text-sm font-bold">Refund Policy</h2>
          <p className="mt-1 text-xs leading-relaxed text-muted-foreground">{camp.refundPolicy}</p>
        </div>
      </div>

      {/* Sticky register button */}
      <div className="fixed inset-x-0 bottom-0 z-40 border-t border-border bg-background/95 px-4 py-3 backdrop-blur sm:px-6">
        <div className="mx-auto flex max-w-4xl items-center justify-between gap-3">
          <div className="min-w-0">
            <div className="truncate text-sm font-semibold">{camp.name}</div>
            <div className="text-xs text-muted-foreground">${activePrice} · {remaining > 0 ? `${remaining} left` : "Waitlist"}</div>
          </div>
          <Button
            onClick={() => setRegOpen(true)}
            className="shrink-0 bg-gradient-to-r from-teal-500 to-emerald-500 px-6 text-white hover:opacity-90"
          >
            {remaining > 0 ? "Register Now" : "Join Waitlist"}
          </Button>
        </div>
      </div>

      {regOpen && <RegistrationFlow camp={camp} onClose={() => setRegOpen(false)} />}

      <Footer />
    </div>
  );
}

