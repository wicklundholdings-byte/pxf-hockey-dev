import { useState } from "react";
import { createFileRoute } from "@tanstack/react-router";
import {
  Search,
  Plus,
  Megaphone,
  Pin,
  Info,
  Paperclip,
  FileText,
  Clock,
  Send,
  Hash,
  Users,
  User,
  X,
} from "lucide-react";

export const Route = createFileRoute("/inbox")({
  head: () => ({
    meta: [
      { title: "Inbox · PXF Hockey" },
      { name: "description", content: "Team channels and direct messages." },
    ],
  }),
  component: Page,
});

type Tab = "Channels" | "Direct Messages";

type Channel = {
  id: string;
  name: string;
  members: number;
  preview: string;
  time?: string;
  unread?: boolean;
};

type DM = {
  id: string;
  name: string;
  role?: string;
  preview: string;
  time: string;
  unread?: boolean;
  initials: string;
};

type PersonOption = {
  id: string;
  name: string;
  role: string;
  initials: string;
};

const CHANNELS: Channel[] = [
  {
    id: "elite",
    name: "Elite Skating Camp",
    members: 38,
    preview: "Day 4 today! See you at 9am",
    time: "10m ago",
    unread: true,
  },
  {
    id: "u15",
    name: "U15 AA Elite",
    members: 22,
    preview: "Practice moved to Rink B",
    time: "2hrs ago",
  },
  {
    id: "goalie",
    name: "Goalie Development",
    members: 12,
    preview: "No messages yet",
  },
];

const DMS: DM[] = [
  {
    id: "sarah",
    name: "Sarah Wilson",
    preview: "Thanks for the update...",
    time: "2m ago",
    unread: true,
    initials: "SW",
  },
  {
    id: "mike",
    name: "Mike Thompson",
    preview: "Is Jake's payment due?",
    time: "1hr",
    initials: "MT",
  },
  {
    id: "mark",
    name: "Mark Ellis",
    role: "Staff",
    preview: "I can cover Monday",
    time: "Yesterday",
    initials: "ME",
  },
];

const PEOPLE: PersonOption[] = [
  { id: "sarah", name: "Sarah Wilson", role: "Parent", initials: "SW" },
  { id: "mike", name: "Mike Thompson", role: "Parent", initials: "MT" },
  { id: "mark", name: "Mark Ellis", role: "Staff", initials: "ME" },
  { id: "rachel", name: "Rachel Kim", role: "Parent", initials: "RK" },
  { id: "emma", name: "Emma Wilson", role: "Athlete", initials: "EW" },
  { id: "jake", name: "Jake Thompson", role: "Athlete", initials: "JT" },
];

type Msg = { from: "me" | "them"; author: string; text: string };

const THREAD: Msg[] = [
  {
    from: "me",
    author: "Jordan",
    text: "Day 4 today! See you at 9am at Rink A. Full gear required.",
  },
  { from: "them", author: "Sarah Wilson", text: "We'll be there!" },
  { from: "them", author: "Rachel Kim", text: "Emma is so excited!" },
];

const MEMBERS = ["EW", "JT", "SW", "RK", "MB", "AL", "DP", "+31"];

const PINNED = [
  { title: "Camp schedule (Week 1)", meta: "Pinned by Jordan · Jun 24" },
  { title: "Gear checklist", meta: "Pinned by Jordan · Jun 22" },
];

const FILES = [
  { name: "camp-schedule.pdf", size: "212 KB" },
  { name: "waiver-form.pdf", size: "88 KB" },
  { name: "rink-a-map.png", size: "540 KB" },
];

function Page() {
  const [tab, setTab] = useState<Tab>("Channels");
  const [search, setSearch] = useState("");
  const [draft, setDraft] = useState("");
  const [newOpen, setNewOpen] = useState(false);
  const [broadcastOpen, setBroadcastOpen] = useState(false);
  const [channels, setChannels] = useState<Channel[]>(CHANNELS);
  const [activeChannelId, setActiveChannelId] = useState(CHANNELS[0].id);
  const [threads, setThreads] = useState<Record<string, Msg[]>>({
    elite: THREAD,
  });

  const activeChannel = channels.find((c) => c.id === activeChannelId) ?? channels[0];
  const activeThread = threads[activeChannel.id] ?? [];


  return (
    <>
    <div className="grid grid-cols-1 lg:grid-cols-4 gap-4 h-[calc(100vh-8rem)] min-h-[640px]">
      {/* FAR LEFT */}
      <aside className="lg:col-span-1 flex flex-col rounded-lg border border-border bg-card overflow-hidden">
        <div className="p-4 border-b border-border space-y-3">
          <div className="flex items-center justify-between">
            <h2 className="text-lg font-semibold">Conversations</h2>
          </div>
          <div className="flex gap-2">
            <button onClick={() => setBroadcastOpen(true)} className="flex-1 inline-flex items-center justify-center gap-1.5 rounded-md bg-amber-500/20 hover:bg-amber-500/30 text-amber-200 border border-amber-500/40 px-3 py-1.5 text-xs font-medium">
              <Megaphone className="h-3.5 w-3.5" />
              Broadcast
            </button>
            <button onClick={() => setNewOpen(true)} className="flex-1 inline-flex items-center justify-center gap-1.5 rounded-md bg-teal-500 hover:bg-teal-400 text-teal-950 px-3 py-1.5 text-xs font-medium">
              <Plus className="h-3.5 w-3.5" />
              New
            </button>
          </div>
          <div className="relative">
            <Search className="absolute left-2.5 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
            <input
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="Search messages..."
              className="w-full rounded-md border border-border bg-background pl-8 pr-3 py-2 text-sm placeholder:text-muted-foreground focus:outline-none focus:ring-1 focus:ring-teal-500"
            />
          </div>
          <div className="grid grid-cols-2 gap-1 rounded-md bg-muted/40 p-1">
            {(["Channels", "Direct Messages"] as Tab[]).map((t) => (
              <button
                key={t}
                onClick={() => setTab(t)}
                className={`px-2 py-1.5 rounded text-xs font-medium transition-colors ${
                  tab === t
                    ? "bg-background text-foreground shadow-sm"
                    : "text-muted-foreground hover:text-foreground"
                }`}
              >
                {t}
              </button>
            ))}
          </div>
        </div>

        <div className="flex-1 overflow-y-auto">
          {tab === "Channels"
            ? channels.map((c) => (
                <button
                  key={c.id}
                  onClick={() => setActiveChannelId(c.id)}
                  className={`w-full text-left px-4 py-3 border-b border-border/60 hover:bg-muted/40 transition-colors ${
                    c.id === activeChannel.id ? "bg-muted/60" : ""
                  }`}
                >
                  <div className="flex items-start gap-3">
                    <div className="h-9 w-9 rounded-md bg-teal-500/20 text-teal-100 flex items-center justify-center shrink-0">
                      <Hash className="h-4 w-4" />
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center justify-between gap-2">
                        <div className="text-sm font-medium truncate">{c.name}</div>
                        <div className="flex items-center gap-1.5 shrink-0">
                          {c.time && (
                            <span className="text-xs text-muted-foreground">{c.time}</span>
                          )}
                          {c.unread && <span className="h-2 w-2 rounded-full bg-sky-400" />}
                        </div>
                      </div>
                      <div className="text-xs text-muted-foreground mt-0.5">
                        {c.members} members
                      </div>
                      <div className="text-xs text-muted-foreground truncate mt-1">
                        {c.preview}
                      </div>
                    </div>
                  </div>
                </button>
              ))
            : DMS.map((d) => (
                <button
                  key={d.id}
                  className="w-full text-left px-4 py-3 border-b border-border/60 hover:bg-muted/40 transition-colors flex gap-3 items-start"
                >
                  <div className="h-9 w-9 rounded-full bg-teal-500/20 text-teal-100 flex items-center justify-center text-xs font-semibold shrink-0">
                    {d.initials}
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center justify-between gap-2">
                      <div className="text-sm font-medium truncate">
                        {d.name}
                        {d.role && (
                          <span className="ml-1.5 text-xs text-muted-foreground">
                            ({d.role})
                          </span>
                        )}
                      </div>
                      <div className="flex items-center gap-1.5 shrink-0">
                        <span className="text-xs text-muted-foreground">{d.time}</span>
                        {d.unread && <span className="h-2 w-2 rounded-full bg-sky-400" />}
                      </div>
                    </div>
                    <div className="text-xs text-muted-foreground truncate mt-0.5">
                      {d.preview}
                    </div>
                  </div>
                </button>
              ))}
        </div>

        <div className="p-3 border-t border-border text-xs text-muted-foreground">
          Channels are created automatically when you add a camp or team.
        </div>
      </aside>

      {/* MIDDLE */}
      <section className="lg:col-span-2 flex flex-col rounded-lg border border-border bg-card overflow-hidden">
        <div className="px-5 py-3 border-b border-border flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="h-10 w-10 rounded-md bg-teal-500/20 text-teal-100 flex items-center justify-center">
              <Hash className="h-5 w-5" />
            </div>
            <div>
              <div className="text-base font-semibold">{activeChannel.name}</div>
              <div className="text-xs text-muted-foreground">
                {activeChannel.members} members
              </div>
            </div>
          </div>
          <div className="flex items-center gap-1 text-muted-foreground">
            <button className="p-2 rounded-md hover:bg-muted/60 hover:text-foreground">
              <Pin className="h-4 w-4" />
            </button>
            <button className="p-2 rounded-md hover:bg-muted/60 hover:text-foreground">
              <Search className="h-4 w-4" />
            </button>
            <button className="p-2 rounded-md hover:bg-muted/60 hover:text-foreground">
              <Info className="h-4 w-4" />
            </button>
          </div>
        </div>

        <div className="flex-1 overflow-y-auto p-5 space-y-4">
          {activeThread.length === 0 ? (
            <div className="h-full flex items-center justify-center text-sm text-muted-foreground">
              No messages yet. Say hello 👋
            </div>
          ) : (
            activeThread.map((m, i) => (
              <div
                key={i}
                className={`flex ${m.from === "me" ? "justify-end" : "justify-start"}`}
              >
                <div className="max-w-[75%]">
                  <div
                    className={`text-xs mb-1 ${
                      m.from === "me" ? "text-right text-muted-foreground" : "text-muted-foreground"
                    }`}
                  >
                    {m.author}
                  </div>
                  <div
                    className={`rounded-2xl px-4 py-2.5 text-sm ${
                      m.from === "me"
                        ? "bg-teal-500 text-teal-950 rounded-br-sm"
                        : "bg-muted text-foreground rounded-bl-sm"
                    }`}
                  >
                    {m.text}
                  </div>
                </div>
              </div>
            ))
          )}
        </div>

        <form
          onSubmit={(e) => {
            e.preventDefault();
            const text = draft.trim();
            if (!text) return;
            setThreads((prev) => ({
              ...prev,
              [activeChannel.id]: [
                ...(prev[activeChannel.id] ?? []),
                { from: "me", author: "Jordan", text },
              ],
            }));
            setDraft("");
          }}

          className="p-3 border-t border-border flex items-center gap-2"
        >
          <button
            type="button"
            className="p-2 rounded-md text-muted-foreground hover:bg-muted/60 hover:text-foreground"
          >
            <Paperclip className="h-4 w-4" />
          </button>
          <button
            type="button"
            className="p-2 rounded-md text-muted-foreground hover:bg-muted/60 hover:text-foreground"
          >
            <FileText className="h-4 w-4" />
          </button>
          <button
            type="button"
            className="p-2 rounded-md text-muted-foreground hover:bg-muted/60 hover:text-foreground"
          >
            <Clock className="h-4 w-4" />
          </button>
          <input
            value={draft}
            onChange={(e) => setDraft(e.target.value)}
            placeholder={`Message #${activeChannel.name.toLowerCase().replace(/\s+/g, "-")}`}
            className="flex-1 rounded-md border border-border bg-background px-3 py-2 text-sm placeholder:text-muted-foreground focus:outline-none focus:ring-1 focus:ring-teal-500"
          />
          <button
            type="submit"
            className="inline-flex items-center gap-1.5 rounded-md bg-teal-500 hover:bg-teal-400 text-teal-950 px-4 py-2 text-sm font-medium"
          >
            <Send className="h-4 w-4" />
            Send
          </button>
        </form>
      </section>

      {/* FAR RIGHT */}
      <aside className="lg:col-span-1 flex flex-col rounded-lg border border-border bg-card overflow-hidden">
        <div className="p-4 border-b border-border">
          <div className="text-base font-semibold">{activeChannel.name}</div>
          <div className="text-xs text-muted-foreground mt-0.5 flex items-center gap-1.5">
            <Users className="h-3.5 w-3.5" />
            {activeChannel.members} members
          </div>
          <div className="flex flex-wrap gap-1.5 mt-3">
            {MEMBERS.map((m, i) => (
              <div
                key={i}
                className="h-8 w-8 rounded-full bg-teal-500/20 text-teal-100 flex items-center justify-center text-[10px] font-semibold border border-card"
              >
                {m}
              </div>
            ))}
          </div>
        </div>

        <div className="flex-1 overflow-y-auto">
          <div className="p-4 border-b border-border">
            <div className="flex items-center gap-2 text-xs font-semibold uppercase tracking-wide text-muted-foreground mb-3">
              <Pin className="h-3.5 w-3.5" />
              Pinned Messages
            </div>
            <div className="space-y-2">
              {PINNED.map((p, i) => (
                <div
                  key={i}
                  className="rounded-md border border-border bg-background/40 p-2.5"
                >
                  <div className="text-sm">{p.title}</div>
                  <div className="text-xs text-muted-foreground mt-0.5">{p.meta}</div>
                </div>
              ))}
            </div>
          </div>

          <div className="p-4 border-b border-border">
            <div className="flex items-center gap-2 text-xs font-semibold uppercase tracking-wide text-muted-foreground mb-3">
              <Paperclip className="h-3.5 w-3.5" />
              Shared Files
            </div>
            <div className="space-y-2">
              {FILES.map((f, i) => (
                <div
                  key={i}
                  className="flex items-center gap-2 rounded-md border border-border bg-background/40 p-2.5"
                >
                  <FileText className="h-4 w-4 text-teal-300 shrink-0" />
                  <div className="flex-1 min-w-0">
                    <div className="text-sm truncate">{f.name}</div>
                    <div className="text-xs text-muted-foreground">{f.size}</div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>

        <div className="p-3 border-t border-border text-xs text-muted-foreground">
          Channels are created automatically when you add a camp or team.
        </div>
      </aside>
    </div>

    {newOpen && (
      <NewConversationModal
        onClose={() => setNewOpen(false)}
        onCreateChannel={(channel) => {
          setChannels((current) => [channel, ...current]);
          setActiveChannelId(channel.id);
          setTab("Channels");
          setNewOpen(false);
        }}
      />
    )}
    {broadcastOpen && <BroadcastModal onClose={() => setBroadcastOpen(false)} />}
    </>
  );
}

function ModalShell({
  title,
  onClose,
  children,
  maxWidth = "max-w-lg",
}: {
  title: string;
  onClose: () => void;
  children: React.ReactNode;
  maxWidth?: string;
}) {
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
      <div
        className="absolute inset-0 bg-black/70 backdrop-blur-sm"
        onClick={onClose}
      />
      <div className={`relative w-full ${maxWidth} rounded-lg border border-border bg-card shadow-xl`}>
        <div className="flex items-center justify-between px-5 py-4 border-b border-border">
          <h3 className="text-base font-semibold">{title}</h3>
          <button
            onClick={onClose}
            className="p-1 rounded-md text-muted-foreground hover:bg-muted/60 hover:text-foreground"
          >
            <X className="h-4 w-4" />
          </button>
        </div>
        <div className="p-5">{children}</div>
      </div>
    </div>
  );
}

function NewConversationModal({
  onClose,
  onCreateChannel,
}: {
  onClose: () => void;
  onCreateChannel: (channel: Channel) => void;
}) {
  const [mode, setMode] = useState<"choose" | "channel" | "dm">("choose");
  const [query, setQuery] = useState("");
  const [selected, setSelected] = useState<string | null>(null);
  const [name, setName] = useState("");
  const [channelMemberIds, setChannelMemberIds] = useState<string[]>([
    "sarah",
    "mark",
  ]);

  const people = PEOPLE.filter((p) =>
    p.name.toLowerCase().includes(query.toLowerCase()),
  );
  const selectedMembers = PEOPLE.filter((p) => channelMemberIds.includes(p.id));

  return (
    <ModalShell title="New Conversation" onClose={onClose}>
      {mode === "choose" && (
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
          <button
            onClick={() => setMode("channel")}
            className="text-left rounded-lg border border-border bg-background/40 hover:border-teal-500/60 hover:bg-teal-500/5 p-5 transition-colors"
          >
            <div className="h-10 w-10 rounded-md bg-teal-500/20 text-teal-100 flex items-center justify-center mb-3">
              <Hash className="h-5 w-5" />
            </div>
            <div className="text-sm font-semibold">New Channel</div>
            <div className="text-xs text-muted-foreground mt-1">
              Create a group for a camp or team
            </div>
          </button>
          <button
            onClick={() => setMode("dm")}
            className="text-left rounded-lg border border-border bg-background/40 hover:border-teal-500/60 hover:bg-teal-500/5 p-5 transition-colors"
          >
            <div className="h-10 w-10 rounded-md bg-teal-500/20 text-teal-100 flex items-center justify-center mb-3">
              <User className="h-5 w-5" />
            </div>
            <div className="text-sm font-semibold">Direct Message</div>
            <div className="text-xs text-muted-foreground mt-1">
              Message a parent or staff member
            </div>
          </button>
        </div>
      )}

      {mode === "channel" && (
        <form
          onSubmit={(e) => {
            e.preventDefault();
            if (!name.trim() || channelMemberIds.length === 0) return;
            onCreateChannel({
              id: `custom-${Date.now()}`,
              name: name.trim(),
              members: channelMemberIds.length,
              preview: "No messages yet",
              time: "Now",
            });
          }}
          className="space-y-4"
        >
          <div>
            <label className="text-xs font-medium text-muted-foreground">Channel name</label>
            <input
              autoFocus
              value={name}
              onChange={(e) => setName(e.target.value)}
              placeholder="e.g. U15 AA Elite"
              className="mt-1 w-full rounded-md border border-border bg-background px-3 py-2 text-sm focus:outline-none focus:ring-1 focus:ring-teal-500"
            />
          </div>
          <div className="space-y-2">
            <div className="flex items-center justify-between gap-2">
              <label className="text-xs font-medium text-muted-foreground">
                Channel members
              </label>
              <span className="text-xs text-muted-foreground">
                {channelMemberIds.length} selected
              </span>
            </div>
            <div className="relative">
              <Search className="absolute left-2.5 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              <input
                value={query}
                onChange={(e) => setQuery(e.target.value)}
                placeholder="Search parents or staff..."
                className="w-full rounded-md border border-border bg-background pl-8 pr-3 py-2 text-sm placeholder:text-muted-foreground focus:outline-none focus:ring-1 focus:ring-teal-500"
              />
            </div>
            {selectedMembers.length > 0 && (
              <div className="flex flex-wrap gap-1.5">
                {selectedMembers.map((member) => (
                  <span
                    key={member.id}
                    className="inline-flex items-center gap-1 rounded-full border border-teal-500/30 bg-teal-500/10 px-2 py-1 text-xs text-teal-100"
                  >
                    {member.name}
                  </span>
                ))}
              </div>
            )}
            <div className="max-h-52 overflow-y-auto rounded-md border border-border bg-background/40 p-1">
              {people.map((p) => {
                const checked = channelMemberIds.includes(p.id);
                return (
                  <button
                    type="button"
                    key={p.id}
                    onClick={() =>
                      setChannelMemberIds((current) =>
                        checked
                          ? current.filter((id) => id !== p.id)
                          : [...current, p.id],
                      )
                    }
                    className={`w-full text-left flex items-center gap-3 px-3 py-2 rounded-md border ${
                      checked
                        ? "border-teal-500/60 bg-teal-500/10"
                        : "border-transparent hover:bg-muted/50"
                    }`}
                  >
                    <div className="h-8 w-8 rounded-full bg-teal-500/20 text-teal-100 flex items-center justify-center text-xs font-semibold">
                      {p.initials}
                    </div>
                    <div className="flex-1">
                      <div className="text-sm">{p.name}</div>
                      <div className="text-xs text-muted-foreground">{p.role}</div>
                    </div>
                    <div
                      className={`h-4 w-4 rounded border ${
                        checked
                          ? "border-teal-400 bg-teal-500"
                          : "border-border bg-background"
                      }`}
                    />
                  </button>
                );
              })}
              {people.length === 0 && (
                <div className="text-xs text-muted-foreground text-center py-4">
                  No matches
                </div>
              )}
            </div>
          </div>
          <div className="flex justify-between items-center">
            <button
              type="button"
              onClick={() => setMode("choose")}
              className="text-xs text-muted-foreground hover:text-foreground"
            >
              ← Back
            </button>
            <button
              type="submit"
              disabled={!name.trim() || channelMemberIds.length === 0}
              className="inline-flex items-center gap-1.5 rounded-md bg-teal-500 hover:bg-teal-400 text-teal-950 px-4 py-2 text-sm font-medium disabled:opacity-40 disabled:cursor-not-allowed"
            >
              Create Channel
            </button>
          </div>
        </form>
      )}

      {mode === "dm" && (
        <div className="space-y-4">
          <div className="relative">
            <Search className="absolute left-2.5 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
            <input
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              placeholder="Search parents or staff..."
              className="w-full rounded-md border border-border bg-background pl-8 pr-3 py-2 text-sm placeholder:text-muted-foreground focus:outline-none focus:ring-1 focus:ring-teal-500"
            />
          </div>
          <div className="space-y-1 max-h-64 overflow-y-auto">
            {people.map((p) => (
              <button
                key={p.id}
                onClick={() => setSelected(p.id)}
                className={`w-full text-left flex items-center gap-3 px-3 py-2 rounded-md border ${
                  selected === p.id
                    ? "border-teal-500/60 bg-teal-500/10"
                    : "border-transparent hover:bg-muted/50"
                }`}
              >
                <div className="h-8 w-8 rounded-full bg-teal-500/20 text-teal-100 flex items-center justify-center text-xs font-semibold">
                  {p.initials}
                </div>
                <div className="flex-1">
                  <div className="text-sm">{p.name}</div>
                  <div className="text-xs text-muted-foreground">{p.role}</div>
                </div>
              </button>
            ))}
            {people.length === 0 && (
              <div className="text-xs text-muted-foreground text-center py-4">
                No matches
              </div>
            )}
          </div>
          <div className="flex justify-between">
            <button
              onClick={() => setMode("choose")}
              className="text-xs text-muted-foreground hover:text-foreground"
            >
              ← Back
            </button>
            <button
              disabled={!selected}
              className="inline-flex items-center gap-1.5 rounded-md bg-teal-500 hover:bg-teal-400 text-teal-950 px-4 py-2 text-sm font-medium disabled:opacity-40 disabled:cursor-not-allowed"
            >
              Start Conversation
            </button>
          </div>
        </div>
      )}
    </ModalShell>
  );
}

function BroadcastModal({ onClose }: { onClose: () => void }) {
  const [target, setTarget] = useState("All Parents");
  const [message, setMessage] = useState("");

  return (
    <ModalShell title="Send Broadcast" onClose={onClose}>
      <div className="space-y-4">
        <div>
          <label className="text-xs font-medium text-muted-foreground">Send to</label>
          <select
            value={target}
            onChange={(e) => setTarget(e.target.value)}
            className="mt-1 w-full rounded-md border border-border bg-background px-3 py-2 text-sm focus:outline-none focus:ring-1 focus:ring-amber-500"
          >
            <option>All Parents</option>
            <option>By Camp</option>
            <option>By Team</option>
          </select>
        </div>
        <div>
          <label className="text-xs font-medium text-muted-foreground">Message</label>
          <textarea
            value={message}
            onChange={(e) => setMessage(e.target.value)}
            rows={5}
            placeholder="Type your broadcast message..."
            className="mt-1 w-full rounded-md border border-border bg-background px-3 py-2 text-sm resize-none focus:outline-none focus:ring-1 focus:ring-amber-500"
          />
        </div>
        <div className="text-xs text-muted-foreground flex items-center gap-1.5">
          <Info className="h-3.5 w-3.5" />
          Parents cannot reply to broadcasts.
        </div>
        <div className="flex justify-end gap-2">
          <button
            onClick={onClose}
            className="px-4 py-2 rounded-md text-sm text-muted-foreground hover:bg-muted/60 hover:text-foreground"
          >
            Cancel
          </button>
          <button className="inline-flex items-center gap-1.5 rounded-md bg-amber-500 hover:bg-amber-400 text-amber-950 px-4 py-2 text-sm font-medium">
            <Megaphone className="h-4 w-4" />
            Send Broadcast
          </button>
        </div>
      </div>
    </ModalShell>
  );
}
