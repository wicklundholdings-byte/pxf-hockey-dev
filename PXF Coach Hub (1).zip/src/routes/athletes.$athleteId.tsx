import { useState } from "react";
import { createFileRoute, Link } from "@tanstack/react-router";
import { ChevronLeft, Mail, Plus, Pencil, Check } from "lucide-react";

export const Route = createFileRoute("/athletes/$athleteId")({
  head: () => ({
    meta: [
      { title: "Athlete Profile · PXF Hockey" },
      { name: "description", content: "Athlete profile, sessions, dryland and payments." },
    ],
  }),
  component: Page,
});

type TabKey = "Overview" | "History" | "Dryland" | "Notes" | "Payments";
const TABS: TabKey[] = ["Overview", "History", "Dryland", "Notes", "Payments"];

function Page() {
  const [tab, setTab] = useState<TabKey>("Overview");

  return (
    <div className="space-y-6">
      <Link
        to="/athletes"
        className="inline-flex items-center gap-1 text-xs font-medium text-muted-foreground hover:text-foreground"
      >
        <ChevronLeft className="h-3.5 w-3.5" /> Athletes
      </Link>

      <div className="flex flex-col gap-4 rounded-xl border border-border bg-card p-5 lg:flex-row lg:items-center lg:justify-between">
        <div className="flex items-center gap-4">
          <div className="flex h-16 w-16 items-center justify-center rounded-full bg-teal-500 text-lg font-semibold text-white">
            EW
          </div>
          <div>
            <h1 className="text-2xl font-semibold tracking-tight">Emma Wilson</h1>
            <div className="mt-1 flex flex-wrap items-center gap-2 text-xs text-muted-foreground">
              <span>14 yrs</span>
              <span>·</span>
              <span>Forward</span>
              <span className="ml-1 rounded-full bg-teal-500/15 px-2 py-0.5 text-[10px] font-semibold uppercase tracking-wide text-teal-100">
                Active
              </span>
            </div>
          </div>
        </div>
        <button className="inline-flex items-center gap-1.5 self-start rounded-lg border border-border bg-background px-3 py-2 text-xs font-semibold text-foreground hover:border-teal-400/60 hover:text-teal-100 lg:self-auto">
          <Mail className="h-3.5 w-3.5" /> Message Parent
        </button>
      </div>

      <div className="flex flex-wrap items-center gap-2 border-b border-border pb-2">
        {TABS.map((t) => (
          <button
            key={t}
            onClick={() => setTab(t)}
            className={`rounded-md px-3 py-1.5 text-xs font-medium transition ${
              tab === t
                ? "bg-teal-500/15 text-teal-100"
                : "text-muted-foreground hover:text-foreground"
            }`}
          >
            {t}
          </button>
        ))}
      </div>

      {tab === "Overview" && <Overview />}
      {tab === "History" && <HistoryTab />}
      {tab === "Dryland" && <DrylandTab />}
      {tab === "Notes" && <NotesTab />}
      {tab === "Payments" && <PaymentsTab />}
      {tab !== "Overview" && tab !== "History" && tab !== "Dryland" && tab !== "Notes" && tab !== "Payments" && (
        <div className="rounded-xl border border-border bg-card p-8 text-center text-sm text-muted-foreground">
          {tab} coming soon.
        </div>
      )}

    </div>
  );
}

function Overview() {
  const stats = [
    { label: "Total Sessions", value: "24" },
    { label: "Attendance", value: "94%" },
    { label: "Dryland", value: "3/5" },
    { label: "Balance", value: "$0" },
  ];

  return (
    <div className="space-y-5">
      <div className="grid grid-cols-2 gap-3 lg:grid-cols-4">
        {stats.map((s) => (
          <div key={s.label} className="rounded-xl border border-border bg-card p-4">
            <div className="text-[11px] font-semibold uppercase tracking-[0.15em] text-muted-foreground">
              {s.label}
            </div>
            <div className="mt-1 text-2xl font-semibold text-teal-100">{s.value}</div>
          </div>
        ))}
      </div>

      <div className="rounded-xl border border-border bg-card p-5">
        <h2 className="text-sm font-semibold">Details</h2>
        <dl className="mt-3 grid grid-cols-1 gap-3 text-xs sm:grid-cols-2">
          <Detail label="Teams" value="U15 AA Elite · House League" />
          <Detail label="Jersey" value="#11" />
          <Detail
            label="Parent"
            value="Sarah Wilson · sarah@email.com · 604-555-0142"
          />
          <Detail label="Joined" value="Sep 2024" />
        </dl>
      </div>

      <div className="rounded-xl border border-border bg-card p-5">
        <h2 className="text-sm font-semibold">Current Enrollments</h2>
        <ul className="mt-3 space-y-2">
          <Enrollment
            title="Elite Skating Camp"
            sub="Jul 1–5"
            status="Active"
            accent="teal"
          />
          <Enrollment
            title="Private Sessions"
            sub="Tue / Thu"
            status="Active"
            accent="purple"
          />
          <Enrollment
            title="Power Skating Program"
            sub="Dryland · 3/5 complete"
            status="In Progress"
            accent="teal"
            progress={{ current: 3, total: 5 }}
          />
        </ul>
      </div>
    </div>
  );
}

function Detail({ label, value }: { label: string; value: string }) {
  return (
    <div>
      <dt className="text-[11px] font-semibold uppercase tracking-wide text-muted-foreground">
        {label}
      </dt>
      <dd className="mt-0.5 text-foreground">{value}</dd>
    </div>
  );
}

function Enrollment({
  title,
  sub,
  status,
  accent,
  progress,
}: {
  title: string;
  sub: string;
  status: string;
  accent: "teal" | "purple";
  progress?: { current: number; total: number };
}) {
  const dot = accent === "teal" ? "bg-teal-500" : "bg-purple-500";
  const badge =
    status === "Active"
      ? "bg-teal-500/15 text-teal-100"
      : "bg-muted text-muted-foreground";
  return (
    <li className="flex flex-col gap-2 rounded-lg border border-border bg-background p-3 sm:flex-row sm:items-center sm:justify-between">
      <div className="flex items-center gap-3">
        <span className={`h-2 w-2 shrink-0 rounded-full ${dot}`} />
        <div>
          <div className="text-sm font-medium">{title}</div>
          <div className="text-xs text-muted-foreground">{sub}</div>
        </div>
      </div>
      <div className="flex items-center gap-3">
        {progress && (
          <div className="h-1.5 w-24 overflow-hidden rounded-full bg-muted">
            <div
              className="h-full rounded-full bg-teal-500"
              style={{ width: `${(progress.current / progress.total) * 100}%` }}
            />
          </div>
        )}
        <span
          className={`rounded-full px-2 py-0.5 text-[10px] font-semibold uppercase tracking-wide ${badge}`}
        >
          {status}
        </span>
      </div>
    </li>
  );
}

type SessionRow = {
  date: string;
  name: string;
  coach: string;
  duration: string;
  status: "Present" | "Absent";
};

const SESSIONS: SessionRow[] = [
  { date: "Jul 4, 2026", name: "Elite Skating Camp – Day 4", coach: "Jordan Doe", duration: "3 hrs", status: "Present" },
  { date: "Jul 3, 2026", name: "Private Session", coach: "Jordan Doe", duration: "1 hr", status: "Present" },
  { date: "Jul 2, 2026", name: "Elite Skating Camp – Day 3", coach: "Jordan Doe", duration: "3 hrs", status: "Present" },
  { date: "Jul 1, 2026", name: "Elite Skating Camp – Day 2", coach: "Jordan Doe", duration: "3 hrs", status: "Present" },
  { date: "Jun 26, 2026", name: "Private Session", coach: "Jordan Doe", duration: "1 hr", status: "Present" },
  { date: "Jun 24, 2026", name: "Elite Skating Camp – Day 1", coach: "Jordan Doe", duration: "3 hrs", status: "Absent" },
  { date: "Jun 19, 2026", name: "Private Session", coach: "Jordan Doe", duration: "1 hr", status: "Present" },
];

function HistoryTab() {
  return (
    <div className="space-y-4">
      <div className="flex flex-wrap items-center gap-4 rounded-xl border border-border bg-card px-5 py-3 text-xs">
        <span><span className="font-semibold text-foreground">24</span> <span className="text-muted-foreground">sessions</span></span>
        <span className="text-border">·</span>
        <span><span className="font-semibold text-teal-100">94%</span> <span className="text-muted-foreground">attendance</span></span>
        <span className="text-border">·</span>
        <span><span className="font-semibold text-foreground">1</span> <span className="text-muted-foreground">absence</span></span>
      </div>

      <ul className="divide-y divide-border rounded-xl border border-border bg-card">
        {SESSIONS.map((s, i) => (
          <li key={i} className="flex flex-col gap-2 px-5 py-3 sm:flex-row sm:items-center sm:justify-between">
            <div className="flex flex-col sm:flex-row sm:items-center sm:gap-3">
              <div className="w-28 shrink-0 text-xs font-medium text-muted-foreground">{s.date}</div>
              <div>
                <div className="text-sm font-medium">{s.name}</div>
                <div className="text-xs text-muted-foreground">{s.coach} · {s.duration}</div>
              </div>
            </div>
            <span
              className={`self-start rounded-full px-2 py-0.5 text-[10px] font-semibold uppercase tracking-wide sm:self-auto ${
                s.status === "Present"
                  ? "bg-teal-500/15 text-teal-100"
                  : "bg-red-500/15 text-red-300"
              }`}
            >
              {s.status}
            </span>
          </li>
        ))}
      </ul>
    </div>
  );
}

type DrylandSession = {
  number: number;
  title: string;
  duration: string;
  date: string | null;
  status: "Complete" | "Locked";
};

const DRYLAND: DrylandSession[] = [
  { number: 1, title: "Edge Work Basics", duration: "35 min", date: "Jun 15", status: "Complete" },
  { number: 2, title: "Crossover Fundamentals", duration: "40 min", date: "Jun 19", status: "Complete" },
  { number: 3, title: "Speed & Agility", duration: "38 min", date: "Jul 2", status: "Complete" },
  { number: 4, title: "Battle Footwork", duration: "42 min", date: null, status: "Locked" },
  { number: 5, title: "Full Speed Circuit", duration: "45 min", date: null, status: "Locked" },
];

function DrylandTab() {
  const completed = 3;
  const total = 5;
  const percent = Math.round((completed / total) * 100);

  return (
    <div className="space-y-5">
      <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
        <div className="flex flex-wrap items-center gap-3 text-xs">
          <span>
            <span className="font-semibold text-foreground">{completed}/{total}</span>
            <span className="text-muted-foreground"> sessions complete</span>
          </span>
          <span className="text-border">·</span>
          <span className="font-semibold text-teal-100">{percent}%</span>
          <span className="text-border">·</span>
          <span className="text-muted-foreground">Last activity: <span className="text-foreground">Jul 2</span></span>
        </div>
        <button className="inline-flex items-center gap-1.5 self-start rounded-lg bg-teal-500 px-3 py-2 text-xs font-semibold text-white hover:bg-teal-400 sm:self-auto">
          <Plus className="h-3.5 w-3.5" /> Assign Program
        </button>
      </div>

      <div className="rounded-xl border border-border bg-card p-5">
        <div className="flex items-center justify-between">
          <div>
            <div className="text-sm font-semibold">Power Skating Program</div>
            <div className="text-xs text-muted-foreground">PXF Series</div>
          </div>
        </div>
        <div className="mt-4">
          <div className="mb-1.5 flex items-center justify-between text-xs">
            <span className="text-muted-foreground">Progress</span>
            <span className="font-semibold text-foreground">{completed}/{total} sessions · {percent}%</span>
          </div>
          <div className="h-2 w-full overflow-hidden rounded-full bg-muted">
            <div
              className="h-full rounded-full bg-teal-500"
              style={{ width: `${percent}%` }}
            />
          </div>
        </div>
      </div>

      <ul className="divide-y divide-border rounded-xl border border-border bg-card">
        {DRYLAND.map((s) => (
          <li key={s.number} className="flex flex-col gap-2 px-5 py-3 sm:flex-row sm:items-center sm:justify-between">
            <div className="flex flex-col sm:flex-row sm:items-center sm:gap-4">
              <div className="w-20 shrink-0 text-xs font-medium text-muted-foreground">Session {s.number}</div>
              <div>
                <div className="text-sm font-medium">{s.title}</div>
                <div className="text-xs text-muted-foreground">{s.duration} · {s.date ? s.date : "Not started"}</div>
              </div>
            </div>
            <span
              className={`self-start rounded-full px-2 py-0.5 text-[10px] font-semibold uppercase tracking-wide sm:self-auto ${
                s.status === "Complete"
                  ? "bg-emerald-500/15 text-emerald-300"
                  : "bg-muted text-muted-foreground"
              }`}
            >
              {s.status === "Complete" ? "Complete" : "Locked"}
            </span>
          </li>
        ))}
      </ul>

      <p className="text-xs text-muted-foreground">
        Must complete previous session to unlock
      </p>
    </div>
  );
}

type NoteCard = {
  category: string;
  body: string;
  author: string;
  date: string;
};

const PINNED_NOTES: NoteCard[] = [
  {
    category: "Strengths",
    body: "Strong edges, explosive first step, excellent hockey sense and awareness.",
    author: "Jordan Doe",
    date: "Jun 28, 2026",
  },
  {
    category: "Development Areas",
    body: "Crossovers on backhand side need work. Struggles with tight turns at high speed. Focus on hip rotation drills.",
    author: "Jordan Doe",
    date: "Jun 28, 2026",
  },
  {
    category: "Goals",
    body: "Make AAA Midget by next season. Improve backward skating evaluation score to 85+.",
    author: "Jordan Doe",
    date: "Jun 15, 2026",
  },
];

const SESSION_NOTES = [
  {
    date: "Jul 3",
    author: "Jordan Doe",
    body: "Great improvement on inside edges today. Speed is noticeably better.",
  },
  {
    date: "Jun 26",
    author: "Jordan Doe",
    body: "Worked on crossover sequences. Right side still weak — assign extra reps.",
  },
];

function NotesTab() {
  return (
    <div className="space-y-5">
      <div className="flex items-center justify-between">
        <div className="text-sm font-semibold">Athlete Notes</div>
        <button className="inline-flex items-center gap-1.5 rounded-lg bg-teal-500 px-3 py-2 text-xs font-semibold text-white hover:bg-teal-400">
          <Plus className="h-3.5 w-3.5" /> Add Note
        </button>
      </div>

      <div className="grid grid-cols-1 gap-4 lg:grid-cols-3">
        {PINNED_NOTES.map((note) => (
          <div
            key={note.category}
            className="rounded-xl border border-border bg-card p-4"
          >
            <div className="flex items-center justify-between">
              <h3 className="text-xs font-semibold uppercase tracking-wide text-teal-100">
                {note.category}
              </h3>
              <button className="text-muted-foreground hover:text-foreground">
                <Pencil className="h-3.5 w-3.5" />
              </button>
            </div>
            <p className="mt-2 text-sm leading-relaxed text-foreground">
              {note.body}
            </p>
            <div className="mt-3 text-xs text-muted-foreground">
              {note.author} · {note.date}
            </div>
          </div>
        ))}
      </div>

      <div>
        <h3 className="text-sm font-semibold">Session Notes</h3>
        <ul className="mt-3 space-y-3">
          {SESSION_NOTES.map((note, i) => (
            <li key={i} className="rounded-xl border border-border bg-card p-4">
              <div className="text-xs font-medium text-teal-100">
                {note.date} · {note.author}
              </div>
              <p className="mt-1 text-sm leading-relaxed text-foreground">
                {note.body}
              </p>
            </li>
          ))}
        </ul>
      </div>

      <p className="text-xs text-muted-foreground">
        All coaches in your school can view and add notes.
      </p>
    </div>
  );
}

type PaymentRow = {
  date: string;
  description: string;
  amount: string;
  status: "Paid" | "Due";
  receipt: boolean;
};

const PAYMENTS: PaymentRow[] = [
  { date: "Jun 1", description: "Elite Skating Camp", amount: "$150", status: "Paid", receipt: true },
  { date: "May 1", description: "Private Sessions (May)", amount: "$720", status: "Paid", receipt: true },
  { date: "Apr 1", description: "Private Sessions (Apr)", amount: "$360", status: "Paid", receipt: true },
];

const UPCOMING = { date: "Jul 8", description: "Private Sessions (Jul)", amount: "$180", status: "Due" as const };

function PaymentsTab() {
  return (
    <div className="space-y-5">
      <div className="flex flex-wrap items-center gap-4 rounded-xl border border-border bg-card px-5 py-3 text-xs">
        <span>
          <span className="font-semibold text-foreground">Total Paid:</span>
          <span className="text-muted-foreground"> $1,230</span>
        </span>
        <span className="text-border">·</span>
        <span>
          <span className="font-semibold text-foreground">Outstanding:</span>
          <span className="text-muted-foreground"> $0</span>
        </span>
        <span className="text-border">·</span>
        <span className="inline-flex items-center gap-1.5 text-emerald-300">
          <Check className="h-3.5 w-3.5" /> All payments current
        </span>
      </div>

      <div className="overflow-hidden rounded-xl border border-border bg-card">
        <table className="w-full text-xs">
          <thead>
            <tr className="border-b border-border text-left text-muted-foreground">
              <th className="px-5 py-3 font-semibold">Date</th>
              <th className="px-5 py-3 font-semibold">Description</th>
              <th className="px-5 py-3 font-semibold">Amount</th>
              <th className="px-5 py-3 font-semibold">Status</th>
              <th className="px-5 py-3 font-semibold">Receipt</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-border">
            {PAYMENTS.map((p, i) => (
              <tr key={i}>
                <td className="px-5 py-3 text-muted-foreground">{p.date}</td>
                <td className="px-5 py-3 text-foreground">{p.description}</td>
                <td className="px-5 py-3 text-foreground">{p.amount}</td>
                <td className="px-5 py-3">
                  <span className="rounded-full bg-emerald-500/15 px-2 py-0.5 text-[10px] font-semibold uppercase tracking-wide text-emerald-300">
                    {p.status}
                  </span>
                </td>
                <td className="px-5 py-3">
                  <button className="text-teal-100 hover:text-teal-100/80 hover:underline">
                    Receipt
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      <div>
        <h3 className="text-sm font-semibold">Upcoming</h3>
        <div className="mt-3 rounded-xl border border-border bg-card p-4">
          <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
            <div className="grid grid-cols-1 gap-1 sm:grid-cols-4 sm:gap-4">
              <div className="text-xs text-muted-foreground">{UPCOMING.date}</div>
              <div className="text-sm font-medium text-foreground">{UPCOMING.description}</div>
              <div className="text-sm font-medium text-foreground">{UPCOMING.amount}</div>
              <div>
                <span className="rounded-full bg-amber-500/15 px-2 py-0.5 text-[10px] font-semibold uppercase tracking-wide text-amber-300">
                  {UPCOMING.status}
                </span>
              </div>
            </div>
            <button className="inline-flex items-center gap-1.5 self-start rounded-lg bg-teal-500 px-3 py-2 text-xs font-semibold text-white hover:bg-teal-400 sm:self-auto">
              Send Invoice
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
