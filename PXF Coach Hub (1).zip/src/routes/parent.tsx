import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useEffect } from "react";
import { useAuth } from "@/hooks/useAuth";
import { supabase } from "@/lib/supabase";

export const Route = createFileRoute("/parent")({
  head: () => ({
    meta: [
      { title: "Parent — PXF Hockey" },
      { name: "robots", content: "noindex" },
    ],
  }),
  component: ParentDashboard,
});

function ParentDashboard() {
  const { session, loading } = useAuth();
  const navigate = useNavigate();

  useEffect(() => {
    if (!loading && !session) {
      navigate({ to: "/login", replace: true, search: { redirect: "/parent" } });
    }
  }, [loading, session, navigate]);

  if (loading || !session) {
    return (
      <div
        className="flex min-h-screen items-center justify-center text-sm"
        style={{ background: "#0D1117", color: "#8B949E" }}
      >
        Loading…
      </div>
    );
  }

  async function handleSignOut() {
    await supabase.auth.signOut();
    navigate({ to: "/login", replace: true });
  }

  return (
    <div className="min-h-screen px-4 py-10" style={{ background: "#0D1117", color: "#FFFFFF" }}>
      <div className="mx-auto max-w-4xl space-y-6">
        <div className="flex items-start justify-between gap-4">
          <div>
            <h1 className="text-3xl font-bold tracking-tight">Parent Dashboard</h1>
            <p className="mt-1 text-sm" style={{ color: "#8B949E" }}>
              Signed in as {session.user.email}
            </p>
          </div>
          <button
            onClick={handleSignOut}
            className="rounded-md px-4 py-2 text-sm font-semibold transition hover:opacity-80"
            style={{ background: "#21262D", color: "#FFFFFF", border: "1px solid #30363D" }}
          >
            Sign out
          </button>
        </div>

        <div className="grid gap-4 sm:grid-cols-2">
          <StatCard label="My Athletes" value="0" />
          <StatCard label="Upcoming Events" value="0" />
        </div>
      </div>
    </div>
  );
}

function StatCard({ label, value }: { label: string; value: string }) {
  return (
    <div
      className="rounded-xl p-5"
      style={{ background: "#161B22", border: "1px solid #21262D" }}
    >
      <div
        className="text-[11px] font-semibold uppercase tracking-wider"
        style={{ color: "#8B949E" }}
      >
        {label}
      </div>
      <div className="mt-1 text-3xl font-bold tabular-nums" style={{ color: "#00C4B4" }}>
        {value}
      </div>
    </div>
  );
}
