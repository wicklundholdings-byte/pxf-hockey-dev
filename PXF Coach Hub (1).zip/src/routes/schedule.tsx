import { useMemo, useState } from "react";
import { createFileRoute, Link } from "@tanstack/react-router";
import { ChevronLeft, ChevronRight, Plus } from "lucide-react";

export const Route = createFileRoute("/schedule")({
  head: () => ({
    meta: [
      { title: "Schedule · PXF Hockey" },
      { name: "description", content: "Weekly schedule of camps, privates and practices." },
    ],
  }),
  component: Page,
});

type EventType = "CAMP" | "PRIVATE" | "PRACTICE";
type Ev = {
  id: string;
  type: EventType;
  title: string;
  rink?: string;
  date: string; // YYYY-MM-DD
  start: number; // hour float (e.g. 9, 16.5)
  end: number;
  to: string;
  params?: Record<string, string>;
};

const EVENTS: Ev[] = [
  { id: "c1", type: "CAMP", title: "Elite Skating Camp D1", rink: "Rink A", date: "2026-07-01", start: 9, end: 12, to: "/camps/$campId", params: { campId: "1" } },
  { id: "c2", type: "CAMP", title: "Elite Skating Camp D2", rink: "Rink A", date: "2026-07-02", start: 9, end: 12, to: "/camps/$campId", params: { campId: "1" } },
  { id: "c3", type: "CAMP", title: "Elite Skating Camp D3", rink: "Rink A", date: "2026-07-03", start: 9, end: 12, to: "/camps/$campId", params: { campId: "1" } },
  { id: "p1", type: "PRIVATE", title: "Emma Wilson – Private", date: "2026-07-03", start: 16.5, end: 17.5, to: "/privates/$privateId", params: { privateId: "emma-wilson" } },
  { id: "c4", type: "CAMP", title: "Elite Skating Camp D4", rink: "Rink A", date: "2026-07-04", start: 9, end: 12, to: "/camps/$campId", params: { campId: "1" } },
  { id: "c5", type: "CAMP", title: "Elite Skating Camp D5", rink: "Rink A", date: "2026-07-05", start: 9, end: 12, to: "/camps/$campId", params: { campId: "1" } },
  { id: "p2", type: "PRIVATE", title: "Emma Wilson – Private", date: "2026-07-08", start: 16.5, end: 17.5, to: "/privates/$privateId", params: { privateId: "emma-wilson" } },
  { id: "p3", type: "PRIVATE", title: "Emma Wilson – Private", date: "2026-07-10", start: 16.5, end: 17.5, to: "/privates/$privateId", params: { privateId: "emma-wilson" } },
];

const DAYS = ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"];
const HOURS = Array.from({ length: 16 }, (_, i) => i + 6); // 6am–9pm
const DAY_HOURS = Array.from({ length: 11 }, (_, i) => i + 8); // 8am–6pm
const HOUR_PX = 56;

const TYPE_STYLES: Record<EventType, string> = {
  CAMP: "bg-teal-500/20 border-teal-400/60 text-teal-100 hover:bg-teal-500/30",
  PRIVATE: "bg-purple-500/20 border-purple-400/60 text-purple-100 hover:bg-purple-500/30",
  PRACTICE: "bg-blue-500/20 border-blue-400/60 text-blue-100 hover:bg-blue-500/30",
};

const KEY_DOTS: { label: string; cls: string; type: EventType }[] = [
  { label: "CAMP", cls: "bg-teal-400", type: "CAMP" },
  { label: "PRIVATE", cls: "bg-purple-400", type: "PRIVATE" },
  { label: "PRACTICE", cls: "bg-blue-400", type: "PRACTICE" },
];

type ViewMode = "Month" | "Week" | "Day";
type Filter = "All" | "Camps" | "Privates" | "Practices";
const FILTERS: Filter[] = ["All", "Camps", "Privates", "Practices"];

function startOfWeek(d: Date) {
  const x = new Date(d);
  x.setHours(0, 0, 0, 0);
  x.setDate(x.getDate() - x.getDay());
  return x;
}
function fmtISO(d: Date) {
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;
}
function fmtHour(h: number) {
  const hr = Math.floor(h);
  const m = Math.round((h - hr) * 60);
  const ampm = hr >= 12 ? "PM" : "AM";
  const hh = ((hr + 11) % 12) + 1;
  return m ? `${hh}:${String(m).padStart(2, "0")} ${ampm}` : `${hh} ${ampm}`;
}

function Page() {
  const [view, setView] = useState<ViewMode>("Week");
  const [filter, setFilter] = useState<Filter>("All");
  const [weekStart, setWeekStart] = useState<Date>(new Date("2026-07-01T00:00:00"));
  const [dayDate, setDayDate] = useState<Date>(new Date("2026-07-04T00:00:00"));
  const [createOpen, setCreateOpen] = useState(false);

  const days = useMemo(
    () =>
      Array.from({ length: 7 }, (_, i) => {
        const d = new Date(weekStart);
        d.setDate(d.getDate() + i);
        return d;
      }),
    [weekStart],
  );

  const filtered = EVENTS.filter((e) => {
    if (filter === "All") return true;
    if (filter === "Camps") return e.type === "CAMP";
    if (filter === "Privates") return e.type === "PRIVATE";
    return e.type === "PRACTICE";
  });

  const rangeLabel = useMemo(() => {
    if (view === "Day") {
      return dayDate.toLocaleDateString(undefined, { weekday: "long", month: "short", day: "numeric", year: "numeric" });
    }
    return `${days[0].toLocaleDateString(undefined, { month: "short", day: "numeric" })} – ${days[6].toLocaleDateString(undefined, { month: "short", day: "numeric", year: "numeric" })}`;
  }, [view, dayDate, days]);

  function shift(delta: number) {
    if (view === "Day") {
      const d = new Date(dayDate);
      d.setDate(d.getDate() + delta);
      setDayDate(d);
    } else {
      const d = new Date(weekStart);
      d.setDate(d.getDate() + delta * 7);
      setWeekStart(d);
    }
  }

  return (
    <div className="space-y-5">
      <div className="flex flex-wrap items-start justify-between gap-4">
        <div>
          <div className="text-[11px] font-semibold uppercase tracking-[0.18em] text-muted-foreground">Schedule</div>
          <h1 className="mt-1 text-2xl font-semibold tracking-tight">All sessions & ice</h1>
          <p className="mt-1 text-sm text-muted-foreground">Camps, privates and practices in one place.</p>
        </div>
        <div className="flex items-center gap-2">
          <div className="inline-flex rounded-lg border border-border bg-card p-0.5">
            {(["Month", "Week", "Day"] as ViewMode[]).map((m) => (
              <button
                key={m}
                onClick={() => setView(m)}
                className={`rounded-md px-3 py-1.5 text-xs font-medium transition ${
                  view === m ? "bg-teal-500/20 text-teal-100" : "text-muted-foreground hover:text-foreground"
                }`}
              >
                {m}
              </button>
            ))}
          </div>
          <button
            onClick={() => setCreateOpen(true)}
            className="inline-flex items-center gap-1.5 rounded-lg bg-gradient-to-r from-teal-500 to-cyan-500 px-3 py-1.5 text-xs font-semibold text-white shadow hover:opacity-90"
          >
            <Plus className="h-3.5 w-3.5" /> Create
          </button>
        </div>
      </div>

      <div className="flex flex-wrap items-center justify-between gap-3">
        <div className="flex flex-wrap items-center gap-1.5">
          {FILTERS.map((f) => (
            <button
              key={f}
              onClick={() => setFilter(f)}
              className={`rounded-full border px-3 py-1 text-xs font-medium transition ${
                filter === f
                  ? "border-teal-400/60 bg-teal-500/15 text-teal-100"
                  : "border-border bg-card text-muted-foreground hover:text-foreground"
              }`}
            >
              {f}
            </button>
          ))}
        </div>
        <div className="flex items-center gap-3">
          <div className="flex items-center gap-3 text-[11px] text-muted-foreground">
            {KEY_DOTS.map((k) => (
              <span key={k.label} className="inline-flex items-center gap-1.5">
                <span className={`h-2 w-2 rounded-full ${k.cls}`} /> {k.label}
              </span>
            ))}
          </div>
          <div className="inline-flex items-center gap-1 rounded-lg border border-border bg-card px-1 py-0.5">
            <button onClick={() => shift(-1)} className="rounded p-1 text-muted-foreground hover:text-foreground">
              <ChevronLeft className="h-4 w-4" />
            </button>
            <span className="px-2 text-xs font-medium">{rangeLabel}</span>
            <button onClick={() => shift(1)} className="rounded p-1 text-muted-foreground hover:text-foreground">
              <ChevronRight className="h-4 w-4" />
            </button>
          </div>
        </div>
      </div>

      {view === "Week" && <WeekGrid days={days} events={filtered} />}
      {view === "Month" && <MonthView year={2026} month={6} events={filtered} />}
      {view === "Day" && <DayView day={dayDate} events={filtered} />}

      {createOpen && <CreateModal onClose={() => setCreateOpen(false)} />}
    </div>
  );
}

type IceSlot = { id: string; rink: string; date: string; start: number; end: number };
const ICE_SLOTS: IceSlot[] = [
  { id: "i1", rink: "Rink B", date: "2026-07-04", start: 18, end: 20 },
  { id: "i2", rink: "Rink B", date: "2026-07-06", start: 18, end: 20 },
  { id: "i3", rink: "Rink A", date: "2026-07-07", start: 7, end: 9 },
];

function WeekGrid({ days, events }: { days: Date[]; events: Ev[] }) {
  const [openIce, setOpenIce] = useState<IceSlot | null>(null);
  return (
    <div className="relative overflow-hidden rounded-xl border border-border bg-card">
      <div className="grid grid-cols-[64px_repeat(7,minmax(0,1fr))] border-b border-border bg-muted/20">
        <div />
        {days.map((d) => (
          <div key={d.toISOString()} className="px-2 py-2 text-center">
            <div className="text-[10px] font-semibold uppercase tracking-widest text-muted-foreground">
              {DAYS[d.getDay()]}
            </div>
            <div className="mt-0.5 text-sm font-semibold">{d.getDate()}</div>
          </div>
        ))}
      </div>
      <div className="relative grid grid-cols-[64px_repeat(7,minmax(0,1fr))]">
        <div>
          {HOURS.map((h) => (
            <div
              key={h}
              style={{ height: HOUR_PX }}
              className="border-b border-border/60 pr-2 pt-1 text-right text-[10px] text-muted-foreground"
            >
              {fmtHour(h)}
            </div>
          ))}
        </div>
        {days.map((d) => {
          const iso = fmtISO(d);
          const dayEvents = events.filter((e) => e.date === iso);
          const daySlots = ICE_SLOTS.filter((s) => s.date === iso);
          return (
            <div key={iso} className="relative border-l border-border/60">
              {HOURS.map((h) => (
                <div key={h} style={{ height: HOUR_PX }} className="border-b border-border/60" />
              ))}
              {daySlots.map((s) => {
                const top = (s.start - HOURS[0]) * HOUR_PX;
                const height = Math.max(24, (s.end - s.start) * HOUR_PX - 4);
                return (
                  <button
                    key={s.id}
                    onClick={() => setOpenIce(s)}
                    style={{ top, height }}
                    className="absolute inset-x-1 rounded-md border border-dashed border-orange-500/60 bg-orange-500/15 p-1.5 text-left text-[11px] leading-tight text-orange-200 transition hover:bg-orange-500/25"
                  >
                    <div className="font-semibold truncate">{s.rink} · Unassigned</div>
                    <div className="opacity-80">
                      {fmtHour(s.start)} – {fmtHour(s.end)}
                    </div>
                  </button>
                );
              })}
              {dayEvents.map((e) => {
                const top = (e.start - HOURS[0]) * HOUR_PX;
                const height = Math.max(24, (e.end - e.start) * HOUR_PX - 4);
                return (
                  <Link
                    key={e.id}
                    to={e.to as any}
                    params={e.params as any}
                    style={{ top, height }}
                    className={`absolute inset-x-1 rounded-md border p-1.5 text-[11px] leading-tight transition ${TYPE_STYLES[e.type]}`}
                  >
                    <div className="font-semibold truncate">{e.title}</div>
                    <div className="opacity-80">
                      {fmtHour(e.start)} – {fmtHour(e.end)}
                    </div>
                  </Link>
                );
              })}
            </div>
          );
        })}
      </div>
      {openIce && <IcePopup slot={openIce} onClose={() => setOpenIce(null)} />}
    </div>
  );
}

function IcePopup({ slot, onClose }: { slot: IceSlot; onClose: () => void }) {
  const d = new Date(slot.date + "T00:00:00");
  const label = `${slot.rink} · ${d.toLocaleDateString(undefined, { weekday: "short", month: "short", day: "numeric" })} · ${fmtHour(slot.start)} – ${fmtHour(slot.end)}`;
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 p-4 backdrop-blur-sm" onClick={onClose}>
      <div
        className="w-full max-w-sm rounded-xl border border-border bg-card p-5 shadow-2xl"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="mb-4 text-sm font-semibold">{label}</div>
        <div className="flex flex-col gap-2">
          <button onClick={onClose} className="rounded-lg bg-gradient-to-r from-teal-500 to-cyan-500 px-3 py-2 text-xs font-semibold text-white">
            + Create Camp
          </button>
          <button onClick={onClose} className="rounded-lg border border-purple-400/60 bg-purple-500/15 px-3 py-2 text-xs font-semibold text-purple-100">
            + Add Private
          </button>
          <button onClick={onClose} className="rounded-lg border border-border bg-muted/20 px-3 py-2 text-xs font-medium text-muted-foreground">
            Leave Open
          </button>
        </div>
      </div>
    </div>
  );
}

function DayView({ day, events }: { day: Date; events: Ev[] }) {
  const [openIce, setOpenIce] = useState<IceSlot | null>(null);
  const iso = fmtISO(day);
  const list = events.filter((e) => e.date === iso);
  const slots = ICE_SLOTS.filter((s) => s.date === iso);

  return (
    <div className="relative overflow-hidden rounded-xl border border-border bg-card">
      <div className="border-b border-border bg-muted/20 px-3 py-2 text-center text-sm font-semibold">
        {day.toLocaleDateString(undefined, { weekday: "long", month: "short", day: "numeric" })}
      </div>
      <div className="relative grid grid-cols-[64px_1fr]">
        <div>
          {DAY_HOURS.map((h) => (
            <div
              key={h}
              style={{ height: HOUR_PX }}
              className="border-b border-border/60 pr-2 pt-1 text-right text-[10px] text-muted-foreground"
            >
              {fmtHour(h)}
            </div>
          ))}
        </div>
        <div className="relative border-l border-border/60">
          {DAY_HOURS.map((h) => (
            <div key={h} style={{ height: HOUR_PX }} className="border-b border-border/60" />
          ))}
          {slots.map((s) => {
            const top = (s.start - DAY_HOURS[0]) * HOUR_PX;
            const height = Math.max(24, (s.end - s.start) * HOUR_PX - 4);
            return (
              <button
                key={s.id}
                onClick={() => setOpenIce(s)}
                style={{ top, height }}
                className="absolute inset-x-2 rounded-md border border-dashed border-orange-500/60 bg-orange-500/15 p-2 text-left text-xs leading-tight text-orange-200 transition hover:bg-orange-500/25"
              >
                <div className="font-semibold truncate">{s.rink} · Unassigned</div>
                <div className="opacity-80">
                  {fmtHour(s.start)} – {fmtHour(s.end)}
                </div>
              </button>
            );
          })}
          {list.map((e) => {
            const top = (e.start - DAY_HOURS[0]) * HOUR_PX;
            const height = Math.max(24, (e.end - e.start) * HOUR_PX - 4);
            const title = e.type === "CAMP" && e.rink
              ? e.title.replace(/\s*D(\d+)$/, " – Day $1") + " · " + e.rink
              : e.title;
            return (
              <Link
                key={e.id}
                to={e.to as any}
                params={e.params as any}
                style={{ top, height }}
                className={`absolute inset-x-2 rounded-md border p-2 text-xs leading-tight transition ${TYPE_STYLES[e.type]}`}
              >
                <div className="font-semibold truncate">{title}</div>
                <div className="opacity-80">
                  {fmtHour(e.start)} – {fmtHour(e.end)}
                </div>
              </Link>
            );
          })}
        </div>
      </div>
      {openIce && <IcePopup slot={openIce} onClose={() => setOpenIce(null)} />}
    </div>
  );
}

function MonthView({ year, month, events }: { year: number; month: number; events: Ev[] }) {
  const [selected, setSelected] = useState<string | null>(null);
  const first = new Date(year, month, 1);
  const startPad = first.getDay();
  const daysInMonth = new Date(year, month + 1, 0).getDate();
  const cells: (Date | null)[] = [];
  for (let i = 0; i < startPad; i++) cells.push(null);
  for (let d = 1; d <= daysInMonth; d++) cells.push(new Date(year, month, d));
  while (cells.length % 7 !== 0) cells.push(null);
  const today = "2026-07-04";
  const monthLabel = first.toLocaleDateString(undefined, { month: "long", year: "numeric" });
  const selectedEvents = selected ? events.filter((e) => e.date === selected) : [];

  return (
    <div className="space-y-3">
      <div className="text-sm font-semibold">{monthLabel}</div>
      <div className="overflow-hidden rounded-xl border border-border bg-card">
        <div className="grid grid-cols-7 border-b border-border bg-muted/20">
          {DAYS.map((d) => (
            <div key={d} className="px-2 py-2 text-center text-[10px] font-semibold uppercase tracking-widest text-muted-foreground">
              {d}
            </div>
          ))}
        </div>
        <div className="grid grid-cols-7">
          {cells.map((d, i) => {
            if (!d) return <div key={i} className="h-28 border-b border-l border-border/60 bg-muted/5 first:border-l-0" />;
            const iso = fmtISO(d);
            const dayEvents = events.filter((e) => e.date === iso);
            const isToday = iso === today;
            const isSelected = iso === selected;
            return (
              <button
                key={i}
                onClick={() => setSelected(isSelected ? null : iso)}
                className={`relative h-28 border-b border-l border-border/60 p-1.5 text-left transition first:border-l-0 hover:bg-muted/10 ${
                  isSelected ? "bg-muted/20" : ""
                }`}
              >
                <div className="flex justify-end">
                  <span
                    className={`inline-flex h-6 w-6 items-center justify-center rounded-full text-xs font-semibold ${
                      isToday ? "bg-teal-500 text-white" : "text-foreground"
                    }`}
                  >
                    {d.getDate()}
                  </span>
                </div>
                <div className="mt-1 space-y-1">
                  {dayEvents.slice(0, 3).map((e) =>
                    e.type === "PRIVATE" ? (
                      <div key={e.id} className="flex items-center gap-1 text-[10px] text-purple-200">
                        <span className="h-1.5 w-1.5 rounded-full bg-purple-400" />
                        <span className="truncate">{e.title.replace(" – Private", "")}</span>
                      </div>
                    ) : (
                      <div
                        key={e.id}
                        className={`truncate rounded px-1 py-0.5 text-[10px] font-medium ${
                          e.type === "CAMP"
                            ? "bg-teal-500/25 text-teal-100"
                            : "bg-blue-500/25 text-blue-100"
                        }`}
                      >
                        {e.title.replace(/\s*D\d+$/, "").replace(/\s*–.*$/, "").trim() ||
                          e.title}
                      </div>
                    ),
                  )}
                </div>
              </button>
            );
          })}
        </div>
      </div>
      {selected && (
        <div className="rounded-xl border border-border bg-card p-4">
          <div className="mb-2 text-sm font-semibold">
            {new Date(selected + "T00:00:00").toLocaleDateString(undefined, {
              weekday: "long",
              month: "long",
              day: "numeric",
            })}
          </div>
          {selectedEvents.length === 0 ? (
            <p className="text-sm text-muted-foreground">No events.</p>
          ) : (
            <ul className="space-y-2">
              {selectedEvents.map((e) => (
                <li key={e.id}>
                  <Link
                    to={e.to as any}
                    params={e.params as any}
                    className={`block rounded-md border p-2 text-xs ${TYPE_STYLES[e.type]}`}
                  >
                    <div className="font-semibold">{e.title}</div>
                    <div className="opacity-80">
                      {fmtHour(e.start)} – {fmtHour(e.end)}
                    </div>
                  </Link>
                </li>
              ))}
            </ul>
          )}
        </div>
      )}
    </div>
  );
}


function CreateModal({ onClose }: { onClose: () => void }) {
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 p-4 backdrop-blur-sm">
      <div className="w-full max-w-lg rounded-2xl border border-border bg-card p-6 shadow-2xl">
        <div className="mb-4 flex items-center justify-between">
          <h2 className="text-lg font-semibold">What would you like to create?</h2>
          <button onClick={onClose} className="rounded p-1 text-muted-foreground hover:text-foreground">
            ✕
          </button>
        </div>
        <p className="text-sm text-muted-foreground">
          Use the Camps & Privates page to create camps and private sessions.
        </p>
        <div className="mt-4 flex justify-end">
          <Link
            to="/camps"
            onClick={onClose}
            className="rounded-lg bg-gradient-to-r from-teal-500 to-cyan-500 px-3 py-1.5 text-xs font-semibold text-white"
          >
            Go to Camps & Privates
          </Link>
        </div>
      </div>
    </div>
  );
}
