import { createFileRoute } from "@tanstack/react-router";
import { useAccount } from "@/components/account-provider";
import { AssociationSettings } from "@/components/association-settings";
import { CoachSettings } from "@/components/coach-settings";

export const Route = createFileRoute("/settings")({
  head: () => ({
    meta: [
      { title: "Settings · PXF Hockey" },
      { name: "description", content: "Profile, staff, ice, website, notifications, and billing settings." },
    ],
  }),
  component: Page,
});

function Page() {
  const { account } = useAccount();
  if (account.role === "association-admin") return <AssociationSettings />;
  return <CoachSettings />;
}

