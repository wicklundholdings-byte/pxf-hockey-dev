import { createFileRoute } from "@tanstack/react-router";
import { CampDetail } from "@/components/camp-detail";

export const Route = createFileRoute("/camps/$campId")({
  head: () => ({
    meta: [
      { title: "Camp Detail · PXF Hockey" },
      { name: "description", content: "Camp details, schedule, registrations, and payments." },
    ],
  }),
  component: CampDetailRoute,
});

function CampDetailRoute() {
  const { campId } = Route.useParams();
  return <CampDetail campId={campId} />;
}
