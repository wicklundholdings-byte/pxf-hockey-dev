import { createFileRoute } from "@tanstack/react-router";
import { AssociationWebsite } from "@/components/association-website";

export const Route = createFileRoute("/website")({
  head: () => ({
    meta: [
      { title: "Website · PXF Hockey" },
      { name: "description", content: "Build and manage the public-facing association website." },
    ],
  }),
  component: AssociationWebsite,
});
