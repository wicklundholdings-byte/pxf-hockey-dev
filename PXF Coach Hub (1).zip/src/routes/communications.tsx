import { createFileRoute } from "@tanstack/react-router";
import { useAccount } from "@/components/account-provider";
import { AssociationCommunications } from "@/components/association-communications";

export const Route = createFileRoute("/communications")({
  head: () => ({
    meta: [
      { title: "Communications · PXF Hockey" },
      { name: "description", content: "Broadcasts, messages, and newsletters for PXF Hockey associations." },
    ],
  }),
  component: Page,
});

function Page() {
  const { account } = useAccount();
  if (account.role === "association-admin") return <AssociationCommunications />;
  return (
    <div className="rounded-lg border border-dashed border-border p-12 text-center">
      <h2 className="text-xl font-semibold">Communications</h2>
      <p className="mt-2 text-sm text-muted-foreground">Available in the Association Admin view.</p>
    </div>
  );
}
