import { createFileRoute } from "@tanstack/react-router";
import { useMemo, useState } from "react";
import { ChevronDown, ChevronRight, X, Snowflake } from "lucide-react";
import { cn } from "@/lib/utils";
import { useAccount } from "@/components/account-provider";
import { AssociationAdminDashboard } from "@/components/association-admin-dashboard";
import { TeamCoachDashboard } from "@/components/team-coach-dashboard";

export const Route = createFileRoute("/dashboard")({
  head: () => ({
    meta: [
      { title: "Dashboard · PXF Hockey" },
      { name: "description", content: "Elite Coach operations dashboard for PXF Hockey." },
    ],
  }),
  component: Dashboard,
});

/* ---------- Types & mock data ---------- */

type EventType = "CAMP" | "PRACTICE" | "GAME" | "PRIVATE";

type Event = {
  id: string;
  day: "today" | "week";
  date: string;
  time: string;
  name: string;
  type: EventType;
  location: string;
  attendance: string;
  instructor?: string;
};

const todayEvents: Event[] = [
  { id: "t1", day: "today", date: "Fri Jul 03", time: "6:00 AM", name: "Elite Skating Camp · Day 5", type: "CAMP", location: "Rink A", attendance: "38/40", instructor: "Coach Maddox" },
  { id: "t2", day: "today", date: "Fri Jul 03", time: "9:30 AM", name: "Power Skating Private — L. Tremblay", type: "PRIVATE", location: "Rink C", attendance: "1/1", instructor: "Coach Maddox" },
  { id: "t3", day: "today", date: "Fri Jul 03", time: "5:30 PM", name: "U14 AA Practice", type: "PRACTICE", location: "Rink A", attendance: "19/20", instructor: "Coach Park" },
];

const weekEvents: Event[] = [
  { id: "w1", day: "week", date: "Sat Jul 04", time: "8:00 AM", name: "Elite Skating Camp · Day 6", type: "CAMP", location: "Rink A", attendance: "38/40" },
  { id: "w2", day: "week", date: "Sat Jul 04", time: "1:00 PM", name: "Showcase Game vs. Riverside", type: "GAME", location: "Civic Arena", attendance: "—" },
  { id: "w3", day: "week", date: "Sun Jul 05", time: "9:00 AM", name: "Goalie Development Camp", type: "CAMP", location: "Rink B", attendance: "12/14" },
  { id: "w4", day: "week", date: "Mon Jul 06", time: "7:00 AM", name: "Stickhandling Private — A. Chen", type: "PRIVATE", location: "Rink C", attendance: "1/1" },
  { id: "w5", day: "week", date: "Tue Jul 07", time: "4:30 PM", name: "U16 AAA Practice", type: "PRACTICE", location: "Rink B", attendance: "22/22" },
];

const pendingBookings = [
  { id: "p1", athlete: "Mason Lévesque", date: "Sat Jul 04 · 9:00 AM" },
  { id: "p2", athlete: "Priya Singh", date: "Sun Jul 05 · 7:30 AM" },
  { id: "p3", athlete: "Eli Tanaka", date: "Tue Jul 07 · 4:00 PM" },
];

const unassignedIce = 4;

const typeBadge: Record<EventType, string> = {
  CAMP: "bg-teal-500/10 text-teal-300 ring-teal-500/30",
  PRACTICE: "bg-emerald-500/10 text-emerald-300 ring-emerald-500/30",
  GAME: "bg-red-500/10 text-red-300 ring-red-500/30",
  PRIVATE: "bg-purple-500/10 text-purple-300 ring-purple-500/30",
};

/* ---------- Small building blocks ---------- */

function SectionLabel({ children }: { children: React.ReactNode }) {
  return (
    <div className="text-[11px] font-semibold uppercase tracking-[0.18em] text-muted-foreground">
      {children}
    </div>
  );
}

function MetricCard({ label, value, sub }: { label: string; value: string; sub: string }) {
  return (
    <div className="rounded-xl border border-border border-l-2 border-l-[#00D4C8] bg-card p-6">
      <div className="text-[11px] font-semibold uppercase tracking-[0.18em] text-muted-foreground">
        {label}
      </div>
      <div className="mt-3 text-3xl font-semibold tracking-tight text-foreground">{value}</div>
      <div className="mt-1.5 text-xs text-muted-foreground">{sub}</div>
    </div>
  );
}

function EventCard({
  event,
  onOpen,
}: {
  event: Event;
  onOpen: (e: Event) => void;
}) {
  return (
    <button
      onClick={() => onOpen(event)}
      className="group flex w-full items-center gap-5 rounded-xl border border-border bg-card px-5 py-4 text-left transition hover:border-[#00D4C8]/50 hover:bg-card/80"
    >
      <div className="w-20 shrink-0">
        <div className="text-lg font-semibold tracking-tight text-[#00D4C8]">{event.time}</div>
      </div>
      <div className="min-w-0 flex-1">
        <div className="flex items-center gap-2">
          <span className="truncate text-sm font-semibold text-foreground">{event.name}</span>
          <span
            className={cn(
              "shrink-0 rounded-full px-2 py-0.5 text-[10px] font-bold tracking-wider ring-1 ring-inset",
              typeBadge[event.type]
            )}
          >
            {event.type}
          </span>
        </div>
        <div className="mt-1 text-xs text-muted-foreground">{event.location}</div>
      </div>
      <div className="shrink-0 rounded-full border border-border bg-background/60 px-3 py-1 text-xs font-medium text-muted-foreground">
        {event.attendance}
      </div>
    </button>
  );
}

/* ---------- Dashboard ---------- */

function Dashboard() {
  const { account } = useAccount();
  const [selected, setSelected] = useState<Event | null>(null);
  const [weekOpen, setWeekOpen] = useState(false);
  const greeting = useMemo(() => {
    const h = new Date().getHours();
    if (h < 12) return "Good morning";
    if (h < 18) return "Good afternoon";
    return "Good evening";
  }, []);

  if (account.role === "association-admin") return <AssociationAdminDashboard />;
  if (account.role === "team-coach") return <TeamCoachDashboard />;

  const firstName = (account.name ?? "Coach").split(" ")[0];
  const today = "Today · Fri, Jul 3";

  return (
    <div className="mx-auto max-w-[1400px] space-y-10">
      {/* Header row */}
      <div className="flex items-start justify-between gap-6">
        <div>
          <h1 className="text-3xl font-semibold tracking-tight text-foreground">
            {greeting}, {firstName}.
          </h1>
          <p className="mt-1.5 text-sm text-muted-foreground">Friday, July 3, 2026</p>
        </div>
      </div>

      {/* Metric row — 3 cards */}
      <div className="grid grid-cols-1 gap-4 md:grid-cols-3">
        <MetricCard
          label="Revenue this month"
          value="$84,320"
          sub="+12.4% vs last month"
        />
        <MetricCard
          label="Active athletes"
          value="218"
          sub="Across all camps & teams"
        />
        <MetricCard
          label="Today's sessions"
          value="3"
          sub="Next at 6:00 AM"
        />
      </div>

      {/* Main content */}
      <div className="grid grid-cols-1 gap-8 lg:grid-cols-[65fr_35fr]">
        {/* LEFT — Today */}
        <div className="space-y-4">
          <SectionLabel>{today}</SectionLabel>
          <div className="space-y-3">
            {todayEvents.map((e) => (
              <EventCard key={e.id} event={e} onOpen={setSelected} />
            ))}
          </div>

          {/* This week collapse */}
          <div className="pt-2">
            <button
              onClick={() => setWeekOpen((v) => !v)}
              className="flex w-full items-center justify-between rounded-lg px-1 py-2 text-left text-[11px] font-semibold uppercase tracking-[0.18em] text-muted-foreground transition hover:text-foreground"
            >
              <span>This week</span>
              <ChevronDown
                className={cn(
                  "h-5 w-5 transition-transform",
                  weekOpen && "rotate-180"
                )}
              />
            </button>
            {weekOpen && (
              <div className="mt-3 space-y-3">
                {weekEvents.map((e) => (
                  <EventCard key={e.id} event={e} onOpen={setSelected} />
                ))}
              </div>
            )}
          </div>
        </div>

        {/* RIGHT — Needs attention */}
        <div className="space-y-4">
          <SectionLabel>Needs attention</SectionLabel>
          <div className="rounded-xl border border-border bg-card">
            <ul className="divide-y divide-border/70">
              {pendingBookings.map((b) => (
                <li key={b.id} className="flex items-center justify-between gap-3 px-4 py-3.5">
                  <div className="min-w-0">
                    <div className="truncate text-sm font-medium text-foreground">{b.athlete}</div>
                    <div className="truncate text-xs text-muted-foreground">{b.date}</div>
                  </div>
                  <div className="flex shrink-0 gap-1.5">
                    <button className="rounded-md bg-[#00D4C8] px-2.5 py-1 text-[11px] font-semibold text-black hover:opacity-90">
                      Confirm
                    </button>
                    <button className="rounded-md border border-border bg-card px-2.5 py-1 text-[11px] font-semibold text-foreground hover:bg-accent hover:text-foreground">
                      Decline
                    </button>
                  </div>
                </li>
              ))}
              <li className="flex items-center justify-between gap-3 px-4 py-3.5">
                <div className="flex items-center gap-3 min-w-0">
                  <div className="flex h-8 w-8 shrink-0 items-center justify-center rounded-md bg-[#00D4C8]/10 text-[#00D4C8]">
                    <Snowflake className="h-4 w-4" />
                  </div>
                  <div className="min-w-0">
                    <div className="truncate text-sm font-medium text-foreground">
                      {unassignedIce} unassigned ice slots
                    </div>
                    <div className="truncate text-xs text-muted-foreground">
                      No instructor assigned
                    </div>
                  </div>
                </div>
                <button className="inline-flex shrink-0 items-center gap-0.5 text-xs font-semibold text-[#00D4C8] hover:opacity-80">
                  Assign <ChevronRight className="h-3 w-3" />
                </button>
              </li>
            </ul>
            <div className="border-t border-border px-4 py-2.5">
              <button className="text-xs font-semibold text-muted-foreground hover:text-foreground">
                View all
              </button>
            </div>
          </div>
        </div>
      </div>

      {selected && <EventDetailPanel event={selected} onClose={() => setSelected(null)} />}
    </div>
  );
}

function EventDetailPanel({ event, onClose }: { event: Event; onClose: () => void }) {
  return (
    <>
      <div className="fixed inset-0 z-30 bg-black/40 backdrop-blur-sm animate-in fade-in" onClick={onClose} />
      <aside className="fixed inset-y-0 right-0 z-40 flex w-full max-w-md flex-col border-l border-border bg-card shadow-2xl animate-in slide-in-from-right">
        <div className="flex items-start justify-between border-b border-border p-5">
          <div>
            <span
              className={cn(
                "rounded-full px-2 py-0.5 text-[10px] font-bold tracking-wider ring-1 ring-inset",
                typeBadge[event.type]
              )}
            >
              {event.type}
            </span>
            <h2 className="mt-2 text-lg font-bold leading-tight">{event.name}</h2>
            <p className="mt-1 text-xs text-muted-foreground">
              {event.date} · {event.time}
            </p>
          </div>
          <button
            onClick={onClose}
            className="rounded-md p-1.5 text-muted-foreground hover:bg-accent hover:text-foreground"
            aria-label="Close"
          >
            <X className="h-4 w-4" />
          </button>
        </div>
        <div className="flex-1 space-y-4 overflow-y-auto p-5 text-sm">
          <div>
            <div className="text-[11px] uppercase tracking-wider text-muted-foreground">Location</div>
            <div className="mt-1 font-medium">{event.location}</div>
          </div>
          {event.instructor && (
            <div>
              <div className="text-[11px] uppercase tracking-wider text-muted-foreground">Instructor</div>
              <div className="mt-1 font-medium">{event.instructor}</div>
            </div>
          )}
          <div>
            <div className="text-[11px] uppercase tracking-wider text-muted-foreground">Attendance</div>
            <div className="mt-1 font-medium">{event.attendance}</div>
          </div>
        </div>
      </aside>
    </>
  );
}
