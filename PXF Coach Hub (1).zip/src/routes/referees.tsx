import { createFileRoute } from "@tanstack/react-router";
import { useAccount } from "@/components/account-provider";
import { AssociationReferees } from "@/components/association-referees";

export const Route = createFileRoute("/referees")({
  head: () => ({
    meta: [
      { title: "Referees · PXF Hockey" },
      { name: "description", content: "Referee pool, assignments, and payments for PXF Hockey associations." },
    ],
  }),
  component: Page,
});

function Page() {
  const { account } = useAccount();
  if (account.role === "association-admin") return <AssociationReferees />;
  return (
    <div className="rounded-lg border border-dashed border-border p-12 text-center">
      <h2 className="text-xl font-semibold">Referees</h2>
      <p className="mt-2 text-sm text-muted-foreground">Available in the Association Admin view.</p>
    </div>
  );
}
