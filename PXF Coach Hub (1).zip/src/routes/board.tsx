import { createFileRoute } from "@tanstack/react-router";
import { AssociationBoard } from "@/components/association-board";

export const Route = createFileRoute("/board")({
  head: () => ({
    meta: [
      { title: "Board & Staff · PXF Hockey" },
      { name: "description", content: "Manage board members and staff with role-based portal permissions." },
    ],
  }),
  component: Page,
});

function Page() {
  return <AssociationBoard />;
}
