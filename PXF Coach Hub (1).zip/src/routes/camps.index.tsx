import { createFileRoute } from "@tanstack/react-router";
import { AssociationCamps } from "@/components/association-camps";

export const Route = createFileRoute("/camps/")({
  head: () => ({
    meta: [
      { title: "Camps & Privates · PXF Hockey" },
      { name: "description", content: "Camps, privates, practices, and clinics for PXF Hockey." },
    ],
  }),
  component: AssociationCamps,
});

