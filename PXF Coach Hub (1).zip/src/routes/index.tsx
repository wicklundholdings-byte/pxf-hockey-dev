import { createFileRoute, Link } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { PricingPlans } from "@/components/pricing-plans";
import img7802 from "@/assets/IMG_7802.png.asset.json";
import img7803 from "@/assets/IMG_7803.png.asset.json";
import img7804 from "@/assets/IMG_7804.png.asset.json";
import img7805 from "@/assets/IMG_7805.png.asset.json";
import img7806 from "@/assets/IMG_7806.png.asset.json";
import img7807 from "@/assets/IMG_7807.png.asset.json";
import img7808 from "@/assets/IMG_7808.png.asset.json";
import img7809 from "@/assets/IMG_7809.png.asset.json";
import img7810 from "@/assets/IMG_7810.png.asset.json";
import img7811 from "@/assets/IMG_7811.png.asset.json";

const SHOT = {
  dashboard: img7802.url,
  events: img7803.url,
  teamOverview: img7804.url,
  teamSchedule: img7805.url,
  gameDetail: img7806.url,
  tournamentLogistics: img7807.url,
  tournamentSchedule: img7808.url,
  playbook: img7809.url,
  drillDetail: img7810.url,
  financials: img7811.url,
};
import {
  Menu,
  X,
  ArrowRight,
  Check,
  Users,
  Tent,
  BookOpen,
  Calendar,
  DollarSign,
  Inbox,
  Instagram,
  Twitter,
  Facebook,
  Youtube,
  Music2,
  Quote,
} from "lucide-react";
import { cn } from "@/lib/utils";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "PXF Hockey — Run your hockey business. Not your admin." },
      {
        name: "description",
        content:
          "Teams, camps, tournaments, private sessions, athlete development, and payments — all in one platform built for hockey coaches.",
      },
      { property: "og:title", content: "PXF Hockey — Built for hockey coaches" },
      {
        property: "og:description",
        content:
          "The all-in-one platform for hockey coaches. Teams, camps, tournaments, private sessions, and payments.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: MarketingHome,
});

/* ---------- Small primitives ---------- */

function GradientButton({
  children,
  size = "md",
  as = "button",
  href,
  className,
  ...rest
}: {
  children: React.ReactNode;
  size?: "md" | "lg";
  as?: "button" | "a" | "link";
  href?: string;
  className?: string;
} & React.ButtonHTMLAttributes<HTMLButtonElement>) {
  const sizes = size === "lg" ? "px-6 py-3.5 text-base" : "px-4 py-2.5 text-sm";
  const cls = cn(
    "inline-flex items-center justify-center gap-2 rounded-md bg-gradient-to-r from-emerald-500 to-teal-500 font-semibold text-white shadow-lg shadow-teal-500/20 transition hover:opacity-95 hover:shadow-teal-500/40",
    sizes,
    className,
  );
  if (as === "link" && href) {
    return (
      <Link to={href as never} className={cls}>
        {children}
      </Link>
    );
  }
  if (as === "a" && href) {
    return (
      <a href={href} className={cls}>
        {children}
      </a>
    );
  }
  return (
    <button className={cls} {...rest}>
      {children}
    </button>
  );
}

function OutlineButton({
  children,
  size = "md",
  href,
  className,
  as = "button",
  ...rest
}: {
  children: React.ReactNode;
  size?: "md" | "lg";
  href?: string;
  className?: string;
  as?: "button" | "a" | "link";
} & React.ButtonHTMLAttributes<HTMLButtonElement>) {
  const sizes = size === "lg" ? "px-6 py-3.5 text-base" : "px-4 py-2.5 text-sm";
  const cls = cn(
    "inline-flex items-center justify-center gap-2 rounded-md border border-white/15 bg-white/[0.03] font-semibold text-white transition hover:border-teal-400/40 hover:bg-white/[0.06]",
    sizes,
    className,
  );
  if (as === "link" && href) {
    return (
      <Link to={href as never} className={cls}>
        {children}
      </Link>
    );
  }
  if (as === "a" && href) {
    return (
      <a href={href} className={cls}>
        {children}
      </a>
    );
  }
  return (
    <button className={cls} {...rest}>
      {children}
    </button>
  );
}

/* ---------- Nav ---------- */

function Nav() {
  const [open, setOpen] = useState(false);
  const links = [
    { label: "Features", href: "#features" },
    { label: "Pricing", href: "/pricing" },
    { label: "About", href: "#about" },
    { label: "Blog", href: "#blog" },
  ];
  return (
    <header className="sticky top-0 z-50 border-b border-white/10 bg-black/80 backdrop-blur-md">
      <div className="mx-auto flex max-w-7xl items-center justify-between px-4 py-3 sm:px-6 lg:px-8">
        <a href="#top" className="flex items-center gap-2">
          <div className="flex h-8 w-8 items-center justify-center rounded-md bg-gradient-to-br from-emerald-400 to-teal-500 text-xs font-black text-white">
            PXF
          </div>
          <span className="text-sm font-black tracking-widest text-white">PXF HOCKEY</span>
        </a>
        <nav className="hidden items-center gap-8 md:flex">
          {links.map((l) =>
            l.href.startsWith("#") ? (
              <a
                key={l.label}
                href={l.href}
                className="text-sm font-medium text-white/70 transition hover:text-white"
              >
                {l.label}
              </a>
            ) : (
              <Link
                key={l.label}
                to={l.href as never}
                className="text-sm font-medium text-white/70 transition hover:text-white"
              >
                {l.label}
              </Link>
            )
          )}
        </nav>
        <div className="hidden items-center gap-2 md:flex">
          <OutlineButton as="link" href="/login">
            Log In
          </OutlineButton>
          <GradientButton as="link" href="/signup">
            Start Free Trial
          </GradientButton>
        </div>
        <button
          className="rounded-md border border-white/10 p-2 text-white md:hidden"
          onClick={() => setOpen((v) => !v)}
          aria-label="Toggle menu"
        >
          {open ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
        </button>
      </div>
      {open && (
        <div className="border-t border-white/10 bg-black md:hidden">
          <div className="space-y-1 px-4 py-4">
            {links.map((l) =>
              l.href.startsWith("#") ? (
                <a
                  key={l.label}
                  href={l.href}
                  onClick={() => setOpen(false)}
                  className="block rounded-md px-3 py-2 text-sm font-medium text-white/80 hover:bg-white/5"
                >
                  {l.label}
                </a>
              ) : (
                <Link
                  key={l.label}
                  to={l.href as never}
                  onClick={() => setOpen(false)}
                  className="block rounded-md px-3 py-2 text-sm font-medium text-white/80 hover:bg-white/5"
                >
                  {l.label}
                </Link>
              )
            )}
            <div className="mt-3 flex flex-col gap-2 pt-3">
              <OutlineButton as="link" href="/login">
                Log In
              </OutlineButton>
              <GradientButton as="link" href="/signup">
                Start Free Trial
              </GradientButton>
            </div>
          </div>
        </div>
      )}
    </header>
  );
}

/* ---------- Phone mockup ---------- */

function PhoneMockup({
  children,
  className,
}: {
  children: React.ReactNode;
  className?: string;
}) {
  return (
    <div
      className={cn(
        "relative mx-auto w-full max-w-[280px] rounded-[2.5rem] border-[10px] border-neutral-800 bg-neutral-950 shadow-2xl shadow-teal-500/10",
        className,
      )}
    >
      <div className="absolute left-1/2 top-2 z-10 h-5 w-24 -translate-x-1/2 rounded-full bg-black" />
      <div className="aspect-[9/19.5] overflow-hidden rounded-[2rem] bg-black">
        {children}
      </div>
    </div>
  );
}

function PhoneShot({ src, alt }: { src: string; alt: string }) {
  return (
    <img
      src={src}
      alt={alt}
      loading="lazy"
      className="h-full w-full object-cover object-top"
    />
  );
}

const HERO_SHOTS = [
  { src: SHOT.dashboard, alt: "PXF Hockey dashboard" },
  { src: SHOT.tournamentSchedule, alt: "Tournament schedule" },
  { src: SHOT.drillDetail, alt: "Drill detail with rink diagram" },
  { src: SHOT.teamOverview, alt: "Team overview" },
];

function HeroPhone({
  activeIdx,
  variant = "main",
  tiltDeg = 0,
  className,
}: {
  activeIdx: number;
  variant?: "main" | "ghost";
  tiltDeg?: number;
  className?: string;
}) {
  const isGhost = variant === "ghost";
  return (
    <div
      className={cn(
        "relative inline-flex aspect-[9/19.5] h-[62vh] max-h-[680px] rounded-[2.5rem] border-neutral-800 bg-neutral-950",
        isGhost
          ? "border-[8px] shadow-xl shadow-teal-500/5"
          : "border-[10px] shadow-2xl shadow-teal-500/20 hero-phone-glow",
        className,
      )}
      style={{ transform: tiltDeg ? `rotate(${tiltDeg}deg)` : undefined }}
    >
      <div className="absolute left-1/2 top-2 z-10 h-5 w-24 -translate-x-1/2 rounded-full bg-black" />
      <div className="relative h-full w-full overflow-hidden rounded-[2rem] bg-black">
        {HERO_SHOTS.map((s, idx) => (
          <img
            key={s.src}
            src={s.src}
            alt={s.alt}
            loading={idx === 0 ? "eager" : "lazy"}
            className={cn(
              "absolute inset-0 h-full w-full object-cover object-top transition-opacity ease-in-out",
              idx === activeIdx
                ? cn("opacity-100", !isGhost && "hero-kenburns")
                : "opacity-0",
            )}
            style={{ transitionDuration: "600ms" }}
          />
        ))}
      </div>
    </div>
  );
}

function HeroShowcase() {
  const [i, setI] = useState(0);
  useEffect(() => {
    const t = setInterval(() => setI((v) => (v + 1) % HERO_SHOTS.length), 4000);
    return () => clearInterval(t);
  }, []);
  const prev = (i - 1 + HERO_SHOTS.length) % HERO_SHOTS.length;
  const next = (i + 1) % HERO_SHOTS.length;

  return (
    <div className="relative flex h-full w-full flex-col items-center justify-center">
      {/* Radial teal glow behind */}
      <div className="pointer-events-none absolute left-1/2 top-1/2 -z-0 h-[70%] w-[70%] -translate-x-1/2 -translate-y-1/2 rounded-full bg-teal-400/15 blur-[120px]" />

      {/* Left-edge gradient fade into the dark background */}
      <div className="pointer-events-none absolute inset-y-0 left-0 z-30 w-16 bg-gradient-to-r from-black via-black/80 to-transparent sm:w-20 lg:w-24" />

      {/* Phones container — fully contained within the right column */}
      <div className="relative z-10 flex w-full items-center justify-center px-2 sm:px-4">
        {/* Left ghost — visible within the phone column only */}
        <div className="pointer-events-none absolute left-[3%] top-1/2 z-10 hidden w-[24%] max-w-[150px] -translate-y-1/2 opacity-50 blur-[0.5px] lg:block">
          <HeroPhone activeIdx={prev} variant="ghost" tiltDeg={-6} className="h-[44vh] max-h-[500px]" />
        </div>

        {/* Main phone */}
        <div className="relative z-20 p-8 lg:p-12">
          <div className="lg:[transform:rotate(3deg)_scale(0.98)]">
            <HeroPhone activeIdx={i} variant="main" />
          </div>
        </div>

        {/* Right ghost */}
        <div className="pointer-events-none absolute right-[3%] top-1/2 z-10 hidden w-[24%] max-w-[150px] -translate-y-1/2 opacity-50 blur-[0.5px] lg:block">
          <HeroPhone activeIdx={next} variant="ghost" tiltDeg={6} className="h-[44vh] max-h-[500px]" />
        </div>
      </div>

      {/* Dot indicators */}
      <div className="relative z-20 mt-4 flex items-center justify-center gap-2">
        {HERO_SHOTS.map((s, idx) => (
          <button
            key={s.src}
            type="button"
            aria-label={`Show ${s.alt}`}
            onClick={() => setI(idx)}
            className={cn(
              "h-2 rounded-full transition-all duration-300",
              idx === i ? "w-6 bg-teal-400" : "w-2 bg-neutral-600 hover:bg-neutral-500",
            )}
          />
        ))}
      </div>
    </div>
  );
}


type Tab = { key: string; label: string; src: string; alt: string; headline: string; description: string };

function TabbedFeature({
  eyebrow,
  sectionTitle,
  tabs,
  phoneSide = "left",
}: {
  eyebrow: string;
  sectionTitle: string;
  tabs: Tab[];
  phoneSide?: "left" | "right";
}) {
  const [active, setActive] = useState(tabs[0].key);
  const current = tabs.find((t) => t.key === active) ?? tabs[0];
  const phone = (
    <div key={current.src} className="animate-in fade-in duration-300">
      <PhoneMockup>
        <PhoneShot src={current.src} alt={current.alt} />
      </PhoneMockup>
    </div>
  );
  const content = (
    <div>
      <div className="mb-3 text-xs font-bold uppercase tracking-[0.2em] text-teal-400">
        {eyebrow}
      </div>
      <h3 className="text-3xl font-black leading-tight text-white md:text-4xl">
        {sectionTitle}
      </h3>
      <div className="mt-6 flex flex-wrap gap-x-6 gap-y-2 border-b border-white/10">
        {tabs.map((t) => {
          const isActive = t.key === active;
          return (
            <button
              key={t.key}
              onClick={() => setActive(t.key)}
              className={cn(
                "relative -mb-px pb-3 text-sm font-semibold transition",
                isActive ? "text-white" : "text-white/50 hover:text-white/80",
              )}
            >
              {t.label}
              {isActive && (
                <span className="absolute inset-x-0 -bottom-px h-0.5 rounded-full bg-teal-400" />
              )}
            </button>
          );
        })}
      </div>
      <div key={current.key + "-txt"} className="mt-6 animate-in fade-in duration-300">
        <div className="text-lg font-bold text-white md:text-xl">{current.headline}</div>
        <p className="mt-2 text-sm text-white/70 md:text-base">{current.description}</p>
      </div>
    </div>
  );
  return (
    <div className="mx-auto max-w-6xl px-4 py-16 sm:px-6 lg:px-8">
      <div
        className={cn(
          "grid grid-cols-1 items-center gap-10 md:grid-cols-2",
          phoneSide === "right" && "md:[&>*:first-child]:order-2",
        )}
      >
        {phoneSide === "left" ? (
          <>
            <div>{phone}</div>
            {content}
          </>
        ) : (
          <>
            {content}
            <div>{phone}</div>
          </>
        )}
      </div>
    </div>
  );
}



/* ---------- Sections ---------- */

function Hero() {
  return (
    <section id="top" className="relative overflow-hidden border-b border-white/5 bg-black">
      <div className="pointer-events-none absolute inset-0">
        <div className="absolute left-1/2 top-1/2 h-[600px] w-[600px] -translate-x-1/2 -translate-y-1/2 rounded-full bg-teal-500/20 blur-[120px]" />
      </div>
      <div className="relative mx-auto grid min-h-[calc(100vh-4rem)] max-w-7xl grid-cols-1 items-center px-4 pb-16 pt-16 sm:px-6 lg:grid-cols-[minmax(0,45%)_minmax(0,55%)] lg:px-8 lg:pt-8">
        {/* LEFT — copy (45% width, fully contained) */}
        <div className="relative z-20 text-center lg:pr-8 lg:text-left">
          <div className="mb-6 text-xs font-bold uppercase tracking-[0.2em] text-teal-400">
            The platform built for hockey coaches
          </div>
          <h1 className="text-4xl font-black leading-[1.05] tracking-tight text-white sm:text-5xl md:text-6xl lg:text-[3.25rem] xl:text-5xl">
            Run your hockey business.{" "}
            <span className="bg-gradient-to-r from-emerald-400 to-teal-400 bg-clip-text text-transparent">
              Not your admin.
            </span>
          </h1>
          <p className="mx-auto mt-6 max-w-xl text-base text-white/60 sm:text-lg lg:mx-0">
            Teams, camps, tournaments, private sessions, athlete development, and payments — all in
            one platform coaches actually want to use.
          </p>
          <div className="mt-8 flex flex-col items-center justify-center gap-3 sm:flex-row lg:justify-start">
            <GradientButton size="lg" as="link" href="/signup">
              Start Free Trial <ArrowRight className="h-4 w-4" />
            </GradientButton>
            <OutlineButton size="lg">Book a Demo</OutlineButton>
          </div>
          <p className="mt-4 text-xs text-white/40">
            14-day free trial · No credit card required · Cancel anytime
          </p>
        </div>

        {/* RIGHT — floating phone mockup image, hidden on mobile */}
        <div className="relative hidden h-auto items-center justify-center py-12 lg:flex lg:py-16">
          <div className="relative p-8 lg:p-12">
            <div
              className="relative transition-transform duration-500 ease-out will-change-transform"
              style={{
                transform: "rotate(7deg) translateY(-12px)",
                filter: "drop-shadow(0 32px 64px rgba(0, 196, 180, 0.30)) drop-shadow(0 0 40px rgba(0, 196, 180, 0.15))",
              }}
            >
              <img
                src="https://cdn.midjourney.com/b18e8209-73b4-45a2-a7e4-3a2c20878cab/0_0.png"
                alt="PXF Hockey app on a phone"
                loading="eager"
                className="h-auto w-full max-w-[340px] rounded-[2.5rem] object-cover sm:max-w-[380px] lg:max-w-[420px]"
              />
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}


function SocialProof() {
  return (
    <section className="border-b border-white/5 bg-black py-8">
      <div className="mx-auto max-w-6xl px-4 text-center sm:px-6 lg:px-8">
        <p className="text-sm text-white/40">Trusted by coaches across Canada</p>
      </div>
    </section>
  );
}

function ProblemValue() {
  const problems = [
    "TeamSnap for scheduling",
    "GroupMe or iMessage for messaging",
    "Excel for payments and tracking",
    "Google Drive for practice plans",
    "A separate camp registration tool",
    "Another app for athlete development",
    "Your phone for everything else",
  ];
  return (
    <section className="border-b border-white/5 bg-black py-20">
      <div className="mx-auto grid max-w-6xl grid-cols-1 gap-10 px-4 sm:px-6 md:grid-cols-2 lg:px-8">
        <div className="md:border-r md:border-teal-500/30 md:pr-10">
          <h3 className="text-xl font-bold text-white/50">Right now you're juggling…</h3>
          <ul className="mt-6 space-y-3">
            {problems.map((p) => (
              <li key={p} className="flex items-start gap-2 text-white/50">
                <span className="mt-2 h-1 w-1 shrink-0 rounded-full bg-white/30" />
                <span className="text-sm">{p}</span>
              </li>
            ))}
          </ul>
        </div>
        <div className="md:pl-2">
          <h3 className="text-3xl font-black leading-tight text-white md:text-4xl">
            PXF Hockey replaces all of it.
          </h3>
          <p className="mt-4 text-lg text-white/70">
            One platform. One login.{" "}
            <span className="text-teal-400">Built specifically for hockey.</span>
          </p>
        </div>
      </div>
    </section>
  );
}

function FeatureRow({
  eyebrow,
  title,
  bullets,
  phone,
  reverse,
}: {
  eyebrow: string;
  title: string;
  bullets: string[];
  phone: React.ReactNode;
  reverse?: boolean;
}) {
  return (
    <div className="mx-auto max-w-6xl px-4 py-16 sm:px-6 lg:px-8">
      <div
        className={cn(
          "grid grid-cols-1 items-center gap-10 md:grid-cols-2",
          reverse && "md:[&>*:first-child]:order-2",
        )}
      >
        <div>
          <div className="mb-3 text-xs font-bold uppercase tracking-[0.2em] text-teal-400">
            {eyebrow}
          </div>
          <h3 className="text-3xl font-black leading-tight text-white md:text-4xl">{title}</h3>
          <ul className="mt-6 space-y-3">
            {bullets.map((b) => (
              <li key={b} className="flex items-start gap-3 text-white/75">
                <Check className="mt-0.5 h-4 w-4 shrink-0 text-teal-400" />
                <span className="text-sm md:text-base">{b}</span>
              </li>
            ))}
          </ul>
        </div>
        <div>{phone}</div>
      </div>
    </div>
  );
}

function Features() {
  return (
    <section id="features" className="border-b border-white/5 bg-neutral-950">
      <TabbedFeature
        eyebrow="Teams"
        sectionTitle="Built for your team."
        phoneSide="left"
        tabs={[
          {
            key: "overview",
            label: "Overview",
            src: SHOT.teamOverview,
            alt: "Team overview screen",
            headline: "Your team at a glance",
            description:
              "See your next game, last result, and season record the moment you open the app. Real-time attendance, opponent details, and rink info all in one place.",
          },
          {
            key: "schedule",
            label: "Schedule",
            src: SHOT.teamSchedule,
            alt: "Team schedule",
            headline: "Every game and practice, organized",
            description:
              "Upcoming and past events in a clean list. Coaches see live attendance responses. Tap any event for full details, media, and game prep.",
          },
          {
            key: "tournaments",
            label: "Tournaments",
            src: SHOT.tournamentSchedule,
            alt: "Tournament schedule",
            headline: "Tournament weekends, fully managed",
            description:
              "Every bus departure, hotel check-in, team meal, and game on one scrollable timeline. Filter by type. RSVP tracking per event. Push updates to the whole team instantly.",
          },
          {
            key: "logistics",
            label: "Logistics",
            src: SHOT.tournamentLogistics,
            alt: "Tournament logistics",
            headline: "Hotel, billets, and gear — sorted",
            description:
              "Manage accommodation, billet assignments, equipment checklists, and tournament notes in one place. Parents only see what applies to their child.",
          },
        ]}
      />
      <TabbedFeature
        eyebrow="Coaching"
        sectionTitle="Your coaching toolkit."
        phoneSide="right"
        tabs={[
          {
            key: "playbook",
            label: "Playbook",
            src: SHOT.playbook,
            alt: "Playbook drill library",
            headline: "Your entire drill library, organized",
            description:
              "Skating, slip training, dryland, and GameIQ drills organized by category. Add any drill to a practice session in one tap.",
          },
          {
            key: "drill",
            label: "Drill Detail",
            src: SHOT.drillDetail,
            alt: "Drill detail with rink diagram",
            headline: "Every drill, visualized",
            description:
              "Drill videos, rink diagrams with player routes, coaching notes, and progressions all on one screen. Tap \"Add to Practice Session\" to build your practice plan on the fly.",
          },
          {
            key: "game",
            label: "Game Detail",
            src: SHOT.gameDetail,
            alt: "Game detail screen",
            headline: "Before, during, and after every game",
            description:
              "Game prep notes, attendance tracking, post-game stats, and a full media library — all attached to the game. Upload highlight clips or full game footage directly from your phone.",
          },
        ]}
      />
      <TabbedFeature
        eyebrow="Business"
        sectionTitle="Run your business."
        phoneSide="left"
        tabs={[
          {
            key: "dashboard",
            label: "Dashboard",
            src: SHOT.dashboard,
            alt: "Coach dashboard",
            headline: "Your whole business, every morning",
            description:
              "See today's sessions, live revenue, pending payments, and active camps the moment you open the app. Built for coaches who run multiple teams and programs.",
          },
          {
            key: "financials",
            label: "Financials",
            src: SHOT.financials,
            alt: "Financials screen",
            headline: "Full financial visibility",
            description:
              "Track gross revenue, pending payments, payouts, ice costs, and coach costs in real time. Built-in reports, tax tracking, and Stripe-powered payouts.",
          },
          {
            key: "camps",
            label: "Camps",
            src: SHOT.events,
            alt: "Events and camps",
            headline: "Camps and clinics, organized",
            description:
              "Manage registrations, track spots sold, send updates, and collect payments all in one place. Filter by camp, private sessions, or team events across your whole business.",
          },
        ]}
      />
    </section>
  );
}

function AppShowcase() {
  return (
    <section className="relative overflow-hidden border-b border-white/5 bg-black py-20">
      <div className="pointer-events-none absolute inset-x-0 top-1/2 h-[500px] -translate-y-1/2 bg-gradient-to-r from-emerald-500/10 via-teal-500/10 to-transparent blur-3xl" />
      <div className="relative mx-auto max-w-6xl px-4 sm:px-6 lg:px-8">
        <div className="mx-auto max-w-2xl text-center">
          <h2 className="text-3xl font-black leading-tight text-white md:text-5xl">
            Everything in your pocket.
            <br />
            <span className="text-teal-400">Nothing left at the rink.</span>
          </h2>
        </div>
        <div className="mt-14 grid grid-cols-1 gap-8 md:grid-cols-3">
          <PhoneMockup><PhoneShot src={SHOT.teamSchedule} alt="Team schedule" /></PhoneMockup>
          <PhoneMockup className="md:-translate-y-6"><PhoneShot src={SHOT.tournamentSchedule} alt="Tournament schedule" /></PhoneMockup>
          <PhoneMockup><PhoneShot src={SHOT.playbook} alt="Playbook" /></PhoneMockup>
        </div>
        <div className="mt-10 flex flex-col items-center gap-4">
          <p className="text-sm font-semibold uppercase tracking-widest text-white/50">
            Available on iOS and Android
          </p>
          <div className="flex flex-wrap justify-center gap-3">
            <a href="#" className="flex items-center gap-3 rounded-lg border border-white/15 bg-white/5 px-5 py-2.5 text-white transition hover:border-teal-400/40">
              <div className="text-2xl leading-none"></div>
              <div className="text-left leading-tight">
                <div className="text-[10px] text-white/60">Download on the</div>
                <div className="text-sm font-bold">App Store</div>
              </div>
            </a>
            <a href="#" className="flex items-center gap-3 rounded-lg border border-white/15 bg-white/5 px-5 py-2.5 text-white transition hover:border-teal-400/40">
              <div className="flex h-6 w-6 items-center justify-center rounded-sm bg-gradient-to-br from-emerald-400 to-teal-500 text-[10px] font-black">▶</div>
              <div className="text-left leading-tight">
                <div className="text-[10px] text-white/60">Get it on</div>
                <div className="text-sm font-bold">Google Play</div>
              </div>
            </a>
          </div>
        </div>
      </div>
    </section>
  );
}

function StatsStrip() {
  const stats = [
    "Replaces 5+ tools",
    "100% hockey-specific",
    "Set up in under 10 minutes",
    "Used by coaches from Atom to AAA",
  ];
  return (
    <section className="border-b border-white/5 bg-neutral-950 py-10">
      <div className="mx-auto max-w-6xl px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-2 gap-4 md:grid-cols-4">
          {stats.map((s) => (
            <div
              key={s}
              className="rounded-xl border border-white/10 bg-white/[0.02] p-6 text-center"
            >
              <div className="text-sm font-bold text-white md:text-base">
                <span className="bg-gradient-to-r from-emerald-400 to-teal-400 bg-clip-text text-transparent">
                  {s}
                </span>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

function Testimonials() {
  const items = [
    {
      q: "PXF Hockey replaced TeamSnap, GroupMe, and our camp registration software in one shot. Our parents actually use it.",
      n: "Mike Davis",
      r: "AAA Midget Coach",
      o: "Elite Hockey",
    },
    {
      q: "The tournament module alone is worth the subscription. My parents know exactly where to be and when — no more group texts.",
      n: "Sarah Chen",
      r: "U15 Rep Coach",
      o: "Pacific Hockey Academy",
    },
    {
      q: "Being able to build my practice plan from my drill library and send it to parents the night before is a game changer.",
      n: "James Kowalski",
      r: "Power Skating Coach",
      o: "",
    },
  ];
  return (
    <section className="border-b border-white/5 bg-black py-20">
      <div className="mx-auto max-w-6xl px-4 sm:px-6 lg:px-8">
        <h2 className="text-center text-3xl font-black text-white md:text-5xl">
          Coaches, in their words.
        </h2>
        <div className="mt-12 grid grid-cols-1 gap-5 md:grid-cols-3">
          {items.map((t) => (
            <div
              key={t.n}
              className="flex flex-col rounded-2xl border border-white/10 bg-gradient-to-b from-white/[0.04] to-transparent p-6"
            >
              <Quote className="h-6 w-6 text-teal-400" />
              <p className="mt-4 flex-1 text-sm leading-relaxed text-white/80">"{t.q}"</p>
              <div className="mt-6 border-t border-white/10 pt-4">
                <div className="text-sm font-bold text-white">{t.n}</div>
                <div className="text-xs text-white/50">
                  {t.r}
                  {t.o && ` · ${t.o}`}
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

function Pricing() {
  return (
    <section id="pricing" className="border-b border-white/5 bg-neutral-950 py-20">
      <PricingPlans />
    </section>
  );
}

function FinalCta() {
  return (
    <section className="relative overflow-hidden bg-black py-20">
      <div className="absolute inset-0 bg-gradient-to-br from-emerald-900/60 via-teal-800/50 to-black" />
      <div className="pointer-events-none absolute -left-20 top-0 h-64 w-64 rounded-full bg-teal-500/30 blur-3xl" />
      <div className="pointer-events-none absolute -right-20 bottom-0 h-64 w-64 rounded-full bg-emerald-500/30 blur-3xl" />
      <div className="relative mx-auto max-w-4xl px-4 text-center sm:px-6 lg:px-8">
        <h2 className="text-4xl font-black leading-tight text-white md:text-6xl">
          Stop duct-taping tools together.
          <br />
          <span className="bg-gradient-to-r from-emerald-300 to-teal-300 bg-clip-text text-transparent">
            Start coaching.
          </span>
        </h2>
        <div className="mt-8 flex flex-col items-center justify-center gap-3 sm:flex-row">
          <a
            href="/signup"
            className="inline-flex items-center justify-center gap-2 rounded-md bg-white px-6 py-3.5 text-base font-bold text-neutral-900 shadow-xl transition hover:bg-white/90"
          >
            Start Free Trial <ArrowRight className="h-4 w-4" />
          </a>
          <button className="inline-flex items-center justify-center rounded-md border border-white/40 bg-transparent px-6 py-3.5 text-base font-semibold text-white transition hover:bg-white/10">
            Book a Demo
          </button>
        </div>
        <p className="mt-4 text-sm text-white/60">
          14-day free trial · No credit card · Set up in under 10 minutes
        </p>
      </div>
    </section>
  );
}

function Footer() {
  const cols = [
    {
      title: "Product",
      links: ["Features", "Pricing", "Mobile App", "Changelog", "Status"],
    },
    {
      title: "Company",
      links: ["About", "Blog", "Careers", "Contact", "Press Kit"],
    },
    {
      title: "Support",
      links: ["Help Center", "Book a Demo", "Privacy Policy", "Terms of Service"],
    },
  ];
  const socials = [Instagram, Twitter, Facebook, Youtube, Music2];
  return (
    <footer className="border-t border-white/10 bg-black py-14 text-white">
      <div className="mx-auto max-w-6xl px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-2 gap-8 md:grid-cols-4">
          <div className="col-span-2 md:col-span-1">
            <div className="flex items-center gap-2">
              <div className="flex h-8 w-8 items-center justify-center rounded-md bg-gradient-to-br from-emerald-400 to-teal-500 text-xs font-black text-white">
                PXF
              </div>
              <span className="text-sm font-black tracking-widest">PXF HOCKEY</span>
            </div>
            <p className="mt-4 text-sm text-white/60">
              Built for coaches. Loved by parents.
            </p>
            <div className="mt-4 flex gap-3">
              {socials.map((Icon, i) => (
                <a
                  key={i}
                  href="#"
                  className="flex h-8 w-8 items-center justify-center rounded-md border border-white/10 text-white/60 transition hover:border-teal-400/40 hover:text-teal-400"
                >
                  <Icon className="h-4 w-4" />
                </a>
              ))}
            </div>
          </div>
          {cols.map((c) => (
            <div key={c.title}>
              <div className="text-xs font-bold uppercase tracking-widest text-white/50">
                {c.title}
              </div>
              <ul className="mt-4 space-y-2">
                {c.links.map((l) => (
                  <li key={l}>
                    {l === "Pricing" ? (
                      <Link to="/pricing" className="text-sm text-white/70 transition hover:text-white">
                        {l}
                      </Link>
                    ) : (
                      <a href="#" className="text-sm text-white/70 transition hover:text-white">
                        {l}
                      </a>
                    )}
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>
        <div className="mt-12 flex flex-col items-center justify-between gap-3 border-t border-white/10 pt-6 text-xs text-white/40 md:flex-row">
          <span>© 2026 PXF Hockey. All rights reserved.</span>
          <span>Made for the game.</span>
        </div>
      </div>
    </footer>
  );
}

/* ---------- Icon usage (silence unused-warnings) ---------- */
const _iconRefs = { Users, Tent, BookOpen, Calendar, DollarSign, Inbox };
void _iconRefs;

function MarketingHome() {
  return (
    <div className="min-h-screen bg-black text-white">
      <Nav />
      <Hero />
      <SocialProof />
      <ProblemValue />
      <Features />
      <AppShowcase />
      <StatsStrip />
      <Testimonials />
      <Pricing />
      <FinalCta />
      <Footer />
    </div>
  );
}
