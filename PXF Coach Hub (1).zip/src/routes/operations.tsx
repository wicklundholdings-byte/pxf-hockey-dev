import { createFileRoute } from "@tanstack/react-router";

export const Route = createFileRoute("/operations")({
  head: () => ({
    meta: [
      { title: "Operations · PXF Hockey" },
      { name: "description", content: "Operations view for PXF Hockey Elite Coach portal." },
    ],
  }),
  component: Page,
});

function Page() {
  return (
    <div className="rounded-lg border border-dashed border-border p-12 text-center">
      <h2 className="text-xl font-semibold">Operations</h2>
      <p className="mt-2 text-sm text-muted-foreground">Coming soon.</p>
    </div>
  );
}
