import { createFileRoute } from "@tanstack/react-router";
import { PrivateDetail } from "@/components/private-detail";

export const Route = createFileRoute("/privates/$privateId")({
  head: () => ({
    meta: [
      { title: "Private Sessions · PXF Hockey" },
      { name: "description", content: "Private session details, schedule, and payments." },
    ],
  }),
  component: PrivateRoute,
});

function PrivateRoute() {
  const { privateId } = Route.useParams();
  return <PrivateDetail privateId={privateId} />;
}
