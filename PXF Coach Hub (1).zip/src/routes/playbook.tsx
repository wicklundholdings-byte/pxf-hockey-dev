import { createFileRoute } from "@tanstack/react-router";
import { useState, useMemo, useRef, useEffect, useSyncExternalStore } from "react";
import {
  ChevronLeft, ChevronRight, Search, SlidersHorizontal, Plus, Play, Heart,
  Snowflake, Dumbbell, Brain, Zap, Star, Upload, Lock,
  Undo2, Redo2, Trash2, GripVertical, StickyNote, X, Eye, Copy,
  Spline, MousePointer2, Pencil, Minus, Sun, Moon, RotateCw,
} from "lucide-react";
import { cn } from "@/lib/utils";
import { Toaster, toast } from "sonner";

export const Route = createFileRoute("/playbook")({
  head: () => ({
    meta: [
      { title: "Playbook · PXF Hockey" },
      { name: "description", content: "Drill library, practice sessions, and custom playbook for PXF Hockey coaches." },
    ],
  }),
  component: PlaybookPage,
});

const TEAL = "#00D4C8";

/* ============================================================
   TYPES + DATA
============================================================ */

type Category = "Skating" | "Slip Training" | "GameIQ" | "Dryland" | "My Drills";
type Level = "BEGINNER" | "INTERMEDIATE" | "ADVANCED";

type Drill = {
  id: string;
  name: string;
  category: Category;
  level: Level;
  ages: string;
  duration: string;
  sessions: number;
  description: string;
  notes?: string;
  progressions?: string[];
  custom?: boolean;
  favorite?: boolean;
  diagram?: { items: Item[]; view: RinkView; iceMode: IceMode };
  videoName?: string;
  ihsUrl?: string;
};

/* ---------- Custom drills store (module-level, subscribable) ---------- */

let customDrillsStore: Drill[] = [];
const customDrillListeners = new Set<() => void>();
function subscribeCustomDrills(l: () => void) {
  customDrillListeners.add(l);
  return () => { customDrillListeners.delete(l); };
}
function getCustomDrillsSnapshot() { return customDrillsStore; }
function addCustomDrill(d: Drill) {
  customDrillsStore = [d, ...customDrillsStore];
  customDrillListeners.forEach((l) => l());
}
function useCustomDrills(): Drill[] {
  return useSyncExternalStore(subscribeCustomDrills, getCustomDrillsSnapshot, getCustomDrillsSnapshot);
}
function findDrill(id: string): Drill | undefined {
  return customDrillsStore.find((d) => d.id === id) ?? DRILLS.find((d) => d.id === id);
}

type PracticeSession = {
  id: string;
  name: string;
  date: string;
  duration: string;
  location: string;
  drillCount: number;
  status: "DRAFT" | "PUBLISHED";
};

const DRILLS: Drill[] = [
  {
    id: "d1", name: "Edge Mastery Series", category: "Skating", level: "INTERMEDIATE",
    ages: "10-16", duration: "30m", sessions: 6,
    description: "Full-ice edge work progressions for speed and agility development.",
    notes: "Focus on ankle flexion and knee bend throughout. Keep chest up.",
    progressions: [
      "Begin at blue line, focus on inside edges",
      "Add speed — complete in under 8 seconds",
      "Add puck — maintain edge quality",
    ],
    favorite: true,
  },
  {
    id: "d2", name: "Crossover Power Program", category: "Skating", level: "ADVANCED",
    ages: "13+", duration: "25m", sessions: 4,
    description: "Build explosive crossover strength through progressive circuit work.",
    progressions: ["Slow tempo, focus on push", "Add tempo", "Add resistance band"],
  },
  {
    id: "d3", name: "Core Stability Circuit", category: "Dryland", level: "BEGINNER",
    ages: "8-14", duration: "20m", sessions: 3,
    description: "Foundation core strength for on-ice stability.",
  },
  {
    id: "d4", name: "Speed & Agility Program", category: "Dryland", level: "INTERMEDIATE",
    ages: "12+", duration: "30m", sessions: 5,
    description: "Ladder, cone, and resistance band progressions.",
    favorite: true,
  },
  {
    id: "d5", name: "Slip Read Progressions", category: "Slip Training", level: "INTERMEDIATE",
    ages: "12+", duration: "20m", sessions: 4,
    description: "Small-area reads training deception on and off the puck.",
  },
];

const PRACTICES: PracticeSession[] = [
  { id: "s1", name: "Pre-Camp Skate", date: "Fri Jul 4 · 6:00 AM", duration: "60m", location: "Rink A", drillCount: 4, status: "PUBLISHED" },
  { id: "s2", name: "U14 AA Practice", date: "Mon Jul 7 · 5:30 PM", duration: "75m", location: "Rink A", drillCount: 6, status: "PUBLISHED" },
  { id: "s3", name: "Goalie Session", date: "Wed Jul 9 · 4:00 PM", duration: "45m", location: "Rink B", drillCount: 3, status: "DRAFT" },
];

const CATEGORY_META: Record<Category, { icon: React.ComponentType<{ className?: string }>; desc: string }> = {
  Skating: { icon: Snowflake, desc: "Edge work, crossovers, and stride mechanics." },
  "Slip Training": { icon: Zap, desc: "Deceptive skating, tight-space skill work." },
  GameIQ: { icon: Brain, desc: "Reads, systems, and video-based study." },
  Dryland: { icon: Dumbbell, desc: "Off-ice strength, mobility, and conditioning." },
  "My Drills": { icon: Star, desc: "Your custom-authored drills." },
};

/* ============================================================
   VIEW ROUTER
============================================================ */

type View =
  | { kind: "main"; tab?: string }
  | { kind: "drill"; drillId: string }
  | { kind: "builder" }
  | { kind: "practice"; practiceId?: string }
  | { kind: "series"; seriesId?: string }
  | { kind: "progress"; programId: string };

function PlaybookPage() {
  const [view, setView] = useState<View>({ kind: "main" });
  if (view.kind === "drill") {
    const drill = findDrill(view.drillId);
    if (!drill) return <div className="p-8 text-sm text-muted-foreground">Drill not found.</div>;
    return <DrillDetail drill={drill} onBack={() => setView({ kind: "main" })} />;
  }
  if (view.kind === "builder") {
    return (
      <DrillBuilder
        onBack={() => setView({ kind: "main" })}
        onPublished={(id) => setView({ kind: "drill", drillId: id })}
      />
    );
  }
  if (view.kind === "practice") {
    return <PracticeBuilder practiceId={view.practiceId} onBack={() => setView({ kind: "main", tab: "Practices" })} />;
  }
  if (view.kind === "series") {
    return <SeriesBuilder seriesId={view.seriesId} onBack={() => setView({ kind: "main", tab: "Series" })} />;
  }
  if (view.kind === "progress") {
    return <ProgressView programId={view.programId} onBack={() => setView({ kind: "main", tab: "Dryland" })} />;
  }
  return (
    <>
      <Toaster position="top-right" richColors theme="dark" />
      <PlaybookMain
        initialTab={view.tab}
        onOpenDrill={(id) => setView({ kind: "drill", drillId: id })}
        onCreate={() => setView({ kind: "builder" })}
        onOpenPractice={(id) => setView({ kind: "practice", practiceId: id })}
        onOpenSeries={(id) => setView({ kind: "series", seriesId: id })}
        onOpenProgress={(id) => setView({ kind: "progress", programId: id })}
      />
    </>
  );
}

/* ============================================================
   PRIMITIVES
============================================================ */

function SectionLabel({ children }: { children: React.ReactNode }) {
  return (
    <div className="text-[11px] font-semibold uppercase tracking-[0.18em] text-muted-foreground">
      {children}
    </div>
  );
}

function TabBar({ tabs, active, onChange }: { tabs: string[]; active: string; onChange: (t: string) => void }) {
  return (
    <div className="border-b border-border">
      <div className="flex gap-6 overflow-x-auto">
        {tabs.map((t) => {
          const on = t === active;
          return (
            <button
              key={t}
              onClick={() => onChange(t)}
              className={cn(
                "relative -mb-px py-3 text-sm font-medium whitespace-nowrap transition",
                on ? "text-foreground" : "text-muted-foreground hover:text-foreground"
              )}
            >
              {t}
              {on && <span className="absolute inset-x-0 -bottom-px h-0.5 bg-[#00D4C8]" />}
            </button>
          );
        })}
      </div>
    </div>
  );
}

function GradientButton({ children, className, onClick, type }: { children: React.ReactNode; className?: string; onClick?: () => void; type?: "button" | "submit" }) {
  return (
    <button
      type={type ?? "button"}
      onClick={onClick}
      className={cn(
        "inline-flex items-center justify-center gap-1.5 rounded-md bg-gradient-to-r from-[#00D4C8] to-emerald-500 px-4 py-2.5 text-xs font-semibold text-black transition hover:opacity-90",
        className
      )}
    >
      {children}
    </button>
  );
}

function OutlineButton({ children, className, onClick }: { children: React.ReactNode; className?: string; onClick?: () => void }) {
  return (
    <button
      onClick={onClick}
      className={cn(
        "inline-flex items-center justify-center gap-1.5 rounded-md border border-border bg-transparent px-4 py-2.5 text-xs font-medium text-foreground transition hover:bg-accent",
        className
      )}
    >
      {children}
    </button>
  );
}

function LevelBadge({ level }: { level: Level }) {
  const map = {
    BEGINNER: "bg-emerald-500/15 text-emerald-300 ring-emerald-500/30",
    INTERMEDIATE: "bg-[#00D4C8]/15 text-[#00D4C8] ring-[#00D4C8]/30",
    ADVANCED: "bg-purple-500/15 text-purple-300 ring-purple-500/30",
  }[level];
  return <span className={cn("rounded px-1.5 py-0.5 text-[10px] font-bold uppercase tracking-wider ring-1", map)}>{level}</span>;
}

function CategoryAvatar({ category, size = 40 }: { category: Category; size?: number }) {
  const Icon = CATEGORY_META[category].icon;
  return (
    <div
      className="flex shrink-0 items-center justify-center rounded-lg"
      style={{ width: size, height: size, background: `${TEAL}20`, color: TEAL }}
    >
      <Icon className="h-5 w-5" />
    </div>
  );
}

function TagPill({ children, tone = "muted" }: { children: React.ReactNode; tone?: "muted" | "teal" }) {
  return (
    <span
      className={cn(
        "rounded px-1.5 py-0.5 text-[10px] font-bold uppercase tracking-wider ring-1",
        tone === "teal"
          ? "bg-[#00D4C8]/15 text-[#00D4C8] ring-[#00D4C8]/30"
          : "bg-muted text-muted-foreground ring-border"
      )}
    >
      {children}
    </span>
  );
}

/* ============================================================
   MAIN PLAYBOOK PAGE
============================================================ */

function PlaybookMain({
  initialTab,
  onOpenDrill,
  onCreate,
  onOpenPractice,
  onOpenSeries,
  onOpenProgress,
}: {
  initialTab?: string;
  onOpenDrill: (id: string) => void;
  onCreate: () => void;
  onOpenPractice: (id?: string) => void;
  onOpenSeries: (id?: string) => void;
  onOpenProgress: (id: string) => void;
}) {
  const [tab, setTab] = useState(initialTab ?? "Drills");
  const tabs = ["Drills", "Practices", "Series", "Dryland", "Favorites"];

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-semibold tracking-tight">Playbook</h1>
        <p className="mt-1 text-sm text-muted-foreground">Drills, practice sessions, series, and your custom library.</p>
      </div>

      <TabBar tabs={tabs} active={tab} onChange={setTab} />

      {tab === "Drills" && <DrillsTab onOpenDrill={onOpenDrill} onCreate={onCreate} />}
      {tab === "Practices" && <PracticesTab onOpenPractice={onOpenPractice} />}
      {tab === "Series" && <SeriesTab onOpenSeries={onOpenSeries} />}
      {tab === "Dryland" && <DrylandTab onOpenProgress={onOpenProgress} />}
      {tab === "Favorites" && <FavoritesTab onOpenDrill={onOpenDrill} />}
    </div>
  );
}

/* ---------- Drills Tab ---------- */

type DrillFilter = "All" | "Skating" | "Slip Training" | "GameIQ" | "Dryland" | "My Drills";

function DrillsTab({ onOpenDrill, onCreate }: { onOpenDrill: (id: string) => void; onCreate: () => void }) {
  const [q, setQ] = useState("");
  const [cat, setCat] = useState<DrillFilter>("All");
  const filters: DrillFilter[] = ["All", "Skating", "Slip Training", "GameIQ", "Dryland", "My Drills"];
  const customDrills = useCustomDrills();
  const allDrills = useMemo(() => [...customDrills, ...DRILLS], [customDrills]);

  const drills = useMemo(
    () =>
      allDrills.filter((d) => {
        if (cat === "My Drills") return !!d.custom;
        if (cat !== "All" && d.category !== cat) return false;
        return q === "" || d.name.toLowerCase().includes(q.toLowerCase());
      }),
    [q, cat, allDrills]
  );

  // Group by category; always include GameIQ so we can show the coming-soon card
  const categoriesToShow: Category[] = useMemo(() => {
    if (cat === "All") return ["Skating", "Slip Training", "GameIQ", "Dryland"];
    if (cat === "My Drills") return ["My Drills"];
    return [cat as Category];
  }, [cat]);

  return (
    <div className="space-y-6">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div className="flex flex-1 items-center gap-2">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
            <input
              value={q}
              onChange={(e) => setQ(e.target.value)}
              placeholder="Search drills…"
              className="h-10 w-full rounded-md border border-border bg-card pl-9 pr-3 text-sm"
            />
          </div>
          <button className="inline-flex h-10 w-10 items-center justify-center rounded-md border border-border bg-card hover:bg-accent">
            <SlidersHorizontal className="h-4 w-4" />
          </button>
        </div>
        <div className="flex items-center gap-2">
          <OutlineButton>
            <Upload className="h-3.5 w-3.5" /> Import from IHS
          </OutlineButton>
          <GradientButton onClick={onCreate}>
            <Plus className="h-3.5 w-3.5" /> Create Drill
          </GradientButton>
        </div>
      </div>

      <div className="flex flex-wrap gap-2">
        {filters.map((f) => (
          <button
            key={f}
            onClick={() => setCat(f)}
            className={cn(
              "h-8 rounded-full border px-3 text-xs font-medium transition",
              cat === f ? "border-[#00D4C8] bg-[#00D4C8]/10 text-[#00D4C8]" : "border-border text-muted-foreground hover:text-foreground"
            )}
          >
            {f}
          </button>
        ))}
      </div>

      <div className="space-y-8">
        {categoriesToShow.map((category) => {
          const list = drills.filter((d) => d.category === category);
          if (category === "GameIQ") {
            return (
              <div key={category}>
                <SectionLabel>{category}</SectionLabel>
                <p className="mt-1 text-xs text-muted-foreground">{CATEGORY_META[category].desc}</p>
                <div className="mt-4 grid grid-cols-1 gap-4 md:grid-cols-2">
                  <ComingSoonCard />
                </div>
              </div>
            );
          }
          if (list.length === 0) return null;
          return (
            <div key={category}>
              <SectionLabel>{category}</SectionLabel>
              <p className="mt-1 text-xs text-muted-foreground">{CATEGORY_META[category].desc}</p>
              <div className="mt-4 grid grid-cols-1 gap-4 md:grid-cols-2">
                {list.map((d) => <DrillCard key={d.id} drill={d} onOpen={() => onOpenDrill(d.id)} />)}
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}

function DrillCard({ drill, onOpen }: { drill: Drill; onOpen: () => void }) {
  const [pickOpen, setPickOpen] = useState(false);
  return (
    <div className="flex flex-col overflow-hidden rounded-xl border border-border bg-card">
      <div className="flex-1 p-5">
        <div className="flex items-start gap-3">
          <CategoryAvatar category={drill.category} />
          <div className="min-w-0 flex-1">
            <button onClick={onOpen} className="text-left text-base font-semibold hover:text-[#00D4C8]">
              {drill.name}
            </button>
            <div className="mt-1.5 flex flex-wrap items-center gap-1.5">
              <TagPill tone="teal">{drill.category}</TagPill>
              <LevelBadge level={drill.level} />
            </div>
          </div>
          {drill.favorite && <Star className="h-4 w-4 fill-amber-400 text-amber-400" />}
        </div>
        <div className="mt-3 text-[11px] text-muted-foreground">
          Ages {drill.ages} · {drill.duration} · {drill.sessions} sessions
        </div>
        <p className="mt-2 text-sm text-muted-foreground">{drill.description}</p>
      </div>
      <div className="grid grid-cols-2 gap-2 border-t border-border p-3">
        <OutlineButton onClick={() => toast.success(`Saved "${drill.name}" to Favorites`)}>
          <Heart className="h-3.5 w-3.5" /> Save
        </OutlineButton>
        <GradientButton onClick={() => setPickOpen(true)}>
          <Plus className="h-3.5 w-3.5" /> Add to Practice
        </GradientButton>
      </div>
      {pickOpen && (
        <AddToPracticeModal
          drill={drill}
          onClose={() => setPickOpen(false)}
        />
      )}
    </div>
  );
}

function AddToPracticeModal({ drill, onClose }: { drill: Drill; onClose: () => void }) {
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 p-4" onClick={onClose}>
      <div
        className="w-full max-w-md overflow-hidden rounded-xl border border-border bg-background"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="flex items-center justify-between border-b border-border p-4">
          <div>
            <div className="text-sm font-semibold">Add to Practice</div>
            <div className="mt-0.5 text-xs text-muted-foreground truncate">{drill.name}</div>
          </div>
          <button onClick={onClose} className="text-muted-foreground hover:text-foreground">
            <X className="h-4 w-4" />
          </button>
        </div>
        <div className="max-h-96 space-y-2 overflow-y-auto p-4">
          {PRACTICES.map((p) => (
            <button
              key={p.id}
              onClick={() => {
                toast.success(`Added "${drill.name}" to ${p.name}`);
                onClose();
              }}
              className="flex w-full items-center gap-3 rounded-lg border border-border bg-card p-3 text-left transition hover:border-[#00D4C8]/60"
            >
              <div className="flex h-9 w-9 shrink-0 items-center justify-center rounded-full bg-[#00D4C8]/15 text-[#00D4C8]">
                <Plus className="h-4 w-4" />
              </div>
              <div className="min-w-0 flex-1">
                <div className="truncate text-sm font-semibold">{p.name}</div>
                <div className="mt-0.5 text-[11px] text-muted-foreground">
                  {p.date} · {p.duration} · {p.drillCount} drills · {p.status}
                </div>
              </div>
            </button>
          ))}
        </div>
      </div>
    </div>
  );
}

function ComingSoonCard() {
  return (
    <div className="relative flex min-h-[220px] flex-col overflow-hidden rounded-xl border border-border bg-black/60 p-5">
      <div className="flex items-start gap-3">
        <CategoryAvatar category="GameIQ" />
        <div>
          <div className="text-base font-semibold text-muted-foreground">GameIQ</div>
          <div className="mt-1.5">
            <span className="rounded bg-muted px-1.5 py-0.5 text-[10px] font-bold uppercase tracking-wider text-muted-foreground ring-1 ring-border">
              Coming Soon
            </span>
          </div>
        </div>
      </div>
      <div className="mt-auto flex flex-col items-center gap-2 pt-6 text-center">
        <div className="flex h-12 w-12 items-center justify-center rounded-full bg-white/5 ring-1 ring-white/10">
          <Lock className="h-5 w-5 text-muted-foreground" />
        </div>
        <div className="text-sm font-semibold">Coming Soon</div>
        <div className="text-xs text-muted-foreground">GameIQ analysis tools are coming soon.</div>
      </div>
    </div>
  );
}

/* ---------- Practices Tab ---------- */

function PracticesTab({ onOpenPractice }: { onOpenPractice: (id?: string) => void }) {
  return (
    <div className="space-y-4">
      <div className="flex justify-end">
        <GradientButton onClick={() => onOpenPractice()}>
          <Plus className="h-3.5 w-3.5" /> Create Practice
        </GradientButton>
      </div>
      <div className="space-y-3">
        {PRACTICES.map((p) => (
          <button
            key={p.id}
            onClick={() => onOpenPractice(p.id)}
            className="flex w-full items-center justify-between rounded-lg border border-border bg-card p-4 text-left transition hover:border-[#00D4C8]/50"
          >
            <div>
              <div className="text-sm font-semibold">{p.name}</div>
              <div className="mt-1 text-xs text-muted-foreground">{p.date} · {p.duration} · {p.location}</div>
              <div className="mt-1 text-[11px] text-muted-foreground">{p.drillCount} drills</div>
            </div>
            <span
              className={cn(
                "rounded px-2 py-0.5 text-[10px] font-bold uppercase tracking-wider ring-1",
                p.status === "PUBLISHED"
                  ? "bg-[#00D4C8]/15 text-[#00D4C8] ring-[#00D4C8]/30"
                  : "bg-muted text-muted-foreground ring-border"
              )}
            >
              {p.status}
            </span>
          </button>
        ))}
      </div>
    </div>
  );
}

/* ---------- Series Tab ---------- */

type SeriesProgram = {
  id: string;
  name: string;
  category: Category;
  level: Level;
  sessions: number;
  totalMin: number;
  desc: string;
  pxf?: boolean;
};

const PXF_PROGRAMS: SeriesProgram[] = [
  { id: "pxf1", name: "Skating Level 1", category: "Skating", level: "BEGINNER", sessions: 5, totalMin: 150, desc: "Foundation skating skills for new players.", pxf: true },
  { id: "pxf2", name: "Skating Level 2", category: "Skating", level: "INTERMEDIATE", sessions: 5, totalMin: 175, desc: "Edge work and crossover progressions.", pxf: true },
  { id: "pxf3", name: "Slip Circuit Intensive", category: "Slip Training", level: "INTERMEDIATE", sessions: 3, totalMin: 120, desc: "Full slip training progression program.", pxf: true },
];

const MY_SERIES: SeriesProgram[] = [];

function SeriesTab({ onOpenSeries }: { onOpenSeries: (id?: string) => void }) {
  return (
    <div className="space-y-10">
      <section>
        <SectionLabel>PXF Programs</SectionLabel>
        <p className="mt-1 text-xs text-muted-foreground">Pre-built programs by PXF Hockey. Duplicate to customize.</p>
        <div className="mt-4 grid grid-cols-1 gap-4 md:grid-cols-2">
          {PXF_PROGRAMS.map((s) => (
            <SeriesCard key={s.id} program={s} onDuplicate={() => onOpenSeries(s.id)} />
          ))}
        </div>
      </section>

      <section>
        <div className="flex items-center justify-between">
          <div>
            <SectionLabel>My Series</SectionLabel>
            <p className="mt-1 text-xs text-muted-foreground">Coach-created series you can edit anytime.</p>
          </div>
          <GradientButton onClick={() => onOpenSeries()}>
            <Plus className="h-3.5 w-3.5" /> Create Series
          </GradientButton>
        </div>
        <div className="mt-4">
          {MY_SERIES.length === 0 ? (
            <div className="rounded-xl border border-dashed border-border bg-card p-10 text-center">
              <div className="text-sm font-semibold">No custom series yet.</div>
              <p className="mt-1 text-xs text-muted-foreground">Create your own or duplicate a PXF program above.</p>
            </div>
          ) : (
            <div className="grid grid-cols-1 gap-4 md:grid-cols-2">
              {MY_SERIES.map((s) => (
                <SeriesCard key={s.id} program={s} onDuplicate={() => onOpenSeries(s.id)} />
              ))}
            </div>
          )}
        </div>
      </section>
    </div>
  );
}

function SeriesCard({ program, onDuplicate }: { program: SeriesProgram; onDuplicate: () => void }) {
  return (
    <div className="relative flex flex-col overflow-hidden rounded-xl border border-border bg-card p-5">
      {program.pxf && (
        <span className="absolute right-3 top-3 rounded bg-[#00D4C8]/15 px-1.5 py-0.5 text-[10px] font-bold uppercase tracking-wider text-[#00D4C8] ring-1 ring-[#00D4C8]/30">
          PXF
        </span>
      )}
      <div className="pr-14 text-base font-semibold">{program.name}</div>
      <div className="mt-2 flex flex-wrap items-center gap-1.5">
        <TagPill tone="teal">{program.category}</TagPill>
        <LevelBadge level={program.level} />
      </div>
      <div className="mt-3 text-[11px] text-muted-foreground">
        {program.sessions} sessions · {program.totalMin} min total
      </div>
      <p className="mt-2 text-sm text-muted-foreground">{program.desc}</p>
      <div className="mt-4 grid grid-cols-2 gap-2">
        <OutlineButton>
          <Eye className="h-3.5 w-3.5" /> Preview
        </OutlineButton>
        <GradientButton onClick={onDuplicate}>
          <Copy className="h-3.5 w-3.5" /> Duplicate & Edit
        </GradientButton>
      </div>
    </div>
  );
}

/* ---------- Dryland Tab ---------- */

type DrylandProgram = {
  id: string;
  name: string;
  by: string;
  weeks: number;
  perWeek: number;
  level: Level;
  desc: string;
};

type AssignedProgram = {
  id: string;
  programId: string;
  programName: string;
  assignedTo: string;
  weeks: number;
  completed: number;
  total: number;
};

const DRYLAND_LIBRARY: DrylandProgram[] = [
  { id: "dl1", name: "Off-Season Core Foundation", by: "PXF Hockey", weeks: 8, perWeek: 3, level: "BEGINNER", desc: "Core stability and mobility for young athletes." },
  { id: "dl2", name: "Elite Conditioning Program", by: "PXF Hockey", weeks: 12, perWeek: 4, level: "ADVANCED", desc: "Full-body athletic development for AAA players." },
  { id: "dl3", name: "Explosive Speed Circuit", by: "PXF Hockey", weeks: 6, perWeek: 3, level: "INTERMEDIATE", desc: "Speed, agility, and power development." },
];

const ASSIGNED: AssignedProgram[] = [
  { id: "a1", programId: "dl2", programName: "Elite Conditioning Program", assignedTo: "Elite Demo Team", weeks: 12, completed: 14, total: 48 },
  { id: "a2", programId: "dl1", programName: "Off-Season Core Foundation", assignedTo: "Atom Rep Team", weeks: 8, completed: 6, total: 24 },
  { id: "a3", programId: "dl3", programName: "Explosive Speed Circuit", assignedTo: "J. Sinclair (U16)", weeks: 6, completed: 3, total: 18 },
];

function DrylandTab({ onOpenProgress }: { onOpenProgress: (id: string) => void }) {
  return (
    <div className="space-y-6">
      <div className="rounded-lg border border-border/60 bg-card/60 p-3 text-xs italic text-muted-foreground">
        Dryland programs are managed by PXF Hockey and collaborators. Coaches can assign programs to teams or individual athletes.
      </div>

      <div className="grid grid-cols-1 gap-6 lg:grid-cols-5">
        {/* Left — Assigned */}
        <div className="space-y-4 lg:col-span-3">
          <div className="flex items-center justify-between">
            <SectionLabel>Assigned Programs</SectionLabel>
            <OutlineButton>
              <Plus className="h-3.5 w-3.5" /> Assign Program
            </OutlineButton>
          </div>
          <div className="space-y-3">
            {ASSIGNED.map((a) => {
              const pct = Math.round((a.completed / a.total) * 100);
              return (
                <div key={a.id} className="rounded-lg border border-border bg-card p-4">
                  <div className="flex items-start justify-between gap-3">
                    <div className="min-w-0">
                      <div className="text-sm font-semibold">{a.programName}</div>
                      <div className="mt-1 text-xs text-muted-foreground">
                        Assigned to {a.assignedTo} · {a.weeks} weeks
                      </div>
                    </div>
                    <button
                      onClick={() => onOpenProgress(a.id)}
                      className="whitespace-nowrap text-xs font-medium text-[#00D4C8] hover:underline"
                    >
                      View Progress →
                    </button>
                  </div>
                  <div className="mt-3">
                    <div className="flex items-center justify-between text-[11px] text-muted-foreground">
                      <span>{a.completed} of {a.total} sessions completed</span>
                      <span>{pct}%</span>
                    </div>
                    <div className="mt-1.5 h-1.5 w-full overflow-hidden rounded-full bg-muted">
                      <div className="h-full rounded-full bg-[#00D4C8]" style={{ width: `${pct}%` }} />
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Right — Library */}
        <div className="space-y-4 lg:col-span-2">
          <SectionLabel>Dryland Library</SectionLabel>
          <div className="space-y-3">
            {DRYLAND_LIBRARY.map((p) => (
              <div key={p.id} className="rounded-lg border border-border bg-card p-4">
                <div className="text-sm font-semibold">{p.name}</div>
                <div className="mt-0.5 text-[11px] text-muted-foreground">By {p.by}</div>
                <div className="mt-2 flex flex-wrap items-center gap-1.5">
                  <TagPill>{p.weeks}w</TagPill>
                  <TagPill>{p.perWeek}x/wk</TagPill>
                  <LevelBadge level={p.level} />
                </div>
                <p className="mt-2 text-xs text-muted-foreground">{p.desc}</p>
                <button className="mt-3 inline-flex h-8 w-full items-center justify-center gap-1.5 rounded-md border border-[#00D4C8]/40 bg-transparent px-3 text-xs font-semibold text-[#00D4C8] transition hover:bg-[#00D4C8]/10">
                  <Plus className="h-3.5 w-3.5" /> Assign
                </button>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}

/* ---------- Favorites Tab ---------- */

function FavoritesTab({ onOpenDrill }: { onOpenDrill: (id: string) => void }) {
  const favs = DRILLS.filter((d) => d.favorite);
  if (favs.length === 0) {
    return (
      <div className="rounded-xl border border-dashed border-border bg-card p-12 text-center">
        <Star className="mx-auto h-8 w-8 text-muted-foreground" />
        <div className="mt-3 text-sm font-semibold">No favorites yet.</div>
        <p className="mt-1 text-xs text-muted-foreground">Browse the drill library and tap ♡ to save drills here.</p>
      </div>
    );
  }
  return (
    <div className="grid grid-cols-1 gap-4 md:grid-cols-2">
      {favs.map((d) => <DrillCard key={d.id} drill={d} onOpen={() => onOpenDrill(d.id)} />)}
    </div>
  );
}

/* ============================================================
   DRILL DETAIL
============================================================ */

function DrillDetail({ drill, onBack }: { drill: Drill; onBack: () => void }) {
  const [notes, setNotes] = useState(drill.notes ?? "");
  const [pickOpen, setPickOpen] = useState(false);
  const progressions = drill.progressions ?? [];

  return (
    <div className="space-y-6 pb-8">
      <button onClick={onBack} className="inline-flex items-center gap-1 text-xs text-muted-foreground hover:text-foreground">
        <ChevronLeft className="h-3.5 w-3.5" /> Drills
      </button>

      <div className="grid grid-cols-1 gap-6 lg:grid-cols-5">
        {/* LEFT — 60% */}
        <div className="space-y-6 lg:col-span-3">
          <div className="flex aspect-video items-center justify-center overflow-hidden rounded-xl border border-border bg-black">
            {drill.videoName || drill.ihsUrl ? (
              <div className="flex flex-col items-center gap-3 text-muted-foreground">
                <div className="flex h-16 w-16 items-center justify-center rounded-full bg-[#00D4C8]/15 ring-1 ring-[#00D4C8]/40">
                  <Play className="ml-1 h-7 w-7 text-[#00D4C8]" />
                </div>
                <div className="text-xs">
                  {drill.videoName ? `▶ ${drill.videoName}` : `IHS link: ${drill.ihsUrl}`}
                </div>
              </div>
            ) : (
              <div className="flex flex-col items-center gap-3 text-muted-foreground">
                <div className="flex h-16 w-16 items-center justify-center rounded-full bg-white/5 ring-1 ring-white/10">
                  <Play className="ml-1 h-7 w-7" />
                </div>
                <div className="text-xs">No video uploaded</div>
              </div>
            )}
          </div>

          <div>
            <div className="text-[11px] font-semibold uppercase tracking-[0.18em] text-[#00D4C8]">
              {drill.category}
            </div>
            <h1 className="mt-2 text-2xl font-semibold tracking-tight">{drill.name}</h1>
            <div className="mt-3 flex flex-wrap items-center gap-1.5">
              <TagPill tone="teal">{drill.category}</TagPill>
              <LevelBadge level={drill.level} />
              <TagPill>Ages {drill.ages}</TagPill>
              <TagPill>{drill.duration}</TagPill>
            </div>
            <p className="mt-4 text-sm text-muted-foreground">{drill.description}</p>
          </div>

          <div>
            <SectionLabel>Coaching Notes</SectionLabel>
            <textarea
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              rows={4}
              placeholder="Add notes for this drill…"
              className="mt-3 w-full resize-none rounded-lg border border-border bg-card p-3 text-sm outline-none focus:border-[#00D4C8]"
            />
          </div>

          <div>
            <SectionLabel>Progressions</SectionLabel>
            <ol className="mt-3 space-y-2">
              {progressions.length === 0 && (
                <li className="text-xs text-muted-foreground">No progressions defined.</li>
              )}
              {progressions.map((p, i) => (
                <li key={i} className="flex gap-3 rounded-lg border border-border bg-card p-3 text-sm">
                  <span className="flex h-6 w-6 shrink-0 items-center justify-center rounded-full bg-[#00D4C8]/15 text-[11px] font-bold text-[#00D4C8]">
                    {i + 1}
                  </span>
                  <span>{p}</span>
                </li>
              ))}
            </ol>
          </div>
        </div>

        {/* RIGHT — 40% */}
        <div className="space-y-6 lg:col-span-2">
          <div>
            <SectionLabel>Rink Diagram</SectionLabel>
            <div className="mt-3 rounded-xl border border-border bg-card p-3">
              {drill.diagram ? (
                <SavedRinkSnapshot diagram={drill.diagram} />
              ) : (
                <RinkDiagram />
              )}
              <div className="mt-3 flex justify-end">
                <OutlineButton>Edit Diagram</OutlineButton>
              </div>
            </div>
          </div>

          <div className="rounded-xl border border-border bg-card p-4">
            <GradientButton
              className="w-full py-3 text-sm"
              onClick={() => setPickOpen(true)}
            >
              <Plus className="h-4 w-4" /> Add to Practice
            </GradientButton>
            <button
              onClick={() => toast.success(`"${drill.name}" added to Favorites`)}
              className="mt-3 inline-flex w-full items-center justify-center gap-1.5 text-xs text-muted-foreground hover:text-[#00D4C8]"
            >
              <Heart className="h-3.5 w-3.5" /> Add to Favorites
            </button>
          </div>
        </div>
      </div>
      {pickOpen && <AddToPracticeModal drill={drill} onClose={() => setPickOpen(false)} />}
    </div>
  );
}

function RinkDiagram({ waypoints, showSecondary = true }: { waypoints?: { x: number; y: number }[]; showSecondary?: boolean }) {
  const pts = waypoints ?? [
    { x: 140, y: 250 },
    { x: 320, y: 150 },
    { x: 480, y: 200 },
    { x: 640, y: 100 },
  ];

  const primaryPath = useMemo(() => {
    if (pts.length < 2) return "";
    let d = `M ${pts[0].x} ${pts[0].y}`;
    for (let i = 1; i < pts.length; i++) {
      const prev = pts[i - 1];
      const cur = pts[i];
      const cx = (prev.x + cur.x) / 2;
      const cy = (prev.y + cur.y) / 2 - 30;
      d += ` Q ${cx} ${cy} ${cur.x} ${cur.y}`;
    }
    return d;
  }, [pts]);

  return (
    <div className="overflow-hidden rounded-lg bg-[#0a0a0a] p-2">
      <svg viewBox="0 0 800 340" className="w-full">
        <rect x="10" y="10" width="780" height="320" rx="80" ry="80" fill="#0f1a1a" stroke="#e5e7eb" strokeWidth="2" />
        <line x1="400" y1="10" x2="400" y2="330" stroke="#dc2626" strokeWidth="2" />
        <line x1="280" y1="10" x2="280" y2="330" stroke="#2563eb" strokeWidth="2" />
        <line x1="520" y1="10" x2="520" y2="330" stroke="#2563eb" strokeWidth="2" />
        <line x1="80" y1="10" x2="80" y2="330" stroke="#dc2626" strokeWidth="1.5" />
        <line x1="720" y1="10" x2="720" y2="330" stroke="#dc2626" strokeWidth="1.5" />
        <circle cx="400" cy="170" r="45" fill="none" stroke="#2563eb" strokeWidth="1.5" />
        <circle cx="400" cy="170" r="3" fill={TEAL} />
        {[[160, 90], [160, 250], [640, 90], [640, 250]].map(([cx, cy]) => (
          <circle key={`${cx}-${cy}`} cx={cx} cy={cy} r="28" fill="none" stroke="#dc2626" strokeWidth="1.5" />
        ))}
        {/* Goal creases */}
        <path d="M 80 150 A 20 20 0 0 1 80 190" fill="none" stroke={TEAL} strokeWidth="1.5" />
        <path d="M 720 150 A 20 20 0 0 0 720 190" fill="none" stroke={TEAL} strokeWidth="1.5" />

        {primaryPath && (
          <path d={primaryPath} fill="none" stroke={TEAL} strokeWidth="3" strokeLinecap="round" />
        )}
        {showSecondary && (
          <path
            d="M 140 250 C 220 200, 320 210, 400 220 S 560 150, 640 100"
            fill="none"
            stroke="#22c55e"
            strokeWidth="2.5"
            strokeDasharray="6 6"
            strokeLinecap="round"
          />
        )}

        {pts.map((w, i) => (
          <g key={i}>
            <circle cx={w.x} cy={w.y} r="14" fill={TEAL} />
            <text x={w.x} y={w.y + 4} textAnchor="middle" fontSize="13" fontWeight="700" fill="#001a19">
              {i + 1}
            </text>
          </g>
        ))}
      </svg>
    </div>
  );
}

/* ============================================================
   DRILL BUILDER — Full-screen dark arena
============================================================ */

type RinkView = "full" | "half" | "neutral" | "corner";

type Point = { x: number; y: number };

type Item =
  | { kind: "freedraw"; id: string; points: Point[] }
  | { kind: "route"; id: string; points: Point[] }
  | { kind: "pass"; id: string; points: Point[] }
  | { kind: "cone"; id: string; at: Point; rotation: number }
  | { kind: "slip"; id: string; at: Point; rotation: number }
  | { kind: "bumper"; id: string; at: Point; rotation: number }
  | { kind: "tire"; id: string; at: Point; rotation: number }
  | { kind: "net"; id: string; at: Point; rotation: number }
  | { kind: "puck"; id: string; at: Point };

type ToolId =
  | "select"
  | "freedraw"
  | "route"
  | "pass"
  | "cone" | "slip" | "bumper" | "tire" | "net" | "puck";

type IceMode = "dark" | "white";

const RINK_VIEWS: { id: RinkView; label: string }[] = [
  { id: "full", label: "Full Ice" },
  { id: "half", label: "Half Ice" },
  { id: "neutral", label: "Neutral" },
  { id: "corner", label: "Corner" },
];

const FULL_W = 1000;
const FULL_H = 500;

function viewBoxFor(v: RinkView): string {
  switch (v) {
    case "full": return `0 0 ${FULL_W} ${FULL_H}`;
    case "half": return `500 0 500 ${FULL_H}`;
    case "neutral": return `320 0 360 ${FULL_H}`;
    case "corner": return `700 0 300 250`;
  }
}

function itemAnchor(it: Item): Point {
  if ("at" in it) return it.at;
  const pts = it.points;
  return pts[pts.length - 1] ?? { x: 0, y: 0 };
}

/* Reduce noise in a freehand stroke: distance filter + Chaikin smoothing. */
function simplifyStroke(points: Point[], minDist = 5): Point[] {
  if (points.length < 3) return points;
  const filtered: Point[] = [points[0]];
  for (let i = 1; i < points.length - 1; i++) {
    const last = filtered[filtered.length - 1];
    const p = points[i];
    if (Math.hypot(p.x - last.x, p.y - last.y) >= minDist) filtered.push(p);
  }
  filtered.push(points[points.length - 1]);
  // Chaikin corner cutting (2 passes) — endpoints preserved
  let pts = filtered;
  for (let pass = 0; pass < 2 && pts.length >= 3; pass++) {
    const next: Point[] = [pts[0]];
    for (let i = 0; i < pts.length - 1; i++) {
      const a = pts[i], b = pts[i + 1];
      next.push({ x: 0.75 * a.x + 0.25 * b.x, y: 0.75 * a.y + 0.25 * b.y });
      next.push({ x: 0.25 * a.x + 0.75 * b.x, y: 0.25 * a.y + 0.75 * b.y });
    }
    next.push(pts[pts.length - 1]);
    pts = next;
  }
  return pts;
}

function DrillBuilder({
  onBack,
  onPublished,
}: {
  onBack: () => void;
  onPublished?: (id: string) => void;
}) {
  // form
  const [name, setName] = useState("");
  const [category, setCategory] = useState<Category>("Skating");
  const [difficulty, setDifficulty] = useState<Level>("BEGINNER");
  const [ages, setAges] = useState("");
  const [duration, setDuration] = useState<number | "">("");
  const [description, setDescription] = useState("");
  const [notes, setNotes] = useState("");
  const [progressions, setProgressions] = useState<string[]>([""]);
  const [ihsUrl, setIhsUrl] = useState("");
  const [videoName, setVideoName] = useState("");
  const detailsRef = useRef<HTMLDivElement>(null);
  const rinkRef = useRef<HTMLDivElement>(null);

  // rink state
  const [view, setView] = useState<RinkView>("full");
  const [iceMode, setIceMode] = useState<IceMode>("dark");
  const [tool, setTool] = useState<ToolId>("select");
  const [history, setHistory] = useState<Item[][]>([[]]);
  const [histIdx, setHistIdx] = useState(0);
  const items = history[histIdx];
  const [selectedId, setSelectedId] = useState<string | null>(null);

  // in-progress drawing
  const [freePts, setFreePts] = useState<Point[] | null>(null);
  const [routePts, setRoutePts] = useState<Point[]>([]);
  const [passPts, setPassPts] = useState<Point[]>([]);
  const [hoverPt, setHoverPt] = useState<Point | null>(null);

  // drag state for select (move + rotate)
  const [drag, setDrag] = useState<
    | { mode: "move"; id: string; offset: Point }
    | { mode: "rotate"; id: string; startAngle: number; startRotation: number }
    | null
  >(null);

  // UI
  const [confirmClear, setConfirmClear] = useState(false);

  const svgRef = useRef<SVGSVGElement>(null);

  const commit = (next: Item[]) => {
    const trimmed = history.slice(0, histIdx + 1);
    setHistory([...trimmed, next]);
    setHistIdx(trimmed.length);
  };
  const undo = () => { if (histIdx > 0) setHistIdx(histIdx - 1); };
  const redo = () => { if (histIdx < history.length - 1) setHistIdx(histIdx + 1); };
  const clearAll = () => { commit([]); setConfirmClear(false); setSelectedId(null); };

  // finalize any in-progress lines when tool changes
  useEffect(() => {
    if (freePts && tool !== "freedraw") {
      if (freePts.length > 1) commit([...items, { kind: "freedraw", id: `f${Date.now()}`, points: simplifyStroke(freePts) }]);
      setFreePts(null);
    }
    if (routePts.length && tool !== "route") {
      if (routePts.length > 1) commit([...items, { kind: "route", id: `r${Date.now()}`, points: routePts }]);
      setRoutePts([]);
    }
    if (passPts.length && tool !== "pass") {
      if (passPts.length > 1) commit([...items, { kind: "pass", id: `p${Date.now()}`, points: passPts }]);
      setPassPts([]);
    }
    setHoverPt(null);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [tool]);

  // Escape/Enter to finish multi-click lines
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape" || e.key === "Enter") {
        if (routePts.length > 1) commit([...items, { kind: "route", id: `r${Date.now()}`, points: routePts }]);
        if (passPts.length > 1) commit([...items, { kind: "pass", id: `p${Date.now()}`, points: passPts }]);
        setRoutePts([]); setPassPts([]); setHoverPt(null);
      }
      if (e.key === "Delete" || e.key === "Backspace") {
        if (selectedId) {
          commit(items.filter((i) => i.id !== selectedId));
          setSelectedId(null);
        }
      }
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [routePts, passPts, selectedId, items]);

  const svgPoint = (clientX: number, clientY: number): Point | null => {
    const svg = svgRef.current;
    if (!svg) return null;
    const pt = svg.createSVGPoint();
    pt.x = clientX; pt.y = clientY;
    const ctm = svg.getScreenCTM();
    if (!ctm) return null;
    const loc = pt.matrixTransform(ctm.inverse());
    return { x: loc.x, y: loc.y };
  };

  const onDown = (e: React.MouseEvent<SVGSVGElement>) => {
    const p = svgPoint(e.clientX, e.clientY);
    if (!p) return;
    if (tool === "select") {
      setSelectedId(null);
      return;
    }
    if (tool === "freedraw") { setFreePts([p]); return; }
    if (tool === "route") { setRoutePts((r) => [...r, p]); return; }
    if (tool === "pass") { setPassPts((r) => [...r, p]); return; }
    // placement tools
    const id = `${tool}${Date.now()}`;
    if (tool === "cone") commit([...items, { kind: "cone", id, at: p, rotation: 0 }]);
    else if (tool === "slip") commit([...items, { kind: "slip", id, at: p, rotation: 0 }]);
    else if (tool === "bumper") commit([...items, { kind: "bumper", id, at: p, rotation: 0 }]);
    else if (tool === "tire") commit([...items, { kind: "tire", id, at: p, rotation: 0 }]);
    else if (tool === "net") commit([...items, { kind: "net", id, at: p, rotation: 0 }]);
    else if (tool === "puck") commit([...items, { kind: "puck", id, at: p }]);
  };

  const onMove = (e: React.MouseEvent<SVGSVGElement>) => {
    const p = svgPoint(e.clientX, e.clientY);
    if (!p) return;
    if (tool === "freedraw" && freePts) {
      setFreePts([...freePts, p]);
      return;
    }
    if ((tool === "route" && routePts.length) || (tool === "pass" && passPts.length)) {
      setHoverPt(p);
      return;
    }
    if (tool === "select" && drag) {
      if (drag.mode === "move") {
        const next = items.map((it) => {
          if (it.id !== drag.id) return it;
          const nx = p.x - drag.offset.x;
          const ny = p.y - drag.offset.y;
          if ("at" in it) return { ...it, at: { x: nx, y: ny } };
          const first = it.points[0];
          const dx = nx - first.x;
          const dy = ny - first.y;
          return { ...it, points: it.points.map((pt) => ({ x: pt.x + dx, y: pt.y + dy })) };
        });
        const copy = [...history];
        copy[histIdx] = next;
        setHistory(copy);
      } else if (drag.mode === "rotate") {
        const it = items.find((i) => i.id === drag.id);
        if (!it || !("at" in it) || !("rotation" in it)) return;
        const a = itemAnchor(it);
        const ang = (Math.atan2(p.y - a.y, p.x - a.x) * 180) / Math.PI;
        const rotation = drag.startRotation + (ang - drag.startAngle);
        const next = items.map((x) =>
          x.id === drag.id && "rotation" in x ? { ...x, rotation } : x
        );
        const copy = [...history];
        copy[histIdx] = next;
        setHistory(copy);
      }
    }
  };

  const onUp = () => {
    if (tool === "freedraw" && freePts) {
      if (freePts.length > 1) commit([...items, { kind: "freedraw", id: `f${Date.now()}`, points: simplifyStroke(freePts) }]);
      setFreePts(null);
    }
    if (drag) {
      const trimmed = history.slice(0, histIdx + 1);
      setHistory(trimmed);
      setDrag(null);
    }
  };

  const startDrag = (e: React.MouseEvent, id: string) => {
    if (tool !== "select") return;
    e.stopPropagation();
    setSelectedId(id);
    const p = svgPoint(e.clientX, e.clientY);
    const it = items.find((i) => i.id === id);
    if (!p || !it) return;
    const a = itemAnchor(it);
    setDrag({ mode: "move", id, offset: { x: p.x - a.x, y: p.y - a.y } });
  };

  const startRotate = (e: React.MouseEvent, id: string) => {
    e.stopPropagation();
    const p = svgPoint(e.clientX, e.clientY);
    const it = items.find((i) => i.id === id);
    if (!p || !it || !("rotation" in it)) return;
    const a = itemAnchor(it);
    const startAngle = (Math.atan2(p.y - a.y, p.x - a.x) * 180) / Math.PI;
    setDrag({ mode: "rotate", id, startAngle, startRotation: it.rotation });
  };

  const deleteSelected = () => {
    if (!selectedId) return;
    commit(items.filter((i) => i.id !== selectedId));
    setSelectedId(null);
  };

  const cursor =
    tool === "select"
      ? drag ? (drag.mode === "rotate" ? "grabbing" : "grabbing") : "default"
      : tool === "freedraw" || tool === "route" || tool === "pass"
      ? "crosshair"
      : "copy";

  const selectedItem = selectedId ? items.find((i) => i.id === selectedId) : null;

  const publish = () => {
    const id = `custom-${Date.now()}`;
    const newDrill: Drill = {
      id,
      name: name.trim() || "Untitled Drill",
      category,
      level: difficulty,
      ages: ages || "All ages",
      duration: duration ? `${duration}m` : "—",
      sessions: 1,
      description: description || "Custom drill created in the builder.",
      notes,
      progressions: progressions.map((p) => p.trim()).filter(Boolean),
      custom: true,
      diagram: { items, view, iceMode },
      videoName: videoName || undefined,
      ihsUrl: ihsUrl || undefined,
    };
    addCustomDrill(newDrill);
    if (onPublished) onPublished(id);
    else onBack();
  };

  const scrollToRink = () => rinkRef.current?.scrollIntoView({ behavior: "smooth", block: "start" });

  return (
    <div className="min-h-screen bg-[#08090c] text-foreground">
      {/* Sticky top bar */}
      <div className="sticky top-0 z-30 flex items-center gap-3 border-b border-white/5 bg-[#0d1117]/95 px-4 py-2.5 backdrop-blur">
        <button onClick={onBack} className="inline-flex items-center gap-1 rounded-md px-2 py-1.5 text-xs text-muted-foreground hover:bg-white/5 hover:text-foreground">
          <ChevronLeft className="h-3.5 w-3.5" /> Exit
        </button>
        <input
          value={name}
          onChange={(e) => setName(e.target.value)}
          placeholder="Untitled drill…"
          className="h-8 w-64 rounded-md border border-white/10 bg-white/5 px-3 text-sm outline-none focus:border-[#00D4C8]"
        />

        <div className="mx-auto flex items-center gap-2">
          <div className="flex items-center gap-1 rounded-full border border-white/10 bg-white/5 p-1">
            {RINK_VIEWS.map((v) => (
              <button
                key={v.id}
                onClick={() => setView(v.id)}
                className={cn(
                  "rounded-full px-3 py-1 text-[11px] font-medium transition",
                  view === v.id ? "bg-[#00D4C8] text-black" : "text-muted-foreground hover:text-foreground"
                )}
              >
                {v.label}
              </button>
            ))}
          </div>
          <button
            onClick={() => setIceMode((m) => (m === "dark" ? "white" : "dark"))}
            title="Toggle ice surface"
            className="inline-flex items-center gap-1.5 rounded-full border border-white/10 bg-white/5 px-3 py-1 text-[11px] font-medium text-muted-foreground hover:text-foreground"
          >
            {iceMode === "dark" ? <Moon className="h-3 w-3" /> : <Sun className="h-3 w-3" />}
            {iceMode === "dark" ? "Dark Ice" : "White Ice"}
          </button>
        </div>

        <div className="flex items-center gap-2">
          <OutlineButton>Save Draft</OutlineButton>
          <GradientButton onClick={publish}>Publish</GradientButton>
        </div>
      </div>

      {/* Video bar */}
      <div className="flex h-14 items-center gap-4 border-b border-white/5 bg-[#0d1117]/60 px-4">
        <label className="flex flex-1 cursor-pointer items-center gap-3 rounded-md border border-white/10 bg-white/5 px-3 py-2 text-xs hover:border-[#00D4C8]/40 hover:bg-white/10">
          <div className="flex h-7 w-7 items-center justify-center rounded-md bg-[#00D4C8]/15 text-[#00D4C8]">
            <Upload className="h-3.5 w-3.5" />
          </div>
          <div className="min-w-0 flex-1">
            <div className="text-[12px] font-semibold text-foreground">
              {videoName ? videoName : "Upload Drill Video"}
            </div>
            <div className="truncate text-[10px] text-muted-foreground">
              Drag &amp; drop or click to browse · MP4 or MOV · Max 2GB
            </div>
          </div>
          <input
            type="file"
            accept="video/mp4,video/quicktime"
            className="hidden"
            onChange={(e) => {
              const f = e.target.files?.[0];
              if (f) setVideoName(f.name);
            }}
          />
        </label>
        <div className="hidden items-center gap-2 md:flex">
          <span className="text-[10px] font-semibold uppercase tracking-[0.16em] text-muted-foreground">Or Link from IHS</span>
          <input
            value={ihsUrl}
            onChange={(e) => setIhsUrl(e.target.value)}
            placeholder="https://ihs…"
            className="h-9 w-72 rounded-md border border-white/10 bg-white/5 px-3 text-xs outline-none focus:border-[#00D4C8]"
          />
        </div>
      </div>

      {/* Rink section — fills the viewport */}
      <div ref={rinkRef} className="relative h-[calc(100vh-57px-56px)] min-h-[420px]">
        <svg
          ref={svgRef}
          viewBox={viewBoxFor(view)}
          preserveAspectRatio="xMidYMid meet"
          onMouseDown={onDown}
          onMouseMove={onMove}
          onMouseUp={onUp}
          onMouseLeave={onUp}
          className="absolute inset-0 h-full w-full select-none"
          style={{ background: iceMode === "dark" ? "#08090c" : "#e8ecf0", cursor }}
        >
          <ArenaRink iceMode={iceMode} />

          {items.map((it) => (
            <ItemLayer
              key={it.id}
              item={it}
              selected={selectedId === it.id}
              onDown={(e) => startDrag(e, it.id)}
            />
          ))}

          {freePts && freePts.length > 1 && (
            <path d={smoothPath(freePts)} fill="none" stroke={TEAL} strokeWidth="2.5" strokeLinecap="round" opacity="0.9" />
          )}
          {routePts.length > 0 && (
            <PolyRoute points={hoverPt ? [...routePts, hoverPt] : routePts} dashed={false} ghost />
          )}
          {passPts.length > 0 && (
            <PolyRoute points={hoverPt ? [...passPts, hoverPt] : passPts} dashed ghost />
          )}

          {selectedItem && (() => {
            const a = itemAnchor(selectedItem);
            const canRotate = "rotation" in selectedItem;
            return (
              <g>
                {canRotate && (
                  <g style={{ cursor: "grab" }} onMouseDown={(e) => startRotate(e, selectedItem.id)}>
                    <line x1={a.x} y1={a.y} x2={a.x} y2={a.y - 34} stroke={TEAL} strokeWidth="0.8" strokeDasharray="2 2" opacity="0.7" />
                    <circle cx={a.x} cy={a.y - 34} r="8" fill="#0d1117" stroke={TEAL} strokeWidth="1.5" />
                    <path d={`M ${a.x - 3.5} ${a.y - 36} A 3.5 3.5 0 1 1 ${a.x - 3.5} ${a.y - 32}`} fill="none" stroke={TEAL} strokeWidth="1.2" strokeLinecap="round" />
                    <path d={`M ${a.x - 5} ${a.y - 33} L ${a.x - 3.5} ${a.y - 31.5} L ${a.x - 2} ${a.y - 33}`} fill="none" stroke={TEAL} strokeWidth="1.2" strokeLinecap="round" strokeLinejoin="round" />
                  </g>
                )}
                <g style={{ cursor: "pointer" }} onMouseDown={(e) => { e.stopPropagation(); deleteSelected(); }}>
                  <circle cx={a.x + 22} cy={a.y - 22} r="9" fill="#dc2626" stroke="#fff" strokeWidth="1.5" />
                  <path d={`M ${a.x + 18} ${a.y - 26} L ${a.x + 26} ${a.y - 18} M ${a.x + 26} ${a.y - 26} L ${a.x + 18} ${a.y - 18}`} stroke="#fff" strokeWidth="1.8" strokeLinecap="round" />
                </g>
              </g>
            );
          })()}
        </svg>

        {/* Hint */}
        <div className="pointer-events-none absolute bottom-20 left-1/2 -translate-x-1/2 rounded-full border border-white/10 bg-black/60 px-3 py-1 text-[11px] text-muted-foreground backdrop-blur">
          {tool === "select" && "Click to select · drag to move · drag handle to rotate · Delete to remove"}
          {tool === "freedraw" && "Click and hold to draw freehand · release to finish"}
          {(tool === "route" || tool === "pass") && "Click to place waypoints · Enter or Esc to finish"}
          {["cone","slip","bumper","tire","net","puck"].includes(tool) && "Click on the ice to place"}
        </div>

        {/* Scroll-down cue */}
        <button
          onClick={() => detailsRef.current?.scrollIntoView({ behavior: "smooth" })}
          className="absolute bottom-20 right-4 inline-flex items-center gap-1 rounded-full border border-white/10 bg-black/60 px-3 py-1 text-[11px] text-muted-foreground backdrop-blur hover:text-foreground"
        >
          Fill in details ↓
        </button>

        {/* Bottom tool palette (overlaid on rink) */}
        <div className="absolute bottom-0 left-0 right-0 border-t border-white/5 bg-[#0d1117]/90 px-4 py-2 backdrop-blur">
          <div className="flex items-center justify-between gap-3">
            <div className="flex items-center gap-1 rounded-xl border border-white/10 bg-white/5 p-1">
              <PaletteButton active={tool === "select"} onClick={() => setTool("select")} tip="Select"><MousePointer2 className="h-4 w-4" /></PaletteButton>
              <PaletteButton active={tool === "freedraw"} onClick={() => setTool("freedraw")} tip="Free draw"><Pencil className="h-4 w-4" /></PaletteButton>
              <PaletteButton active={tool === "route"} onClick={() => setTool("route")} tip="Player route"><Spline className="h-4 w-4" /></PaletteButton>
              <PaletteButton active={tool === "pass"} onClick={() => setTool("pass")} tip="Pass line"><Minus className="h-4 w-4" style={{ strokeDasharray: "3 2" }} /></PaletteButton>
            </div>

            <div className="flex items-center gap-1 rounded-xl border border-white/10 bg-white/5 p-1">
              <PaletteButton active={tool === "cone"} onClick={() => setTool("cone")} tip="Cone"><IconCone /></PaletteButton>
              <PaletteButton active={tool === "slip"} onClick={() => setTool("slip")} tip="PXF Slip"><IconSlip /></PaletteButton>
              <PaletteButton active={tool === "bumper"} onClick={() => setTool("bumper")} tip="Bumper pad"><IconBumper /></PaletteButton>
              <PaletteButton active={tool === "tire"} onClick={() => setTool("tire")} tip="Tire"><IconTire /></PaletteButton>
              <PaletteButton active={tool === "net"} onClick={() => setTool("net")} tip="Net"><IconNet /></PaletteButton>
              <PaletteButton active={tool === "puck"} onClick={() => setTool("puck")} tip="Puck"><IconPuck /></PaletteButton>
            </div>

            <div className="flex items-center gap-1 rounded-xl border border-white/10 bg-white/5 p-1">
              <PaletteButton onClick={undo} tip="Undo"><Undo2 className="h-4 w-4" /></PaletteButton>
              <PaletteButton onClick={redo} tip="Redo"><Redo2 className="h-4 w-4" /></PaletteButton>
              <PaletteButton onClick={() => setConfirmClear(true)} tip="Clear all"><Trash2 className="h-4 w-4" /></PaletteButton>
            </div>
          </div>
        </div>
      </div>

      {/* Details section */}
      <div ref={detailsRef} className="border-t border-white/5 bg-[#0b0e13]">
        <div className="mx-auto max-w-4xl space-y-6 px-6 py-10">
          <div>
            <div className="text-[11px] font-semibold uppercase tracking-[0.18em] text-muted-foreground">Drill Name *</div>
            <input
              value={name}
              onChange={(e) => setName(e.target.value)}
              placeholder="e.g. Edge Mastery Series"
              className="mt-2 h-11 w-full rounded-md border border-white/10 bg-white/5 px-3 text-base outline-none focus:border-[#00D4C8]"
            />
          </div>

          <div className="grid grid-cols-1 gap-4 md:grid-cols-2">
            <div className="space-y-4">
              <Field label="Category">
                <select
                  value={category}
                  onChange={(e) => setCategory(e.target.value as Category)}
                  className="h-10 w-full rounded-md border border-white/10 bg-white/5 px-3 text-sm outline-none focus:border-[#00D4C8]"
                >
                  <option>Skating</option>
                  <option>Slip Training</option>
                  <option>GameIQ</option>
                  <option>Dryland</option>
                </select>
              </Field>
              <Field label="Difficulty">
                <select
                  value={difficulty}
                  onChange={(e) => setDifficulty(e.target.value as Level)}
                  className="h-10 w-full rounded-md border border-white/10 bg-white/5 px-3 text-sm outline-none focus:border-[#00D4C8]"
                >
                  <option value="BEGINNER">Beginner</option>
                  <option value="INTERMEDIATE">Intermediate</option>
                  <option value="ADVANCED">Advanced</option>
                </select>
              </Field>
            </div>
            <div className="space-y-4">
              <Field label="Age Range">
                <input
                  value={ages}
                  onChange={(e) => setAges(e.target.value)}
                  placeholder="Ages 10-16"
                  className="h-10 w-full rounded-md border border-white/10 bg-white/5 px-3 text-sm outline-none focus:border-[#00D4C8]"
                />
              </Field>
              <Field label="Duration">
                <div className="relative">
                  <input
                    type="number"
                    value={duration}
                    onChange={(e) => setDuration(e.target.value === "" ? "" : Number(e.target.value))}
                    placeholder="30"
                    className="h-10 w-full rounded-md border border-white/10 bg-white/5 pl-3 pr-10 text-sm outline-none focus:border-[#00D4C8]"
                  />
                  <span className="absolute right-3 top-1/2 -translate-y-1/2 text-xs text-muted-foreground">min</span>
                </div>
              </Field>
            </div>
          </div>

          <Field label="Description">
            <textarea
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              rows={3}
              className="w-full resize-none rounded-md border border-white/10 bg-white/5 p-3 text-sm outline-none focus:border-[#00D4C8]"
            />
          </Field>

          <Field label="Coaching Notes">
            <textarea
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              rows={4}
              className="w-full resize-none rounded-md border border-white/10 bg-white/5 p-3 text-sm outline-none focus:border-[#00D4C8]"
            />
          </Field>

          <div>
            <div className="mb-2 text-[11px] font-semibold uppercase tracking-[0.18em] text-muted-foreground">Progressions</div>
            <div className="space-y-2">
              {progressions.map((p, i) => (
                <div key={i} className="flex items-center gap-2">
                  <span className="flex h-7 w-7 shrink-0 items-center justify-center rounded-full bg-[#00D4C8]/15 text-[11px] font-bold text-[#00D4C8]">
                    {i + 1}
                  </span>
                  <input
                    value={p}
                    onChange={(e) => setProgressions((arr) => arr.map((x, idx) => (idx === i ? e.target.value : x)))}
                    placeholder={`Step ${i + 1}`}
                    className="h-10 flex-1 rounded-md border border-white/10 bg-white/5 px-3 text-sm outline-none focus:border-[#00D4C8]"
                  />
                </div>
              ))}
              <button
                onClick={() => setProgressions((p) => [...p, ""])}
                className="inline-flex items-center gap-1 text-xs font-medium text-[#00D4C8] hover:underline"
              >
                <Plus className="h-3 w-3" /> Add Progression Step
              </button>
            </div>
          </div>

          {/* Sticky footer inside details container */}
          <div className="sticky bottom-0 -mx-6 mt-8 flex items-center justify-between gap-3 border-t border-white/10 bg-[#0d1117]/95 px-6 py-3 backdrop-blur">
            <button
              onClick={scrollToRink}
              className="inline-flex items-center gap-1 text-xs font-medium text-muted-foreground hover:text-foreground"
            >
              <ChevronLeft className="h-3.5 w-3.5" /> Back to Rink
            </button>
            <div className="flex items-center gap-2">
              <OutlineButton>Save Draft</OutlineButton>
              <GradientButton onClick={publish}>Publish</GradientButton>
            </div>
          </div>
        </div>
      </div>

      {/* Clear-all confirm */}
      {confirmClear && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/70">
          <div className="w-full max-w-sm rounded-xl border border-white/10 bg-[#0d1117] p-5">
            <div className="text-sm font-semibold">Clear the ice?</div>
            <p className="mt-2 text-xs text-muted-foreground">This removes everything you've placed. This can be undone.</p>
            <div className="mt-5 flex justify-end gap-2">
              <OutlineButton onClick={() => setConfirmClear(false)}>Cancel</OutlineButton>
              <button
                onClick={clearAll}
                className="inline-flex items-center gap-1.5 rounded-md bg-red-600 px-4 py-2.5 text-xs font-semibold text-white hover:bg-red-500"
              >
                <Trash2 className="h-3.5 w-3.5" /> Clear All
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

/* ---------- Saved rink snapshot (non-interactive) ---------- */

function SavedRinkSnapshot({ diagram }: { diagram: { items: Item[]; view: RinkView; iceMode: IceMode } }) {
  return (
    <div className="overflow-hidden rounded-lg" style={{ background: diagram.iceMode === "dark" ? "#08090c" : "#e8ecf0" }}>
      <svg viewBox={viewBoxFor(diagram.view)} preserveAspectRatio="xMidYMid meet" className="w-full">
        <ArenaRink iceMode={diagram.iceMode} />
        {diagram.items.map((it) => (
          <g key={it.id}>
            <ItemShape item={it} />
          </g>
        ))}
      </svg>
    </div>
  );
}

/* ---------- Palette buttons ---------- */

function PaletteButton({
  active, onClick, tip, children,
}: {
  active?: boolean;
  onClick: () => void;
  tip: string;
  children: React.ReactNode;
}) {
  return (
    <button
      onClick={onClick}
      title={tip}
      className={cn(
        "group relative inline-flex h-10 w-10 items-center justify-center rounded-lg border transition",
        active
          ? "border-[#00D4C8] bg-[#00D4C8]/15 text-[#00D4C8] shadow-[0_0_0_2px_rgba(0,212,200,0.15)]"
          : "border-transparent text-muted-foreground hover:border-white/15 hover:bg-white/5 hover:text-foreground"
      )}
    >
      {children}
      <span className="pointer-events-none absolute bottom-12 left-1/2 -translate-x-1/2 whitespace-nowrap rounded-md border border-white/10 bg-black/80 px-2 py-1 text-[10px] font-medium text-foreground opacity-0 shadow transition group-hover:opacity-100">
        {tip}
      </span>
    </button>
  );
}

/* Palette icon glyphs */

function IconCone() {
  return (
    <svg viewBox="0 0 20 20" width="18" height="18">
      <polygon points="10,3 4,17 16,17" fill="#fb923c" stroke="#7c2d12" strokeWidth="1" />
      <line x1="6" y1="12" x2="14" y2="12" stroke="#fff" strokeWidth="1" />
    </svg>
  );
}
function IconSlip() {
  return (
    <svg viewBox="0 0 20 20" width="18" height="18">
      <defs>
        <linearGradient id="slip-ic" x1="0" x2="1">
          <stop offset="0" stopColor="#00D4C8" />
          <stop offset="1" stopColor="#00FF88" />
        </linearGradient>
      </defs>
      <rect x="2" y="8" width="16" height="4" rx="1.5" fill="url(#slip-ic)" />
    </svg>
  );
}
function IconBumper() {
  return (
    <svg viewBox="0 0 20 20" width="18" height="18">
      <rect x="2" y="6" width="16" height="8" rx="3" fill="#FF8C00" />
    </svg>
  );
}
function IconTire() {
  return (
    <svg viewBox="0 0 20 20" width="18" height="18">
      <circle cx="10" cy="10" r="7" fill="#4b5563" stroke="#1f2937" strokeWidth="1" />
      <circle cx="10" cy="10" r="3" fill="#08090c" />
    </svg>
  );
}
function IconNet() {
  return (
    <svg viewBox="0 0 20 20" width="18" height="18">
      <rect x="4" y="7" width="12" height="6" rx="1.5" fill="rgba(204,0,0,0.2)" stroke="#cc0000" strokeWidth="1.4" />
    </svg>
  );
}
function IconPuck() {
  return (
    <svg viewBox="0 0 20 20" width="18" height="18">
      <ellipse cx="10" cy="11" rx="6" ry="2" fill="#0a0a0a" stroke="#4b5563" strokeWidth="1" />
      <ellipse cx="10" cy="9" rx="6" ry="2" fill="#111827" stroke="#4b5563" strokeWidth="1" />
    </svg>
  );
}

/* ---------- Rink markings ---------- */
/* Proportions and marking layout follow the attached IHS reference. */

function ArenaRink({ iceMode }: { iceMode: IceMode }) {
  const dark = iceMode === "dark";
  const ICE = dark ? "#0d1117" : "#f4f7fa";
  const BOARD = dark ? "#ffffff" : "#111827";
  const BOARD_W = dark ? 3 : 2;
  const BLUE = "#0066ff";
  const RED = "#cc0000";
  const CREASE_FILL = "rgba(96,165,250,0.28)";
  const CREASE_STROKE = "rgba(96,165,250,0.9)";
  const WORDMARK = dark ? "#1f2937" : "#c9d3de";

  const W = FULL_W;
  const H = FULL_H;
  const cx = W / 2;
  const cy = H / 2;

  const iceInset = 5;
  const cornerR = 125;
  const clipId = `rink-clip-${iceMode}`;

  const goalX = 72;                  // IHS reference goal line offset
  const blueX = 357;                 // IHS reference blue lines
  const ezDotX_L = 176;              // end-zone face-off dot X
  const ezDotX_R = W - ezDotX_L;
  const ezDotY_top = 128;            // end-zone face-off dot Y
  const ezDotY_bot = H - ezDotY_top;
  const nzDotX_L = 386;              // neutral-zone dots inside blue lines
  const nzDotX_R = W - nzDotX_L;
  const nzDotY_top = ezDotY_top;
  const nzDotY_bot = H - nzDotY_top;
  const foR = 78;
  const creaseR = 32;

  const ezDots = [
    { cx: ezDotX_L, cy: ezDotY_top }, { cx: ezDotX_L, cy: ezDotY_bot },
    { cx: ezDotX_R, cy: ezDotY_top }, { cx: ezDotX_R, cy: ezDotY_bot },
  ];
  const nzDots = [
    { cx: nzDotX_L, cy: nzDotY_top }, { cx: nzDotX_L, cy: nzDotY_bot },
    { cx: nzDotX_R, cy: nzDotY_top }, { cx: nzDotX_R, cy: nzDotY_bot },
  ];

  const FaceoffSpot = ({ x, y }: { x: number; y: number }) => {
    const sideX = 21;
    const inner = 8;
    const outer = 28;
    const barTop = 18;
    const barBottom = 18;
    return (
      <g stroke={RED} strokeWidth="2" strokeLinecap="square">
        <circle cx={x} cy={y} r="5" fill={RED} stroke="none" />
        <line x1={x - outer} y1={y} x2={x - inner} y2={y} />
        <line x1={x + inner} y1={y} x2={x + outer} y2={y} />
        <line x1={x - sideX} y1={y - barTop} x2={x - sideX} y2={y - 3} />
        <line x1={x - sideX} y1={y + 3} x2={x - sideX} y2={y + barBottom} />
        <line x1={x + sideX} y1={y - barTop} x2={x + sideX} y2={y - 3} />
        <line x1={x + sideX} y1={y + 3} x2={x + sideX} y2={y + barBottom} />
      </g>
    );
  };

  const CircleHash = ({ x, y }: { x: number; y: number }) => {
    const gap = 18;
    const len = 16;
    return (
      <g stroke={RED} strokeWidth="2" strokeLinecap="square">
        <line x1={x - gap} y1={y - foR} x2={x - gap} y2={y - foR - len} />
        <line x1={x + gap} y1={y - foR} x2={x + gap} y2={y - foR - len} />
        <line x1={x - gap} y1={y + foR} x2={x - gap} y2={y + foR + len} />
        <line x1={x + gap} y1={y + foR} x2={x + gap} y2={y + foR + len} />
      </g>
    );
  };

  return (
    <>
      <defs>
        <clipPath id={clipId}>
          <rect x={iceInset} y={iceInset} width={W - iceInset * 2} height={H - iceInset * 2} rx={cornerR} ry={cornerR} />
        </clipPath>
      </defs>

      {/* Ice + boards */}
      <rect x={iceInset} y={iceInset} width={W - iceInset * 2} height={H - iceInset * 2} rx={cornerR} ry={cornerR} fill={ICE} stroke={BOARD} strokeWidth={BOARD_W} />

      <g clipPath={`url(#${clipId})`}>
        {/* Goal lines */}
        <line x1={goalX} y1={iceInset} x2={goalX} y2={H - iceInset} stroke={RED} strokeWidth="2" />
        <line x1={W - goalX} y1={iceInset} x2={W - goalX} y2={H - iceInset} stroke={RED} strokeWidth="2" />

        {/* Blue lines */}
        <line x1={blueX} y1={iceInset} x2={blueX} y2={H - iceInset} stroke={BLUE} strokeWidth="6" />
        <line x1={W - blueX} y1={iceInset} x2={W - blueX} y2={H - iceInset} stroke={BLUE} strokeWidth="6" />

        {/* Red center line */}
        <line x1={cx} y1={iceInset} x2={cx} y2={H - iceInset} stroke={RED} strokeWidth="6" />

        {/* Trapezoid behind each net */}
        <line x1={goalX} y1={cy - 55} x2={iceInset} y2={cy - 70} stroke={RED} strokeWidth="2" />
        <line x1={goalX} y1={cy + 55} x2={iceInset} y2={cy + 70} stroke={RED} strokeWidth="2" />
        <line x1={W - goalX} y1={cy - 55} x2={W - iceInset} y2={cy - 70} stroke={RED} strokeWidth="2" />
        <line x1={W - goalX} y1={cy + 55} x2={W - iceInset} y2={cy + 70} stroke={RED} strokeWidth="2" />
      </g>

      {/* Creases — light-blue filled semicircle in front of each goal line */}
      <path
        d={`M ${goalX} ${cy - creaseR} A ${creaseR} ${creaseR} 0 0 1 ${goalX} ${cy + creaseR} Z`}
        fill={CREASE_FILL} stroke={CREASE_STROKE} strokeWidth="2"
      />
      <path
        d={`M ${W - goalX} ${cy - creaseR} A ${creaseR} ${creaseR} 0 0 0 ${W - goalX} ${cy + creaseR} Z`}
        fill={CREASE_FILL} stroke={CREASE_STROKE} strokeWidth="2"
      />

      {/* End-zone face-off circles + dot + crosshair + circle hash */}
      {ezDots.map((d, i) => (
        <g key={`ez${i}`}>
          <circle cx={d.cx} cy={d.cy} r={foR} fill="none" stroke={RED} strokeWidth="2" />
          <FaceoffSpot x={d.cx} y={d.cy} />
          <CircleHash x={d.cx} y={d.cy} />
        </g>
      ))}

      {/* Neutral-zone dots — close to center line, no circle */}
      {nzDots.map((d, i) => (
        <circle key={`nz${i}`} cx={d.cx} cy={d.cy} r="6" fill={RED} />
      ))}

      {/* Center face-off circle + dot */}
      <circle cx={cx} cy={cy} r={foR} fill="none" stroke={RED} strokeWidth="2" />
      <circle cx={cx} cy={cy} r="6" fill={RED} />

      {/* PXF wordmark in center circle */}
      <text x={cx} y={cy + 5} textAnchor="middle" fontSize="16" fontWeight="800" letterSpacing="4" fill={WORDMARK} style={{ pointerEvents: "none" }}>
        PXF HOCKEY
      </text>
    </>
  );
}

/* ---------- Item layer + shapes ---------- */

function ItemLayer({
  item, selected, onDown,
}: {
  item: Item;
  selected: boolean;
  onDown: (e: React.MouseEvent) => void;
}) {
  const commonProps = {
    onMouseDown: onDown,
    style: { cursor: "grab" as const },
  };
  return (
    <g {...commonProps}>
      <ItemShape item={item} />
      {selected && <SelectionHalo item={item} />}
    </g>
  );
}

function SelectionHalo({ item }: { item: Item }) {
  if ("at" in item) {
    return <circle cx={item.at.x} cy={item.at.y} r="24" fill="none" stroke={TEAL} strokeWidth="1.5" strokeDasharray="4 3" />;
  }
  const d = "points" in item ? smoothPath(item.points) : "";
  return <path d={d} fill="none" stroke={TEAL} strokeWidth="8" strokeLinecap="round" opacity="0.25" />;
}

function EquipLabel({ x, y, text }: { x: number; y: number; text: string }) {
  return (
    <text
      x={x}
      y={y}
      textAnchor="middle"
      fontSize="6.5"
      fontWeight="700"
      letterSpacing="1"
      fill="#e5e7eb"
      opacity="0.75"
      style={{ pointerEvents: "none" }}
    >
      {text}
    </text>
  );
}

function ItemShape({ item }: { item: Item }) {
  if (item.kind === "freedraw") {
    const id = `arr-fd-${item.id}`;
    return (
      <g>
        <defs>
          <marker id={id} viewBox="0 0 10 10" refX="8" refY="5" markerWidth="6" markerHeight="6" orient="auto-start-reverse">
            <path d="M 0 0 L 10 5 L 0 10 z" fill={TEAL} />
          </marker>
        </defs>
        <path d={smoothPath(item.points)} fill="none" stroke={TEAL} strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round" markerEnd={`url(#${id})`} />
      </g>
    );
  }
  if (item.kind === "route") {
    return <PolyRoute points={item.points} dashed={false} />;
  }
  if (item.kind === "pass") {
    return <PolyRoute points={item.points} dashed />;
  }
  if (item.kind === "cone") {
    const s = 12;
    const { x, y } = item.at;
    return (
      <g>
        <g transform={`rotate(${item.rotation} ${x} ${y})`}>
          <polygon
            points={`${x},${y - s} ${x - s * 0.9},${y + s} ${x + s * 0.9},${y + s}`}
            fill="#fb923c" stroke="#7c2d12" strokeWidth="1"
          />
          <line x1={x - s * 0.6} y1={y + 2} x2={x + s * 0.6} y2={y + 2} stroke="#fff" strokeWidth="1" />
        </g>
        <EquipLabel x={x} y={y + s + 10} text="CONE" />
      </g>
    );
  }
  if (item.kind === "slip") {
    const { x, y } = item.at;
    const w = 44, h = 10;
    const gid = `slip-${item.id}`;
    return (
      <g>
        <g transform={`rotate(${item.rotation} ${x} ${y})`}>
          <defs>
            <linearGradient id={gid} x1="0" x2="1">
              <stop offset="0" stopColor="#00D4C8" />
              <stop offset="1" stopColor="#00FF88" />
            </linearGradient>
          </defs>
          <rect x={x - w / 2} y={y - h / 2} width={w} height={h} rx="3" fill={`url(#${gid})`} stroke="#00A99A" strokeWidth="0.6" />
        </g>
        <EquipLabel x={x} y={y + h + 8} text="SLIP" />
      </g>
    );
  }
  if (item.kind === "bumper") {
    const { x, y } = item.at;
    const w = 88, h = 9;
    return (
      <g>
        <g transform={`rotate(${item.rotation} ${x} ${y})`}>
          <rect x={x - w / 2} y={y - h / 2} width={w} height={h} rx="1.5" fill="#FF8C00" stroke="#9a3412" strokeWidth="0.8" />
          <line x1={x - w / 2 + 3} y1={y} x2={x + w / 2 - 3} y2={y} stroke="#c2410c" strokeWidth="0.5" opacity="0.6" />
        </g>
        <EquipLabel x={x} y={y + h / 2 + 9} text="BUMPER" />
      </g>
    );
  }
  if (item.kind === "tire") {
    const { x, y } = item.at;
    return (
      <g>
        <g transform={`rotate(${item.rotation} ${x} ${y})`}>
          <circle cx={x} cy={y} r="14" fill="#4b5563" stroke="#1f2937" strokeWidth="1.2" />
          <circle cx={x} cy={y} r="6" fill="#08090c" />
        </g>
        <EquipLabel x={x} y={y + 24} text="TIRE" />
      </g>
    );
  }
  if (item.kind === "net") {
    const { x, y } = item.at;
    // Top-down: posts on the LEFT (front), cage tapers to a point on the right (back)
    const goalHalf = 11;   // half of goal width (between posts)
    const depth = 20;      // how far the cage extends back
    const frontX = x - depth / 2;
    const backX = x + depth / 2;
    const topPost = { x: frontX, y: y - goalHalf };
    const botPost = { x: frontX, y: y + goalHalf };
    const backPt = { x: backX, y };
    // Cage frame: post -> straight back a bit -> angle in to backPt
    const straightLen = depth * 0.35;
    const topStraight = { x: frontX + straightLen, y: y - goalHalf };
    const botStraight = { x: frontX + straightLen, y: y + goalHalf };
    return (
      <g>
        <g transform={`rotate(${item.rotation} ${x} ${y})`}>
          {/* Crease — light blue semicircle in front of the posts */}
          <path
            d={`M ${frontX} ${y - goalHalf} A ${goalHalf} ${goalHalf} 0 0 0 ${frontX} ${y + goalHalf}`}
            fill="rgba(96,165,250,0.28)" stroke="rgba(96,165,250,0.9)" strokeWidth="0.6"
          />
          {/* Cage fill */}
          <path
            d={`M ${topPost.x} ${topPost.y} L ${topStraight.x} ${topStraight.y} L ${backPt.x} ${backPt.y} L ${botStraight.x} ${botStraight.y} L ${botPost.x} ${botPost.y} Z`}
            fill="rgba(204,0,0,0.10)" stroke="#cc0000" strokeWidth="1.2" strokeLinejoin="round"
          />
          {/* Mesh — horizontal lines running post-to-post */}
          {[0.2, 0.4, 0.6, 0.8].map((t, i) => {
            // Interpolate side-to-side at fractional depth t along cage
            // Top edge at depth t: from topPost to backPt via topStraight
            const seg = (a: Point, b: Point, c: Point, tt: number) => {
              // piecewise: 0..0.35 along a->b, 0.35..1 along b->c
              if (tt <= 0.35) {
                const k = tt / 0.35;
                return { x: a.x + (b.x - a.x) * k, y: a.y + (b.y - a.y) * k };
              }
              const k = (tt - 0.35) / 0.65;
              return { x: b.x + (c.x - b.x) * k, y: b.y + (c.y - b.y) * k };
            };
            const p1 = seg(topPost, topStraight, backPt, t);
            const p2 = seg(botPost, botStraight, backPt, t);
            return <line key={`h${i}`} x1={p1.x} y1={p1.y} x2={p2.x} y2={p2.y} stroke="#cc0000" strokeWidth="0.35" opacity="0.75" />;
          })}
          {/* Mesh — vertical lines (front-to-back) */}
          {[0.25, 0.5, 0.75].map((t, i) => {
            const yy = y - goalHalf + goalHalf * 2 * t;
            // determine back x at this y based on cage shape
            const frac = Math.abs(yy - y) / goalHalf; // 0 center, 1 at post line
            const xBack = backX - (backX - (frontX + straightLen)) * frac;
            return <line key={`v${i}`} x1={frontX + 1} y1={yy} x2={xBack} y2={yy} stroke="#cc0000" strokeWidth="0.35" opacity="0.75" />;
          })}
          {/* Crossbar */}
          <line x1={topPost.x} y1={topPost.y} x2={botPost.x} y2={botPost.y} stroke="#cc0000" strokeWidth="1.4" />
          {/* Posts */}
          <circle cx={topPost.x} cy={topPost.y} r="2" fill="#cc0000" />
          <circle cx={botPost.x} cy={botPost.y} r="2" fill="#cc0000" />
        </g>
        <EquipLabel x={x} y={y + goalHalf + 9} text="NET" />
      </g>
    );
  }
  if (item.kind === "puck") {
    const { x, y } = item.at;
    return (
      <g>
        <circle cx={x} cy={y} r="4" fill="#0a0a0a" stroke="#111827" strokeWidth="0.5" />
        <EquipLabel x={x} y={y + 12} text="PUCK" />
      </g>
    );
  }
  return null;
}


/* ---------- Route rendering ---------- */

function PolyRoute({ points, dashed, ghost }: { points: Point[]; dashed: boolean; ghost?: boolean }) {
  if (points.length < 2) return null;
  const id = `arr-${dashed ? "d" : "s"}${ghost ? "g" : ""}`;
  const d = smoothPath(points);
  return (
    <g opacity={ghost ? 0.6 : 1}>
      <defs>
        <marker id={id} viewBox="0 0 10 10" refX="8" refY="5" markerWidth="6" markerHeight="6" orient="auto-start-reverse">
          <path d="M 0 0 L 10 5 L 0 10 z" fill={TEAL} />
        </marker>
      </defs>
      <path
        d={d}
        fill="none"
        stroke={TEAL}
        strokeWidth={dashed ? 2 : 2.6}
        strokeDasharray={dashed ? "8 5" : undefined}
        strokeLinecap="round"
        strokeLinejoin="round"
        markerEnd={`url(#${id})`}
      />
    </g>
  );
}

function smoothPath(points: Point[]): string {
  if (points.length === 0) return "";
  if (points.length === 1) return `M ${points[0].x} ${points[0].y}`;
  if (points.length === 2) return `M ${points[0].x} ${points[0].y} L ${points[1].x} ${points[1].y}`;
  let d = `M ${points[0].x} ${points[0].y}`;
  for (let i = 1; i < points.length - 1; i++) {
    const cur = points[i];
    const next = points[i + 1];
    const mx = (cur.x + next.x) / 2;
    const my = (cur.y + next.y) / 2;
    d += ` Q ${cur.x} ${cur.y} ${mx} ${my}`;
  }
  const last = points[points.length - 1];
  d += ` T ${last.x} ${last.y}`;
  return d;
}





function Field({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <div>
      <div className="mb-2 text-[11px] font-semibold uppercase tracking-[0.18em] text-muted-foreground">
        {label}
      </div>
      {children}
    </div>
  );
}

/* ============================================================
   PRACTICE BUILDER
============================================================ */

type PracticeDrill = { id: string; drillId: string; note: string };

function PracticeBuilder({ practiceId, onBack }: { practiceId?: string; onBack: () => void }) {
  const existing = practiceId ? PRACTICES.find((p) => p.id === practiceId) : undefined;
  const [name, setName] = useState(existing?.name ?? "");
  const [date, setDate] = useState("");
  const [time, setTime] = useState("");
  const [duration, setDuration] = useState<number | "">(existing ? parseInt(existing.duration) : "");
  const [location, setLocation] = useState(existing?.location ?? "");
  const [items, setItems] = useState<PracticeDrill[]>(
    existing
      ? DRILLS.slice(0, existing.drillCount).map((d, i) => ({ id: `pd${i}`, drillId: d.id, note: "" }))
      : []
  );
  const [pickerOpen, setPickerOpen] = useState(false);
  const [team, setTeam] = useState("Elite Demo Team");
  const [notify, setNotify] = useState(true);

  const rows = items
    .map((it) => ({ ...it, drill: DRILLS.find((d) => d.id === it.drillId)! }))
    .filter((r) => r.drill);

  const totalMin = rows.reduce((sum, r) => sum + parseInt(r.drill.duration), 0);
  const breakdown = useMemo(() => {
    const b: Record<string, number> = {};
    for (const r of rows) b[r.drill.category] = (b[r.drill.category] ?? 0) + parseInt(r.drill.duration);
    return b;
  }, [rows]);

  const remove = (id: string) => setItems((arr) => arr.filter((x) => x.id !== id));
  const move = (id: string, dir: -1 | 1) => {
    setItems((arr) => {
      const i = arr.findIndex((x) => x.id === id);
      const j = i + dir;
      if (i < 0 || j < 0 || j >= arr.length) return arr;
      const copy = [...arr];
      [copy[i], copy[j]] = [copy[j], copy[i]];
      return copy;
    });
  };
  const addDrill = (drillId: string) => {
    setItems((arr) => [...arr, { id: `pd${Date.now()}`, drillId, note: "" }]);
    setPickerOpen(false);
  };
  const setNote = (id: string, note: string) =>
    setItems((arr) => arr.map((x) => (x.id === id ? { ...x, note } : x)));

  return (
    <div className="space-y-6 pb-28">
      <button onClick={onBack} className="inline-flex items-center gap-1 text-xs text-muted-foreground hover:text-foreground">
        <ChevronLeft className="h-3.5 w-3.5" /> Practices
      </button>

      <div>
        <h1 className="text-2xl font-semibold tracking-tight">
          {existing ? "Edit Practice" : "Create Practice"}
        </h1>
      </div>

      {/* Header fields */}
      <div className="grid grid-cols-1 gap-4 md:grid-cols-5">
        <div className="md:col-span-2">
          <Field label="Practice Name">
            <input
              value={name}
              onChange={(e) => setName(e.target.value)}
              placeholder="e.g. U14 AA Practice"
              className="h-10 w-full rounded-md border border-border bg-card px-3 text-sm outline-none focus:border-[#00D4C8]"
            />
          </Field>
        </div>
        <Field label="Date">
          <input
            value={date}
            onChange={(e) => setDate(e.target.value)}
            placeholder="Mon Jul 7"
            className="h-10 w-full rounded-md border border-border bg-card px-3 text-sm outline-none focus:border-[#00D4C8]"
          />
        </Field>
        <Field label="Time">
          <input
            value={time}
            onChange={(e) => setTime(e.target.value)}
            placeholder="5:30 PM"
            className="h-10 w-full rounded-md border border-border bg-card px-3 text-sm outline-none focus:border-[#00D4C8]"
          />
        </Field>
        <Field label="Location">
          <input
            value={location}
            onChange={(e) => setLocation(e.target.value)}
            placeholder="Rink A"
            className="h-10 w-full rounded-md border border-border bg-card px-3 text-sm outline-none focus:border-[#00D4C8]"
          />
        </Field>
      </div>

      <div className="grid grid-cols-1 gap-6 lg:grid-cols-5">
        {/* LEFT — Drill order (65%) */}
        <div className="space-y-4 lg:col-span-3">
          <SectionLabel>Drills in this Practice</SectionLabel>

          {rows.length === 0 ? (
            <div className="rounded-lg border border-dashed border-border bg-card p-10 text-center text-xs text-muted-foreground">
              No drills yet. Add drills from your library.
            </div>
          ) : (
            <div className="space-y-2">
              {rows.map((r, i) => (
                <PracticeDrillRow
                  key={r.id}
                  index={i}
                  row={r}
                  onNote={(v) => setNote(r.id, v)}
                  onRemove={() => remove(r.id)}
                  onUp={() => move(r.id, -1)}
                  onDown={() => move(r.id, 1)}
                />
              ))}
            </div>
          )}

          <div>
            <OutlineButton onClick={() => setPickerOpen(true)}>
              <Plus className="h-3.5 w-3.5" /> Add Drill
            </OutlineButton>
          </div>

          <div className="rounded-lg border border-border bg-card p-3 text-xs text-muted-foreground">
            Total: <span className="font-semibold text-foreground">{rows.length} drills</span> · <span className="font-semibold text-foreground">{totalMin} min</span>
          </div>
        </div>

        {/* RIGHT — Summary (35%) */}
        <div className="space-y-6 lg:col-span-2">
          <div className="rounded-xl border border-border bg-card p-4">
            <SectionLabel>Practice Summary</SectionLabel>
            <div className="mt-3 text-sm">
              <div className="flex items-baseline justify-between">
                <span className="text-muted-foreground">Total duration</span>
                <span className="text-lg font-semibold">{totalMin} min</span>
              </div>
            </div>

            <div className="mt-4">
              <div className="text-[11px] font-semibold uppercase tracking-[0.18em] text-muted-foreground">Breakdown</div>
              {Object.keys(breakdown).length === 0 ? (
                <div className="mt-2 text-xs text-muted-foreground">Add drills to see breakdown.</div>
              ) : (
                <div className="mt-2 space-y-1.5">
                  {Object.entries(breakdown).map(([cat, min]) => (
                    <div key={cat} className="flex items-center justify-between text-xs">
                      <span className="text-muted-foreground">{cat}</span>
                      <span className="font-medium">{min}min</span>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>

          <div className="rounded-xl border border-border bg-card p-4">
            <SectionLabel>Assign To</SectionLabel>
            <div className="mt-3">
              <select
                value={team}
                onChange={(e) => setTeam(e.target.value)}
                className="h-10 w-full rounded-md border border-border bg-card px-3 text-sm outline-none focus:border-[#00D4C8]"
              >
                <option>Elite Demo Team</option>
                <option>Atom Rep Team</option>
              </select>
            </div>
            <label className="mt-3 flex cursor-pointer items-center justify-between text-sm">
              <span className="text-muted-foreground">Notify Team</span>
              <button
                type="button"
                onClick={() => setNotify((v) => !v)}
                className={cn(
                  "relative h-5 w-9 rounded-full transition",
                  notify ? "bg-[#00D4C8]" : "bg-muted"
                )}
              >
                <span
                  className={cn(
                    "absolute top-0.5 h-4 w-4 rounded-full bg-white transition-all",
                    notify ? "left-[18px]" : "left-0.5"
                  )}
                />
              </button>
            </label>
          </div>

          <div className="rounded-xl border border-border bg-card p-4 text-xs text-muted-foreground">
            <div>Duration field: <span className="text-foreground">{duration || "—"} min</span></div>
            <input
              type="number"
              value={duration}
              onChange={(e) => setDuration(e.target.value === "" ? "" : Number(e.target.value))}
              placeholder="Override duration (min)"
              className="mt-2 h-9 w-full rounded-md border border-border bg-background px-3 text-sm text-foreground outline-none focus:border-[#00D4C8]"
            />
          </div>
        </div>
      </div>

      {/* Bottom bar */}
      <div className="fixed inset-x-0 bottom-0 z-10 border-t border-border bg-background/95 p-4 backdrop-blur md:left-[220px]">
        <div className="mx-auto flex max-w-5xl items-center justify-between gap-3">
          <OutlineButton
            onClick={() => {
              if (!name.trim()) {
                toast.error("Add a practice name before saving");
                return;
              }
              toast.success(`Draft saved: ${name}`);
              onBack();
            }}
          >
            Save Draft
          </OutlineButton>
          <GradientButton
            onClick={() => {
              if (!name.trim()) {
                toast.error("Add a practice name before publishing");
                return;
              }
              if (rows.length === 0) {
                toast.error("Add at least one drill before publishing");
                return;
              }
              toast.success(`Practice published: ${name}`);
              onBack();
            }}
          >
            Publish
          </GradientButton>
        </div>
      </div>

      {pickerOpen && <DrillPickerModal onClose={() => setPickerOpen(false)} onPick={addDrill} />}
    </div>
  );
}

function PracticeDrillRow({
  index, row, onNote, onRemove, onUp, onDown,
}: {
  index: number;
  row: { id: string; drill: Drill; note: string };
  onNote: (v: string) => void;
  onRemove: () => void;
  onUp: () => void;
  onDown: () => void;
}) {
  const [noteOpen, setNoteOpen] = useState(false);
  return (
    <div className="rounded-lg border border-border bg-card">
      <div className="flex items-center gap-3 p-3">
        <div className="flex flex-col items-center text-muted-foreground">
          <button onClick={onUp} className="text-xs hover:text-foreground">▲</button>
          <GripVertical className="h-4 w-4" />
          <button onClick={onDown} className="text-xs hover:text-foreground">▼</button>
        </div>
        <div className="flex h-8 w-8 shrink-0 items-center justify-center rounded-full bg-[#00D4C8]/15 text-xs font-bold text-[#00D4C8]">
          {index + 1}
        </div>
        <div className="min-w-0 flex-1">
          <div className="truncate text-sm font-semibold">{row.drill.name}</div>
          <div className="mt-0.5 flex flex-wrap items-center gap-1.5">
            <TagPill tone="teal">{row.drill.category}</TagPill>
            <span className="text-[11px] text-muted-foreground">{row.drill.duration}</span>
          </div>
        </div>
        <button
          onClick={() => setNoteOpen((v) => !v)}
          className={cn(
            "inline-flex h-8 w-8 items-center justify-center rounded-md border border-border transition hover:bg-accent",
            row.note && "text-[#00D4C8]"
          )}
          title="Add coaching note"
        >
          <StickyNote className="h-4 w-4" />
        </button>
        <button
          onClick={onRemove}
          className="inline-flex h-8 w-8 items-center justify-center rounded-md border border-border text-muted-foreground hover:bg-accent hover:text-foreground"
        >
          <X className="h-4 w-4" />
        </button>
      </div>
      {noteOpen && (
        <div className="border-t border-border p-3">
          <textarea
            value={row.note}
            onChange={(e) => onNote(e.target.value)}
            rows={2}
            placeholder="Per-drill coaching note…"
            className="w-full resize-none rounded-md border border-border bg-background p-2 text-sm outline-none focus:border-[#00D4C8]"
          />
        </div>
      )}
    </div>
  );
}

function DrillPickerModal({ onClose, onPick }: { onClose: () => void; onPick: (id: string) => void }) {
  const [q, setQ] = useState("");
  const [cat, setCat] = useState<"All" | Category>("All");
  const filters: ("All" | Category)[] = ["All", "Skating", "Slip Training", "Dryland"];
  const list = DRILLS.filter(
    (d) =>
      (cat === "All" || d.category === cat) &&
      (q === "" || d.name.toLowerCase().includes(q.toLowerCase()))
  );
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 p-4" onClick={onClose}>
      <div
        className="w-full max-w-2xl overflow-hidden rounded-xl border border-border bg-background"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="flex items-center justify-between border-b border-border p-4">
          <div className="text-sm font-semibold">Add drill from library</div>
          <button onClick={onClose} className="text-muted-foreground hover:text-foreground">
            <X className="h-4 w-4" />
          </button>
        </div>
        <div className="space-y-3 p-4">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
            <input
              value={q}
              onChange={(e) => setQ(e.target.value)}
              placeholder="Search drills…"
              className="h-10 w-full rounded-md border border-border bg-card pl-9 pr-3 text-sm"
            />
          </div>
          <div className="flex flex-wrap gap-2">
            {filters.map((f) => (
              <button
                key={f}
                onClick={() => setCat(f)}
                className={cn(
                  "h-7 rounded-full border px-3 text-xs font-medium transition",
                  cat === f ? "border-[#00D4C8] bg-[#00D4C8]/10 text-[#00D4C8]" : "border-border text-muted-foreground"
                )}
              >
                {f}
              </button>
            ))}
          </div>
          <div className="max-h-80 space-y-2 overflow-y-auto">
            {list.map((d) => (
              <button
                key={d.id}
                onClick={() => onPick(d.id)}
                className="flex w-full items-center gap-3 rounded-lg border border-border bg-card p-3 text-left transition hover:border-[#00D4C8]/60"
              >
                <CategoryAvatar category={d.category} size={32} />
                <div className="min-w-0 flex-1">
                  <div className="truncate text-sm font-semibold">{d.name}</div>
                  <div className="mt-0.5 text-[11px] text-muted-foreground">
                    {d.category} · {d.duration} · {d.ages}
                  </div>
                </div>
                <Plus className="h-4 w-4 text-[#00D4C8]" />
              </button>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}

/* ============================================================
   SERIES BUILDER
============================================================ */

type SeriesSession = { id: string; practiceId?: string; name: string; drillCount: number; duration: number };

function SeriesBuilder({ seriesId, onBack }: { seriesId?: string; onBack: () => void }) {
  const base = seriesId ? PXF_PROGRAMS.find((p) => p.id === seriesId) : undefined;
  const [name, setName] = useState(base ? `${base.name} (Copy)` : "");
  const [cat, setCat] = useState<Category>(base?.category ?? "Skating");
  const [target, setTarget] = useState<number>(base?.sessions ?? 5);
  const [sessions, setSessions] = useState<SeriesSession[]>(
    base
      ? Array.from({ length: base.sessions }, (_, i) => ({
          id: `ss${i}`,
          practiceId: PRACTICES[i % PRACTICES.length].id,
          name: `Session ${i + 1}`,
          drillCount: PRACTICES[i % PRACTICES.length].drillCount,
          duration: parseInt(PRACTICES[i % PRACTICES.length].duration),
        }))
      : []
  );

  const totalMin = sessions.reduce((s, x) => s + x.duration, 0);
  const uniqueDrills = new Set(sessions.map((s) => s.practiceId)).size * 3; // rough estimate

  const addSession = () =>
    setSessions((arr) => [
      ...arr,
      { id: `ss${Date.now()}`, practiceId: undefined, name: `Session ${arr.length + 1}`, drillCount: 0, duration: 0 },
    ]);

  const removeSession = (id: string) => setSessions((arr) => arr.filter((s) => s.id !== id));

  const setPractice = (id: string, practiceId: string) => {
    const p = PRACTICES.find((x) => x.id === practiceId);
    setSessions((arr) =>
      arr.map((s) =>
        s.id === id
          ? { ...s, practiceId, name: p?.name ?? s.name, drillCount: p?.drillCount ?? 0, duration: p ? parseInt(p.duration) : 0 }
          : s
      )
    );
  };

  return (
    <div className="space-y-6 pb-28">
      <button onClick={onBack} className="inline-flex items-center gap-1 text-xs text-muted-foreground hover:text-foreground">
        <ChevronLeft className="h-3.5 w-3.5" /> Series
      </button>

      <div>
        <h1 className="text-2xl font-semibold tracking-tight">
          {base ? "Duplicate & Edit Series" : "Create Series"}
        </h1>
      </div>

      <div className="grid grid-cols-1 gap-4 md:grid-cols-3">
        <Field label="Series Name">
          <input
            value={name}
            onChange={(e) => setName(e.target.value)}
            placeholder="e.g. Custom Skating Track"
            className="h-10 w-full rounded-md border border-border bg-card px-3 text-sm outline-none focus:border-[#00D4C8]"
          />
        </Field>
        <Field label="Category">
          <select
            value={cat}
            onChange={(e) => setCat(e.target.value as Category)}
            className="h-10 w-full rounded-md border border-border bg-card px-3 text-sm outline-none focus:border-[#00D4C8]"
          >
            <option>Skating</option>
            <option>Slip Training</option>
            <option>Dryland</option>
            <option>My Drills</option>
          </select>
        </Field>
        <Field label="Total Sessions Target">
          <input
            type="number"
            value={target}
            onChange={(e) => setTarget(Number(e.target.value))}
            className="h-10 w-full rounded-md border border-border bg-card px-3 text-sm outline-none focus:border-[#00D4C8]"
          />
        </Field>
      </div>

      <div className="grid grid-cols-1 gap-6 lg:grid-cols-3">
        <div className="space-y-4 lg:col-span-2">
          <SectionLabel>Sessions</SectionLabel>

          {sessions.length === 0 ? (
            <div className="rounded-lg border border-dashed border-border bg-card p-10 text-center text-xs text-muted-foreground">
              No sessions yet. Add your first session.
            </div>
          ) : (
            <div className="space-y-3">
              {sessions.map((s, i) => (
                <div key={s.id} className="rounded-lg border border-border bg-card p-4">
                  <div className="flex items-center justify-between">
                    <div className="text-[11px] font-semibold uppercase tracking-[0.18em] text-muted-foreground">
                      Session {i + 1}
                    </div>
                    <button
                      onClick={() => removeSession(s.id)}
                      className="text-muted-foreground hover:text-foreground"
                    >
                      <X className="h-4 w-4" />
                    </button>
                  </div>
                  <div className="mt-3 flex flex-col gap-3 md:flex-row md:items-center">
                    <select
                      value={s.practiceId ?? ""}
                      onChange={(e) => e.target.value && setPractice(s.id, e.target.value)}
                      className="h-10 min-w-0 flex-1 rounded-md border border-border bg-background px-3 text-sm outline-none focus:border-[#00D4C8]"
                    >
                      <option value="">Select a practice…</option>
                      {PRACTICES.map((p) => (
                        <option key={p.id} value={p.id}>{p.name}</option>
                      ))}
                    </select>
                    <button className="text-xs font-medium text-[#00D4C8] hover:underline">+ Build Practice</button>
                  </div>
                  {s.practiceId && (
                    <div className="mt-3 text-[11px] text-muted-foreground">
                      <span className="font-semibold text-foreground">{s.name}</span> · {s.drillCount} drills · {s.duration} min
                    </div>
                  )}
                </div>
              ))}
            </div>
          )}

          <OutlineButton onClick={addSession}>
            <Plus className="h-3.5 w-3.5" /> Add Session
          </OutlineButton>
        </div>

        <div className="lg:col-span-1">
          <div className="rounded-xl border border-border bg-card p-4">
            <SectionLabel>Summary</SectionLabel>
            <div className="mt-3 space-y-2 text-sm">
              <div className="flex items-baseline justify-between">
                <span className="text-muted-foreground">Total sessions</span>
                <span className="text-lg font-semibold">{sessions.length}</span>
              </div>
              <div className="flex items-baseline justify-between">
                <span className="text-muted-foreground">Total duration</span>
                <span className="text-lg font-semibold">{totalMin} min</span>
              </div>
              <div className="flex items-baseline justify-between">
                <span className="text-muted-foreground">Drills used</span>
                <span className="text-lg font-semibold">{uniqueDrills}</span>
              </div>
            </div>
          </div>
        </div>
      </div>

      <div className="fixed inset-x-0 bottom-0 z-10 border-t border-border bg-background/95 p-4 backdrop-blur md:left-[220px]">
        <div className="mx-auto flex max-w-5xl items-center justify-between gap-3">
          <OutlineButton>Save as Draft</OutlineButton>
          <GradientButton>Publish to My Series</GradientButton>
        </div>
      </div>
    </div>
  );
}

/* ============================================================
   PROGRESS VIEW
============================================================ */

type AthleteProgress = {
  name: string;
  completed: number;
  total: number;
  lastActive: string;
  streak: number;
  status: "ON TRACK" | "BEHIND" | "NOT STARTED";
};

function ProgressView({ programId, onBack }: { programId: string; onBack: () => void }) {
  const program = ASSIGNED.find((a) => a.id === programId);
  const athletes: AthleteProgress[] = [
    { name: "J. Sinclair", completed: 18, total: 24, lastActive: "Yesterday", streak: 5, status: "ON TRACK" },
    { name: "M. Ramirez", completed: 14, total: 24, lastActive: "3 days ago", streak: 2, status: "ON TRACK" },
    { name: "K. Nguyen", completed: 8, total: 24, lastActive: "1 week ago", streak: 0, status: "BEHIND" },
    { name: "T. Osei", completed: 22, total: 24, lastActive: "Today", streak: 9, status: "ON TRACK" },
    { name: "R. Petrov", completed: 0, total: 24, lastActive: "—", streak: 0, status: "NOT STARTED" },
  ];

  const statusStyle = (s: AthleteProgress["status"]) =>
    s === "ON TRACK"
      ? "bg-[#00D4C8]/15 text-[#00D4C8] ring-[#00D4C8]/30"
      : s === "BEHIND"
      ? "bg-amber-500/15 text-amber-300 ring-amber-500/30"
      : "bg-muted text-muted-foreground ring-border";

  return (
    <div className="space-y-6 pb-8">
      <button onClick={onBack} className="inline-flex items-center gap-1 text-xs text-muted-foreground hover:text-foreground">
        <ChevronLeft className="h-3.5 w-3.5" /> Dryland
      </button>

      <div>
        <div className="text-[11px] font-semibold uppercase tracking-[0.18em] text-[#00D4C8]">
          Program Progress
        </div>
        <h1 className="mt-2 text-2xl font-semibold tracking-tight">
          {program?.programName ?? "Program"}
        </h1>
        <p className="mt-1 text-sm text-muted-foreground">
          Assigned to {program?.assignedTo ?? "—"}
        </p>
      </div>

      <div className="overflow-hidden rounded-xl border border-border bg-card">
        <table className="w-full text-sm">
          <thead>
            <tr className="border-b border-border text-[11px] font-semibold uppercase tracking-[0.18em] text-muted-foreground">
              <th className="px-4 py-3 text-left">Athlete</th>
              <th className="px-4 py-3 text-left">Sessions</th>
              <th className="px-4 py-3 text-left">Last Active</th>
              <th className="px-4 py-3 text-left">Streak</th>
              <th className="px-4 py-3 text-left">Status</th>
            </tr>
          </thead>
          <tbody>
            {athletes.map((a) => (
              <tr key={a.name} className="border-b border-border/50 last:border-b-0">
                <td className="px-4 py-3 font-medium">{a.name}</td>
                <td className="px-4 py-3 text-muted-foreground">{a.completed} / {a.total}</td>
                <td className="px-4 py-3 text-muted-foreground">{a.lastActive}</td>
                <td className="px-4 py-3 text-muted-foreground">{a.streak} 🔥</td>
                <td className="px-4 py-3">
                  <span className={cn("rounded px-2 py-0.5 text-[10px] font-bold uppercase tracking-wider ring-1", statusStyle(a.status))}>
                    {a.status}
                  </span>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
