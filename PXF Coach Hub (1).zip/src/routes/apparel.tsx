import { createFileRoute } from "@tanstack/react-router";
import { AssociationApparel } from "@/components/association-apparel";

export const Route = createFileRoute("/apparel")({
  head: () => ({
    meta: [
      { title: "Apparel · PXF Hockey" },
      { name: "description", content: "Manage team apparel orders, submissions, payments, and distribution." },
    ],
  }),
  component: AssociationApparel,
});
