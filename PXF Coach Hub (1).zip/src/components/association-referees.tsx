import { useMemo, useState } from "react";
import {
  Plus, Search, X, Download, CheckCircle2, AlertTriangle, CreditCard,
  Calendar, DollarSign, ClipboardList, FileText, Mail, Phone,
  ShieldAlert, Clock,
} from "lucide-react";

type Availability = "AVAILABLE" | "UNAVAILABLE";
type AssignmentStatus = "PENDING" | "CONFIRMED" | "COMPLETED" | "NO-SHOW" | "DECLINED";
type PayStatus = "PAID" | "PROCESSING" | "PENDING";

type Assignment = {
  id: string;
  date: string;
  time: string;
  teams: string;
  rink: string;
  level: string;
  fee: number;
  status: AssignmentStatus;
  pay?: PayStatus;
  paidOn?: string;
};

type Referee = {
  id: string;
  name: string;
  initials: string;
  email: string;
  phone: string;
  cert: "Level 1" | "Level 2" | "Level 3" | "Level 4" | "Level 5" | "Level 6";
  certBody: "Hockey Canada" | "USA Hockey";
  certExpiry: string;
  maxAge: "U11" | "U13" | "U15" | "U18" | "Senior";
  availability: Availability;
  daysAvailable: string[];
  timeWindow: string;
  blackouts: string[];
  conflicts: string[];
  stripeConnected: boolean;
  bank: string;
  pending: boolean;
  monthAssigned: number;
  monthCompleted: number;
  monthEarned: number;
  seasonEarned: number;
  careerGames: number;
  careerEarned: number;
  assignments: Assignment[];
};

const REFS: Referee[] = [
  {
    id: "r1", name: "Marcus Devlin", initials: "MD", email: "mdevlin@email.com", phone: "(204) 555-0701",
    cert: "Level 4", certBody: "Hockey Canada", certExpiry: "2026-08-31", maxAge: "U18",
    availability: "AVAILABLE", daysAvailable: ["Mon", "Wed", "Fri", "Sat", "Sun"], timeWindow: "5:00 PM – 10:00 PM",
    blackouts: ["2025-12-22 – 2026-01-02"], conflicts: ["U15 AAA Wolves (son plays)"],
    stripeConnected: true, bank: "Connected via Stripe Express", pending: false,
    monthAssigned: 12, monthCompleted: 9, monthEarned: 645, seasonEarned: 3220,
    careerGames: 487, careerEarned: 28940,
    assignments: [
      { id: "g1", date: "2026-06-28", time: "7:00 PM", teams: "U15 AAA Falcons vs. U15 AAA Bears", rink: "MTS Centre A", level: "U15 AAA", fee: 75, status: "CONFIRMED" },
      { id: "g2", date: "2026-06-26", time: "6:30 PM", teams: "U13 AA Storm vs. U13 AA Kings", rink: "Iceplex B", level: "U13 AA", fee: 55, status: "COMPLETED", pay: "PAID", paidOn: "2026-06-26" },
      { id: "g3", date: "2026-06-24", time: "8:00 PM", teams: "U18 AAA Lions vs. U18 AAA Tigers", rink: "MTS Centre A", level: "U18 AAA", fee: 85, status: "COMPLETED", pay: "PROCESSING" },
      { id: "g4", date: "2026-07-02", time: "7:30 PM", teams: "U15 AAA Bears vs. U15 AAA Hawks", rink: "Iceplex A", level: "U15 AAA", fee: 75, status: "PENDING" },
    ],
  },
  {
    id: "r2", name: "Sasha Petrov", initials: "SP", email: "spetrov@email.com", phone: "(204) 555-0712",
    cert: "Level 3", certBody: "Hockey Canada", certExpiry: "2025-09-15", maxAge: "U15",
    availability: "AVAILABLE", daysAvailable: ["Tue", "Thu", "Sat"], timeWindow: "6:00 PM – 9:30 PM",
    blackouts: [], conflicts: [],
    stripeConnected: true, bank: "Connected via Stripe Express", pending: false,
    monthAssigned: 8, monthCompleted: 7, monthEarned: 395, seasonEarned: 2105,
    careerGames: 142, careerEarned: 8210,
    assignments: [
      { id: "g5", date: "2026-06-27", time: "7:00 PM", teams: "U13 AA Storm vs. U13 AA Eagles", rink: "Iceplex B", level: "U13 AA", fee: 55, status: "CONFIRMED" },
      { id: "g6", date: "2026-06-25", time: "6:00 PM", teams: "U11 A Mites vs. U11 A Jets", rink: "Community Rink 3", level: "U11 A", fee: 35, status: "COMPLETED", pay: "PAID", paidOn: "2026-06-25" },
    ],
  },
  {
    id: "r3", name: "Janelle Okafor", initials: "JO", email: "jokafor@email.com", phone: "(204) 555-0733",
    cert: "Level 5", certBody: "Hockey Canada", certExpiry: "2027-03-31", maxAge: "Senior",
    availability: "AVAILABLE", daysAvailable: ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"], timeWindow: "Anytime",
    blackouts: ["2026-07-15 – 2026-07-22"], conflicts: [],
    stripeConnected: true, bank: "Connected via Stripe Express", pending: false,
    monthAssigned: 15, monthCompleted: 13, monthEarned: 1085, seasonEarned: 5340,
    careerGames: 920, careerEarned: 62400,
    assignments: [
      { id: "g7", date: "2026-06-28", time: "8:00 PM", teams: "U18 AAA Lions vs. U18 AAA Tigers", rink: "MTS Centre A", level: "U18 AAA", fee: 85, status: "CONFIRMED" },
      { id: "g8", date: "2026-06-26", time: "8:00 PM", teams: "U18 AAA Wolves vs. U18 AAA Lions", rink: "MTS Centre B", level: "U18 AAA", fee: 85, status: "COMPLETED", pay: "PAID", paidOn: "2026-06-26" },
    ],
  },
  {
    id: "r4", name: "Tyler Nguyen", initials: "TN", email: "tnguyen@email.com", phone: "(204) 555-0744",
    cert: "Level 2", certBody: "Hockey Canada", certExpiry: "2026-06-30", maxAge: "U13",
    availability: "UNAVAILABLE", daysAvailable: ["Sat", "Sun"], timeWindow: "9:00 AM – 1:00 PM",
    blackouts: ["2026-06-01 – 2026-07-15 (injury)"], conflicts: [],
    stripeConnected: false, bank: "Not connected", pending: false,
    monthAssigned: 0, monthCompleted: 0, monthEarned: 0, seasonEarned: 420,
    careerGames: 38, careerEarned: 1330,
    assignments: [],
  },
  {
    id: "r5", name: "Priya Sharma", initials: "PS", email: "psharma@email.com", phone: "(204) 555-0755",
    cert: "Level 3", certBody: "Hockey Canada", certExpiry: "2026-11-30", maxAge: "U15",
    availability: "AVAILABLE", daysAvailable: ["Wed", "Fri", "Sat"], timeWindow: "5:30 PM – 9:00 PM",
    blackouts: [], conflicts: ["U13 AA Storm (daughter plays)"],
    stripeConnected: false, bank: "Pending — invite sent", pending: true,
    monthAssigned: 0, monthCompleted: 0, monthEarned: 0, seasonEarned: 0,
    careerGames: 0, careerEarned: 0,
    assignments: [],
  },
];

type OpenGame = {
  id: string;
  date: string;
  time: string;
  teams: string;
  rink: string;
  division: string;
  refsNeeded: number;
  refsAssigned: number;
  hoursUntil: number;
};

const OPEN_GAMES: OpenGame[] = [
  { id: "og1", date: "2026-06-27", time: "7:00 PM", teams: "U13 AA Storm vs. U13 AA Eagles", rink: "Iceplex B", division: "U13 AA", refsNeeded: 2, refsAssigned: 1, hoursUntil: 30 },
  { id: "og2", date: "2026-06-27", time: "8:30 PM", teams: "U15 AAA Hawks vs. U15 AAA Bears", rink: "MTS Centre A", division: "U15 AAA", refsNeeded: 3, refsAssigned: 0, hoursUntil: 32 },
  { id: "og3", date: "2026-06-28", time: "7:00 PM", teams: "U15 AAA Falcons vs. U15 AAA Bears", rink: "MTS Centre A", division: "U15 AAA", refsNeeded: 3, refsAssigned: 2, hoursUntil: 56 },
  { id: "og4", date: "2026-06-29", time: "6:00 PM", teams: "U11 A Mites vs. U11 A Jets", rink: "Community Rink 3", division: "U11 A", refsNeeded: 2, refsAssigned: 0, hoursUntil: 78 },
  { id: "og5", date: "2026-07-02", time: "7:30 PM", teams: "U15 AAA Bears vs. U15 AAA Hawks", rink: "Iceplex A", division: "U15 AAA", refsNeeded: 3, refsAssigned: 1, hoursUntil: 152 },
];

const Pill = ({ tone, children }: { tone: "ok" | "warn" | "bad" | "muted" | "info"; children: React.ReactNode }) => {
  const m = {
    ok: "bg-emerald-500/15 text-emerald-400 border-emerald-500/30",
    warn: "bg-amber-500/15 text-amber-400 border-amber-500/30",
    bad: "bg-red-500/15 text-red-400 border-red-500/30",
    muted: "bg-muted text-muted-foreground border-border",
    info: "bg-sky-500/15 text-sky-400 border-sky-500/30",
  }[tone];
  return <span className={`inline-flex rounded-md border px-2 py-0.5 text-[10px] font-semibold ${m}`}>{children}</span>;
};

const certExpiringSoon = (d: string) => {
  const ms = new Date(d).getTime() - Date.now();
  return ms < 1000 * 60 * 60 * 24 * 90;
};

const statusTone = (s: AssignmentStatus): "ok" | "warn" | "bad" | "info" | "muted" =>
  s === "COMPLETED" ? "ok" : s === "CONFIRMED" ? "info" : s === "PENDING" ? "warn" : s === "DECLINED" ? "muted" : "bad";

const payTone = (p: PayStatus): "ok" | "warn" | "info" => p === "PAID" ? "ok" : p === "PROCESSING" ? "info" : "warn";

type View = "list" | "assign";

export function AssociationReferees() {
  const [view, setView] = useState<View>("list");
  const [selected, setSelected] = useState<Referee | null>(null);
  const [showAdd, setShowAdd] = useState(false);
  const [openGame, setOpenGame] = useState<OpenGame | null>(null);
  const [search, setSearch] = useState("");
  const [filterCert, setFilterCert] = useState("all");
  const [filterAvail, setFilterAvail] = useState("all");
  const [sortKey, setSortKey] = useState<keyof Referee>("name");
  const [sortDir, setSortDir] = useState<"asc" | "desc">("asc");

  const rows = useMemo(() => {
    let r = REFS.filter((x) => {
      if (search && !x.name.toLowerCase().includes(search.toLowerCase())) return false;
      if (filterCert !== "all" && x.cert !== filterCert) return false;
      if (filterAvail !== "all" && x.availability !== filterAvail) return false;
      return true;
    });
    r = [...r].sort((a, b) => {
      const av = a[sortKey]; const bv = b[sortKey];
      if (typeof av === "number" && typeof bv === "number") return sortDir === "asc" ? av - bv : bv - av;
      return sortDir === "asc" ? String(av).localeCompare(String(bv)) : String(bv).localeCompare(String(av));
    });
    return r;
  }, [search, filterCert, filterAvail, sortKey, sortDir]);

  const sortBy = (k: keyof Referee) => {
    if (k === sortKey) setSortDir((d) => (d === "asc" ? "desc" : "asc"));
    else { setSortKey(k); setSortDir("asc"); }
  };

  const Th = ({ k, label, num }: { k: keyof Referee; label: string; num?: boolean }) => (
    <th onClick={() => sortBy(k)} className={`cursor-pointer select-none px-3 py-2 ${num ? "text-right" : "text-left"} hover:text-foreground`}>
      {label}{sortKey === k && <span className="ml-1 text-[10px]">{sortDir === "asc" ? "▲" : "▼"}</span>}
    </th>
  );

  return (
    <div className="space-y-5">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div className="flex items-center gap-1 rounded-md border border-border bg-muted/40 p-0.5 text-xs">
          <button onClick={() => setView("list")} className={`rounded px-3 py-1 ${view === "list" ? "bg-background shadow-sm" : "text-muted-foreground"}`}>Referee Pool</button>
          <button onClick={() => setView("assign")} className={`rounded px-3 py-1 ${view === "assign" ? "bg-background shadow-sm" : "text-muted-foreground"}`}>Assign Referees</button>
        </div>
        <div className="flex items-center gap-2">
          <button className="inline-flex h-8 items-center gap-1.5 rounded-md border border-border bg-background px-3 text-xs hover:bg-accent">
            <Download className="h-3.5 w-3.5" /> Export CSV
          </button>
          <button onClick={() => setShowAdd(true)} className="inline-flex h-8 items-center gap-1.5 rounded-md bg-gradient-to-r from-teal-500 to-emerald-500 px-3 text-xs font-medium text-white hover:opacity-90">
            <Plus className="h-3.5 w-3.5" /> Add Referee
          </button>
        </div>
      </div>

      {view === "list" ? (
        <>
          <div className="flex flex-wrap items-center gap-2">
            <div className="relative">
              <Search className="absolute left-2 top-1/2 h-3.5 w-3.5 -translate-y-1/2 text-muted-foreground" />
              <input value={search} onChange={(e) => setSearch(e.target.value)} placeholder="Search referees…"
                className="h-8 w-64 rounded-md border border-border bg-background pl-7 pr-2 text-xs" />
            </div>
            <select value={filterCert} onChange={(e) => setFilterCert(e.target.value)} className="h-8 rounded-md border border-border bg-background px-2 text-xs">
              <option value="all">All certifications</option>
              {["Level 1", "Level 2", "Level 3", "Level 4", "Level 5", "Level 6"].map((c) => <option key={c}>{c}</option>)}
            </select>
            <select value={filterAvail} onChange={(e) => setFilterAvail(e.target.value)} className="h-8 rounded-md border border-border bg-background px-2 text-xs">
              <option value="all">Any availability</option>
              <option value="AVAILABLE">Available</option>
              <option value="UNAVAILABLE">Unavailable</option>
            </select>
          </div>

          <div className="overflow-hidden rounded-lg border border-border">
            <table className="w-full text-sm">
              <thead className="bg-muted/40 text-xs uppercase text-muted-foreground">
                <tr>
                  <Th k="name" label="Name" />
                  <Th k="cert" label="Cert Level" />
                  <Th k="monthAssigned" label="Assigned (mo)" num />
                  <Th k="monthCompleted" label="Completed (mo)" num />
                  <Th k="monthEarned" label="Earned (mo)" num />
                  <Th k="availability" label="Availability" />
                  <Th k="stripeConnected" label="Payment" />
                </tr>
              </thead>
              <tbody>
                {rows.map((r) => (
                  <tr key={r.id} onClick={() => setSelected(r)} className="cursor-pointer border-t border-border hover:bg-accent/40">
                    <td className="px-3 py-2">
                      <div className="flex items-center gap-2">
                        <div className="flex h-7 w-7 items-center justify-center rounded-full bg-gradient-to-br from-teal-500 to-emerald-500 text-[10px] font-semibold text-white">{r.initials}</div>
                        <div>
                          <div className="font-medium">{r.name}</div>
                          {r.pending && <span className="text-[10px] text-amber-400">PENDING invite</span>}
                        </div>
                      </div>
                    </td>
                    <td className="px-3 py-2 text-xs">
                      <div>{r.cert}</div>
                      <div className={`text-[10px] ${certExpiringSoon(r.certExpiry) ? "text-amber-400" : "text-muted-foreground"}`}>
                        exp {r.certExpiry}{certExpiringSoon(r.certExpiry) && " ⚠"}
                      </div>
                    </td>
                    <td className="px-3 py-2 text-right font-mono text-xs">{r.monthAssigned}</td>
                    <td className="px-3 py-2 text-right font-mono text-xs">{r.monthCompleted}</td>
                    <td className="px-3 py-2 text-right font-mono text-xs">${r.monthEarned.toLocaleString()}</td>
                    <td className="px-3 py-2"><Pill tone={r.availability === "AVAILABLE" ? "ok" : "bad"}>{r.availability}</Pill></td>
                    <td className="px-3 py-2">
                      {r.stripeConnected
                        ? <span className="inline-flex items-center gap-1 text-xs text-emerald-400"><CheckCircle2 className="h-3.5 w-3.5" /> Connected</span>
                        : <span className="inline-flex items-center gap-1 text-xs text-amber-400"><AlertTriangle className="h-3.5 w-3.5" /> Not connected</span>}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </>
      ) : (
        <AssignRefereesView onPick={setOpenGame} />
      )}

      {selected && <RefereePanel ref_={selected} onClose={() => setSelected(null)} />}
      {showAdd && <AddRefereeDrawer onClose={() => setShowAdd(false)} />}
      {openGame && <AssignDrawer game={openGame} onClose={() => setOpenGame(null)} />}
    </div>
  );
}

/* -------------------- Assign view -------------------- */

function AssignRefereesView({ onPick }: { onPick: (g: OpenGame) => void }) {
  return (
    <div className="space-y-3">
      <div className="grid grid-cols-1 gap-2 md:grid-cols-3">
        <div className="rounded-lg border border-red-500/30 bg-red-500/5 p-3 text-xs">
          <div className="flex items-center gap-1.5 font-semibold text-red-400"><ShieldAlert className="h-3.5 w-3.5" /> Within 24h, no refs</div>
          <div className="mt-1 text-2xl font-semibold">{OPEN_GAMES.filter(g => g.hoursUntil < 24 && g.refsAssigned === 0).length}</div>
        </div>
        <div className="rounded-lg border border-amber-500/30 bg-amber-500/5 p-3 text-xs">
          <div className="flex items-center gap-1.5 font-semibold text-amber-400"><Clock className="h-3.5 w-3.5" /> Within 48h, short on refs</div>
          <div className="mt-1 text-2xl font-semibold">{OPEN_GAMES.filter(g => g.hoursUntil < 48 && g.refsAssigned < g.refsNeeded).length}</div>
        </div>
        <div className="rounded-lg border border-border bg-muted/30 p-3 text-xs">
          <div className="font-semibold text-muted-foreground">Total open slots</div>
          <div className="mt-1 text-2xl font-semibold">{OPEN_GAMES.reduce((s, g) => s + (g.refsNeeded - g.refsAssigned), 0)}</div>
        </div>
      </div>

      <div className="overflow-hidden rounded-lg border border-border">
        <table className="w-full text-sm">
          <thead className="bg-muted/40 text-xs uppercase text-muted-foreground">
            <tr>
              <th className="px-3 py-2 text-left">Date / Time</th>
              <th className="px-3 py-2 text-left">Teams</th>
              <th className="px-3 py-2 text-left">Rink</th>
              <th className="px-3 py-2 text-left">Division</th>
              <th className="px-3 py-2 text-left">Refs</th>
              <th className="px-3 py-2 text-left">Status</th>
              <th className="px-3 py-2"></th>
            </tr>
          </thead>
          <tbody>
            {OPEN_GAMES.map((g) => {
              const missing = g.refsNeeded - g.refsAssigned;
              const urgent = g.hoursUntil < 24 && missing > 0;
              const warn = g.hoursUntil < 48 && missing > 0;
              return (
                <tr key={g.id} className={`cursor-pointer border-t border-border hover:bg-accent/40 ${urgent ? "bg-red-500/5" : warn ? "bg-amber-500/5" : ""}`} onClick={() => onPick(g)}>
                  <td className="px-3 py-2 text-xs"><div>{g.date}</div><div className="text-muted-foreground">{g.time}</div></td>
                  <td className="px-3 py-2 text-xs font-medium">{g.teams}</td>
                  <td className="px-3 py-2 text-xs">{g.rink}</td>
                  <td className="px-3 py-2 text-xs">{g.division}</td>
                  <td className="px-3 py-2 text-xs font-mono">{g.refsAssigned} / {g.refsNeeded}</td>
                  <td className="px-3 py-2">
                    {missing === 0 ? <Pill tone="ok">Full</Pill>
                      : urgent ? <Pill tone="bad">EMERGENCY · {g.hoursUntil}h</Pill>
                      : warn ? <Pill tone="warn">Urgent · {g.hoursUntil}h</Pill>
                      : <Pill tone="info">{missing} needed</Pill>}
                  </td>
                  <td className="px-3 py-2 text-right">
                    <button className="rounded border border-border bg-background px-2 py-1 text-xs hover:bg-accent">Assign →</button>
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>
    </div>
  );
}

/* -------------------- Referee detail panel -------------------- */

type RTab = "profile" | "assignments" | "payment";

function RefereePanel({ ref_, onClose }: { ref_: Referee; onClose: () => void }) {
  const [tab, setTab] = useState<RTab>("profile");
  const tabs: { id: RTab; label: string; icon: React.ComponentType<{ className?: string }> }[] = [
    { id: "profile", label: "Profile", icon: ClipboardList },
    { id: "assignments", label: "Assignments", icon: Calendar },
    { id: "payment", label: "Payment", icon: DollarSign },
  ];

  return (
    <>
      <div onClick={onClose} className="fixed inset-0 z-40 bg-black/50" />
      <aside className="fixed right-0 top-0 z-50 h-full w-full max-w-2xl overflow-y-auto border-l border-border bg-background shadow-2xl">
        <div className="sticky top-0 z-10 flex items-center justify-between border-b border-border bg-background px-5 py-3">
          <h3 className="text-sm font-semibold">Referee details</h3>
          <button onClick={onClose} className="rounded p-1 hover:bg-accent"><X className="h-4 w-4" /></button>
        </div>

        <div className="border-b border-border p-5">
          <div className="flex items-start gap-3">
            <div className="flex h-14 w-14 items-center justify-center rounded-full bg-gradient-to-br from-teal-500 to-emerald-500 text-lg font-semibold text-white">{ref_.initials}</div>
            <div className="flex-1">
              <div className="flex flex-wrap items-center gap-2">
                <h2 className="text-lg font-semibold">{ref_.name}</h2>
                <Pill tone="info">{ref_.cert}</Pill>
                <Pill tone={ref_.availability === "AVAILABLE" ? "ok" : "bad"}>{ref_.availability}</Pill>
                {ref_.pending && <Pill tone="warn">PENDING</Pill>}
              </div>
              <div className="mt-1 flex flex-wrap gap-3 text-xs text-muted-foreground">
                <span className="inline-flex items-center gap-1"><Mail className="h-3 w-3" />{ref_.email}</span>
                <span className="inline-flex items-center gap-1"><Phone className="h-3 w-3" />{ref_.phone}</span>
              </div>
            </div>
          </div>
        </div>

        <div className="border-b border-border px-5">
          <div className="flex gap-1">
            {tabs.map(({ id, label, icon: Icon }) => (
              <button key={id} onClick={() => setTab(id)}
                className={`flex items-center gap-1.5 border-b-2 px-3 py-2.5 text-xs font-medium transition ${tab === id ? "border-emerald-500 text-foreground" : "border-transparent text-muted-foreground hover:text-foreground"}`}>
                <Icon className="h-3.5 w-3.5" />{label}
              </button>
            ))}
          </div>
        </div>

        <div className="p-5">
          {tab === "profile" && <ProfileTab r={ref_} />}
          {tab === "assignments" && <AssignmentsTab r={ref_} />}
          {tab === "payment" && <PaymentTab r={ref_} />}
        </div>
      </aside>
    </>
  );
}

function Section({ title, children }: { title: string; children: React.ReactNode }) {
  return (
    <section className="rounded-lg border border-border p-4">
      <h4 className="mb-3 text-xs font-semibold uppercase tracking-wide text-muted-foreground">{title}</h4>
      {children}
    </section>
  );
}

function Row({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <div className="flex items-start justify-between gap-3 border-t border-border/60 py-1.5 text-xs first:border-0 first:pt-0">
      <span className="text-muted-foreground">{label}</span>
      <span className="text-right font-medium">{children}</span>
    </div>
  );
}

function ProfileTab({ r }: { r: Referee }) {
  return (
    <div className="space-y-4">
      <Section title="Contact">
        <Row label="Email">{r.email}</Row>
        <Row label="Phone">{r.phone}</Row>
      </Section>
      <Section title="Certification">
        <Row label="Governing body">{r.certBody}</Row>
        <Row label="Level">{r.cert}</Row>
        <Row label="Expires">
          <span className={certExpiringSoon(r.certExpiry) ? "text-amber-400" : ""}>{r.certExpiry}</span>
          {certExpiringSoon(r.certExpiry) && <span className="ml-2 text-[10px] text-amber-400">Renewal alert ⚠</span>}
        </Row>
        <Row label="Max age group">Certified for {r.maxAge} and below</Row>
      </Section>
      <Section title="Availability">
        <Row label="Days available">{r.daysAvailable.join(" · ")}</Row>
        <Row label="Time window">{r.timeWindow}</Row>
        <Row label="Blackout dates">{r.blackouts.length ? r.blackouts.join(", ") : "—"}</Row>
      </Section>
      <Section title="Conflict of interest">
        {r.conflicts.length ? (
          <ul className="space-y-1 text-xs">{r.conflicts.map((c, i) => <li key={i} className="flex items-center gap-1.5"><AlertTriangle className="h-3 w-3 text-amber-400" />{c}</li>)}</ul>
        ) : <p className="text-xs text-muted-foreground">No declared conflicts.</p>}
      </Section>
      <Section title="Payment connection">
        <div className="flex items-center justify-between">
          <div className="text-xs">
            <div className="flex items-center gap-1.5">
              <CreditCard className="h-3.5 w-3.5" />
              {r.stripeConnected ? <span className="text-emerald-400">Stripe Express connected</span> : <span className="text-amber-400">Not connected</span>}
            </div>
            <div className="mt-1 text-muted-foreground">{r.bank}</div>
          </div>
          {!r.stripeConnected && (
            <button className="rounded-md bg-gradient-to-r from-indigo-500 to-purple-500 px-3 py-1.5 text-xs font-medium text-white">Connect Stripe</button>
          )}
        </div>
      </Section>
    </div>
  );
}

function AssignmentsTab({ r }: { r: Referee }) {
  return (
    <div className="space-y-4">
      <div className="grid grid-cols-2 gap-2 text-xs">
        <div className="rounded-lg border border-border bg-muted/30 p-3">
          <div className="text-muted-foreground">Career games</div>
          <div className="text-2xl font-semibold">{r.careerGames}</div>
        </div>
        <div className="rounded-lg border border-border bg-muted/30 p-3">
          <div className="text-muted-foreground">Career earnings</div>
          <div className="text-2xl font-semibold">${r.careerEarned.toLocaleString()}</div>
        </div>
      </div>

      <div className="overflow-hidden rounded-lg border border-border">
        <table className="w-full text-xs">
          <thead className="bg-muted/40 text-[10px] uppercase text-muted-foreground">
            <tr><th className="px-2 py-1.5 text-left">Date</th><th className="px-2 py-1.5 text-left">Game</th><th className="px-2 py-1.5 text-left">Rink</th><th className="px-2 py-1.5 text-right">Fee</th><th className="px-2 py-1.5 text-left">Status</th><th className="px-2 py-1.5 text-left">Pay</th></tr>
          </thead>
          <tbody>
            {r.assignments.length === 0 && <tr><td colSpan={6} className="px-2 py-4 text-center text-muted-foreground">No assignments this season.</td></tr>}
            {r.assignments.map((a) => (
              <tr key={a.id} className="border-t border-border">
                <td className="px-2 py-1.5"><div>{a.date}</div><div className="text-muted-foreground">{a.time}</div></td>
                <td className="px-2 py-1.5">{a.teams}<div className="text-muted-foreground">{a.level}</div></td>
                <td className="px-2 py-1.5">{a.rink}</td>
                <td className="px-2 py-1.5 text-right font-mono">${a.fee}</td>
                <td className="px-2 py-1.5">
                  <Pill tone={statusTone(a.status)}>{a.status}</Pill>
                  {a.status === "PENDING" && (
                    <div className="mt-1 flex gap-1">
                      <button className="rounded bg-emerald-500/20 px-1.5 py-0.5 text-[10px] text-emerald-400">Accept</button>
                      <button className="rounded bg-red-500/20 px-1.5 py-0.5 text-[10px] text-red-400">Decline</button>
                    </div>
                  )}
                </td>
                <td className="px-2 py-1.5">{a.pay && <Pill tone={payTone(a.pay)}>{a.pay}</Pill>}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}

function PaymentTab({ r }: { r: Referee }) {
  const completed = r.assignments.filter((a) => a.pay);
  return (
    <div className="space-y-4">
      <div className="grid grid-cols-2 gap-2 text-xs">
        <div className="rounded-lg border border-emerald-500/30 bg-emerald-500/5 p-3">
          <div className="text-muted-foreground">Earned this month</div>
          <div className="text-2xl font-semibold text-emerald-400">${r.monthEarned.toLocaleString()}</div>
        </div>
        <div className="rounded-lg border border-border bg-muted/30 p-3">
          <div className="text-muted-foreground">Earned this season</div>
          <div className="text-2xl font-semibold">${r.seasonEarned.toLocaleString()}</div>
        </div>
      </div>

      <Section title="Payment history">
        <div className="overflow-hidden rounded border border-border">
          <table className="w-full text-xs">
            <thead className="bg-muted/40 text-[10px] uppercase text-muted-foreground">
              <tr><th className="px-2 py-1.5 text-left">Date</th><th className="px-2 py-1.5 text-left">Game</th><th className="px-2 py-1.5 text-right">Fee</th><th className="px-2 py-1.5 text-left">Paid On</th><th className="px-2 py-1.5 text-left">Status</th></tr>
            </thead>
            <tbody>
              {completed.length === 0 && <tr><td colSpan={5} className="px-2 py-4 text-center text-muted-foreground">No payments yet.</td></tr>}
              {completed.map((a) => (
                <tr key={a.id} className="border-t border-border">
                  <td className="px-2 py-1.5">{a.date}</td>
                  <td className="px-2 py-1.5">{a.teams}</td>
                  <td className="px-2 py-1.5 text-right font-mono">${a.fee}</td>
                  <td className="px-2 py-1.5">{a.paidOn ?? "—"}</td>
                  <td className="px-2 py-1.5">{a.pay && <Pill tone={payTone(a.pay)}>{a.pay}</Pill>}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
        <p className="mt-2 text-[10px] text-muted-foreground">Payments processed automatically via Stripe once a game is marked COMPLETED.</p>
      </Section>

      <Section title="Tax documents">
        <div className="flex items-center justify-between text-xs">
          <div>
            <div className="font-medium">{r.certBody === "Hockey Canada" ? "T4A" : "1099-NEC"} — 2026</div>
            <div className="text-muted-foreground">Generated from all payments in current tax year.</div>
          </div>
          <button className="inline-flex items-center gap-1.5 rounded-md border border-border bg-background px-3 py-1.5 text-xs hover:bg-accent">
            <FileText className="h-3.5 w-3.5" /> Generate {r.certBody === "Hockey Canada" ? "T4A" : "1099"}
          </button>
        </div>
      </Section>
    </div>
  );
}

/* -------------------- Assign drawer -------------------- */

function AssignDrawer({ game, onClose }: { game: OpenGame; onClose: () => void }) {
  const divLevel = Number(game.division.match(/U(\d+)/)?.[1] ?? 18);
  const eligible = REFS.map((r) => {
    const maxAgeNum = r.maxAge === "Senior" ? 99 : Number(r.maxAge.replace("U", ""));
    const meetsCert = maxAgeNum >= divLevel;
    const available = r.availability === "AVAILABLE" && r.stripeConnected;
    const conflict = r.conflicts.some((c) => game.teams.includes(c.split(" (")[0]));
    let reason = "";
    if (!meetsCert) reason = `Cert below ${game.division}`;
    else if (!available) reason = r.availability === "UNAVAILABLE" ? "Marked unavailable" : "Stripe not connected";
    else if (conflict) reason = "Conflict of interest";
    return { ref: r, ok: meetsCert && available && !conflict, reason };
  });

  return (
    <>
      <div onClick={onClose} className="fixed inset-0 z-40 bg-black/50" />
      <aside className="fixed right-0 top-0 z-50 h-full w-full max-w-xl overflow-y-auto border-l border-border bg-background shadow-2xl">
        <div className="sticky top-0 z-10 flex items-center justify-between border-b border-border bg-background px-5 py-3">
          <h3 className="text-sm font-semibold">Assign referees</h3>
          <button onClick={onClose} className="rounded p-1 hover:bg-accent"><X className="h-4 w-4" /></button>
        </div>

        <div className="border-b border-border p-5">
          <div className="text-base font-semibold">{game.teams}</div>
          <div className="mt-1 text-xs text-muted-foreground">{game.date} · {game.time} · {game.rink} · {game.division}</div>
          <div className="mt-2 flex items-center gap-2">
            <Pill tone="info">{game.refsAssigned} / {game.refsNeeded} assigned</Pill>
            {game.hoursUntil < 24 && <Pill tone="bad">EMERGENCY · {game.hoursUntil}h</Pill>}
            {game.hoursUntil >= 24 && game.hoursUntil < 48 && <Pill tone="warn">{game.hoursUntil}h until game</Pill>}
          </div>
        </div>

        <div className="p-5">
          <h4 className="mb-2 text-xs font-semibold uppercase tracking-wide text-muted-foreground">Referee pool</h4>
          <ul className="space-y-2">
            {eligible.map(({ ref, ok, reason }) => (
              <li key={ref.id} title={!ok ? reason : ""} className={`flex items-center justify-between rounded-lg border border-border p-3 ${!ok ? "opacity-50" : "hover:bg-accent/40"}`}>
                <div className="flex items-center gap-2">
                  <div className="flex h-8 w-8 items-center justify-center rounded-full bg-gradient-to-br from-teal-500 to-emerald-500 text-[10px] font-semibold text-white">{ref.initials}</div>
                  <div>
                    <div className="text-sm font-medium">{ref.name}</div>
                    <div className="text-[10px] text-muted-foreground">{ref.cert} · max {ref.maxAge} · {ref.timeWindow}</div>
                    {!ok && <div className="text-[10px] text-amber-400">{reason}</div>}
                  </div>
                </div>
                <button disabled={!ok} className="rounded-md bg-gradient-to-r from-teal-500 to-emerald-500 px-3 py-1.5 text-xs font-medium text-white disabled:cursor-not-allowed disabled:opacity-40">
                  Assign
                </button>
              </li>
            ))}
          </ul>
          <p className="mt-3 text-[10px] text-muted-foreground">Assigned referees get a push notification and have 24 hours to accept or decline. Declined slots reopen automatically.</p>
        </div>
      </aside>
    </>
  );
}

/* -------------------- Add referee drawer -------------------- */

const DAYS = ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"];

function AddRefereeDrawer({ onClose }: { onClose: () => void }) {
  const [days, setDays] = useState<Set<string>>(new Set(["Sat", "Sun"]));
  const toggle = (d: string) => setDays((s) => { const n = new Set(s); n.has(d) ? n.delete(d) : n.add(d); return n; });

  return (
    <>
      <div onClick={onClose} className="fixed inset-0 z-40 bg-black/50" />
      <aside className="fixed right-0 top-0 z-50 h-full w-full max-w-xl overflow-y-auto border-l border-border bg-background shadow-2xl">
        <div className="sticky top-0 z-10 flex items-center justify-between border-b border-border bg-background px-5 py-3">
          <h3 className="text-sm font-semibold">Add referee</h3>
          <button onClick={onClose} className="rounded p-1 hover:bg-accent"><X className="h-4 w-4" /></button>
        </div>

        <div className="space-y-4 p-5 text-xs">
          <div className="grid grid-cols-2 gap-3">
            <Field label="Full name"><input className="field" placeholder="Jane Doe" /></Field>
            <Field label="Email"><input className="field" placeholder="jane@email.com" /></Field>
            <Field label="Phone"><input className="field" placeholder="(204) 555-0100" /></Field>
            <Field label="Certification level">
              <select className="field">{["Level 1", "Level 2", "Level 3", "Level 4", "Level 5", "Level 6"].map((c) => <option key={c}>{c}</option>)}</select>
            </Field>
            <Field label="Certification body">
              <select className="field"><option>Hockey Canada</option><option>USA Hockey</option></select>
            </Field>
            <Field label="Certification expiry"><input type="date" className="field" /></Field>
          </div>

          <Field label="Days available (weekly)">
            <div className="flex flex-wrap gap-1">
              {DAYS.map((d) => (
                <button key={d} onClick={() => toggle(d)} className={`rounded-md border px-2 py-1 text-[10px] ${days.has(d) ? "border-emerald-500 bg-emerald-500/20 text-emerald-400" : "border-border bg-background"}`}>{d}</button>
              ))}
            </div>
          </Field>

          <div className="grid grid-cols-2 gap-3">
            <Field label="Time window"><input className="field" placeholder="5:00 PM – 10:00 PM" /></Field>
            <Field label="Blackout dates"><input className="field" placeholder="2026-07-15 – 2026-07-22" /></Field>
          </div>

          <Field label="Conflict of interest (teams / coaches)">
            <textarea rows={2} className="field" placeholder="e.g. U13 AA Storm (daughter plays)" />
          </Field>

          <div className="rounded-lg border border-sky-500/30 bg-sky-500/5 p-3 text-[11px] text-sky-400">
            Invite is sent via Resend. The referee creates an account, connects Stripe Express for direct deposit, and appears in the list with a PENDING badge until both steps are complete.
          </div>

          <div className="flex justify-end gap-2">
            <button onClick={onClose} className="rounded-md border border-border px-3 py-1.5">Cancel</button>
            <button className="rounded-md bg-gradient-to-r from-teal-500 to-emerald-500 px-3 py-1.5 font-medium text-white">Send invite</button>
          </div>
        </div>

        <style>{`.field { width:100%; height:32px; border:1px solid hsl(var(--border)); background:hsl(var(--background)); border-radius:6px; padding:0 8px; font-size:12px; } textarea.field { height:auto; padding:6px 8px; }`}</style>
      </aside>
    </>
  );
}

function Field({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <label className="block">
      <span className="mb-1 block text-[10px] font-medium uppercase tracking-wide text-muted-foreground">{label}</span>
      {children}
    </label>
  );
}
