import { useMemo, useState } from "react";
import {
  Plus, Search, X, Send, AlertTriangle, Calendar, Clock, Mail,
  MessageSquare, Smartphone, Bell, Users, FileText, Eye, Edit3,
  GripVertical, Image as ImageIcon, Snowflake, Sparkles, ChevronDown,
  CheckCircle2, Filter, Archive,
} from "lucide-react";

// ─────────────── types & mock data ───────────────
type Method = "PUSH" | "EMAIL" | "SMS";
type Audience = "Everyone" | "All Coaches" | "All Parents" | "U11" | "U13" | "U15" | "U18" | "Head Coaches" | "Board Members" | "U15 AA Wolves" | "U13 A Falcons";

type Broadcast = {
  id: string;
  date: string;
  subject: string;
  audience: Audience;
  methods: Method[];
  openRate: number;
  sentBy: string;
  emergency?: boolean;
};

const BROADCASTS: Broadcast[] = [
  { id: "b1", date: "2026-06-24 14:32", subject: "Summer Camp registration now OPEN", audience: "All Parents", methods: ["PUSH", "EMAIL"], openRate: 78, sentBy: "M. Coleman" },
  { id: "b2", date: "2026-06-22 09:15", subject: "Coach meeting moved to Thursday 7pm", audience: "All Coaches", methods: ["PUSH", "EMAIL", "SMS"], openRate: 94, sentBy: "M. Coleman" },
  { id: "b3", date: "2026-06-20 18:40", subject: "EMERGENCY: Bell MTS evacuated — practices cancelled", audience: "Everyone", methods: ["PUSH", "EMAIL", "SMS"], openRate: 99, sentBy: "M. Coleman", emergency: true },
  { id: "b4", date: "2026-06-18 11:00", subject: "U13 tryout schedule released", audience: "U13", methods: ["PUSH", "EMAIL"], openRate: 82, sentBy: "S. Reyes" },
  { id: "b5", date: "2026-06-15 16:22", subject: "Bottle drive Saturday — volunteers needed", audience: "Everyone", methods: ["PUSH", "EMAIL"], openRate: 64, sentBy: "J. Patel" },
  { id: "b6", date: "2026-06-12 08:00", subject: "U15 AA Wolves — game time changed", audience: "U15 AA Wolves", methods: ["PUSH", "SMS"], openRate: 100, sentBy: "M. Coleman" },
  { id: "b7", date: "2026-06-10 19:30", subject: "Board meeting agenda — June", audience: "Board Members", methods: ["EMAIL"], openRate: 88, sentBy: "M. Coleman" },
];

type Thread = {
  id: string;
  name: string;
  role: string;
  initials: string;
  preview: string;
  last: string;
  unread: boolean;
};

const THREADS: Thread[] = [
  { id: "t1", name: "Marcus Devlin", role: "Head Coach · U15 AA", initials: "MD", preview: "Can we move Thursday's practice to 6pm?", last: "9m", unread: true },
  { id: "t2", name: "Jennifer Marchetti", role: "Parent · Sofia M.", initials: "JM", preview: "Following up on the outstanding fee — sent payment today.", last: "1h", unread: true },
  { id: "t3", name: "Sarah Kowalski", role: "Head Coach · U13 A", initials: "SK", preview: "Roster is finalized, ready for your review.", last: "3h", unread: false },
  { id: "t4", name: "David Chen", role: "Referee", initials: "DC", preview: "Updating my availability for next month.", last: "Yesterday", unread: false },
  { id: "t5", name: "Anita Okafor", role: "Parent · Zara O.", initials: "AO", preview: "Thanks for sending the camp details!", last: "2d", unread: false },
];

type Newsletter = {
  id: string;
  date: string;
  title: string;
  audience: Audience;
  opens: number;
};

const NEWSLETTERS: Newsletter[] = [
  { id: "n1", date: "2026-06-01", title: "June Edition — Season Wrap & Summer Camps", audience: "Everyone", opens: 1240 },
  { id: "n2", date: "2026-05-01", title: "May Edition — Playoffs Recap", audience: "Everyone", opens: 1180 },
  { id: "n3", date: "2026-04-01", title: "April Edition — Tryout Season", audience: "Everyone", opens: 1320 },
];

const RINKS = ["Bell MTS Iceplex", "Seven Oaks Arena", "St. James Civic Centre", "Eric Coy Arena"];

// ─────────────── main ───────────────
export function AssociationCommunications() {
  const [tab, setTab] = useState<"broadcasts" | "messages" | "newsletter">("broadcasts");
  const [showNew, setShowNew] = useState(false);
  const [emergencyMode, setEmergencyMode] = useState(false);

  return (
    <div className="space-y-6">
      {/* Top bar */}
      <div className="flex items-center justify-between gap-4 flex-wrap">
        <div className="flex items-center gap-1 rounded-lg border border-border bg-card p-1">
          {(["broadcasts", "messages", "newsletter"] as const).map(t => (
            <button
              key={t}
              onClick={() => setTab(t)}
              className={`px-4 py-1.5 text-sm font-medium rounded-md capitalize transition ${tab === t ? "bg-background text-foreground shadow-sm" : "text-muted-foreground hover:text-foreground"}`}
            >{t}</button>
          ))}
        </div>

        <button
          onClick={() => { setEmergencyMode(false); setShowNew(true); }}
          className="flex items-center gap-2 px-4 py-2 text-sm font-semibold rounded-lg bg-gradient-to-r from-teal-500 to-emerald-500 text-white hover:opacity-90 transition shadow-sm shadow-emerald-500/20"
        >
          <Plus className="h-4 w-4" /> New Broadcast
        </button>
      </div>

      {tab === "broadcasts" && <BroadcastsTab onEmergency={() => { setEmergencyMode(true); setShowNew(true); }} />}
      {tab === "messages" && <MessagesTab />}
      {tab === "newsletter" && <NewsletterTab />}

      {showNew && <NewBroadcastDrawer onClose={() => setShowNew(false)} startEmergency={emergencyMode} />}
    </div>
  );
}

// ─────────────── Broadcasts ───────────────
function BroadcastsTab({ onEmergency }: { onEmergency: () => void }) {
  const [showRinkClosure, setShowRinkClosure] = useState(false);

  return (
    <div className="space-y-4">
      {/* Quick actions */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
        <button
          onClick={() => setShowRinkClosure(true)}
          className="text-left rounded-xl border border-border bg-gradient-to-br from-blue-500/10 via-card to-card p-4 hover:from-blue-500/20 transition group"
        >
          <div className="flex items-center gap-3">
            <div className="h-10 w-10 rounded-lg bg-blue-500/15 flex items-center justify-center">
              <Snowflake className="h-5 w-5 text-blue-500" />
            </div>
            <div className="flex-1">
              <p className="font-semibold text-sm">Send Rink Closure Alert</p>
              <p className="text-xs text-muted-foreground">Notify affected coaches & families · auto-cancels ice slots</p>
            </div>
            <span className="text-xs text-teal-500 group-hover:translate-x-0.5 transition">Open →</span>
          </div>
        </button>
        <button
          onClick={onEmergency}
          className="text-left rounded-xl border border-rose-500/30 bg-gradient-to-br from-rose-500/10 via-card to-card p-4 hover:from-rose-500/20 transition group"
        >
          <div className="flex items-center gap-3">
            <div className="h-10 w-10 rounded-lg bg-rose-500/15 flex items-center justify-center">
              <AlertTriangle className="h-5 w-5 text-rose-500" />
            </div>
            <div className="flex-1">
              <p className="font-semibold text-sm">Emergency Broadcast</p>
              <p className="text-xs text-muted-foreground">Bypasses notification prefs · Push + Email + SMS</p>
            </div>
            <span className="text-xs text-rose-500 group-hover:translate-x-0.5 transition">Open →</span>
          </div>
        </button>
      </div>

      {/* History */}
      <div className="rounded-xl border border-border bg-card overflow-hidden">
        <div className="px-4 py-3 border-b border-border flex items-center justify-between">
          <h3 className="text-sm font-semibold">Broadcast History</h3>
          <span className="text-xs text-muted-foreground">{BROADCASTS.length} sent</span>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b border-border bg-muted/30 text-xs text-muted-foreground">
                <th className="text-left px-4 py-2.5 font-medium">Date</th>
                <th className="text-left px-4 py-2.5 font-medium">Subject</th>
                <th className="text-left px-4 py-2.5 font-medium">Audience</th>
                <th className="text-left px-4 py-2.5 font-medium">Methods</th>
                <th className="text-right px-4 py-2.5 font-medium">Open Rate</th>
                <th className="text-left px-4 py-2.5 font-medium">Sent By</th>
              </tr>
            </thead>
            <tbody>
              {BROADCASTS.map(b => (
                <tr key={b.id} className="border-b border-border last:border-0 hover:bg-muted/20 transition">
                  <td className="px-4 py-3 text-xs text-muted-foreground whitespace-nowrap">{b.date}</td>
                  <td className="px-4 py-3 font-medium">
                    <div className="flex items-center gap-2">
                      {b.emergency && <span className="inline-block px-1.5 py-0.5 text-[9px] font-bold rounded bg-rose-500/15 text-rose-500">EMERGENCY</span>}
                      <span>{b.subject}</span>
                    </div>
                  </td>
                  <td className="px-4 py-3">
                    <span className="inline-block px-2 py-0.5 text-[10px] font-semibold rounded bg-muted text-muted-foreground">{b.audience}</span>
                  </td>
                  <td className="px-4 py-3">
                    <div className="flex items-center gap-1">
                      {b.methods.map(m => <MethodBadge key={m} method={m} />)}
                    </div>
                  </td>
                  <td className="px-4 py-3 text-right">
                    <span className={`font-semibold ${b.openRate >= 80 ? "text-emerald-500" : b.openRate >= 60 ? "text-amber-500" : "text-muted-foreground"}`}>{b.openRate}%</span>
                  </td>
                  <td className="px-4 py-3 text-xs text-muted-foreground">{b.sentBy}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {showRinkClosure && <RinkClosureDrawer onClose={() => setShowRinkClosure(false)} />}
    </div>
  );
}

function MethodBadge({ method }: { method: Method }) {
  const map = {
    PUSH: { icon: Bell, cls: "bg-violet-500/15 text-violet-500" },
    EMAIL: { icon: Mail, cls: "bg-blue-500/15 text-blue-500" },
    SMS: { icon: Smartphone, cls: "bg-emerald-500/15 text-emerald-500" },
  } as const;
  const { icon: Icon, cls } = map[method];
  return (
    <span className={`inline-flex items-center gap-1 px-1.5 py-0.5 text-[10px] font-semibold rounded ${cls}`}>
      <Icon className="h-2.5 w-2.5" /> {method}
    </span>
  );
}

// ─────────────── Messages ───────────────
function MessagesTab() {
  const [search, setSearch] = useState("");
  const [unreadOnly, setUnreadOnly] = useState(false);
  const [activeId, setActiveId] = useState<string>(THREADS[0].id);

  const filtered = useMemo(() =>
    THREADS.filter(t =>
      (!unreadOnly || t.unread) &&
      (search === "" || t.name.toLowerCase().includes(search.toLowerCase()) || t.preview.toLowerCase().includes(search.toLowerCase()))
    ), [search, unreadOnly]);

  const active = THREADS.find(t => t.id === activeId)!;

  return (
    <div className="grid grid-cols-1 lg:grid-cols-12 gap-4 h-[calc(100vh-220px)] min-h-[500px]">
      {/* List */}
      <div className="lg:col-span-4 rounded-xl border border-border bg-card overflow-hidden flex flex-col">
        <div className="p-3 border-b border-border space-y-2">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
            <input
              value={search}
              onChange={e => setSearch(e.target.value)}
              placeholder="Search messages…"
              className="w-full pl-9 pr-3 py-2 text-sm bg-background border border-border rounded-lg focus:outline-none focus:ring-2 focus:ring-teal-500/30"
            />
          </div>
          <div className="flex items-center justify-between">
            <button
              onClick={() => setUnreadOnly(!unreadOnly)}
              className={`flex items-center gap-1.5 px-2 py-1 text-xs rounded ${unreadOnly ? "bg-teal-500/15 text-teal-500" : "text-muted-foreground hover:text-foreground"}`}
            >
              <Filter className="h-3 w-3" /> Unread only
            </button>
            <button className="text-xs text-muted-foreground hover:text-foreground">Mark all read</button>
          </div>
        </div>
        <div className="flex-1 overflow-y-auto">
          {filtered.map(t => (
            <button
              key={t.id}
              onClick={() => setActiveId(t.id)}
              className={`w-full text-left p-3 border-b border-border hover:bg-muted/30 transition ${activeId === t.id ? "bg-muted/40" : ""}`}
            >
              <div className="flex items-start gap-3">
                <div className="h-9 w-9 rounded-full bg-gradient-to-br from-teal-500/20 to-emerald-500/20 flex items-center justify-center text-xs font-semibold flex-shrink-0">
                  {t.initials}
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center justify-between gap-2">
                    <p className={`text-sm truncate ${t.unread ? "font-semibold" : "font-medium"}`}>{t.name}</p>
                    <span className="text-[10px] text-muted-foreground flex-shrink-0">{t.last}</span>
                  </div>
                  <p className="text-[10px] text-muted-foreground">{t.role}</p>
                  <p className={`text-xs mt-1 truncate ${t.unread ? "text-foreground" : "text-muted-foreground"}`}>{t.preview}</p>
                </div>
                {t.unread && <span className="h-2 w-2 rounded-full bg-teal-500 flex-shrink-0 mt-1.5" />}
              </div>
            </button>
          ))}
        </div>
      </div>

      {/* Thread */}
      <div className="lg:col-span-8 rounded-xl border border-border bg-card overflow-hidden flex flex-col">
        <div className="p-4 border-b border-border flex items-center gap-3">
          <div className="h-10 w-10 rounded-full bg-gradient-to-br from-teal-500/20 to-emerald-500/20 flex items-center justify-center text-sm font-semibold">
            {active.initials}
          </div>
          <div>
            <p className="font-semibold text-sm">{active.name}</p>
            <p className="text-xs text-muted-foreground">{active.role}</p>
          </div>
        </div>
        <div className="flex-1 overflow-y-auto p-4 space-y-3">
          <div className="flex gap-2">
            <div className="max-w-[70%] rounded-2xl rounded-tl-sm bg-muted px-4 py-2.5 text-sm">{active.preview}</div>
          </div>
          <p className="text-[10px] text-muted-foreground text-center">{active.last} ago</p>
        </div>
        <div className="p-3 border-t border-border">
          <div className="flex items-center gap-2">
            <input
              placeholder="Type a reply…"
              className="flex-1 px-3 py-2 text-sm bg-background border border-border rounded-lg focus:outline-none focus:ring-2 focus:ring-teal-500/30"
            />
            <button className="p-2 rounded-lg bg-gradient-to-r from-teal-500 to-emerald-500 text-white">
              <Send className="h-4 w-4" />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}

// ─────────────── Newsletter ───────────────
type Block = { id: string; title: string; type: string; visible: boolean; auto?: boolean };

const DEFAULT_BLOCKS: Block[] = [
  { id: "bl1", title: "Header", type: "header", visible: true, auto: true },
  { id: "bl2", title: "Featured Story", type: "featured", visible: true },
  { id: "bl3", title: "Upcoming Events", type: "events", visible: true, auto: true },
  { id: "bl4", title: "Team Spotlight", type: "spotlight", visible: true },
  { id: "bl5", title: "Standings Snapshot", type: "standings", visible: true, auto: true },
  { id: "bl6", title: "Sponsor Recognition", type: "sponsors", visible: true, auto: true },
  { id: "bl7", title: "Footer", type: "footer", visible: true, auto: true },
];

function NewsletterTab() {
  const [building, setBuilding] = useState(false);

  if (!building) {
    return (
      <div className="space-y-4">
        <button
          onClick={() => setBuilding(true)}
          className="w-full rounded-xl border-2 border-dashed border-border bg-card p-8 hover:border-teal-500/40 hover:bg-teal-500/5 transition group"
        >
          <div className="flex flex-col items-center gap-2">
            <div className="h-12 w-12 rounded-xl bg-gradient-to-br from-teal-500/20 to-emerald-500/20 flex items-center justify-center group-hover:scale-110 transition">
              <Sparkles className="h-6 w-6 text-teal-500" />
            </div>
            <p className="font-semibold">Create Newsletter</p>
            <p className="text-xs text-muted-foreground">Drag-and-drop builder with auto-populated sections</p>
          </div>
        </button>

        <div className="rounded-xl border border-border bg-card overflow-hidden">
          <div className="px-4 py-3 border-b border-border flex items-center gap-2">
            <Archive className="h-4 w-4 text-muted-foreground" />
            <h3 className="text-sm font-semibold">Sent Newsletters</h3>
          </div>
          <div className="divide-y divide-border">
            {NEWSLETTERS.map(n => (
              <div key={n.id} className="px-4 py-3 flex items-center justify-between hover:bg-muted/20 transition">
                <div>
                  <p className="text-sm font-medium">{n.title}</p>
                  <p className="text-xs text-muted-foreground">Sent {n.date} · {n.audience}</p>
                </div>
                <div className="flex items-center gap-4">
                  <span className="text-xs text-muted-foreground">{n.opens.toLocaleString()} opens</span>
                  <button className="p-1.5 rounded hover:bg-muted text-muted-foreground hover:text-foreground"><Eye className="h-4 w-4" /></button>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    );
  }

  return <NewsletterBuilder onClose={() => setBuilding(false)} />;
}

function NewsletterBuilder({ onClose }: { onClose: () => void }) {
  const [blocks, setBlocks] = useState<Block[]>(DEFAULT_BLOCKS);
  const [audience, setAudience] = useState<Audience>("Everyone");
  const [scheduled, setScheduled] = useState(false);
  const [showPreview, setShowPreview] = useState(false);

  const toggleVisible = (id: string) => setBlocks(b => b.map(x => x.id === id ? { ...x, visible: !x.visible } : x));
  const move = (id: string, dir: -1 | 1) => {
    setBlocks(b => {
      const i = b.findIndex(x => x.id === id);
      const j = i + dir;
      if (j < 0 || j >= b.length) return b;
      const next = [...b]; [next[i], next[j]] = [next[j], next[i]];
      return next;
    });
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
      {/* Builder */}
      <div className="lg:col-span-2 rounded-xl border border-border bg-card p-5 space-y-3">
        <div className="flex items-center justify-between">
          <h3 className="text-sm font-semibold">Newsletter Blocks</h3>
          <button onClick={onClose} className="text-xs text-muted-foreground hover:text-foreground">← Back to archive</button>
        </div>
        {blocks.map((b, i) => (
          <div key={b.id} className={`flex items-center gap-3 p-3 rounded-lg border ${b.visible ? "border-border bg-background" : "border-border bg-muted/30 opacity-60"}`}>
            <div className="flex flex-col">
              <button onClick={() => move(b.id, -1)} disabled={i === 0} className="text-muted-foreground hover:text-foreground disabled:opacity-30">▴</button>
              <GripVertical className="h-3 w-3 text-muted-foreground" />
              <button onClick={() => move(b.id, 1)} disabled={i === blocks.length - 1} className="text-muted-foreground hover:text-foreground disabled:opacity-30">▾</button>
            </div>
            <div className="flex-1">
              <div className="flex items-center gap-2">
                <p className="font-medium text-sm">{b.title}</p>
                {b.auto && <span className="px-1.5 py-0.5 text-[9px] font-semibold rounded bg-teal-500/15 text-teal-500">AUTO</span>}
              </div>
              <p className="text-[10px] text-muted-foreground">{b.auto ? "Pulled automatically from app data" : "Custom content — click edit"}</p>
            </div>
            <button className="p-1.5 rounded hover:bg-muted text-muted-foreground"><ImageIcon className="h-3.5 w-3.5" /></button>
            <button className="p-1.5 rounded hover:bg-muted text-muted-foreground"><Edit3 className="h-3.5 w-3.5" /></button>
            <button onClick={() => toggleVisible(b.id)} className="p-1.5 rounded hover:bg-muted text-muted-foreground"><Eye className="h-3.5 w-3.5" /></button>
          </div>
        ))}
      </div>

      {/* Settings */}
      <div className="space-y-4">
        <div className="rounded-xl border border-border bg-card p-5 space-y-4">
          <h3 className="text-sm font-semibold">Send Settings</h3>
          <div>
            <label className="text-xs text-muted-foreground">Audience</label>
            <select value={audience} onChange={e => setAudience(e.target.value as Audience)} className="mt-1 w-full px-3 py-2 text-sm bg-background border border-border rounded-lg">
              <option>Everyone</option>
              <option>All Coaches</option>
              <option>All Parents</option>
            </select>
          </div>
          <label className="flex items-center gap-2 text-sm cursor-pointer">
            <input type="checkbox" checked={scheduled} onChange={e => setScheduled(e.target.checked)} className="rounded" />
            <span>Schedule for later</span>
          </label>
          {scheduled && (
            <div className="grid grid-cols-2 gap-2">
              <input type="date" className="px-3 py-2 text-sm bg-background border border-border rounded-lg" />
              <input type="time" className="px-3 py-2 text-sm bg-background border border-border rounded-lg" />
            </div>
          )}
          <button onClick={() => setShowPreview(true)} className="w-full flex items-center justify-center gap-2 px-4 py-2.5 text-sm font-medium rounded-lg border border-border hover:bg-muted transition">
            <Eye className="h-4 w-4" /> Preview as Email
          </button>
          <button className="w-full flex items-center justify-center gap-2 px-4 py-2.5 text-sm font-semibold rounded-lg bg-gradient-to-r from-teal-500 to-emerald-500 text-white hover:opacity-90 transition">
            <Send className="h-4 w-4" /> {scheduled ? "Schedule Send" : "Send Now"}
          </button>
        </div>
      </div>

      {showPreview && (
        <Drawer onClose={() => setShowPreview(false)} title="Email Preview" subtitle="Approximate inbox rendering">
          <div className="rounded-lg border border-border bg-white text-slate-900 p-6 space-y-4">
            <div className="border-b border-slate-200 pb-3">
              <div className="flex items-center gap-2 mb-2">
                <div className="h-8 w-8 rounded bg-gradient-to-br from-teal-500 to-emerald-500 text-white font-black text-xs flex items-center justify-center">PXF</div>
                <span className="font-bold">Winnipeg Wolves Hockey Association</span>
              </div>
              <h1 className="text-xl font-bold">June Newsletter</h1>
            </div>
            {blocks.filter(b => b.visible && b.type !== "header" && b.type !== "footer").map(b => (
              <div key={b.id}>
                <h2 className="font-bold text-sm mb-1">{b.title}</h2>
                <p className="text-xs text-slate-600">Lorem ipsum dolor sit amet, content for {b.title.toLowerCase()}…</p>
              </div>
            ))}
            <div className="border-t border-slate-200 pt-3 text-[10px] text-slate-500">
              You received this email because you are part of the Winnipeg Wolves Hockey Association. <a className="underline">Unsubscribe</a>
            </div>
          </div>
        </Drawer>
      )}
    </div>
  );
}

// ─────────────── New Broadcast Drawer ───────────────
function NewBroadcastDrawer({ onClose, startEmergency }: { onClose: () => void; startEmergency: boolean }) {
  const [emergency, setEmergency] = useState(startEmergency);
  const [audience, setAudience] = useState<Audience>("Everyone");
  const [methods, setMethods] = useState<Set<Method>>(new Set(["PUSH", "EMAIL", "SMS"]));
  const [subject, setSubject] = useState("");
  const [body, setBody] = useState("");
  const [scheduled, setScheduled] = useState(false);
  const [showPreview, setShowPreview] = useState(false);

  const toggleMethod = (m: Method) => {
    if (emergency) return;
    const next = new Set(methods);
    next.has(m) ? next.delete(m) : next.add(m);
    setMethods(next);
  };

  return (
    <Drawer
      onClose={onClose}
      title={emergency ? "Emergency Broadcast" : "New Broadcast"}
      subtitle={emergency ? "Bypasses notification preferences" : "Notify families, coaches, or specific groups"}
      tone={emergency ? "rose" : undefined}
    >
      <div className="space-y-5">
        {/* Emergency toggle */}
        <button
          onClick={() => { setEmergency(!emergency); if (!emergency) setMethods(new Set(["PUSH", "EMAIL", "SMS"])); }}
          className={`w-full flex items-center justify-between p-3 rounded-lg border transition ${emergency ? "border-rose-500/40 bg-rose-500/10" : "border-border bg-card hover:bg-muted/30"}`}
        >
          <div className="flex items-center gap-2">
            <AlertTriangle className={`h-4 w-4 ${emergency ? "text-rose-500" : "text-muted-foreground"}`} />
            <div className="text-left">
              <p className={`text-sm font-medium ${emergency ? "text-rose-500" : ""}`}>Emergency Broadcast</p>
              <p className="text-[10px] text-muted-foreground">Sends immediately via Push + Email + SMS to everyone</p>
            </div>
          </div>
          <div className={`h-5 w-9 rounded-full p-0.5 transition ${emergency ? "bg-rose-500" : "bg-muted"}`}>
            <div className={`h-4 w-4 rounded-full bg-white transition ${emergency ? "translate-x-4" : ""}`} />
          </div>
        </button>

        {/* Subject */}
        <div>
          <label className="text-xs text-muted-foreground">Subject</label>
          <input
            value={subject}
            onChange={e => setSubject(e.target.value)}
            placeholder="What's this about?"
            className="mt-1 w-full px-3 py-2 text-sm bg-background border border-border rounded-lg focus:outline-none focus:ring-2 focus:ring-teal-500/30"
          />
        </div>

        {/* Audience */}
        <div>
          <label className="text-xs text-muted-foreground flex items-center gap-1"><Users className="h-3 w-3" /> Audience</label>
          <select
            value={audience}
            disabled={emergency}
            onChange={e => setAudience(e.target.value as Audience)}
            className="mt-1 w-full px-3 py-2 text-sm bg-background border border-border rounded-lg disabled:opacity-50"
          >
            <optgroup label="Broad">
              <option>Everyone</option>
              <option>All Coaches</option>
              <option>All Parents</option>
            </optgroup>
            <optgroup label="By Division">
              <option>U11</option><option>U13</option><option>U15</option><option>U18</option>
            </optgroup>
            <optgroup label="By Team">
              <option>U15 AA Wolves</option><option>U13 A Falcons</option>
            </optgroup>
            <optgroup label="By Role">
              <option>Head Coaches</option><option>Board Members</option>
            </optgroup>
          </select>
        </div>

        {/* Methods */}
        <div>
          <label className="text-xs text-muted-foreground">Delivery Method</label>
          <div className="mt-1 grid grid-cols-3 gap-2">
            {(["PUSH", "EMAIL", "SMS"] as Method[]).map(m => {
              const Icon = m === "PUSH" ? Bell : m === "EMAIL" ? Mail : Smartphone;
              const on = methods.has(m);
              return (
                <button
                  key={m}
                  onClick={() => toggleMethod(m)}
                  className={`flex flex-col items-center gap-1 p-3 rounded-lg border transition ${on ? "border-teal-500 bg-teal-500/10 text-teal-500" : "border-border text-muted-foreground hover:text-foreground"} ${emergency ? "cursor-not-allowed" : ""}`}
                >
                  <Icon className="h-4 w-4" />
                  <span className="text-xs font-medium">{m}</span>
                </button>
              );
            })}
          </div>
        </div>

        {/* Body */}
        <div>
          <label className="text-xs text-muted-foreground">Message</label>
          <div className="mt-1 rounded-lg border border-border bg-background">
            <div className="flex items-center gap-1 px-2 py-1.5 border-b border-border text-muted-foreground text-xs">
              <button className="px-2 py-1 rounded hover:bg-muted font-bold">B</button>
              <button className="px-2 py-1 rounded hover:bg-muted italic">I</button>
              <button className="px-2 py-1 rounded hover:bg-muted underline">U</button>
              <div className="w-px h-4 bg-border mx-1" />
              <button className="px-2 py-1 rounded hover:bg-muted"><ImageIcon className="h-3 w-3" /></button>
              <button className="px-2 py-1 rounded hover:bg-muted">🔗</button>
            </div>
            <textarea
              value={body}
              onChange={e => setBody(e.target.value)}
              rows={6}
              placeholder="Write your message…"
              className="w-full px-3 py-2 text-sm bg-transparent focus:outline-none resize-none"
            />
          </div>
        </div>

        {/* Schedule */}
        {!emergency && (
          <div>
            <label className="flex items-center gap-2 text-sm cursor-pointer">
              <input type="checkbox" checked={scheduled} onChange={e => setScheduled(e.target.checked)} className="rounded" />
              <Clock className="h-3.5 w-3.5 text-muted-foreground" />
              <span>Schedule for later</span>
            </label>
            {scheduled && (
              <div className="mt-2 grid grid-cols-2 gap-2">
                <input type="date" className="px-3 py-2 text-sm bg-background border border-border rounded-lg" />
                <input type="time" className="px-3 py-2 text-sm bg-background border border-border rounded-lg" />
              </div>
            )}
          </div>
        )}

        {/* Actions */}
        <div className="flex gap-2 pt-2">
          <button
            onClick={() => setShowPreview(true)}
            className="flex-1 flex items-center justify-center gap-2 px-4 py-2.5 text-sm font-medium rounded-lg border border-border hover:bg-muted transition"
          >
            <Eye className="h-4 w-4" /> Preview
          </button>
          <button
            className={`flex-1 flex items-center justify-center gap-2 px-4 py-2.5 text-sm font-semibold rounded-lg text-white transition ${emergency ? "bg-rose-500 hover:bg-rose-600 shadow-sm shadow-rose-500/20" : "bg-gradient-to-r from-teal-500 to-emerald-500 hover:opacity-90"}`}
          >
            <Send className="h-4 w-4" /> {emergency ? "Send Emergency Now" : scheduled ? "Schedule" : "Send Now"}
          </button>
        </div>
      </div>

      {showPreview && (
        <Drawer onClose={() => setShowPreview(false)} title="Broadcast Preview" subtitle="Push · Email · SMS">
          <div className="space-y-4">
            {methods.has("PUSH") && (
              <div>
                <p className="text-[10px] font-semibold text-muted-foreground mb-1 flex items-center gap-1"><Bell className="h-3 w-3" /> PUSH NOTIFICATION</p>
                <div className="rounded-xl bg-slate-800 text-white p-3 border border-slate-700">
                  <div className="flex items-center gap-2 mb-1">
                    <div className="h-5 w-5 rounded bg-gradient-to-br from-teal-500 to-emerald-500 text-white font-black text-[8px] flex items-center justify-center">PXF</div>
                    <span className="text-[10px] text-slate-400">PXF Hockey · now</span>
                  </div>
                  <p className="text-sm font-semibold">{subject || "Subject preview"}</p>
                  <p className="text-xs text-slate-300 line-clamp-2">{body || "Message body preview…"}</p>
                </div>
              </div>
            )}
            {methods.has("EMAIL") && (
              <div>
                <p className="text-[10px] font-semibold text-muted-foreground mb-1 flex items-center gap-1"><Mail className="h-3 w-3" /> EMAIL</p>
                <div className="rounded-lg bg-white text-slate-900 p-4 border border-slate-200">
                  <p className="text-[10px] text-slate-500">From: PXF Hockey &lt;noreply@pxfhockey.app&gt;</p>
                  <p className="text-sm font-bold mt-1">{subject || "Subject preview"}</p>
                  <div className="border-t border-slate-100 mt-2 pt-2 text-sm whitespace-pre-wrap">{body || "Message body preview…"}</div>
                </div>
              </div>
            )}
            {methods.has("SMS") && (
              <div>
                <p className="text-[10px] font-semibold text-muted-foreground mb-1 flex items-center gap-1"><Smartphone className="h-3 w-3" /> SMS</p>
                <div className="rounded-2xl rounded-bl-sm bg-emerald-500 text-white p-3 max-w-[80%] text-sm">
                  <p className="font-semibold">PXF Hockey:</p>
                  <p className="text-xs">{body || subject || "Message body preview…"}</p>
                </div>
              </div>
            )}
          </div>
        </Drawer>
      )}
    </Drawer>
  );
}

// ─────────────── Rink Closure Drawer ───────────────
function RinkClosureDrawer({ onClose }: { onClose: () => void }) {
  const [rink, setRink] = useState(RINKS[0]);
  const [date, setDate] = useState("");
  const slots = ["6:00 AM – 7:30 AM (U13 A Falcons)", "5:00 PM – 6:30 PM (U15 AA Wolves)", "7:00 PM – 8:30 PM (U18 AAA Wolves)"];
  const [selectedSlots, setSelectedSlots] = useState<Set<string>>(new Set(slots));
  const [message, setMessage] = useState(`${rink} is closed on ${date || "[Date]"} for the time slots below. All affected sessions have been cancelled. We will update you when rescheduled.`);

  const toggleSlot = (s: string) => {
    const next = new Set(selectedSlots);
    next.has(s) ? next.delete(s) : next.add(s);
    setSelectedSlots(next);
  };

  return (
    <Drawer onClose={onClose} title="Rink Closure Alert" subtitle="Notifies affected families & marks ice slots CANCELLED">
      <div className="space-y-5">
        <div className="rounded-lg bg-blue-500/10 border border-blue-500/30 p-3 flex items-start gap-2">
          <Snowflake className="h-4 w-4 text-blue-500 mt-0.5 flex-shrink-0" />
          <p className="text-xs text-blue-500/90">Affected ice slots will be automatically marked CANCELLED in the Ice Times section after sending.</p>
        </div>

        <div className="grid grid-cols-2 gap-3">
          <div>
            <label className="text-xs text-muted-foreground">Rink</label>
            <select value={rink} onChange={e => setRink(e.target.value)} className="mt-1 w-full px-3 py-2 text-sm bg-background border border-border rounded-lg">
              {RINKS.map(r => <option key={r}>{r}</option>)}
            </select>
          </div>
          <div>
            <label className="text-xs text-muted-foreground">Date</label>
            <input type="date" value={date} onChange={e => setDate(e.target.value)} className="mt-1 w-full px-3 py-2 text-sm bg-background border border-border rounded-lg" />
          </div>
        </div>

        <div>
          <label className="text-xs text-muted-foreground flex items-center gap-1"><Calendar className="h-3 w-3" /> Affected Time Slots</label>
          <div className="mt-1 space-y-1.5">
            {slots.map(s => (
              <label key={s} className="flex items-center gap-2 p-2 rounded-lg border border-border hover:bg-muted/30 cursor-pointer">
                <input type="checkbox" checked={selectedSlots.has(s)} onChange={() => toggleSlot(s)} className="rounded" />
                <span className="text-sm">{s}</span>
              </label>
            ))}
          </div>
        </div>

        <div>
          <label className="text-xs text-muted-foreground">Message (editable)</label>
          <textarea
            value={message}
            onChange={e => setMessage(e.target.value)}
            rows={4}
            className="mt-1 w-full px-3 py-2 text-sm bg-background border border-border rounded-lg resize-none focus:outline-none focus:ring-2 focus:ring-teal-500/30"
          />
        </div>

        <div className="flex items-center gap-2 text-xs text-muted-foreground">
          <CheckCircle2 className="h-3.5 w-3.5 text-teal-500" />
          <span>Sends via Push + SMS + Email to all affected coaches & families</span>
        </div>

        <button className="w-full flex items-center justify-center gap-2 px-4 py-3 text-sm font-semibold rounded-lg bg-gradient-to-r from-blue-500 to-cyan-500 text-white hover:opacity-90 transition">
          <Send className="h-4 w-4" /> Send Closure Alert
        </button>
      </div>
    </Drawer>
  );
}

// ─────────────── Drawer ───────────────
function Drawer({ title, subtitle, onClose, children, tone }: { title: string; subtitle?: string; onClose: () => void; children: React.ReactNode; tone?: "rose" }) {
  return (
    <div className="fixed inset-0 z-50 flex">
      <div className="flex-1 bg-black/50 backdrop-blur-sm" onClick={onClose} />
      <div className="w-full max-w-xl bg-background border-l border-border overflow-y-auto">
        <div className={`sticky top-0 bg-background border-b ${tone === "rose" ? "border-rose-500/30" : "border-border"} px-6 py-4 flex items-start justify-between`}>
          <div>
            <h2 className={`text-lg font-semibold ${tone === "rose" ? "text-rose-500" : ""}`}>{title}</h2>
            {subtitle && <p className="text-xs text-muted-foreground mt-0.5">{subtitle}</p>}
          </div>
          <button onClick={onClose} className="p-1.5 rounded-md hover:bg-muted">
            <X className="h-4 w-4" />
          </button>
        </div>
        <div className="p-6">{children}</div>
      </div>
    </div>
  );
}
