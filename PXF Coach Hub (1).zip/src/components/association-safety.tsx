import { useMemo, useState } from "react";
import {
  Plus, Search, X, Download, AlertTriangle, ShieldAlert, Lock, Eye,
  FileText, CheckCircle2, Clock, Upload, Bell, Activity, Brain,
  Link as LinkIcon, Copy, ListChecks,
} from "lucide-react";

/* ============================================================
   INCIDENTS
   ============================================================ */

type IncType =
  | "INJURY" | "CONCUSSION" | "FIGHT" | "MEDICAL EMERGENCY"
  | "EQUIPMENT FAILURE" | "ICE HAZARD" | "NEAR MISS" | "MISCONDUCT";
type IncStatus = "OPEN" | "IN REVIEW" | "RESOLVED";
type Severity = "LOW" | "MEDIUM" | "HIGH" | "CRITICAL";

type Incident = {
  id: string;
  caseNo: string;
  date: string;
  time: string;
  location: string;
  type: IncType;
  person: string;
  team: string;
  filedBy: string;
  filedAt: string;
  status: IncStatus;
  severity: Severity;
  description: string;
  witnesses: string[];
  firstAid?: { what: string; by: string };
  parentNotified?: { at: string; by: string };
  ambulance: boolean;
  photos: number;
  notes?: string;
};

const INCIDENTS: Incident[] = [
  { id: "i1", caseNo: "INC-2026-0142", date: "2026-06-24", time: "7:32 PM", location: "MTS Centre A", type: "CONCUSSION", person: "Ethan Carter (#9)", team: "U15 AAA", filedBy: "Coach R. Bell", filedAt: "2026-06-24 19:48", status: "IN REVIEW", severity: "HIGH", description: "Player took an open-ice hit in the neutral zone. Slow to get up, reported headache and dizziness on bench.", witnesses: ["Asst. Coach M. Lin", "Trainer J. Park"], firstAid: { what: "Cold pack, removed from play, monitored on bench", by: "Trainer J. Park" }, parentNotified: { at: "2026-06-24 19:52", by: "Coach R. Bell" }, ambulance: false, photos: 0, notes: "Concussion Protocol opened — see tracker." },
  { id: "i2", caseNo: "INC-2026-0141", date: "2026-06-23", time: "6:15 PM", location: "Iceplex B", type: "MEDICAL EMERGENCY", person: "Mia Rousseau (#22)", team: "U11 A", filedBy: "Trainer J. Park", filedAt: "2026-06-23 18:22", status: "RESOLVED", severity: "CRITICAL", description: "Anaphylactic reaction post-game in dressing room. EpiPen administered.", witnesses: ["Coach K. Yu", "Parent Y. Rousseau"], firstAid: { what: "EpiPen administered, 911 called", by: "Trainer J. Park" }, parentNotified: { at: "2026-06-23 18:18", by: "On-site" }, ambulance: true, photos: 0 },
  { id: "i3", caseNo: "INC-2026-0140", date: "2026-06-22", time: "8:05 PM", location: "MTS Centre A", type: "FIGHT", person: "Owen Tremblay (#4)", team: "U15 AAA", filedBy: "Ref M. Devlin", filedAt: "2026-06-22 20:14", status: "OPEN", severity: "MEDIUM", description: "Roughing escalated to fighting majors. Both players ejected.", witnesses: ["Ref S. Petrov"], ambulance: false, photos: 0 },
  { id: "i4", caseNo: "INC-2026-0139", date: "2026-06-21", time: "5:40 PM", location: "Iceplex A", type: "ICE HAZARD", person: "—", team: "—", filedBy: "Rink Ops T. Chen", filedAt: "2026-06-21 17:55", status: "RESOLVED", severity: "LOW", description: "Soft spot near corner boards. Game delayed 12 minutes for resurface.", witnesses: [], ambulance: false, photos: 2 },
  { id: "i5", caseNo: "INC-2026-0138", date: "2026-06-19", time: "7:00 PM", location: "Community Rink 3", type: "INJURY", person: "Liam Brooks (#17)", team: "U13 AA", filedBy: "Coach D. Brooks", filedAt: "2026-06-19 19:20", status: "RESOLVED", severity: "LOW", description: "Stick to the hand, no break, minor swelling.", witnesses: [], firstAid: { what: "Ice pack", by: "Coach D. Brooks" }, parentNotified: { at: "2026-06-19 19:25", by: "Coach D. Brooks" }, ambulance: false, photos: 0 },
  { id: "i6", caseNo: "INC-2026-0137", date: "2026-06-18", time: "6:45 PM", location: "Iceplex B", type: "NEAR MISS", person: "—", team: "U13 AA", filedBy: "Coach D. Brooks", filedAt: "2026-06-18 19:10", status: "RESOLVED", severity: "LOW", description: "Loose puck deflected toward bench gate that was left open.", witnesses: ["Asst. Coach"], ambulance: false, photos: 0 },
];

const TYPE_STYLES: Record<IncType, { cls: string; pulse?: boolean }> = {
  "INJURY": { cls: "bg-blue-500/15 text-blue-400 border-blue-500/30" },
  "CONCUSSION": { cls: "bg-purple-500/15 text-purple-400 border-purple-500/30" },
  "FIGHT": { cls: "bg-red-500/15 text-red-400 border-red-500/30" },
  "MEDICAL EMERGENCY": { cls: "bg-red-500/20 text-red-400 border-red-500/40", pulse: true },
  "EQUIPMENT FAILURE": { cls: "bg-orange-500/15 text-orange-400 border-orange-500/30" },
  "ICE HAZARD": { cls: "bg-orange-500/15 text-orange-400 border-orange-500/30" },
  "NEAR MISS": { cls: "bg-yellow-500/15 text-yellow-400 border-yellow-500/30" },
  "MISCONDUCT": { cls: "bg-red-500/15 text-red-400 border-red-500/30" },
};

const TypeBadge = ({ t }: { t: IncType }) => {
  const s = TYPE_STYLES[t];
  return <span className={`inline-flex rounded-md border px-2 py-0.5 text-[10px] font-semibold ${s.cls} ${s.pulse ? "animate-pulse" : ""}`}>{t}</span>;
};

const Pill = ({ tone, children }: { tone: "ok" | "warn" | "bad" | "muted" | "info" | "danger"; children: React.ReactNode }) => {
  const m = {
    ok: "bg-emerald-500/15 text-emerald-400 border-emerald-500/30",
    warn: "bg-amber-500/15 text-amber-400 border-amber-500/30",
    bad: "bg-red-500/15 text-red-400 border-red-500/30",
    danger: "bg-red-500/20 text-red-300 border-red-500/40",
    muted: "bg-muted text-muted-foreground border-border",
    info: "bg-sky-500/15 text-sky-400 border-sky-500/30",
  }[tone];
  return <span className={`inline-flex rounded-md border px-2 py-0.5 text-[10px] font-semibold ${m}`}>{children}</span>;
};

const SeverityPill = ({ s }: { s: Severity }) =>
  <Pill tone={s === "CRITICAL" ? "danger" : s === "HIGH" ? "bad" : s === "MEDIUM" ? "warn" : "muted"}>{s}</Pill>;

const StatusPill = ({ s }: { s: IncStatus }) =>
  <Pill tone={s === "RESOLVED" ? "ok" : s === "IN REVIEW" ? "info" : "warn"}>{s}</Pill>;

/* ============================================================
   SAFE SPORT
   ============================================================ */

type SSCategory = "Physical Abuse" | "Emotional Abuse" | "Sexual Abuse" | "Bullying" | "Hazing" | "Discrimination" | "Grooming";
type SSStatus = "NEW" | "UNDER REVIEW" | "REFERRED TO AUTHORITIES" | "CLOSED";

type SafeSportReport = {
  caseNo: string;
  date: string;
  categories: SSCategory[];
  reporter: { anonymous: boolean; name?: string; contact?: string };
  reported: { name: string; role: "Coach" | "Player" | "Volunteer" | "Parent" | "Official" };
  status: SSStatus;
  involvesMinor: boolean;
  description: string;
  witnesses: string;
  investigator?: string;
  attachments: number;
  timeline: { ts: string; by: string; event: string }[];
  notes: { ts: string; by: string; text: string }[];
  views: { ts: string; by: string }[];
  appeal?: { ts: string; by: string; text: string };
};

const SS_REPORTS: SafeSportReport[] = [
  {
    caseNo: "SS-2026-0007", date: "2026-06-20", categories: ["Bullying", "Emotional Abuse"],
    reporter: { anonymous: false, name: "Sandra Carter", contact: "scarter@email.com" },
    reported: { name: "Coach D. Holloway", role: "Coach" },
    status: "UNDER REVIEW", involvesMinor: true,
    description: "Pattern of belittling comments toward U13 athletes during practice over multiple sessions. Player declining to attend.",
    witnesses: "Two parents in stands; asst. coach M. Lin", investigator: "A. Morgan (President)", attachments: 1,
    timeline: [
      { ts: "2026-06-20 09:14", by: "System", event: "Report submitted via public link" },
      { ts: "2026-06-20 09:14", by: "System", event: "Safe Sport Officer + President notified" },
      { ts: "2026-06-20 14:22", by: "A. Morgan", event: "Assigned as investigator" },
      { ts: "2026-06-22 11:00", by: "A. Morgan", event: "Interview scheduled with reporter" },
    ],
    notes: [{ ts: "2026-06-22 16:40", by: "A. Morgan", text: "Coach placed on temporary administrative leave pending review." }],
    views: [
      { ts: "2026-06-20 09:15", by: "A. Morgan (President)" },
      { ts: "2026-06-20 09:18", by: "K. Owens (Safe Sport Officer)" },
      { ts: "2026-06-22 16:35", by: "A. Morgan (President)" },
    ],
  },
  {
    caseNo: "SS-2026-0006", date: "2026-06-12", categories: ["Discrimination"],
    reporter: { anonymous: true },
    reported: { name: "Parent on team U15 AAA Falcons", role: "Parent" },
    status: "NEW", involvesMinor: false,
    description: "Repeated discriminatory remarks in the stands directed at visiting team players.",
    witnesses: "Anonymous", attachments: 0,
    timeline: [
      { ts: "2026-06-12 21:03", by: "System", event: "Anonymous report submitted" },
      { ts: "2026-06-12 21:03", by: "System", event: "Safe Sport Officer + President notified" },
    ],
    notes: [],
    views: [{ ts: "2026-06-13 08:02", by: "K. Owens (Safe Sport Officer)" }],
  },
];

/* ============================================================
   ROOT
   ============================================================ */

type SafetyRole = "admin" | "officer" | "president";
type View = "incidents" | "safesport";

export function AssociationSafety() {
  const [role, setRole] = useState<SafetyRole>("admin");
  const [view, setView] = useState<View>("incidents");
  const canSafeSport = role === "president" || role === "officer";

  return (
    <div className="space-y-5">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div className="flex items-center gap-1 rounded-md border border-border bg-muted/40 p-0.5 text-xs">
          <button onClick={() => setView("incidents")} className={`rounded px-3 py-1 ${view === "incidents" ? "bg-background shadow-sm" : "text-muted-foreground"}`}>
            Incidents
          </button>
          {canSafeSport && (
            <button onClick={() => setView("safesport")} className={`flex items-center gap-1.5 rounded px-3 py-1 ${view === "safesport" ? "bg-background shadow-sm" : "text-muted-foreground"}`}>
              <Lock className="h-3 w-3" /> Safe Sport
            </button>
          )}
        </div>
        <div className="flex items-center gap-2">
          <span className="text-[10px] uppercase tracking-wide text-muted-foreground">Dev role</span>
          <select value={role} onChange={(e) => { const r = e.target.value as SafetyRole; setRole(r); if (r === "admin" && view === "safesport") setView("incidents"); }} className="h-7 rounded-md border border-border bg-background px-2 text-xs">
            <option value="admin">Association Admin</option>
            <option value="officer">Safe Sport Officer</option>
            <option value="president">President</option>
          </select>
        </div>
      </div>

      {view === "incidents" ? <IncidentsView /> : <SafeSportView role={role} />}
    </div>
  );
}

/* ============================================================
   INCIDENTS VIEW
   ============================================================ */

function IncidentsView() {
  const [selected, setSelected] = useState<Incident | null>(null);
  const [showFile, setShowFile] = useState(false);
  const [showProtocol, setShowProtocol] = useState<Incident | null>(null);
  const [search, setSearch] = useState("");
  const [fType, setFType] = useState("all");
  const [fStatus, setFStatus] = useState("all");
  const [fSeverity, setFSeverity] = useState("all");
  const [sort, setSort] = useState<"date" | "severity" | "status">("date");

  const rows = useMemo(() => {
    let r = INCIDENTS.filter((i) => {
      if (search && ![i.person, i.team, i.location, i.caseNo].some(v => v.toLowerCase().includes(search.toLowerCase()))) return false;
      if (fType !== "all" && i.type !== fType) return false;
      if (fStatus !== "all" && i.status !== fStatus) return false;
      if (fSeverity !== "all" && i.severity !== fSeverity) return false;
      return true;
    });
    const sevOrder = { CRITICAL: 0, HIGH: 1, MEDIUM: 2, LOW: 3 };
    if (sort === "date") r = [...r].sort((a, b) => b.date.localeCompare(a.date));
    if (sort === "severity") r = [...r].sort((a, b) => sevOrder[a.severity] - sevOrder[b.severity]);
    if (sort === "status") r = [...r].sort((a, b) => a.status.localeCompare(b.status));
    return r;
  }, [search, fType, fStatus, fSeverity, sort]);

  return (
    <div className="space-y-4">
      <div className="grid grid-cols-2 gap-2 md:grid-cols-4">
        <Stat label="Open" value={INCIDENTS.filter(i => i.status === "OPEN").length} tone="warn" icon={AlertTriangle} />
        <Stat label="In review" value={INCIDENTS.filter(i => i.status === "IN REVIEW").length} tone="info" icon={Eye} />
        <Stat label="Critical (30d)" value={INCIDENTS.filter(i => i.severity === "CRITICAL").length} tone="bad" icon={ShieldAlert} />
        <Stat label="Concussion protocols active" value={INCIDENTS.filter(i => i.type === "CONCUSSION").length} tone="muted" icon={Brain} />
      </div>

      <div className="flex flex-wrap items-center justify-between gap-3">
        <div className="flex flex-wrap items-center gap-2">
          <div className="relative">
            <Search className="absolute left-2 top-1/2 h-3.5 w-3.5 -translate-y-1/2 text-muted-foreground" />
            <input value={search} onChange={(e) => setSearch(e.target.value)} placeholder="Search case #, person, team…"
              className="h-8 w-64 rounded-md border border-border bg-background pl-7 pr-2 text-xs" />
          </div>
          <select value={fType} onChange={(e) => setFType(e.target.value)} className="h-8 rounded-md border border-border bg-background px-2 text-xs">
            <option value="all">All types</option>{Object.keys(TYPE_STYLES).map(t => <option key={t}>{t}</option>)}
          </select>
          <select value={fStatus} onChange={(e) => setFStatus(e.target.value)} className="h-8 rounded-md border border-border bg-background px-2 text-xs">
            <option value="all">Any status</option><option>OPEN</option><option>IN REVIEW</option><option>RESOLVED</option>
          </select>
          <select value={fSeverity} onChange={(e) => setFSeverity(e.target.value)} className="h-8 rounded-md border border-border bg-background px-2 text-xs">
            <option value="all">Any severity</option><option>LOW</option><option>MEDIUM</option><option>HIGH</option><option>CRITICAL</option>
          </select>
          <select value={sort} onChange={(e) => setSort(e.target.value as never)} className="h-8 rounded-md border border-border bg-background px-2 text-xs">
            <option value="date">Sort: Date</option><option value="severity">Sort: Severity</option><option value="status">Sort: Status</option>
          </select>
        </div>
        <div className="flex items-center gap-2">
          <button className="inline-flex h-8 items-center gap-1.5 rounded-md border border-border bg-background px-3 text-xs hover:bg-accent">
            <Download className="h-3.5 w-3.5" /> Export CSV
          </button>
          <button onClick={() => setShowFile(true)} className="inline-flex h-8 items-center gap-1.5 rounded-md bg-gradient-to-r from-teal-500 to-emerald-500 px-3 text-xs font-medium text-white hover:opacity-90">
            <Plus className="h-3.5 w-3.5" /> File Incident
          </button>
        </div>
      </div>

      <div className="overflow-hidden rounded-lg border border-border">
        <table className="w-full text-sm">
          <thead className="bg-muted/40 text-xs uppercase text-muted-foreground">
            <tr>
              <th className="px-3 py-2 text-left">Date</th>
              <th className="px-3 py-2 text-left">Case #</th>
              <th className="px-3 py-2 text-left">Type</th>
              <th className="px-3 py-2 text-left">Person involved</th>
              <th className="px-3 py-2 text-left">Team</th>
              <th className="px-3 py-2 text-left">Filed by</th>
              <th className="px-3 py-2 text-left">Status</th>
              <th className="px-3 py-2 text-left">Severity</th>
            </tr>
          </thead>
          <tbody>
            {rows.map((i) => (
              <tr key={i.id} onClick={() => setSelected(i)} className="cursor-pointer border-t border-border hover:bg-accent/40">
                <td className="px-3 py-2 text-xs"><div>{i.date}</div><div className="text-muted-foreground">{i.time}</div></td>
                <td className="px-3 py-2 font-mono text-xs">{i.caseNo}</td>
                <td className="px-3 py-2"><TypeBadge t={i.type} /></td>
                <td className="px-3 py-2 text-xs font-medium">{i.person}</td>
                <td className="px-3 py-2 text-xs">{i.team}</td>
                <td className="px-3 py-2 text-xs">{i.filedBy}</td>
                <td className="px-3 py-2"><StatusPill s={i.status} /></td>
                <td className="px-3 py-2"><SeverityPill s={i.severity} /></td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {selected && <IncidentPanel inc={selected} onClose={() => setSelected(null)} onOpenProtocol={() => { setShowProtocol(selected); setSelected(null); }} />}
      {showFile && <FileIncidentDrawer onClose={() => setShowFile(false)} />}
      {showProtocol && <ConcussionProtocol inc={showProtocol} onClose={() => setShowProtocol(null)} />}
    </div>
  );
}

function Stat({ label, value, tone, icon: Icon }: { label: string; value: number; tone: "ok" | "warn" | "bad" | "info" | "muted"; icon: React.ComponentType<{ className?: string }> }) {
  const m = { ok: "text-emerald-400", warn: "text-amber-400", bad: "text-red-400", info: "text-sky-400", muted: "text-muted-foreground" }[tone];
  return (
    <div className="rounded-lg border border-border bg-muted/30 p-3">
      <div className="flex items-center justify-between text-[10px] uppercase tracking-wide text-muted-foreground">
        <span>{label}</span><Icon className={`h-3.5 w-3.5 ${m}`} />
      </div>
      <div className={`mt-1 text-2xl font-semibold ${m}`}>{value}</div>
    </div>
  );
}

/* ============================================================
   INCIDENT DETAIL PANEL
   ============================================================ */

function IncidentPanel({ inc, onClose, onOpenProtocol }: { inc: Incident; onClose: () => void; onOpenProtocol: () => void }) {
  const [status, setStatus] = useState<IncStatus>(inc.status);

  return (
    <>
      <div onClick={onClose} className="fixed inset-0 z-40 bg-black/50" />
      <aside className="fixed right-0 top-0 z-50 h-full w-full max-w-2xl overflow-y-auto border-l border-border bg-background shadow-2xl">
        <div className="sticky top-0 z-10 flex items-center justify-between border-b border-border bg-background px-5 py-3">
          <div className="flex items-center gap-2">
            <h3 className="text-sm font-semibold">Incident report</h3>
            <span className="font-mono text-xs text-muted-foreground">{inc.caseNo}</span>
          </div>
          <button onClick={onClose} className="rounded p-1 hover:bg-accent"><X className="h-4 w-4" /></button>
        </div>

        <div className="space-y-4 p-5">
          <div className="flex flex-wrap items-center gap-2">
            <TypeBadge t={inc.type} /><SeverityPill s={inc.severity} /><StatusPill s={status} />
            {inc.ambulance && <Pill tone="bad">AMBULANCE</Pill>}
          </div>

          {inc.type === "CONCUSSION" && (
            <button onClick={onOpenProtocol} className="flex w-full items-center justify-between rounded-lg border border-purple-500/40 bg-purple-500/10 p-3 text-left hover:bg-purple-500/15">
              <div className="flex items-center gap-2"><Brain className="h-4 w-4 text-purple-400" /><div><div className="text-sm font-semibold text-purple-300">Concussion Protocol active</div><div className="text-[11px] text-muted-foreground">Athlete locked from all lineups — open tracker</div></div></div>
              <span className="text-xs text-purple-300">Open →</span>
            </button>
          )}

          <Section title="When & where">
            <Row label="Date / Time">{inc.date} · {inc.time}</Row>
            <Row label="Location">{inc.location}</Row>
            <Row label="Team">{inc.team}</Row>
          </Section>

          <Section title="Parties involved">
            <Row label="Person">{inc.person}</Row>
            <Row label="Witnesses">{inc.witnesses.length ? inc.witnesses.join(", ") : "—"}</Row>
          </Section>

          <Section title="Description">
            <p className="text-xs leading-relaxed">{inc.description}</p>
          </Section>

          <Section title="Response">
            <Row label="First aid">{inc.firstAid ? `${inc.firstAid.what} — ${inc.firstAid.by}` : "Not administered"}</Row>
            <Row label="Parent notified">{inc.parentNotified ? `${inc.parentNotified.at} by ${inc.parentNotified.by}` : "No"}</Row>
            <Row label="Ambulance called">{inc.ambulance ? "Yes" : "No"}</Row>
            <Row label="Photos attached">{inc.photos}</Row>
          </Section>

          <Section title="Filed by">
            <Row label="By">{inc.filedBy}</Row>
            <Row label="At">{inc.filedAt}</Row>
          </Section>

          <Section title="Status">
            <div className="flex items-center gap-2">
              <select value={status} onChange={(e) => setStatus(e.target.value as IncStatus)} className="h-8 flex-1 rounded-md border border-border bg-background px-2 text-xs">
                <option>OPEN</option><option>IN REVIEW</option><option>RESOLVED</option>
              </select>
              <button className="rounded-md bg-gradient-to-r from-teal-500 to-emerald-500 px-3 py-1.5 text-xs font-medium text-white">Update</button>
            </div>
          </Section>

          <Section title="Internal notes">
            <textarea rows={3} defaultValue={inc.notes ?? ""} placeholder="Add admin note…" className="w-full rounded-md border border-border bg-background p-2 text-xs" />
          </Section>

          <Section title="External reporting">
            <button className="inline-flex w-full items-center justify-center gap-1.5 rounded-md border border-amber-500/40 bg-amber-500/10 px-3 py-2 text-xs font-medium text-amber-400 hover:bg-amber-500/15">
              <Bell className="h-3.5 w-3.5" /> Notify Hockey Canada / USA Hockey
            </button>
          </Section>
        </div>
      </aside>
    </>
  );
}

function Section({ title, children }: { title: string; children: React.ReactNode }) {
  return (
    <section className="rounded-lg border border-border p-4">
      <h4 className="mb-3 text-xs font-semibold uppercase tracking-wide text-muted-foreground">{title}</h4>
      {children}
    </section>
  );
}

function Row({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <div className="flex items-start justify-between gap-3 border-t border-border/60 py-1.5 text-xs first:border-0 first:pt-0">
      <span className="text-muted-foreground">{label}</span>
      <span className="text-right font-medium">{children}</span>
    </div>
  );
}

/* ============================================================
   FILE INCIDENT DRAWER
   ============================================================ */

function FileIncidentDrawer({ onClose }: { onClose: () => void }) {
  const [type, setType] = useState<IncType>("INJURY");
  const [firstAid, setFirstAid] = useState(false);
  const [parentNotified, setParentNotified] = useState(false);
  const isConcussion = type === "CONCUSSION";
  const isMedEmergency = type === "MEDICAL EMERGENCY";

  return (
    <>
      <div onClick={onClose} className="fixed inset-0 z-40 bg-black/50" />
      <aside className="fixed right-0 top-0 z-50 h-full w-full max-w-2xl overflow-y-auto border-l border-border bg-background shadow-2xl">
        <div className="sticky top-0 z-10 flex items-center justify-between border-b border-border bg-background px-5 py-3">
          <h3 className="text-sm font-semibold">File incident</h3>
          <button onClick={onClose} className="rounded p-1 hover:bg-accent"><X className="h-4 w-4" /></button>
        </div>

        <div className="space-y-4 p-5 text-xs">
          <Field label="Incident type">
            <select value={type} onChange={(e) => setType(e.target.value as IncType)} className="field">
              {(Object.keys(TYPE_STYLES) as IncType[]).map(t => <option key={t}>{t}</option>)}
            </select>
          </Field>

          {isConcussion && (
            <div className="rounded-lg border border-purple-500/40 bg-purple-500/10 p-3 text-[11px] text-purple-300">
              <Brain className="mr-1 inline h-3.5 w-3.5" />
              Filing this report will automatically open the <strong>Concussion Protocol</strong> tracker and lock the athlete from all lineups.
            </div>
          )}
          {isMedEmergency && (
            <div className="animate-pulse rounded-lg border border-red-500/40 bg-red-500/10 p-3 text-[11px] text-red-300">
              <ShieldAlert className="mr-1 inline h-3.5 w-3.5" />
              Auto-flagged as <strong>CRITICAL</strong>. Association President will be notified immediately via push + email on submit.
            </div>
          )}

          <div className="grid grid-cols-3 gap-3">
            <Field label="Date"><input type="date" className="field" /></Field>
            <Field label="Time"><input type="time" className="field" /></Field>
            <Field label="Location">
              <select className="field"><option>MTS Centre A</option><option>MTS Centre B</option><option>Iceplex A</option><option>Iceplex B</option><option>Community Rink 3</option><option>Other…</option></select>
            </Field>
          </div>

          <Field label="Person involved">
            <input className="field" placeholder="Search roster or type visitor name" />
          </Field>

          <Field label="Description">
            <textarea rows={3} className="field" placeholder="What happened — facts only" />
          </Field>

          <Field label="Witnesses">
            <input className="field" placeholder="Name, role — add multiple separated by comma" />
          </Field>

          <Section title="Response">
            <label className="flex items-center gap-2 text-xs"><input type="checkbox" checked={firstAid} onChange={(e) => setFirstAid(e.target.checked)} className="accent-emerald-500" /> First aid administered</label>
            {firstAid && <div className="mt-2 grid grid-cols-2 gap-2"><input className="field" placeholder="What was done" /><input className="field" placeholder="By whom" /></div>}
            <label className="mt-3 flex items-center gap-2 text-xs"><input type="checkbox" checked={parentNotified} onChange={(e) => setParentNotified(e.target.checked)} className="accent-emerald-500" /> Parent notified</label>
            {parentNotified && <div className="mt-2 grid grid-cols-2 gap-2"><input type="time" className="field" /><input className="field" placeholder="By whom" /></div>}
            <label className="mt-3 flex items-center gap-2 text-xs"><input type="checkbox" className="accent-emerald-500" /> Ambulance called</label>
          </Section>

          <Field label="Photos (up to 5)">
            <button className="inline-flex w-full items-center justify-center gap-1.5 rounded-md border border-dashed border-border bg-muted/30 px-3 py-3 text-xs text-muted-foreground hover:bg-accent">
              <Upload className="h-3.5 w-3.5" /> Drop or click to upload
            </button>
          </Field>

          <Field label="Severity">
            <div className="grid grid-cols-4 gap-1">
              {(["LOW", "MEDIUM", "HIGH", "CRITICAL"] as Severity[]).map(s => (
                <button key={s} disabled={isMedEmergency && s !== "CRITICAL"} className={`rounded-md border px-2 py-1.5 text-[11px] font-medium ${s === "CRITICAL" ? "border-red-500/30 text-red-400" : s === "HIGH" ? "border-red-500/20 text-red-400" : s === "MEDIUM" ? "border-amber-500/30 text-amber-400" : "border-border text-muted-foreground"} hover:bg-accent disabled:opacity-40`}>{s}</button>
              ))}
            </div>
          </Field>

          <div className="flex justify-end gap-2">
            <button onClick={onClose} className="rounded-md border border-border px-3 py-1.5">Cancel</button>
            <button className="rounded-md bg-gradient-to-r from-teal-500 to-emerald-500 px-3 py-1.5 font-medium text-white">File incident</button>
          </div>
        </div>

        <FieldStyles />
      </aside>
    </>
  );
}

/* ============================================================
   CONCUSSION PROTOCOL
   ============================================================ */

type ProtoStep = {
  n: number; title: string; required?: string; complete: boolean;
  completedBy?: string; completedAt?: string; needsUpload?: boolean; needsAdminApproval?: boolean;
};

const PROTO_STEPS: ProtoStep[] = [
  { n: 1, title: "Removal from Play", required: "Symptom checklist + time removed", complete: true, completedBy: "Coach R. Bell", completedAt: "2026-06-24 19:48" },
  { n: 2, title: "Parent Notification", required: "Time & method confirmed", complete: true, completedBy: "Coach R. Bell", completedAt: "2026-06-24 19:52" },
  { n: 3, title: "Medical Evaluation", required: "Provider, clinic, evaluation document", complete: true, completedBy: "Parent S. Carter", completedAt: "2026-06-25 14:10", needsUpload: true, needsAdminApproval: true },
  { n: 4, title: "RTP 1 — Complete Rest", required: "24h symptom-free", complete: true, completedBy: "Coach R. Bell", completedAt: "2026-06-26 09:00" },
  { n: 5, title: "RTP 2 — Light Aerobic", required: "Coach confirms symptom-free", complete: false },
  { n: 6, title: "RTP 3 — Sport-Specific (skating, no contact)", required: "Coach confirms symptom-free", complete: false },
  { n: 7, title: "RTP 4 — Non-Contact Training", required: "Coach confirms symptom-free", complete: false },
  { n: 8, title: "RTP 5 — Full Contact Practice", required: "Written medical clearance + admin approval", complete: false, needsUpload: true, needsAdminApproval: true },
  { n: 9, title: "Return to Competition", required: "Association admin final sign-off", complete: false, needsAdminApproval: true },
];

function ConcussionProtocol({ inc, onClose }: { inc: Incident; onClose: () => void }) {
  return (
    <>
      <div onClick={onClose} className="fixed inset-0 z-40 bg-black/50" />
      <aside className="fixed right-0 top-0 z-50 h-full w-full max-w-3xl overflow-y-auto border-l border-border bg-background shadow-2xl">
        <div className="sticky top-0 z-10 flex items-center justify-between border-b border-purple-500/30 bg-gradient-to-r from-purple-500/10 to-background px-5 py-3">
          <div className="flex items-center gap-2">
            <Brain className="h-4 w-4 text-purple-400" />
            <h3 className="text-sm font-semibold text-purple-300">Concussion Protocol</h3>
            <span className="font-mono text-xs text-muted-foreground">{inc.caseNo}</span>
          </div>
          <button onClick={onClose} className="rounded p-1 hover:bg-accent"><X className="h-4 w-4" /></button>
        </div>

        <div className="border-b border-border p-5">
          <div className="flex items-start gap-3">
            <div className="flex h-12 w-12 items-center justify-center rounded-full bg-gradient-to-br from-purple-500 to-pink-500 text-sm font-semibold text-white">EC</div>
            <div className="flex-1">
              <div className="text-base font-semibold">{inc.person}</div>
              <div className="text-xs text-muted-foreground">{inc.team} · injury {inc.date}</div>
              <div className="mt-2 flex flex-wrap gap-1.5">
                <Pill tone="danger">PROTOCOL ACTIVE</Pill>
                <Pill tone="info">Locked from lineups</Pill>
                <Pill tone="muted">Parent auto-notified at each step</Pill>
              </div>
            </div>
          </div>
        </div>

        <ol className="relative space-y-3 p-5">
          {PROTO_STEPS.map((s, i) => {
            const prevDone = i === 0 || PROTO_STEPS[i - 1].complete;
            const locked = !s.complete && !prevDone;
            return (
              <li key={s.n} className={`relative rounded-lg border p-4 ${s.complete ? "border-emerald-500/30 bg-emerald-500/5" : locked ? "border-border bg-muted/20 opacity-60" : "border-amber-500/40 bg-amber-500/5"}`}>
                <div className="flex items-start gap-3">
                  <div className={`flex h-7 w-7 shrink-0 items-center justify-center rounded-full text-xs font-semibold ${s.complete ? "bg-emerald-500 text-white" : locked ? "bg-muted text-muted-foreground" : "bg-amber-500 text-white"}`}>
                    {s.complete ? <CheckCircle2 className="h-4 w-4" /> : s.n}
                  </div>
                  <div className="min-w-0 flex-1">
                    <div className="flex flex-wrap items-center gap-2">
                      <h4 className="text-sm font-semibold">{s.title}</h4>
                      {s.needsUpload && <Pill tone="info">Document required</Pill>}
                      {s.needsAdminApproval && <Pill tone="warn">Admin approval</Pill>}
                    </div>
                    {s.required && <p className="mt-1 text-[11px] text-muted-foreground">{s.required}</p>}
                    {s.complete ? (
                      <div className="mt-2 text-[11px] text-emerald-400">✓ {s.completedBy} · {s.completedAt}</div>
                    ) : !locked ? (
                      <div className="mt-2 flex flex-wrap gap-2">
                        {s.needsUpload && (
                          <button className="inline-flex items-center gap-1.5 rounded border border-border bg-background px-2 py-1 text-[11px] hover:bg-accent">
                            <Upload className="h-3 w-3" /> Upload document
                          </button>
                        )}
                        <button className="rounded bg-gradient-to-r from-teal-500 to-emerald-500 px-2 py-1 text-[11px] font-medium text-white">Mark complete</button>
                      </div>
                    ) : (
                      <div className="mt-2 text-[11px] text-muted-foreground"><Lock className="mr-1 inline h-3 w-3" />Unlocks after previous step</div>
                    )}
                  </div>
                </div>
              </li>
            );
          })}
        </ol>

        <div className="border-t border-border bg-muted/20 p-4 text-[11px] text-muted-foreground">
          <Clock className="mr-1 inline h-3 w-3" />
          If no step update for 7 days, an amber alert is sent to the association admin. Full timeline is archived permanently on the athlete profile.
        </div>
      </aside>
    </>
  );
}

/* ============================================================
   SAFE SPORT VIEW
   ============================================================ */

function SafeSportView({ role }: { role: SafetyRole }) {
  const [selected, setSelected] = useState<SafeSportReport | null>(null);
  const [showFile, setShowFile] = useState(false);
  const [showLink, setShowLink] = useState(false);

  return (
    <div className="space-y-4">
      <div className="overflow-hidden rounded-lg border border-red-500/30 bg-gradient-to-r from-red-950/40 via-background to-background">
        <div className="flex items-center justify-between border-b border-red-500/30 bg-red-950/30 px-4 py-2 text-xs">
          <div className="flex items-center gap-2 text-red-300">
            <Lock className="h-3.5 w-3.5" />
            <span className="font-semibold tracking-wider">CONFIDENTIAL · SAFE SPORT</span>
          </div>
          <span className="text-[10px] uppercase text-muted-foreground">Viewing as {role === "president" ? "President" : "Safe Sport Officer"} · all access logged</span>
        </div>
        <div className="flex flex-wrap items-center justify-between gap-3 p-4">
          <div className="text-xs text-muted-foreground max-w-xl">
            Reports in this area are visible only to the Association President and Safe Sport Officer. They cannot be deleted by any user. Every view is recorded in the report's audit trail.
          </div>
          <div className="flex items-center gap-2">
            <button onClick={() => setShowLink(true)} className="inline-flex h-8 items-center gap-1.5 rounded-md border border-border bg-background px-3 text-xs hover:bg-accent">
              <LinkIcon className="h-3.5 w-3.5" /> Public report link
            </button>
            <button onClick={() => setShowFile(true)} className="inline-flex h-8 items-center gap-1.5 rounded-md bg-red-500 px-3 text-xs font-medium text-white hover:bg-red-600">
              <Plus className="h-3.5 w-3.5" /> File Safe Sport report
            </button>
          </div>
        </div>
      </div>

      <div className="overflow-hidden rounded-lg border border-border">
        <table className="w-full text-sm">
          <thead className="bg-muted/40 text-xs uppercase text-muted-foreground">
            <tr>
              <th className="px-3 py-2 text-left">Case #</th>
              <th className="px-3 py-2 text-left">Date</th>
              <th className="px-3 py-2 text-left">Category</th>
              <th className="px-3 py-2 text-left">Reporter</th>
              <th className="px-3 py-2 text-left">Person reported</th>
              <th className="px-3 py-2 text-left">Status</th>
            </tr>
          </thead>
          <tbody>
            {SS_REPORTS.map((r) => (
              <tr key={r.caseNo} onClick={() => setSelected(r)} className="cursor-pointer border-t border-border hover:bg-accent/40">
                <td className="px-3 py-2 font-mono text-xs">{r.caseNo}</td>
                <td className="px-3 py-2 text-xs">{r.date}</td>
                <td className="px-3 py-2 text-xs">
                  <div className="flex flex-wrap gap-1">{r.categories.map(c => <Pill key={c} tone="danger">{c}</Pill>)}</div>
                </td>
                <td className="px-3 py-2 text-xs">{r.reporter.anonymous ? <span className="italic text-muted-foreground">Anonymous</span> : r.reporter.name}</td>
                <td className="px-3 py-2 text-xs font-medium">{r.reported.name} <span className="text-muted-foreground">({r.reported.role})</span></td>
                <td className="px-3 py-2"><Pill tone={r.status === "CLOSED" ? "muted" : r.status === "REFERRED TO AUTHORITIES" ? "bad" : r.status === "UNDER REVIEW" ? "info" : "warn"}>{r.status}</Pill></td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {selected && <SafeSportPanel rep={selected} onClose={() => setSelected(null)} viewerRole={role} />}
      {showFile && <SafeSportFileDrawer onClose={() => setShowFile(false)} />}
      {showLink && <PublicLinkDialog onClose={() => setShowLink(false)} />}
    </div>
  );
}

function SafeSportPanel({ rep, onClose, viewerRole }: { rep: SafeSportReport; onClose: () => void; viewerRole: SafetyRole }) {
  const [tab, setTab] = useState<"report" | "timeline" | "audit">("report");
  const mandatoryFlag = rep.involvesMinor && (rep.categories.includes("Physical Abuse") || rep.categories.includes("Sexual Abuse"));

  return (
    <>
      <div onClick={onClose} className="fixed inset-0 z-40 bg-black/60" />
      <aside className="fixed right-0 top-0 z-50 h-full w-full max-w-2xl overflow-y-auto border-l border-red-500/40 bg-background shadow-2xl">
        <div className="sticky top-0 z-10 flex items-center justify-between border-b border-red-500/30 bg-red-950/30 px-5 py-3">
          <div className="flex items-center gap-2">
            <Lock className="h-3.5 w-3.5 text-red-300" />
            <h3 className="text-sm font-semibold text-red-200">Safe Sport · {rep.caseNo}</h3>
          </div>
          <button onClick={onClose} className="rounded p-1 hover:bg-accent"><X className="h-4 w-4" /></button>
        </div>

        {mandatoryFlag && (
          <div className="border-b border-amber-500/40 bg-amber-500/10 p-4 text-xs text-amber-200">
            <div className="mb-1 flex items-center gap-1.5 font-semibold"><AlertTriangle className="h-3.5 w-3.5" /> Mandatory reporting flag</div>
            This report involves a minor and allegations of physical or sexual abuse. It may require mandatory reporting to child protective services or law enforcement. Consult your Safe Sport policy and legal counsel before proceeding. <strong>The system does not make the legal determination — it flags the obligation only.</strong>
          </div>
        )}

        <div className="border-b border-border px-5">
          <div className="flex gap-1">
            {(["report", "timeline", "audit"] as const).map((t) => (
              <button key={t} onClick={() => setTab(t)} className={`border-b-2 px-3 py-2.5 text-xs font-medium capitalize ${tab === t ? "border-red-500 text-foreground" : "border-transparent text-muted-foreground hover:text-foreground"}`}>
                {t === "audit" ? "Audit trail" : t}
              </button>
            ))}
          </div>
        </div>

        <div className="space-y-4 p-5">
          {tab === "report" && (
            <>
              <Section title="Report">
                <Row label="Filed">{rep.date}</Row>
                <Row label="Reporter">{rep.reporter.anonymous ? "Anonymous" : `${rep.reporter.name} · ${rep.reporter.contact}`}</Row>
                <Row label="Person reported">{rep.reported.name} ({rep.reported.role})</Row>
                <Row label="Categories"><div className="flex flex-wrap justify-end gap-1">{rep.categories.map(c => <Pill key={c} tone="danger">{c}</Pill>)}</div></Row>
                <Row label="Involves minor">{rep.involvesMinor ? "Yes" : "No"}</Row>
                <Row label="Attachments">{rep.attachments} file(s)</Row>
              </Section>
              <Section title="Description">
                <p className="text-xs leading-relaxed whitespace-pre-wrap">{rep.description}</p>
              </Section>
              <Section title="Witnesses">
                <p className="text-xs">{rep.witnesses || "—"}</p>
              </Section>
              <Section title="Investigation">
                <Row label="Status"><Pill tone={rep.status === "CLOSED" ? "muted" : rep.status === "REFERRED TO AUTHORITIES" ? "bad" : rep.status === "UNDER REVIEW" ? "info" : "warn"}>{rep.status}</Pill></Row>
                <Row label="Assigned investigator">{rep.investigator ?? "Unassigned"}</Row>
                <div className="mt-3 flex flex-wrap gap-2">
                  <select className="field flex-1"><option>NEW</option><option>UNDER REVIEW</option><option>REFERRED TO AUTHORITIES</option><option>CLOSED</option></select>
                  <button className="rounded-md bg-red-500 px-3 py-1.5 text-xs font-medium text-white">Update</button>
                </div>
              </Section>
              <Section title="Internal notes">
                <ul className="space-y-2 text-xs">
                  {rep.notes.map((n, i) => <li key={i} className="rounded border border-border bg-muted/30 p-2"><div className="text-[10px] text-muted-foreground">{n.ts} · {n.by}</div><div>{n.text}</div></li>)}
                  {rep.notes.length === 0 && <li className="text-muted-foreground">No notes yet.</li>}
                </ul>
                <textarea rows={2} className="field mt-2" placeholder="Add note (visible only to President & Safe Sport Officer)…" />
              </Section>
              <Section title="Appeal / response from subject">
                {rep.appeal ? (
                  <div className="rounded border border-border bg-muted/30 p-2 text-xs"><div className="text-[10px] text-muted-foreground">{rep.appeal.ts} · {rep.appeal.by}</div>{rep.appeal.text}</div>
                ) : (
                  <p className="text-xs text-muted-foreground">No formal response filed. The subject of the report may submit a response via a separate form; both sides are documented in the case file.</p>
                )}
              </Section>
              <FieldStyles />
            </>
          )}
          {tab === "timeline" && (
            <ol className="space-y-2">
              {rep.timeline.map((t, i) => (
                <li key={i} className="rounded-lg border border-border bg-muted/20 p-3 text-xs">
                  <div className="text-[10px] text-muted-foreground">{t.ts}</div>
                  <div className="font-medium">{t.event}</div>
                  <div className="text-muted-foreground">{t.by}</div>
                </li>
              ))}
            </ol>
          )}
          {tab === "audit" && (
            <Section title="Access log (immutable)">
              <ul className="space-y-1 text-xs">
                {rep.views.map((v, i) => (
                  <li key={i} className="flex items-center justify-between border-b border-border/60 py-1.5 last:border-0">
                    <span className="flex items-center gap-1.5"><Eye className="h-3 w-3 text-muted-foreground" />{v.by}</span>
                    <span className="font-mono text-[10px] text-muted-foreground">{v.ts}</span>
                  </li>
                ))}
                <li className="flex items-center justify-between py-1.5 text-emerald-400">
                  <span className="flex items-center gap-1.5"><Eye className="h-3 w-3" />You ({viewerRole === "president" ? "President" : "Safe Sport Officer"})</span>
                  <span className="font-mono text-[10px]">just now</span>
                </li>
              </ul>
              <p className="mt-3 text-[10px] text-muted-foreground">Reports cannot be deleted by any user, including admin. All views are recorded automatically.</p>
            </Section>
          )}
        </div>
      </aside>
    </>
  );
}

function SafeSportFileDrawer({ onClose }: { onClose: () => void }) {
  const [anon, setAnon] = useState(false);
  const cats: SSCategory[] = ["Physical Abuse", "Emotional Abuse", "Sexual Abuse", "Bullying", "Hazing", "Discrimination", "Grooming"];
  const [picked, setPicked] = useState<Set<SSCategory>>(new Set());
  const toggle = (c: SSCategory) => setPicked(p => { const n = new Set(p); n.has(c) ? n.delete(c) : n.add(c); return n; });

  return (
    <>
      <div onClick={onClose} className="fixed inset-0 z-40 bg-black/60" />
      <aside className="fixed right-0 top-0 z-50 h-full w-full max-w-xl overflow-y-auto border-l border-red-500/40 bg-background shadow-2xl">
        <div className="sticky top-0 z-10 flex items-center justify-between border-b border-red-500/30 bg-red-950/30 px-5 py-3">
          <div className="flex items-center gap-2"><Lock className="h-3.5 w-3.5 text-red-300" /><h3 className="text-sm font-semibold text-red-200">File Safe Sport report</h3></div>
          <button onClick={onClose} className="rounded p-1 hover:bg-accent"><X className="h-4 w-4" /></button>
        </div>

        <div className="space-y-4 p-5 text-xs">
          <div className="rounded-lg border border-red-500/30 bg-red-500/5 p-3 text-[11px] text-red-200">
            On submit, this report is sent immediately via push + email to the Safe Sport Officer and Association President only. A case number is assigned and returned to the reporter for follow-up — even if submitted anonymously.
          </div>

          <Section title="Reporter">
            <label className="flex items-center gap-2 text-xs"><input type="checkbox" checked={anon} onChange={(e) => setAnon(e.target.checked)} className="accent-red-500" /> Submit anonymously</label>
            {!anon && (
              <div className="mt-3 grid grid-cols-2 gap-2">
                <input className="field" placeholder="Your name" />
                <input className="field" placeholder="Email or phone" />
              </div>
            )}
          </Section>

          <Section title="Person being reported">
            <div className="grid grid-cols-2 gap-2">
              <input className="field" placeholder="Name" />
              <select className="field"><option>Coach</option><option>Player</option><option>Volunteer</option><option>Parent</option><option>Official</option></select>
            </div>
          </Section>

          <Field label="Category (multi-select)">
            <div className="flex flex-wrap gap-1">
              {cats.map(c => (
                <button key={c} onClick={() => toggle(c)} className={`rounded-md border px-2 py-1 text-[11px] ${picked.has(c) ? "border-red-500 bg-red-500/20 text-red-300" : "border-border bg-background"}`}>{c}</button>
              ))}
            </div>
          </Field>

          <Field label="Date(s) of incident(s)"><input className="field" placeholder="e.g. May 12 2026, May 18 2026" /></Field>
          <Field label="Detailed description"><textarea rows={5} className="field" placeholder="Be as specific as possible — what, when, where, who was present." /></Field>
          <Field label="Witnesses (optional)"><input className="field" placeholder="Names or descriptions" /></Field>
          <Field label="Supporting documents or photos (optional)">
            <button className="inline-flex w-full items-center justify-center gap-1.5 rounded-md border border-dashed border-border bg-muted/30 px-3 py-3 text-xs text-muted-foreground hover:bg-accent">
              <Upload className="h-3.5 w-3.5" /> Drop or click to upload
            </button>
          </Field>

          <div className="flex justify-end gap-2">
            <button onClick={onClose} className="rounded-md border border-border px-3 py-1.5">Cancel</button>
            <button className="rounded-md bg-red-500 px-3 py-1.5 font-medium text-white">Submit report</button>
          </div>

          <FieldStyles />
        </div>
      </aside>
    </>
  );
}

function PublicLinkDialog({ onClose }: { onClose: () => void }) {
  const url = "https://safe.pxfhockey.app/report/wpg-river-east";
  return (
    <>
      <div onClick={onClose} className="fixed inset-0 z-50 bg-black/60" />
      <div className="fixed left-1/2 top-1/2 z-50 w-[min(28rem,calc(100vw-2rem))] -translate-x-1/2 -translate-y-1/2 rounded-lg border border-border bg-background p-5 shadow-2xl">
        <div className="mb-3 flex items-center justify-between">
          <h3 className="text-sm font-semibold">Public Safe Sport reporting link</h3>
          <button onClick={onClose} className="rounded p-1 hover:bg-accent"><X className="h-4 w-4" /></button>
        </div>
        <p className="mb-3 text-xs text-muted-foreground">Share this URL on your website or with members. Anyone can submit a report — anonymously or with contact info — without logging in.</p>
        <div className="flex items-center gap-2 rounded-md border border-border bg-muted/30 px-3 py-2">
          <ListChecks className="h-3.5 w-3.5 text-muted-foreground" />
          <span className="flex-1 truncate font-mono text-xs">{url}</span>
          <button className="inline-flex items-center gap-1 rounded border border-border bg-background px-2 py-1 text-[11px] hover:bg-accent"><Copy className="h-3 w-3" /> Copy</button>
        </div>
      </div>
    </>
  );
}

function Field({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <label className="block">
      <span className="mb-1 block text-[10px] font-medium uppercase tracking-wide text-muted-foreground">{label}</span>
      {children}
    </label>
  );
}

function FieldStyles() {
  return <style>{`.field { width:100%; min-height:32px; border:1px solid hsl(var(--border)); background:hsl(var(--background)); border-radius:6px; padding:6px 8px; font-size:12px; } textarea.field { padding:6px 8px; }`}</style>;
}
