import { useMemo, useState } from "react";
import { ChevronDown, ArrowUpRight, Mail, Download } from "lucide-react";

// ───────────────────── types & demo data ─────────────────────
type TxStatus = "PAID" | "PENDING" | "OVERDUE" | "REFUNDED";
type Tx = { id: string; date: string; athlete: string; type: string; amount: number; status: TxStatus };

const TRANSACTIONS: Tx[] = [
  { id: "t1", date: "Jul 3", athlete: "Jake Andersson", type: "Private Session", amount: 120, status: "PAID" },
  { id: "t2", date: "Jul 2", athlete: "Priya Singh", type: "Camp Registration", amount: 450, status: "PAID" },
  { id: "t3", date: "Jul 1", athlete: "Mason Lévesque", type: "Private Session", amount: 120, status: "OVERDUE" },
  { id: "t4", date: "Jun 30", athlete: "Eli Tanaka", type: "Camp Registration", amount: 450, status: "PAID" },
  { id: "t5", date: "Jun 28", athlete: "Aiden Park", type: "Camp Registration", amount: 450, status: "PENDING" },
  { id: "t6", date: "Jun 25", athlete: "Sofia Chen", type: "Private Session", amount: 120, status: "PAID" },
];

type Outstanding = { id: string; athlete: string; amount: number; due: string; urgent: boolean };
const OUTSTANDING: Outstanding[] = [
  { id: "o1", athlete: "Mason Lévesque", amount: 120, due: "3 days overdue", urgent: true },
  { id: "o2", athlete: "Aiden Park", amount: 450, due: "Due today", urgent: false },
  { id: "o3", athlete: "Connor Walsh", amount: 120, due: "Due Jul 8", urgent: false },
  { id: "o4", athlete: "Emma Johansson", amount: 450, due: "7 days overdue", urgent: true },
];

const REVENUE_TREND = [
  { m: "Feb", v: 3200 }, { m: "Mar", v: 4100 }, { m: "Apr", v: 5800 },
  { m: "May", v: 6200 }, { m: "Jun", v: 7900 }, { m: "Jul", v: 8437 },
];

const RANGES = ["This Week", "This Month", "Last Month", "This Season", "Custom Range"] as const;
type Range = typeof RANGES[number];

const TABS = ["Overview", "Profitability", "Payments", "Insights"] as const;
type Tab = typeof TABS[number];

const fmt = (n: number) => `$${n.toLocaleString("en-US")}`;

// ───────────────────── main ─────────────────────
export function AssociationFinancials() {
  const [tab, setTab] = useState<Tab>("Overview");
  const [range, setRange] = useState<Range>("This Month");
  const [rangeOpen, setRangeOpen] = useState(false);

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between gap-4 flex-wrap">
        <h1 className="text-2xl font-semibold tracking-tight">Financials</h1>
        <div className="relative">
          <button
            onClick={() => setRangeOpen(o => !o)}
            className="flex items-center gap-2 rounded-full border border-border bg-card px-4 py-2 text-sm font-medium hover:bg-muted transition"
          >
            {range}
            <ChevronDown className="h-4 w-4 text-muted-foreground" />
          </button>
          {rangeOpen && (
            <>
              <div className="fixed inset-0 z-10" onClick={() => setRangeOpen(false)} />
              <div className="absolute right-0 mt-2 w-48 rounded-lg border border-border bg-card shadow-xl z-20 py-1">
                {RANGES.map(r => (
                  <button
                    key={r}
                    onClick={() => { setRange(r); setRangeOpen(false); }}
                    className={`w-full text-left px-3 py-2 text-sm hover:bg-muted transition ${range === r ? "text-teal-400" : ""}`}
                  >{r}</button>
                ))}
              </div>
            </>
          )}
        </div>
      </div>

      {/* Tabs */}
      <div className="flex items-center gap-1 border-b border-border">
        {TABS.map(t => (
          <button
            key={t}
            onClick={() => setTab(t)}
            className={`px-4 py-2.5 text-sm font-medium transition border-b-2 -mb-px ${
              tab === t ? "border-teal-400 text-foreground" : "border-transparent text-muted-foreground hover:text-foreground"
            }`}
          >{t}</button>
        ))}
      </div>

      {tab === "Overview" ? <Overview /> : tab === "Profitability" ? <Profitability /> : tab === "Payments" ? <Payments /> : <Insights />}
    </div>
  );
}

// ───────────────────── overview ─────────────────────
function Overview() {
  return (
    <div className="space-y-6">
      {/* KPI cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <MetricCard
          label="Total Revenue"
          value={fmt(8437)}
          trend={{ text: "+12.4% vs last month", up: true, tone: "teal" }}
        />
        <MetricCard
          label="Pending"
          value={fmt(2688)}
          sub="8 outstanding"
          tone="amber"
        />
        <MetricCard
          label="Ice Costs"
          value={fmt(1200)}
          sub="6 slots"
          tone="muted"
        />
        <MetricCard
          label="Net Profit"
          value={fmt(5914)}
          sub="42% margin"
          tone="teal"
        />
      </div>

      {/* Revenue trend */}
      <div className="rounded-xl border border-border bg-card p-5">
        <p className="text-xs font-semibold uppercase tracking-wider text-muted-foreground mb-4">
          Revenue · Last 6 Months
        </p>
        <RevenueBarChart data={REVENUE_TREND} />
      </div>

      {/* Two columns */}
      <div className="grid grid-cols-1 lg:grid-cols-5 gap-4">
        <RecentTransactions />
        <OutstandingList />
      </div>
    </div>
  );
}

// ───────────────────── metric card ─────────────────────
function MetricCard({
  label, value, sub, trend, tone,
}: {
  label: string;
  value: string;
  sub?: string;
  trend?: { text: string; up: boolean; tone: "teal" };
  tone?: "teal" | "amber" | "muted";
}) {
  const subColor =
    tone === "amber" ? "text-amber-400" :
    tone === "teal" ? "text-teal-400" :
    "text-muted-foreground";

  return (
    <div className="relative rounded-xl border border-border bg-card p-5 overflow-hidden">
      <span className="absolute left-0 top-0 bottom-0 w-[2px] bg-teal-400" />
      <p className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">{label}</p>
      <p className="mt-3 text-3xl font-bold tracking-tight">{value}</p>
      {trend ? (
        <p className={`mt-2 flex items-center gap-1 text-xs font-medium ${trend.tone === "teal" ? "text-teal-400" : ""}`}>
          <ArrowUpRight className="h-3.5 w-3.5" />
          {trend.text}
        </p>
      ) : sub ? (
        <p className={`mt-2 text-xs font-medium ${subColor}`}>{sub}</p>
      ) : null}
    </div>
  );
}

// ───────────────────── bar chart ─────────────────────
function RevenueBarChart({ data }: { data: { m: string; v: number }[] }) {
  const [hover, setHover] = useState<number | null>(null);
  const max = Math.max(...data.map(d => d.v));

  return (
    <div>
      <div className="flex items-end gap-3 h-56 pl-8 relative">
        {/* y-axis grid */}
        <div className="absolute inset-y-0 left-0 w-8 flex flex-col justify-between text-[10px] text-muted-foreground pr-2 text-right">
          <span>{fmt(Math.ceil(max / 1000) * 1000)}</span>
          <span>{fmt(Math.ceil(max / 2 / 1000) * 1000)}</span>
          <span>$0</span>
        </div>
        {data.map((d, i) => {
          const h = (d.v / max) * 100;
          const active = hover === i;
          return (
            <div
              key={d.m}
              className="flex-1 h-full flex flex-col justify-end relative group"
              onMouseEnter={() => setHover(i)}
              onMouseLeave={() => setHover(null)}
            >
              {active && (
                <div className="absolute -top-1 left-1/2 -translate-x-1/2 -translate-y-full whitespace-nowrap rounded-md border border-border bg-background px-2 py-1 text-xs shadow-lg z-10">
                  <span className="font-semibold">{fmt(d.v)}</span>
                  <span className="text-muted-foreground ml-1.5">{d.m}</span>
                </div>
              )}
              <div
                className="w-full rounded-t-md bg-gradient-to-t from-teal-500/40 via-teal-400/70 to-teal-300 transition-opacity"
                style={{ height: `${h}%`, opacity: hover === null || active ? 1 : 0.5 }}
              />
            </div>
          );
        })}
      </div>
      <div className="flex gap-3 pl-8 mt-2">
        {data.map(d => (
          <div key={d.m} className="flex-1 text-center text-xs text-muted-foreground">{d.m}</div>
        ))}
      </div>
    </div>
  );
}

// ───────────────────── transactions ─────────────────────
function RecentTransactions() {
  return (
    <div className="lg:col-span-3 rounded-xl border border-border bg-card p-5">
      <div className="flex items-center justify-between mb-4">
        <p className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">Recent Transactions</p>
        <button className="text-xs text-teal-400 hover:text-teal-300 transition">View all →</button>
      </div>
      <div className="overflow-x-auto">
        <table className="w-full text-sm">
          <thead>
            <tr className="text-[10px] uppercase tracking-wider text-muted-foreground border-b border-border">
              <th className="text-left font-semibold py-2 pr-3">Date</th>
              <th className="text-left font-semibold py-2 pr-3">Athlete</th>
              <th className="text-left font-semibold py-2 pr-3">Type</th>
              <th className="text-right font-semibold py-2 pr-3">Amount</th>
              <th className="text-right font-semibold py-2">Status</th>
            </tr>
          </thead>
          <tbody>
            {TRANSACTIONS.map(t => (
              <tr key={t.id} className="border-b border-border/50 last:border-0">
                <td className="py-3 pr-3 text-muted-foreground">{t.date}</td>
                <td className="py-3 pr-3 font-medium">{t.athlete}</td>
                <td className="py-3 pr-3 text-muted-foreground">{t.type}</td>
                <td className="py-3 pr-3 text-right font-medium tabular-nums">{fmt(t.amount)}</td>
                <td className="py-3 text-right"><StatusBadge status={t.status} /></td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}

function StatusBadge({ status }: { status: TxStatus }) {
  const styles: Record<TxStatus, string> = {
    PAID: "bg-teal-500/15 text-teal-400 border-teal-500/30",
    PENDING: "bg-amber-500/15 text-amber-400 border-amber-500/30",
    OVERDUE: "bg-red-500/15 text-red-400 border-red-500/30",
    REFUNDED: "bg-muted text-muted-foreground border-border",
  };
  return (
    <span className={`inline-block rounded-full border px-2 py-0.5 text-[10px] font-semibold uppercase tracking-wider ${styles[status]}`}>
      {status}
    </span>
  );
}

// ───────────────────── outstanding ─────────────────────
function OutstandingList() {
  const total = useMemo(() => OUTSTANDING.reduce((s, o) => s + o.amount, 0), []);

  return (
    <div className="lg:col-span-2 rounded-xl border border-border bg-card p-5 flex flex-col">
      <p className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">Outstanding</p>
      <p className="mt-1 text-xs text-muted-foreground">8 payments · {fmt(2688)} total</p>

      <div className="mt-4 space-y-2 flex-1">
        {OUTSTANDING.map(o => (
          <div key={o.id} className="flex items-center justify-between gap-3 rounded-lg border border-border p-3 hover:bg-muted/30 transition">
            <div className="min-w-0">
              <p className="text-sm font-semibold truncate">{o.athlete}</p>
              <p className={`text-xs mt-0.5 ${o.urgent ? "text-red-400" : "text-muted-foreground"}`}>
                {o.due}
              </p>
            </div>
            <div className="flex items-center gap-2 flex-shrink-0">
              <span className="text-sm font-semibold text-amber-400 tabular-nums">{fmt(o.amount)}</span>
              <button className="flex items-center gap-1 rounded-full border border-teal-500/40 px-2.5 py-1 text-[11px] font-medium text-teal-400 hover:bg-teal-500/10 transition">
                <Mail className="h-3 w-3" /> Remind
              </button>
            </div>
          </div>
        ))}
      </div>

      <button
        className="mt-4 w-full rounded-lg border border-teal-500/40 py-2.5 text-sm font-medium text-teal-400 hover:bg-teal-500/10 transition"
        onClick={() => {/* stub */}}
      >
        Send reminder to all
      </button>
      <span className="sr-only">Total outstanding {fmt(total)}</span>
    </div>
  );
}

// ───────────────────── coming soon ─────────────────────
function ComingSoon({ title }: { title: string }) {
  return (
    <div className="rounded-xl border border-dashed border-border p-16 text-center">
      <h2 className="text-lg font-semibold">{title}</h2>
      <p className="mt-2 text-sm text-muted-foreground">Coming soon.</p>
    </div>
  );
}

// ───────────────────── profitability ─────────────────────
type Camp = {
  id: string;
  name: string;
  spots: number;
  capacity: number;
  pricePerSpot: number;
  revenue: number;
  iceCost: number;
  staffCost: number;
};

const CAMPS: Camp[] = [
  { id: "c1", name: "Elite Skating Camp", spots: 38, capacity: 40, pricePerSpot: 150, revenue: 5700, iceCost: 800, staffCost: 400 },
  { id: "c2", name: "Goalie Development", spots: 12, capacity: 14, pricePerSpot: 150, revenue: 1800, iceCost: 300, staffCost: 200 },
  { id: "c3", name: "Power Skating Intensive", spots: 24, capacity: 30, pricePerSpot: 150, revenue: 3600, iceCost: 600, staffCost: 300 },
];

function Profitability() {
  const rows = CAMPS.map(c => {
    const net = c.revenue - c.iceCost - c.staffCost;
    const margin = c.revenue > 0 ? net / c.revenue : 0;
    const breakEven = Math.ceil((c.iceCost + c.staffCost) / c.pricePerSpot);
    return { ...c, net, margin, breakEven };
  });

  const totals = rows.reduce(
    (a, r) => ({
      spots: a.spots + r.spots,
      capacity: a.capacity + r.capacity,
      revenue: a.revenue + r.revenue,
      iceCost: a.iceCost + r.iceCost,
      staffCost: a.staffCost + r.staffCost,
      net: a.net + r.net,
    }),
    { spots: 0, capacity: 0, revenue: 0, iceCost: 0, staffCost: 0, net: 0 },
  );
  const totalMargin = totals.revenue > 0 ? totals.net / totals.revenue : 0;

  return (
    <div className="rounded-xl border border-border bg-card p-5">
      <p className="text-xs font-semibold uppercase tracking-wider text-muted-foreground mb-4">
        Camps & Programs · Profitability
      </p>
      <div className="overflow-x-auto">
        <table className="w-full text-sm">
          <thead>
            <tr className="text-[10px] uppercase tracking-wider text-muted-foreground border-b border-border">
              <th className="text-left font-semibold py-2 pr-3">Camp</th>
              <th className="text-right font-semibold py-2 pr-3">Spots</th>
              <th className="text-right font-semibold py-2 pr-3">Revenue</th>
              <th className="text-right font-semibold py-2 pr-3">Ice Cost</th>
              <th className="text-right font-semibold py-2 pr-3">Staff Cost</th>
              <th className="text-right font-semibold py-2 pr-3">Net Profit</th>
              <th className="text-right font-semibold py-2">Margin</th>
            </tr>
          </thead>
          <tbody>
            {rows.map(r => {
              const marginColor = r.margin >= 0 ? "text-teal-400" : "text-red-400";
              return (
                <tr key={r.id} className="border-b border-border/50 align-top">
                  <td className="py-3 pr-3">
                    <p className="font-medium">{r.name}</p>
                    <p className="mt-0.5 text-[11px] text-muted-foreground">Break-even at {r.breakEven} spots</p>
                  </td>
                  <td className="py-3 pr-3 text-right tabular-nums text-muted-foreground">{r.spots}/{r.capacity}</td>
                  <td className="py-3 pr-3 text-right font-medium tabular-nums">{fmt(r.revenue)}</td>
                  <td className="py-3 pr-3 text-right tabular-nums text-muted-foreground">{fmt(r.iceCost)}</td>
                  <td className="py-3 pr-3 text-right tabular-nums text-muted-foreground">{fmt(r.staffCost)}</td>
                  <td className={`py-3 pr-3 text-right font-semibold tabular-nums ${marginColor}`}>{fmt(r.net)}</td>
                  <td className={`py-3 text-right font-semibold tabular-nums ${marginColor}`}>{Math.round(r.margin * 100)}%</td>
                </tr>
              );
            })}
          </tbody>
          <tfoot>
            <tr className="font-bold">
              <td className="py-3 pr-3">Total</td>
              <td className="py-3 pr-3 text-right tabular-nums">{totals.spots}/{totals.capacity}</td>
              <td className="py-3 pr-3 text-right tabular-nums">{fmt(totals.revenue)}</td>
              <td className="py-3 pr-3 text-right tabular-nums">{fmt(totals.iceCost)}</td>
              <td className="py-3 pr-3 text-right tabular-nums">{fmt(totals.staffCost)}</td>
              <td className={`py-3 pr-3 text-right tabular-nums ${totalMargin >= 0 ? "text-teal-400" : "text-red-400"}`}>{fmt(totals.net)}</td>
              <td className={`py-3 text-right tabular-nums ${totalMargin >= 0 ? "text-teal-400" : "text-red-400"}`}>{Math.round(totalMargin * 100)}%</td>
            </tr>
          </tfoot>
        </table>
      </div>
    </div>
  );
}

// ───────────────────── payments ─────────────────────
const PAYMENTS: Tx[] = [
  { id: "p1", date: "Jul 3", athlete: "Jake Andersson", type: "Private Session", amount: 120, status: "PAID" },
  { id: "p2", date: "Jul 2", athlete: "Priya Singh", type: "Camp Registration", amount: 450, status: "PAID" },
  { id: "p3", date: "Jul 1", athlete: "Mason Lévesque", type: "Private Session", amount: 120, status: "OVERDUE" },
  { id: "p4", date: "Jun 30", athlete: "Eli Tanaka", type: "Camp Registration", amount: 450, status: "PAID" },
  { id: "p5", date: "Jun 28", athlete: "Aiden Park", type: "Camp Registration", amount: 450, status: "PENDING" },
  { id: "p6", date: "Jun 25", athlete: "Sofia Chen", type: "Private Session", amount: 120, status: "PAID" },
  { id: "p7", date: "Jun 22", athlete: "Connor Walsh", type: "Camp Registration", amount: 450, status: "REFUNDED" },
  { id: "p8", date: "Jun 18", athlete: "Emma Johansson", type: "Private Session", amount: 120, status: "OVERDUE" },
];

const FILTERS: (TxStatus | "All")[] = ["All", "PAID", "PENDING", "OVERDUE", "REFUNDED"];

function Payments() {
  const [filter, setFilter] = useState<TxStatus | "All">("All");
  const filtered = useMemo(() => (filter === "All" ? PAYMENTS : PAYMENTS.filter(t => t.status === filter)), [filter]);

  return (
    <div className="space-y-4">
      {/* Filter chips */}
      <div className="flex flex-wrap items-center gap-2">
        {FILTERS.map(f => {
          const active = filter === f;
          return (
            <button
              key={f}
              onClick={() => setFilter(f)}
              className={`rounded-full px-3 py-1.5 text-xs font-medium transition border ${
                active
                  ? "border-teal-500/50 bg-teal-500/15 text-teal-400"
                  : "border-border bg-card text-muted-foreground hover:text-foreground"
              }`}
            >
              {f === "All" ? f : f.charAt(0) + f.slice(1).toLowerCase()}
            </button>
          );
        })}
      </div>

      <div className="rounded-xl border border-border bg-card p-5">
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="text-[10px] uppercase tracking-wider text-muted-foreground border-b border-border">
                <th className="text-left font-semibold py-2 pr-3">Date</th>
                <th className="text-left font-semibold py-2 pr-3">Athlete</th>
                <th className="text-left font-semibold py-2 pr-3">Type</th>
                <th className="text-right font-semibold py-2 pr-3">Amount</th>
                <th className="text-right font-semibold py-2 pr-3">Status</th>
                <th className="text-right font-semibold py-2">Action</th>
              </tr>
            </thead>
            <tbody>
              {filtered.map(t => (
                <tr key={t.id} className="border-b border-border/50 last:border-0">
                  <td className="py-3 pr-3 text-muted-foreground">{t.date}</td>
                  <td className="py-3 pr-3 font-medium">{t.athlete}</td>
                  <td className="py-3 pr-3 text-muted-foreground">{t.type}</td>
                  <td className="py-3 pr-3 text-right font-medium tabular-nums">{fmt(t.amount)}</td>
                  <td className="py-3 pr-3 text-right"><StatusBadge status={t.status} /></td>
                  <td className="py-3 text-right">
                    {t.status === "PAID" && (
                      <button className="text-xs text-teal-400 hover:text-teal-300 transition">Receipt</button>
                    )}
                    {(t.status === "PENDING" || t.status === "OVERDUE") && (
                      <button className="flex items-center gap-1 ml-auto rounded-full border border-teal-500/40 px-2.5 py-1 text-[11px] font-medium text-teal-400 hover:bg-teal-500/10 transition">
                        <Mail className="h-3 w-3" /> Remind
                      </button>
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      <div className="flex justify-end">
        <button
          className="rounded-lg border border-teal-500/40 px-4 py-2 text-sm font-medium text-teal-400 hover:bg-teal-500/10 transition"
          onClick={() => {/* stub */}}
        >
          Send reminder to all overdue
        </button>
      </div>
    </div>
  );
}

// ───────────────────── insights ─────────────────────
const TOP_ATHLETES = [
  { id: "a1", athlete: "Jake Andersson", spent: 1860, sessions: 14, last: "Jul 3" },
  { id: "a2", athlete: "Priya Singh", spent: 1350, sessions: 8, last: "Jul 2" },
  { id: "a3", athlete: "Eli Tanaka", spent: 900, sessions: 6, last: "Jun 30" },
  { id: "a4", athlete: "Aiden Park", spent: 720, sessions: 5, last: "Jun 28" },
  { id: "a5", athlete: "Sofia Chen", spent: 600, sessions: 4, last: "Jun 25" },
];

const VARIANCE = (current: number, previous: number) => {
  const diff = current - previous;
  const pct = previous > 0 ? Math.round((diff / previous) * 100) : 0;
  return { diff, pct, positive: diff >= 0 };
};

function Insights() {
  const july = VARIANCE(8437, 6200);
  const season = VARIANCE(42100, 31800);

  return (
    <div className="space-y-6">
      {/* Top athletes by spend */}
      <div className="rounded-xl border border-border bg-card p-5">
        <p className="text-xs font-semibold uppercase tracking-wider text-muted-foreground mb-4">
          Top Athletes by Spend
        </p>
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="text-[10px] uppercase tracking-wider text-muted-foreground border-b border-border">
                <th className="text-left font-semibold py-2 pr-3">Athlete</th>
                <th className="text-right font-semibold py-2 pr-3">Total Spent</th>
                <th className="text-right font-semibold py-2 pr-3">Sessions</th>
                <th className="text-right font-semibold py-2">Last Payment</th>
              </tr>
            </thead>
            <tbody>
              {TOP_ATHLETES.map(a => (
                <tr key={a.id} className="border-b border-border/50 last:border-0">
                  <td className="py-3 pr-3 font-medium">{a.athlete}</td>
                  <td className="py-3 pr-3 text-right font-semibold tabular-nums">{fmt(a.spent)}</td>
                  <td className="py-3 pr-3 text-right tabular-nums text-muted-foreground">{a.sessions}</td>
                  <td className="py-3 text-right text-muted-foreground">{a.last}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Year over year */}
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
        <YoYCard label="This July" current={8437} previous={6200} period="Last July" />
        <YoYCard label="This Season" current={42100} previous={31800} period="Last Season" />
      </div>

      {/* Annual summary */}
      <div className="rounded-xl border border-border bg-card p-5">
        <p className="text-xs font-semibold uppercase tracking-wider text-muted-foreground mb-4">Annual Summary</p>
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 mb-4">
          <div>
            <p className="text-xs text-muted-foreground">Total Revenue YTD</p>
            <p className="mt-1 text-xl font-bold tabular-nums">{fmt(42100)}</p>
          </div>
          <div>
            <p className="text-xs text-muted-foreground">Total Ice Costs</p>
            <p className="mt-1 text-xl font-bold tabular-nums">{fmt(6200)}</p>
          </div>
          <div>
            <p className="text-xs text-muted-foreground">Total Staff Costs</p>
            <p className="mt-1 text-xl font-bold tabular-nums">{fmt(4300)}</p>
          </div>
          <div>
            <p className="text-xs text-muted-foreground">Net Profit YTD</p>
            <p className="mt-1 text-xl font-bold text-teal-400 tabular-nums">{fmt(31600)}</p>
          </div>
        </div>
        <div className="flex justify-end">
          <button className="flex items-center gap-2 rounded-lg border border-teal-500/40 px-4 py-2 text-sm font-medium text-teal-400 hover:bg-teal-500/10 transition">
            <Download className="h-4 w-4" /> Download PDF Summary
          </button>
        </div>
      </div>
    </div>
  );
}

function YoYCard({ label, current, previous, period }: { label: string; current: number; previous: number; period: string }) {
  const v = VARIANCE(current, previous);
  return (
    <div className="rounded-xl border border-border bg-card p-5">
      <p className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">{label}</p>
      <p className="mt-3 text-3xl font-bold tracking-tight tabular-nums">{fmt(current)}</p>
      <p className="mt-1 text-sm text-muted-foreground">
        vs {period} <span className="font-medium text-foreground">{fmt(previous)}</span>
      </p>
      <p className={`mt-3 flex items-center gap-1 text-xs font-medium ${v.positive ? "text-teal-400" : "text-red-400"}`}>
        <ArrowUpRight className={`h-3.5 w-3.5 ${v.positive ? "" : "rotate-90"}`} />
        {v.positive ? "+" : ""}{v.pct}%
      </p>
    </div>
  );
}
