import { useMemo, useState } from "react";
import {
  Plus, Search, X, Download, MessageSquare, Calendar, Edit3,
  AlertTriangle, CheckCircle2, ShieldCheck, Users, ClipboardList,
} from "lucide-react";

type Status = "ACTIVE" | "INACTIVE" | "PENDING";
type Division = "AAA" | "AA" | "A" | "B" | "C";

type Team = {
  id: string;
  name: string;
  ageGroup: string;
  division: Division;
  season: string;
  colors: [string, string];
  headCoach: { name: string; initials: string; compliance: "compliant" | "action" | "non-compliant"; cert: string };
  assistants: string[];
  roster: { count: number; registered: number };
  games: number;
  record: { w: number; l: number; ot: number };
  status: Status;
  iceThisWeek: string;
  nextEvent: { date: string; time: string; type: "GAME" | "PRACTICE"; vs?: string; location: string };
};

const TEAMS: Team[] = [
  {
    id: "t1", name: "Northern Lights U15 AAA", ageGroup: "U15", division: "AAA", season: "2025-26",
    colors: ["#0d9488", "#1e293b"],
    headCoach: { name: "Marcus Bell", initials: "MB", compliance: "compliant", cert: "Development 1" },
    assistants: ["Sara Chen", "Jamie Wu"],
    roster: { count: 19, registered: 19 }, games: 22, record: { w: 14, l: 6, ot: 2 },
    status: "ACTIVE", iceThisWeek: "6.5 hrs",
    nextEvent: { date: "Nov 28", time: "7:00 PM", type: "GAME", vs: "Selkirk Wings", location: "MTS Iceplex — Rink B" },
  },
  {
    id: "t2", name: "Northern Lights U13 AA", ageGroup: "U13", division: "AA", season: "2025-26",
    colors: ["#0d9488", "#1e293b"],
    headCoach: { name: "Priya Singh", initials: "PS", compliance: "action", cert: "Trained" },
    assistants: ["Dan Becker"],
    roster: { count: 17, registered: 16 }, games: 18, record: { w: 11, l: 5, ot: 2 },
    status: "ACTIVE", iceThisWeek: "5 hrs",
    nextEvent: { date: "Nov 27", time: "6:15 PM", type: "PRACTICE", location: "Seven Oaks Arena" },
  },
  {
    id: "t3", name: "Northern Lights U18 AAA", ageGroup: "U18", division: "AAA", season: "2025-26",
    colors: ["#0d9488", "#1e293b"],
    headCoach: { name: "Tom Reilly", initials: "TR", compliance: "non-compliant", cert: "Community" },
    assistants: ["Sara Chen"],
    roster: { count: 20, registered: 20 }, games: 24, record: { w: 16, l: 7, ot: 1 },
    status: "ACTIVE", iceThisWeek: "7 hrs",
    nextEvent: { date: "Nov 29", time: "8:30 PM", type: "GAME", vs: "Brandon Wheat Kings", location: "Bell MTS Place" },
  },
  {
    id: "t4", name: "Northern Lights U11 A", ageGroup: "U11", division: "A", season: "2025-26",
    colors: ["#0d9488", "#1e293b"],
    headCoach: { name: "Derek Olson", initials: "DO", compliance: "action", cert: "Intro" },
    assistants: [],
    roster: { count: 14, registered: 12 }, games: 14, record: { w: 7, l: 6, ot: 1 },
    status: "PENDING", iceThisWeek: "3 hrs",
    nextEvent: { date: "Nov 30", time: "10:00 AM", type: "PRACTICE", location: "St. James Civic Centre" },
  },
];

const ROSTER = [
  { name: "Ethan Carter", pos: "C", jersey: 9, status: "Registered", verified: true, health: "On File" },
  { name: "Liam Brooks", pos: "LW", jersey: 17, status: "Registered", verified: true, health: "On File" },
  { name: "Noah Patel", pos: "RW", jersey: 22, status: "Registered", verified: true, health: "On File" },
  { name: "Owen Tremblay", pos: "D", jersey: 4, status: "Registered", verified: true, health: "Missing" },
  { name: "Jaxon Lee", pos: "D", jersey: 7, status: "Pending", verified: false, health: "On File" },
  { name: "Caleb Wright", pos: "G", jersey: 31, status: "Registered", verified: true, health: "On File" },
];

const SCHEDULE = [
  { date: "Nov 18", time: "7:00 PM", side: "Home", opp: "Selkirk Wings", loc: "MTS Iceplex", ref: true, result: "W 4-2" },
  { date: "Nov 22", time: "6:30 PM", side: "Away", opp: "Steinbach Pistons", loc: "Steinbach Arena", ref: true, result: "L 2-3 OT" },
  { date: "Nov 28", time: "7:00 PM", side: "Home", opp: "Selkirk Wings", loc: "MTS Iceplex", ref: false, result: "" },
  { date: "Dec 02", time: "8:15 PM", side: "Away", opp: "Brandon Wheat Kings", loc: "Bell MTS Place", ref: true, result: "" },
];

const ComplianceBadge = ({ c }: { c: "compliant" | "action" | "non-compliant" }) => {
  const m = {
    compliant: { l: "COMPLIANT", c: "bg-emerald-500/15 text-emerald-400 border-emerald-500/30" },
    action: { l: "ACTION REQ", c: "bg-amber-500/15 text-amber-400 border-amber-500/30" },
    "non-compliant": { l: "NON-COMPLIANT", c: "bg-red-500/15 text-red-400 border-red-500/30" },
  }[c];
  return <span className={`inline-flex rounded-md border px-2 py-0.5 text-[10px] font-semibold ${m.c}`}>{m.l}</span>;
};

const StatusBadge = ({ s }: { s: Status }) => {
  const m = {
    ACTIVE: "bg-emerald-500/15 text-emerald-400",
    INACTIVE: "bg-muted text-muted-foreground",
    PENDING: "bg-amber-500/15 text-amber-400",
  }[s];
  return <span className={`rounded px-1.5 py-0.5 text-[10px] font-semibold ${m}`}>{s}</span>;
};

const DivisionBadge = ({ d }: { d: Division }) => (
  <span className="rounded border border-border bg-muted px-1.5 py-0.5 text-[10px] font-semibold">{d}</span>
);

export function AssociationTeams() {
  const [selected, setSelected] = useState<Team | null>(null);
  const [showAdd, setShowAdd] = useState(false);
  const [search, setSearch] = useState("");
  const [age, setAge] = useState("all");
  const [div, setDiv] = useState("all");
  const [season, setSeason] = useState("2025-26");
  const [sortKey, setSortKey] = useState<"name" | "roster" | "record">("name");

  const rows = useMemo(() => {
    let r = TEAMS.filter((t) => {
      if (search && !t.name.toLowerCase().includes(search.toLowerCase())) return false;
      if (age !== "all" && t.ageGroup !== age) return false;
      if (div !== "all" && t.division !== div) return false;
      if (season !== t.season) return false;
      return true;
    });
    if (sortKey === "name") r = [...r].sort((a, b) => a.name.localeCompare(b.name));
    if (sortKey === "roster") r = [...r].sort((a, b) => b.roster.count - a.roster.count);
    if (sortKey === "record") r = [...r].sort((a, b) => b.record.w - a.record.w);
    return r;
  }, [search, age, div, season, sortKey]);

  return (
    <div className="space-y-5">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div className="flex flex-wrap items-center gap-2">
          <div className="relative">
            <Search className="absolute left-2 top-1/2 h-3.5 w-3.5 -translate-y-1/2 text-muted-foreground" />
            <input value={search} onChange={(e) => setSearch(e.target.value)} placeholder="Search team…"
              className="h-8 w-56 rounded-md border border-border bg-background pl-7 pr-2 text-xs" />
          </div>
          <select value={age} onChange={(e) => setAge(e.target.value)} className="h-8 rounded-md border border-border bg-background px-2 text-xs">
            <option value="all">All ages</option>
            {["U9", "U11", "U13", "U15", "U18"].map((a) => <option key={a}>{a}</option>)}
          </select>
          <select value={div} onChange={(e) => setDiv(e.target.value)} className="h-8 rounded-md border border-border bg-background px-2 text-xs">
            <option value="all">All divisions</option>
            {["AAA", "AA", "A", "B", "C"].map((d) => <option key={d}>{d}</option>)}
          </select>
          <select value={season} onChange={(e) => setSeason(e.target.value)} className="h-8 rounded-md border border-border bg-background px-2 text-xs">
            <option>2025-26</option><option>2024-25</option>
          </select>
          <select value={sortKey} onChange={(e) => setSortKey(e.target.value as never)} className="h-8 rounded-md border border-border bg-background px-2 text-xs">
            <option value="name">Sort: Name</option>
            <option value="roster">Sort: Roster size</option>
            <option value="record">Sort: Record</option>
          </select>
        </div>
        <button onClick={() => setShowAdd(true)} className="inline-flex h-8 items-center gap-1.5 rounded-md bg-gradient-to-r from-teal-500 to-emerald-500 px-3 text-xs font-medium text-white hover:opacity-90">
          <Plus className="h-3.5 w-3.5" /> Add Team
        </button>
      </div>

      <div className="overflow-hidden rounded-lg border border-border">
        <table className="w-full text-sm">
          <thead className="bg-muted/40 text-xs uppercase text-muted-foreground">
            <tr>
              <th className="px-3 py-2 text-left">Team Name</th>
              <th className="px-3 py-2 text-left">Age</th>
              <th className="px-3 py-2 text-left">Div</th>
              <th className="px-3 py-2 text-left">Head Coach</th>
              <th className="px-3 py-2 text-left">Roster</th>
              <th className="px-3 py-2 text-left">GP</th>
              <th className="px-3 py-2 text-left">Record</th>
              <th className="px-3 py-2 text-left">Status</th>
              <th className="px-3 py-2 text-left">Compliance</th>
            </tr>
          </thead>
          <tbody>
            {rows.map((t) => (
              <tr key={t.id} onClick={() => setSelected(t)} className="cursor-pointer border-t border-border hover:bg-accent/40">
                <td className="px-3 py-2">
                  <div className="flex items-center gap-2">
                    <div className="flex h-6 overflow-hidden rounded">
                      <span className="w-2" style={{ background: t.colors[0] }} />
                      <span className="w-2" style={{ background: t.colors[1] }} />
                    </div>
                    <span className="font-medium">{t.name}</span>
                  </div>
                </td>
                <td className="px-3 py-2 text-xs">{t.ageGroup}</td>
                <td className="px-3 py-2"><DivisionBadge d={t.division} /></td>
                <td className="px-3 py-2 text-xs">{t.headCoach.name}</td>
                <td className="px-3 py-2 text-xs">{t.roster.count}</td>
                <td className="px-3 py-2 text-xs">{t.games}</td>
                <td className="px-3 py-2 text-xs font-mono">{t.record.w}-{t.record.l}-{t.record.ot}</td>
                <td className="px-3 py-2"><StatusBadge s={t.status} /></td>
                <td className="px-3 py-2"><ComplianceBadge c={t.headCoach.compliance} /></td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {selected && <TeamPanel team={selected} onClose={() => setSelected(null)} />}
      {showAdd && <AddTeamDrawer onClose={() => setShowAdd(false)} />}
    </div>
  );
}

/* -------------------- Detail Panel -------------------- */

type Tab = "overview" | "roster" | "schedule" | "compliance";

function TeamPanel({ team, onClose }: { team: Team; onClose: () => void }) {
  const [tab, setTab] = useState<Tab>("overview");
  const tabs: { id: Tab; label: string; icon: React.ComponentType<{ className?: string }> }[] = [
    { id: "overview", label: "Overview", icon: ClipboardList },
    { id: "roster", label: "Roster", icon: Users },
    { id: "schedule", label: "Schedule", icon: Calendar },
    { id: "compliance", label: "Compliance", icon: ShieldCheck },
  ];

  return (
    <>
      <div onClick={onClose} className="fixed inset-0 z-40 bg-black/50" />
      <aside className="fixed right-0 top-0 z-50 h-full w-full max-w-2xl overflow-y-auto border-l border-border bg-background shadow-2xl">
        <div className="sticky top-0 z-10 border-b border-border bg-background">
          <div className="flex items-center justify-between px-5 py-3">
            <h3 className="text-sm font-semibold">Team details</h3>
            <button onClick={onClose} className="rounded p-1 hover:bg-accent"><X className="h-4 w-4" /></button>
          </div>
        </div>

        <div className="border-b border-border p-5">
          <div className="flex items-start gap-3">
            <div className="flex h-12 overflow-hidden rounded">
              <span className="w-3" style={{ background: team.colors[0] }} />
              <span className="w-3" style={{ background: team.colors[1] }} />
            </div>
            <div className="flex-1">
              <div className="flex flex-wrap items-center gap-2">
                <h2 className="text-lg font-semibold">{team.name}</h2>
                <DivisionBadge d={team.division} />
                <StatusBadge s={team.status} />
              </div>
              <div className="mt-1 text-xs text-muted-foreground">{team.ageGroup} · Season {team.season}</div>
            </div>
          </div>
        </div>

        <div className="border-b border-border px-5">
          <div className="flex gap-1">
            {tabs.map(({ id, label, icon: Icon }) => (
              <button key={id} onClick={() => setTab(id)}
                className={`inline-flex items-center gap-1.5 border-b-2 px-3 py-2 text-xs font-medium transition ${
                  tab === id ? "border-emerald-500 text-foreground" : "border-transparent text-muted-foreground hover:text-foreground"
                }`}>
                <Icon className="h-3.5 w-3.5" /> {label}
              </button>
            ))}
          </div>
        </div>

        <div className="p-5">
          {tab === "overview" && <OverviewTab team={team} />}
          {tab === "roster" && <RosterTab />}
          {tab === "schedule" && <ScheduleTab />}
          {tab === "compliance" && <ComplianceTab team={team} />}
        </div>
      </aside>
    </>
  );
}

function OverviewTab({ team }: { team: Team }) {
  return (
    <div className="space-y-4">
      <div className="grid grid-cols-2 gap-3">
        <Card title="Head Coach">
          <div className="flex items-center justify-between">
            <div>
              <div className="text-sm font-medium">{team.headCoach.name}</div>
              <div className="text-[11px] text-muted-foreground">{team.headCoach.cert}</div>
            </div>
            <ComplianceBadge c={team.headCoach.compliance} />
          </div>
        </Card>
        <Card title="Assistant Coaches">
          {team.assistants.length === 0 ? (
            <div className="text-xs text-muted-foreground">—</div>
          ) : (
            <ul className="text-xs">{team.assistants.map((a) => <li key={a}>{a}</li>)}</ul>
          )}
        </Card>
        <Card title="Next Event">
          <div className="text-xs">
            <div className="font-medium">{team.nextEvent.type} · {team.nextEvent.date} {team.nextEvent.time}</div>
            {team.nextEvent.vs && <div className="text-muted-foreground">vs {team.nextEvent.vs}</div>}
            <div className="text-muted-foreground">{team.nextEvent.location}</div>
          </div>
        </Card>
        <Card title="Season Record">
          <div className="font-mono text-lg">{team.record.w}-{team.record.l}-{team.record.ot}</div>
          <div className="text-[11px] text-muted-foreground">{team.record.w * 2 + team.record.ot} PTS · {team.games} GP</div>
        </Card>
        <Card title="Roster">
          <div className="text-sm font-medium">{team.roster.count} players</div>
          <div className="text-[11px] text-muted-foreground">
            {team.roster.registered} registered · {team.roster.count - team.roster.registered} pending
          </div>
        </Card>
        <Card title="Ice This Week">
          <div className="text-sm font-medium">{team.iceThisWeek}</div>
        </Card>
      </div>

      <div className="flex flex-wrap gap-2">
        <QuickBtn icon={Edit3}>Edit Team</QuickBtn>
        <QuickBtn icon={MessageSquare}>Message Team</QuickBtn>
        <QuickBtn icon={Calendar}>View Schedule</QuickBtn>
        <QuickBtn icon={Download}>Export Roster</QuickBtn>
      </div>
    </div>
  );
}

function RosterTab() {
  return (
    <div className="space-y-3">
      <div className="flex flex-wrap gap-2">
        <button className="inline-flex h-7 items-center gap-1 rounded border border-border bg-background px-2 text-xs hover:bg-accent">
          <Plus className="h-3 w-3" /> Add player
        </button>
        <button className="inline-flex h-7 items-center gap-1 rounded border border-border bg-background px-2 text-xs hover:bg-accent">
          From waitlist
        </button>
        <button className="inline-flex h-7 items-center gap-1 rounded border border-border bg-background px-2 text-xs hover:bg-accent">
          <Download className="h-3 w-3" /> CSV
        </button>
        <button className="inline-flex h-7 items-center gap-1 rounded border border-border bg-background px-2 text-xs hover:bg-accent">
          <Download className="h-3 w-3" /> PDF
        </button>
      </div>
      <div className="overflow-hidden rounded-lg border border-border">
        <table className="w-full text-xs">
          <thead className="bg-muted/40 uppercase text-muted-foreground">
            <tr>
              <th className="px-3 py-2 text-left">#</th>
              <th className="px-3 py-2 text-left">Name</th>
              <th className="px-3 py-2 text-left">Pos</th>
              <th className="px-3 py-2 text-left">Registration</th>
              <th className="px-3 py-2 text-left">HC/USA Verified</th>
              <th className="px-3 py-2 text-left">Health Form</th>
              <th className="px-3 py-2 text-right">Actions</th>
            </tr>
          </thead>
          <tbody>
            {ROSTER.map((p) => (
              <tr key={p.jersey} className="border-t border-border">
                <td className="px-3 py-2 font-mono">{p.jersey}</td>
                <td className="px-3 py-2">{p.name}</td>
                <td className="px-3 py-2">{p.pos}</td>
                <td className="px-3 py-2">
                  <span className={`rounded px-1.5 py-0.5 ${p.status === "Registered" ? "bg-emerald-500/15 text-emerald-400" : "bg-amber-500/15 text-amber-400"}`}>{p.status}</span>
                </td>
                <td className="px-3 py-2">
                  {p.verified ? <CheckCircle2 className="h-3.5 w-3.5 text-emerald-400" /> : <X className="h-3.5 w-3.5 text-red-400" />}
                </td>
                <td className="px-3 py-2">
                  <span className={p.health === "On File" ? "text-emerald-400" : "text-red-400"}>{p.health}</span>
                </td>
                <td className="px-3 py-2 text-right text-muted-foreground">
                  <button className="hover:text-foreground">Transfer</button> · <button className="hover:text-foreground">Remove</button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}

function ScheduleTab() {
  return (
    <div className="space-y-3">
      <div className="flex justify-end">
        <button className="inline-flex h-7 items-center gap-1 rounded bg-gradient-to-r from-teal-500 to-emerald-500 px-2 text-xs font-medium text-white">
          <Plus className="h-3 w-3" /> Add game / practice
        </button>
      </div>
      <div className="overflow-hidden rounded-lg border border-border">
        <table className="w-full text-xs">
          <thead className="bg-muted/40 uppercase text-muted-foreground">
            <tr>
              <th className="px-3 py-2 text-left">Date</th>
              <th className="px-3 py-2 text-left">Time</th>
              <th className="px-3 py-2 text-left">H/A</th>
              <th className="px-3 py-2 text-left">Opponent</th>
              <th className="px-3 py-2 text-left">Location</th>
              <th className="px-3 py-2 text-left">Ref</th>
              <th className="px-3 py-2 text-left">Result</th>
            </tr>
          </thead>
          <tbody>
            {SCHEDULE.map((g, i) => (
              <tr key={i} className="border-t border-border">
                <td className="px-3 py-2">{g.date}</td>
                <td className="px-3 py-2">{g.time}</td>
                <td className="px-3 py-2">{g.side}</td>
                <td className="px-3 py-2">{g.opp}</td>
                <td className="px-3 py-2 text-muted-foreground">{g.loc}</td>
                <td className="px-3 py-2">
                  {g.ref ? <CheckCircle2 className="h-3.5 w-3.5 text-emerald-400" /> : <X className="h-3.5 w-3.5 text-red-400" />}
                </td>
                <td className="px-3 py-2">
                  {g.result ? <span className="font-mono">{g.result}</span> : (
                    <button className="rounded border border-border px-1.5 py-0.5 text-[10px] hover:bg-accent">Enter score</button>
                  )}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
      <div className="text-[11px] text-muted-foreground">Scores update standings automatically.</div>
    </div>
  );
}

function ComplianceTab({ team }: { team: Team }) {
  const list = [
    { name: team.headCoach.name, role: "HEAD COACH", compliance: team.headCoach.compliance, missing: team.headCoach.compliance === "non-compliant" ? "VSC expired · First Aid expired" : team.headCoach.compliance === "action" ? "COI not signed" : "" },
    ...team.assistants.map((a) => ({ name: a, role: "ASSISTANT", compliance: "compliant" as const, missing: "" })),
  ];
  return (
    <div className="space-y-2">
      {list.map((c) => (
        <div key={c.name} className="flex items-center justify-between rounded-lg border border-border p-3">
          <div>
            <div className="text-sm font-medium">{c.name}</div>
            <div className="text-[11px] text-muted-foreground">{c.role}</div>
            {c.missing && <div className="mt-1 text-[11px] text-amber-400">Missing: {c.missing}</div>}
          </div>
          <div className="flex items-center gap-2">
            <ComplianceBadge c={c.compliance} />
            {c.compliance !== "compliant" && (
              <button className="rounded border border-border bg-background px-2 py-1 text-[11px] hover:bg-accent">Fix</button>
            )}
          </div>
        </div>
      ))}
    </div>
  );
}

function Card({ title, children }: { title: string; children: React.ReactNode }) {
  return (
    <div className="rounded-lg border border-border p-3">
      <div className="mb-1 text-[11px] uppercase tracking-wide text-muted-foreground">{title}</div>
      {children}
    </div>
  );
}

function QuickBtn({ icon: Icon, children }: { icon: React.ComponentType<{ className?: string }>; children: React.ReactNode }) {
  return (
    <button className="inline-flex h-8 items-center gap-1.5 rounded-md border border-border bg-background px-3 text-xs hover:bg-accent">
      <Icon className="h-3.5 w-3.5" /> {children}
    </button>
  );
}

/* -------------------- Add Team Drawer -------------------- */

const COACH_OPTIONS = [
  { name: "Marcus Bell", cert: "Development 1" },
  { name: "Priya Singh", cert: "Trained" },
  { name: "Tom Reilly", cert: "Community" },
  { name: "Sara Chen", cert: "Development 2" },
  { name: "Derek Olson", cert: "Intro" },
];

const MIN_CERT: Record<string, string> = {
  U9: "Intro", U11: "Community", U13: "Trained", U15: "Development 1", U18: "Development 1",
};

const CERT_RANK = ["Intro", "Community", "Trained", "Development 1", "Development 2", "High Performance"];

function AddTeamDrawer({ onClose }: { onClose: () => void }) {
  const [age, setAge] = useState("U15");
  const [coach, setCoach] = useState(COACH_OPTIONS[0].name);
  const [override, setOverride] = useState(false);
  const coachCert = COACH_OPTIONS.find((c) => c.name === coach)?.cert ?? "Intro";
  const minCert = MIN_CERT[age];
  const belowMin = CERT_RANK.indexOf(coachCert) < CERT_RANK.indexOf(minCert);

  return (
    <>
      <div onClick={onClose} className="fixed inset-0 z-40 bg-black/50" />
      <aside className="fixed right-0 top-0 z-50 h-full w-full max-w-md overflow-y-auto border-l border-border bg-background shadow-2xl">
        <div className="flex items-center justify-between border-b border-border px-5 py-3">
          <h3 className="text-sm font-semibold">Add Team</h3>
          <button onClick={onClose} className="rounded p-1 hover:bg-accent"><X className="h-4 w-4" /></button>
        </div>
        <div className="space-y-3 p-5 text-sm">
          <Field label="Team name"><input className="input" placeholder="Northern Lights U13 AA" /></Field>
          <div className="grid grid-cols-3 gap-2">
            <Field label="Age group">
              <select className="input" value={age} onChange={(e) => setAge(e.target.value)}>
                {["U9", "U11", "U13", "U15", "U18"].map((a) => <option key={a}>{a}</option>)}
              </select>
            </Field>
            <Field label="Division">
              <select className="input">{["AAA", "AA", "A", "B", "C"].map((d) => <option key={d}>{d}</option>)}</select>
            </Field>
            <Field label="Season">
              <select className="input"><option>2025-26</option><option>2026-27</option></select>
            </Field>
          </div>

          <Field label="Head coach">
            <select className="input" value={coach} onChange={(e) => setCoach(e.target.value)}>
              {COACH_OPTIONS.map((c) => <option key={c.name}>{c.name}</option>)}
              <option value="__invite">+ Invite new coach…</option>
            </select>
          </Field>
          <div className="text-[11px] text-muted-foreground">
            Required minimum cert for {age}: <strong>{minCert}</strong> · Coach holds: <strong>{coachCert}</strong>
          </div>

          {belowMin && (
            <div className="rounded-md border border-red-500/30 bg-red-500/10 p-2 text-xs text-red-400">
              <div className="flex items-start gap-2">
                <AlertTriangle className="mt-0.5 h-3.5 w-3.5" />
                <div>
                  Coach cert is below the required minimum for {age}.
                  <label className="mt-2 flex items-center gap-1.5">
                    <input type="checkbox" checked={override} onChange={(e) => setOverride(e.target.checked)} className="accent-red-500" />
                    Override and log to audit trail
                  </label>
                </div>
              </div>
            </div>
          )}

          <Field label="Team colors">
            <div className="flex gap-2">
              <input type="color" defaultValue="#0d9488" className="h-8 w-10 cursor-pointer rounded border border-border bg-background" />
              <input type="color" defaultValue="#1e293b" className="h-8 w-10 cursor-pointer rounded border border-border bg-background" />
            </div>
          </Field>

          <Field label="Preferred ice times">
            <textarea className="input min-h-[60px] py-1.5" placeholder="e.g. Mon/Wed 6-8pm, Sat mornings" />
          </Field>

          <div className="flex justify-end gap-2 pt-2">
            <button onClick={onClose} className="rounded-md border border-border bg-background px-3 py-1.5 text-xs hover:bg-accent">Cancel</button>
            <button disabled={belowMin && !override}
              className="rounded-md bg-gradient-to-r from-teal-500 to-emerald-500 px-3 py-1.5 text-xs font-medium text-white disabled:opacity-50">
              Save Team
            </button>
          </div>
        </div>
        <style>{`.input{width:100%;height:32px;border-radius:6px;border:1px solid hsl(var(--border));background:hsl(var(--background));padding:0 8px;font-size:12px;}`}</style>
      </aside>
    </>
  );
}

function Field({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <label className="block">
      <span className="mb-1 block text-[11px] font-medium text-muted-foreground">{label}</span>
      {children}
    </label>
  );
}
