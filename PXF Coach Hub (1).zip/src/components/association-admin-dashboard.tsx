import {
  Users,
  UserCheck,
  ClipboardList,
  DollarSign,
  CalendarRange,
  Flag,
  ShieldAlert,
  Trophy,
  Check,
  X,
  Plus,
  UserPlus,
  Megaphone,
  Shirt,
  ClipboardCheck,
  FileWarning,
} from "lucide-react";

type EventType = "GAME" | "PRACTICE";
type IncidentType = "INJURY" | "CONCUSSION" | "MISCONDUCT";
type IncidentStatus = "OPEN" | "IN REVIEW" | "RESOLVED";

const kpis = [
  { label: "Total Teams", value: "28", sub: "Active this season", icon: Trophy, tone: "default" as const },
  { label: "Total Athletes", value: "412", sub: "Registered across teams", icon: Users, tone: "default" as const },
  {
    label: "Total Coaches",
    value: "24",
    sub: "3 non-compliant",
    icon: UserCheck,
    tone: "warn" as const,
  },
  {
    label: "Registrations",
    value: "387",
    sub: "362 confirmed · 25 pending",
    icon: ClipboardList,
    tone: "default" as const,
  },
  {
    label: "Outstanding Fees",
    value: "$24,850",
    sub: "42 families unpaid",
    icon: DollarSign,
    tone: "warn" as const,
  },
  { label: "Upcoming Tryouts", value: "6", sub: "Next 30 days", icon: CalendarRange, tone: "default" as const },
  {
    label: "Unassigned Refs",
    value: "4",
    sub: "Games this week",
    icon: Flag,
    tone: "warn" as const,
  },
];

const weekEvents: {
  date: string;
  time: string;
  team: string;
  type: EventType;
  location: string;
  ref: boolean;
  attendance: string;
}[] = [
  { date: "Mon Jun 29", time: "5:30 PM", team: "U14 AAA Blades", type: "PRACTICE", location: "Rink A", ref: true, attendance: "Confirmed" },
  { date: "Tue Jun 30", time: "6:45 PM", team: "U16 AA Wolves", type: "GAME", location: "Civic Arena", ref: true, attendance: "Confirmed" },
  { date: "Wed Jul 01", time: "7:00 PM", team: "U12 A Lightning", type: "GAME", location: "North Pad", ref: false, attendance: "Pending" },
  { date: "Thu Jul 02", time: "4:15 PM", team: "U10 Mites", type: "PRACTICE", location: "Rink B", ref: true, attendance: "Confirmed" },
  { date: "Fri Jul 03", time: "8:00 PM", team: "U18 AAA Storm", type: "GAME", location: "Civic Arena", ref: false, attendance: "Confirmed" },
  { date: "Sat Jul 04", time: "10:00 AM", team: "U14 AA Foxes", type: "GAME", location: "South Pad", ref: true, attendance: "Confirmed" },
  { date: "Sun Jul 05", time: "1:30 PM", team: "U16 A Hawks", type: "PRACTICE", location: "Rink A", ref: true, attendance: "Pending" },
];

const compliance = [
  { coach: "Marcus Reilly", team: "U16 AAA Storm", issue: "Background check expired", days: -4, severity: "red" as const },
  { coach: "Erin Chen", team: "U14 AA Foxes", issue: "Safe Sport expiring", days: 9, severity: "amber" as const },
  { coach: "Devon Walsh", team: "U18 AAA Wolves", issue: "Coaching cert expiring", days: 21, severity: "amber" as const },
  { coach: "Sasha Petrov", team: "U12 A Lightning", issue: "Missing background check", days: 0, severity: "red" as const },
];

const pendingRegs = [
  { athlete: "Liam O'Connor", team: "U14 AAA Blades", date: "Jun 27" },
  { athlete: "Ava Thompson", team: "U10 Mites", date: "Jun 27" },
  { athlete: "Noah Patel", team: "U16 AA Wolves", date: "Jun 26" },
  { athlete: "Mia Rodriguez", team: "U12 A Lightning", date: "Jun 25" },
  { athlete: "Ethan Kim", team: "U18 AAA Storm", date: "Jun 25" },
];

const activity = [
  { t: "12 min ago", msg: "Registration approved · Liam O'Connor → U14 AAA Blades" },
  { t: "48 min ago", msg: "Coach added · Jamie Park assigned to U10 Mites" },
  { t: "2 hr ago", msg: "Incident filed · Concussion protocol started for #17" },
  { t: "3 hr ago", msg: "Payment received · $420 from Rodriguez family" },
  { t: "5 hr ago", msg: "Apparel order submitted · 38 jerseys, U16 AA Wolves" },
  { t: "Yesterday", msg: "Ref assignments published · Week of Jul 1" },
];

const incidents: { type: IncidentType; name: string; date: string; status: IncidentStatus }[] = [
  { type: "CONCUSSION", name: "Tyler Brooks (U16 AA)", date: "Jun 26", status: "IN REVIEW" },
  { type: "INJURY", name: "Mia Rodriguez (U12 A)", date: "Jun 24", status: "OPEN" },
  { type: "MISCONDUCT", name: "Coach D. Walsh", date: "Jun 22", status: "IN REVIEW" },
];

const quickActions = [
  { label: "Add Team", icon: Plus },
  { label: "Invite Coach", icon: UserPlus },
  { label: "Create Tryout", icon: CalendarRange },
  { label: "Start Apparel Order", icon: Shirt },
  { label: "Assign Referees", icon: Flag },
  { label: "Send Communication", icon: Megaphone },
];

const typeBadge: Record<EventType, string> = {
  GAME: "bg-red-500/15 text-red-400 ring-red-500/30",
  PRACTICE: "bg-emerald-500/15 text-emerald-400 ring-emerald-500/30",
};
const rowTint: Record<EventType, string> = {
  GAME: "hover:bg-red-500/5",
  PRACTICE: "hover:bg-emerald-500/5",
};
const incidentBadge: Record<IncidentType, string> = {
  INJURY: "bg-amber-500/15 text-amber-400 ring-amber-500/30",
  CONCUSSION: "bg-red-500/15 text-red-400 ring-red-500/30",
  MISCONDUCT: "bg-purple-500/15 text-purple-400 ring-purple-500/30",
};
const statusBadge: Record<IncidentStatus, string> = {
  OPEN: "bg-red-500/15 text-red-400",
  "IN REVIEW": "bg-amber-500/15 text-amber-400",
  RESOLVED: "bg-emerald-500/15 text-emerald-400",
};

export function AssociationAdminDashboard() {
  return (
    <div className="space-y-6">
      {/* Row 1 — KPIs */}
      <div className="grid grid-cols-2 gap-3 md:grid-cols-4 xl:grid-cols-7">
        {kpis.map(({ label, value, sub, icon: Icon, tone }) => (
          <div
            key={label}
            className={`rounded-lg border bg-card p-4 ${
              tone === "warn" ? "border-amber-500/30" : "border-border"
            }`}
          >
            <div className="flex items-center justify-between">
              <span className="text-[10px] font-semibold uppercase tracking-wider text-muted-foreground">
                {label}
              </span>
              <Icon className={`h-4 w-4 ${tone === "warn" ? "text-amber-500" : "text-teal-400"}`} />
            </div>
            <div className="mt-2 text-2xl font-bold tracking-tight">{value}</div>
            <div className={`mt-0.5 text-[11px] ${tone === "warn" ? "text-amber-500" : "text-muted-foreground"}`}>
              {sub}
            </div>
          </div>
        ))}
      </div>

      {/* Row 2 */}
      <div className="grid grid-cols-1 gap-4 lg:grid-cols-[65fr_35fr]">
        {/* This week table */}
        <div className="rounded-lg border border-border bg-card">
          <div className="flex items-center justify-between border-b border-border px-5 py-3">
            <h3 className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">This Week</h3>
            <span className="text-[11px] text-muted-foreground">{weekEvents.length} events</span>
          </div>
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="text-left text-[11px] uppercase tracking-wider text-muted-foreground">
                  <th className="px-5 py-2 font-medium">Date</th>
                  <th className="px-2 py-2 font-medium">Time</th>
                  <th className="px-2 py-2 font-medium">Team</th>
                  <th className="px-2 py-2 font-medium">Type</th>
                  <th className="px-2 py-2 font-medium">Location</th>
                  <th className="px-2 py-2 font-medium">Ref</th>
                  <th className="px-5 py-2 font-medium">Attendance</th>
                </tr>
              </thead>
              <tbody>
                {weekEvents.map((e, i) => (
                  <tr
                    key={i}
                    className={`cursor-pointer border-t border-border/60 transition ${rowTint[e.type]}`}
                  >
                    <td className="px-5 py-3 font-medium">{e.date}</td>
                    <td className="px-2 py-3 text-muted-foreground">{e.time}</td>
                    <td className="px-2 py-3">{e.team}</td>
                    <td className="px-2 py-3">
                      <span className={`inline-flex items-center rounded px-1.5 py-0.5 text-[10px] font-bold ring-1 ${typeBadge[e.type]}`}>
                        {e.type}
                      </span>
                    </td>
                    <td className="px-2 py-3 text-muted-foreground">{e.location}</td>
                    <td className="px-2 py-3">
                      {e.ref ? (
                        <Check className="h-4 w-4 text-emerald-500" />
                      ) : (
                        <X className="h-4 w-4 text-red-500" />
                      )}
                    </td>
                    <td className="px-5 py-3 text-muted-foreground">{e.attendance}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

        {/* Right column */}
        <div className="space-y-4">
          {/* Compliance Alerts */}
          <div className="rounded-lg border border-border bg-card">
            <div className="flex items-center justify-between border-b border-border px-4 py-3">
              <div className="flex items-center gap-2">
                <ShieldAlert className="h-4 w-4 text-amber-500" />
                <h3 className="text-xs font-semibold uppercase tracking-wider">Compliance Alerts</h3>
              </div>
              <button className="text-[11px] font-medium text-teal-400 hover:text-teal-300">View All</button>
            </div>
            <ul className="divide-y divide-border/60">
              {compliance.map((c, i) => (
                <li key={i} className="px-4 py-3">
                  <div className="flex items-start justify-between gap-2">
                    <div className="min-w-0">
                      <div className="text-sm font-medium truncate">{c.coach}</div>
                      <div className="text-[11px] text-muted-foreground truncate">{c.team} · {c.issue}</div>
                    </div>
                    <span
                      className={`shrink-0 rounded px-1.5 py-0.5 text-[10px] font-bold ${
                        c.severity === "red"
                          ? "bg-red-500/15 text-red-400"
                          : "bg-amber-500/15 text-amber-400"
                      }`}
                    >
                      {c.days < 0 ? `${Math.abs(c.days)}d overdue` : c.days === 0 ? "Missing" : `${c.days}d left`}
                    </span>
                  </div>
                </li>
              ))}
            </ul>
          </div>

          {/* Pending Registrations */}
          <div className="rounded-lg border border-border bg-card">
            <div className="flex items-center justify-between border-b border-border px-4 py-3">
              <div className="flex items-center gap-2">
                <ClipboardCheck className="h-4 w-4 text-teal-400" />
                <h3 className="text-xs font-semibold uppercase tracking-wider">Pending Registrations</h3>
              </div>
              <button className="text-[11px] font-medium text-teal-400 hover:text-teal-300">View All</button>
            </div>
            <ul className="divide-y divide-border/60">
              {pendingRegs.map((r, i) => (
                <li key={i} className="flex items-center justify-between gap-2 px-4 py-2.5">
                  <div className="min-w-0">
                    <div className="text-sm font-medium truncate">{r.athlete}</div>
                    <div className="text-[11px] text-muted-foreground truncate">{r.team} · {r.date}</div>
                  </div>
                  <div className="flex shrink-0 gap-1">
                    <button className="rounded bg-gradient-to-r from-teal-500 to-emerald-500 px-2 py-1 text-[11px] font-semibold text-white hover:opacity-90">
                      Approve
                    </button>
                    <button className="rounded border border-border px-2 py-1 text-[11px] font-semibold hover:bg-accent">
                      Review
                    </button>
                  </div>
                </li>
              ))}
            </ul>
          </div>
        </div>
      </div>

      {/* Row 3 */}
      <div className="grid grid-cols-1 gap-4 lg:grid-cols-3">
        {/* Recent Activity */}
        <div className="rounded-lg border border-border bg-card">
          <div className="border-b border-border px-4 py-3">
            <h3 className="text-xs font-semibold uppercase tracking-wider">Recent Activity</h3>
          </div>
          <ul className="space-y-3 px-4 py-3">
            {activity.map((a, i) => (
              <li key={i} className="flex gap-3">
                <div className="mt-1.5 h-1.5 w-1.5 shrink-0 rounded-full bg-teal-400" />
                <div className="min-w-0">
                  <div className="text-sm leading-snug">{a.msg}</div>
                  <div className="text-[11px] text-muted-foreground">{a.t}</div>
                </div>
              </li>
            ))}
          </ul>
        </div>

        {/* Safety & Incidents */}
        <div className="rounded-lg border border-border bg-card">
          <div className="flex items-center justify-between border-b border-border px-4 py-3">
            <div className="flex items-center gap-2">
              <FileWarning className="h-4 w-4 text-red-400" />
              <h3 className="text-xs font-semibold uppercase tracking-wider">Safety & Incidents</h3>
            </div>
            <button className="text-[11px] font-medium text-teal-400 hover:text-teal-300">View All</button>
          </div>
          <ul className="divide-y divide-border/60">
            {incidents.map((inc, i) => (
              <li key={i} className="px-4 py-3">
                <div className="flex items-center justify-between gap-2">
                  <span className={`rounded px-1.5 py-0.5 text-[10px] font-bold ring-1 ring-inset ${incidentBadge[inc.type]}`}>
                    {inc.type}
                  </span>
                  <span className={`rounded px-1.5 py-0.5 text-[10px] font-bold ${statusBadge[inc.status]}`}>
                    {inc.status}
                  </span>
                </div>
                <div className="mt-2 text-sm font-medium">{inc.name}</div>
                <div className="text-[11px] text-muted-foreground">Filed {inc.date}</div>
              </li>
            ))}
          </ul>
        </div>

        {/* Quick Actions */}
        <div className="rounded-lg border border-border bg-card">
          <div className="border-b border-border px-4 py-3">
            <h3 className="text-xs font-semibold uppercase tracking-wider">Quick Actions</h3>
          </div>
          <div className="grid grid-cols-2 gap-2 p-3">
            {quickActions.map(({ label, icon: Icon }) => (
              <button
                key={label}
                className="group flex flex-col items-start gap-2 rounded-md bg-gradient-to-br from-teal-500 to-emerald-500 p-3 text-left text-white shadow-sm transition hover:opacity-90"
              >
                <Icon className="h-4 w-4" />
                <span className="text-xs font-semibold leading-tight">{label}</span>
              </button>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
