import { createContext, useContext, useEffect, useState, type ReactNode } from "react";

export type AccountRole = "elite-coach" | "association-admin" | "team-coach" | "parent";

export type Account = {
  role: AccountRole;
  name: string;
  initials: string;
  badge: string;
  org: string;
};

export const ACCOUNTS: Record<AccountRole, Account> = {
  "elite-coach": {
    role: "elite-coach",
    name: "Jordan Doe",
    initials: "JD",
    badge: "Elite Coach",
    org: "Elite Portal",
  },
  "association-admin": {
    role: "association-admin",
    name: "Alex Morgan",
    initials: "AM",
    badge: "Association Admin",
    org: "Association Portal",
  },
  "team-coach": {
    role: "team-coach",
    name: "Sam Rivera",
    initials: "SR",
    badge: "Team Coach",
    org: "Team Portal",
  },
  parent: {
    role: "parent",
    name: "Jamie Dev",
    initials: "JD",
    badge: "Parent",
    org: "Parent Portal",
  },
};

type Ctx = {
  account: Account;
  setRole: (role: AccountRole) => void;
};

const AccountContext = createContext<Ctx | null>(null);
const STORAGE_KEY = "pxf-account-role";

export function AccountProvider({ children }: { children: ReactNode }) {
  const [role, setRoleState] = useState<AccountRole>("elite-coach");

  useEffect(() => {
    const stored = localStorage.getItem(STORAGE_KEY) as AccountRole | null;
    if (stored && ACCOUNTS[stored]) setRoleState(stored);
  }, []);

  const setRole = (r: AccountRole) => {
    setRoleState(r);
    localStorage.setItem(STORAGE_KEY, r);
  };

  return (
    <AccountContext.Provider value={{ account: ACCOUNTS[role], setRole }}>
      {children}
    </AccountContext.Provider>
  );
}

export function useAccount() {
  const ctx = useContext(AccountContext);
  if (!ctx) throw new Error("useAccount must be used within AccountProvider");
  return ctx;
}
