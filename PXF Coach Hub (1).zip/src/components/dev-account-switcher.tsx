import { useNavigate, useRouterState } from "@tanstack/react-router";
import { useAccount, ACCOUNTS, type AccountRole } from "./account-provider";
import { cn } from "@/lib/utils";

export function DevAccountSwitcher() {
  const { account, setRole } = useAccount();
  const navigate = useNavigate();
  const pathname = useRouterState({ select: (r) => r.location.pathname });

  const options: { value: AccountRole; label: string }[] = [
    { value: "elite-coach", label: "Elite Coach" },
    { value: "association-admin", label: "Assoc. Admin" },
    { value: "team-coach", label: "Team Coach" },
    { value: "parent", label: "Parent" },
  ];

  const handleSelect = (role: AccountRole) => {
    setRole(role);
    if (role === "parent") {
      navigate({ to: "/parent" });
    } else if (pathname === "/parent") {
      navigate({ to: "/dashboard" });
    }
  };

  return (
    <div className="fixed bottom-4 right-4 z-50 rounded-lg border border-border bg-background/95 p-2 shadow-lg backdrop-blur">
      <div className="px-1 pb-1 text-[9px] font-bold uppercase tracking-widest text-muted-foreground">
        Dev · Test Account
      </div>
      <div className="flex flex-wrap gap-1">
        {options.map((opt) => {
          const active = account.role === opt.value;
          return (
            <button
              key={opt.value}
              onClick={() => handleSelect(opt.value)}
              className={cn(
                "rounded-md px-2.5 py-1 text-[11px] font-semibold transition",
                active
                  ? "bg-gradient-to-r from-teal-500 to-emerald-500 text-white"
                  : "bg-muted text-muted-foreground hover:text-foreground"
              )}
              title={ACCOUNTS[opt.value].name}
            >
              {opt.label}
            </button>
          );
        })}
      </div>
    </div>
  );
}
