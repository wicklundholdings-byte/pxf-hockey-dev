import { useState } from "react";
import {
  Globe,
  Eye,
  Upload,
  Monitor,
  Smartphone,
  ChevronDown,
  ChevronUp,
  GripVertical,
  EyeOff,
  Edit3,
  Lock,
  CheckCircle2,
  AlertCircle,
  Sparkles,
  Image as ImageIcon,
  Palette,
  Type,
  MapPin,
  Mail,
  Phone,
  Twitter,
  Facebook,
  Instagram,
  Youtube,
  ExternalLink,
  Copy,
} from "lucide-react";
import { cn } from "@/lib/utils";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { toast } from "sonner";

type Template = "classic" | "modern" | "minimal";
type Visibility = "public" | "password" | "draft";

type PageDef = {
  id: string;
  name: string;
  source: "auto" | "manual" | "mixed";
  description: string;
  visible: boolean;
};

const DEFAULT_PAGES: PageDef[] = [
  { id: "home", name: "Home", source: "mixed", description: "Landing page with hero, upcoming camps, and highlights", visible: true },
  { id: "about", name: "About", source: "manual", description: "Bio, certifications, coaching philosophy", visible: true },
  { id: "camps", name: "Camps", source: "auto", description: "All LIVE camps with Register Now", visible: true },
  { id: "privates", name: "Private Sessions", source: "auto", description: "Bookable private lesson slots", visible: true },
  { id: "schedule", name: "Schedule", source: "auto", description: "Public availability from Ice Times", visible: true },
  { id: "testimonials", name: "Testimonials", source: "manual", description: "Reviews from athletes and parents", visible: true },
  { id: "gallery", name: "Gallery", source: "manual", description: "Photos and video highlights from sessions", visible: true },
  { id: "resources", name: "Resources", source: "manual", description: "Training PDFs, drills, and video library", visible: true },
  { id: "book", name: "Book Now", source: "auto", description: "Direct booking flow for camps and privates", visible: true },
  { id: "contact", name: "Contact", source: "mixed", description: "Contact info + inquiry form", visible: true },
];

export function CoachWebsite() {
  const [tab, setTab] = useState<"builder" | "pages" | "settings">("builder");
  const [template, setTemplate] = useState<Template | null>("modern");
  const [hasUnpublished, setHasUnpublished] = useState(true);
  const [previewOpen, setPreviewOpen] = useState(false);

  const [primary, setPrimary] = useState("#0d9488");
  const [secondary, setSecondary] = useState("#10b981");
  const [name, setName] = useState("Jordan Doe");
  const [tagline, setTagline] = useState("Elite Skating Coach");
  const [headline, setHeadline] = useState("Skate faster. Play smarter.");
  const [sub, setSub] = useState("12 years developing elite skaters — edge work, speed, and hockey IQ.");
  const [cta, setCta] = useState("Book a Session");

  const siteUrl = "pxfhockey.com/coach/jordan-doe";


  return (
    <div className="space-y-6">
      {/* Top bar */}
      <div className="space-y-3">
        <div className="flex items-center gap-3 text-sm">
          <Globe className="h-4 w-4 text-teal-400" />
          <span className="text-muted-foreground">Live page:</span>
          <a href={`https://${siteUrl}`} className="font-mono text-teal-400 hover:underline" target="_blank" rel="noreferrer">
            {siteUrl}
          </a>
          <button onClick={() => { navigator.clipboard.writeText(siteUrl); toast.success("URL copied"); }} className="text-muted-foreground hover:text-foreground">
            <Copy className="h-3.5 w-3.5" />
          </button>
          {hasUnpublished && (
            <span className="ml-auto inline-flex items-center gap-1.5 rounded-full bg-amber-500/15 text-amber-400 ring-1 ring-amber-500/30 px-2.5 py-0.5 text-[10px] font-semibold uppercase tracking-wider">
              <AlertCircle className="h-3 w-3" /> Unpublished changes
            </span>
          )}
        </div>

        <div className="flex items-center justify-between gap-4">
          <div className="flex items-center gap-1 rounded-lg border border-border bg-card p-1">
            {(["builder","pages","settings"] as const).map((t) => (
              <button
                key={t}
                onClick={() => setTab(t)}
                className={cn(
                  "rounded-md px-4 py-1.5 text-sm font-medium transition-colors capitalize",
                  tab === t
                    ? "bg-gradient-to-r from-teal-500 to-emerald-500 text-white"
                    : "text-muted-foreground hover:text-foreground"
                )}
              >
                {t}
              </button>
            ))}
          </div>
          <div className="flex gap-2">
            <Button variant="outline" asChild>
              <a href="/preview/website" target="_blank" rel="noreferrer">
                <Eye className="h-4 w-4 mr-1.5" /> Preview Page
              </a>
            </Button>
            <Button
              className="bg-teal-500 hover:bg-teal-600 text-white"
              disabled={!hasUnpublished}
              onClick={() => { setHasUnpublished(false); toast.success("Changes publishing — live within 60 seconds"); }}
            >
              <CheckCircle2 className="h-4 w-4 mr-1.5" /> Publish Changes
            </Button>
          </div>
        </div>
      </div>

      {tab === "builder" && (
        template ? (
          <BuilderTab
            template={template}
            onChangeTemplate={() => setTemplate(null)}
            onEdit={() => setHasUnpublished(true)}
            values={{ primary, secondary, name, tagline, headline, sub, cta }}
            setters={{ setPrimary, setSecondary, setName, setTagline, setHeadline, setSub, setCta }}
          />
        ) : (
          <TemplatePicker onPick={(t) => { setTemplate(t); setHasUnpublished(true); toast.success(`${t.charAt(0).toUpperCase() + t.slice(1)} template applied`); }} />
        )
      )}
      {tab === "pages" && <PagesTab onChange={() => setHasUnpublished(true)} />}
      {tab === "settings" && <SettingsTab siteUrl={siteUrl} onChange={() => setHasUnpublished(true)} />}

      {previewOpen && (
        <div
          className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex flex-col"
          onClick={() => setPreviewOpen(false)}
        >
          <div className="flex items-center justify-between px-4 py-3 border-b border-border bg-card">
            <div className="flex items-center gap-2 text-sm">
              <Globe className="h-4 w-4 text-teal-400" />
              <span className="font-mono text-teal-400">{siteUrl}</span>
              <span className="inline-flex items-center gap-1 rounded bg-amber-500/15 text-amber-400 px-1.5 py-0.5 text-[9px] font-bold uppercase">Draft Preview</span>
            </div>
            <Button variant="ghost" size="sm" onClick={() => setPreviewOpen(false)}>Close</Button>
          </div>
          <div className="flex-1 overflow-auto p-6 flex justify-center" onClick={(e) => e.stopPropagation()}>
            <div className="w-full max-w-5xl">
              <SitePreview
                template={template ?? "classic"}
                device="desktop"
                primary={primary}
                secondary={secondary}
                name={name}
                tagline={tagline}
                headline={headline}
                sub={sub}
                cta={cta}
              />
            </div>

          </div>
        </div>
      )}
    </div>
  );
}

/* -------------- Template picker -------------- */

function TemplatePicker({ onPick }: { onPick: (t: Template) => void }) {
  const templates: { id: Template; name: string; tagline: string; preview: React.ReactNode }[] = [
    {
      id: "classic",
      name: "Classic",
      tagline: "Traditional coach profile — dark navy, bold accent color",
      preview: (
        <div className="h-full w-full bg-slate-900 flex flex-col">
          <div className="h-8 bg-slate-950 border-b border-slate-800 flex items-center px-3 gap-2">
            <div className="h-3 w-3 rounded-full bg-red-500" />
            <div className="h-2 w-16 bg-slate-700 rounded" />
          </div>
          <div className="flex-1 p-3 space-y-2">
            <div className="h-3 w-2/3 bg-red-500 rounded" />
            <div className="h-2 w-1/2 bg-slate-600 rounded" />
            <div className="grid grid-cols-3 gap-1 mt-3">
              {[0,1,2].map(i => <div key={i} className="aspect-square bg-slate-800 rounded" />)}
            </div>
          </div>
        </div>
      ),
    },
    {
      id: "modern",
      name: "Modern",
      tagline: "Bold hero, large type, teal/green dynamic accents",
      preview: (
        <div className="h-full w-full bg-gradient-to-br from-slate-900 via-teal-950 to-emerald-950 flex flex-col">
          <div className="h-8 flex items-center px-3 gap-2">
            <div className="h-3 w-3 rounded bg-gradient-to-br from-teal-400 to-emerald-500" />
            <div className="h-2 w-12 bg-white/30 rounded" />
          </div>
          <div className="flex-1 p-3 space-y-2 flex flex-col justify-center">
            <div className="h-4 w-3/4 bg-white rounded" />
            <div className="h-3 w-1/2 bg-teal-400 rounded" />
            <div className="h-6 w-20 bg-gradient-to-r from-teal-500 to-emerald-500 rounded mt-2" />
          </div>
        </div>
      ),
    },
    {
      id: "minimal",
      name: "Minimal",
      tagline: "Clean light background, information-first, editorial",
      preview: (
        <div className="h-full w-full bg-white flex flex-col">
          <div className="h-8 border-b border-gray-200 flex items-center px-3 gap-2">
            <div className="h-3 w-3 rounded bg-gray-800" />
            <div className="h-2 w-16 bg-gray-300 rounded" />
          </div>
          <div className="flex-1 p-3 space-y-2">
            <div className="h-3 w-1/2 bg-gray-900 rounded" />
            <div className="h-2 w-full bg-gray-200 rounded" />
            <div className="h-2 w-3/4 bg-gray-200 rounded" />
            <div className="grid grid-cols-2 gap-1 mt-3">
              {[0,1].map(i => <div key={i} className="h-8 bg-gray-100 border border-gray-200 rounded" />)}
            </div>
          </div>
        </div>
      ),
    },
  ];

  return (
    <div className="space-y-6">
      <div className="text-center">
        <Sparkles className="h-8 w-8 text-teal-400 mx-auto mb-2" />
        <h2 className="text-2xl font-bold">Pick a template to start</h2>
        <p className="text-muted-foreground mt-1">You can switch templates anytime without losing content.</p>
      </div>
      <div className="grid grid-cols-3 gap-4">
        {templates.map((t) => (
          <button
            key={t.id}
            onClick={() => onPick(t.id)}
            className="group rounded-xl border border-border bg-card overflow-hidden text-left transition-all hover:border-teal-500 hover:shadow-lg hover:shadow-teal-500/10"
          >
            <div className="aspect-[4/3] overflow-hidden border-b border-border">
              {t.preview}
            </div>
            <div className="p-4">
              <div className="flex items-center justify-between">
                <h3 className="font-semibold">{t.name}</h3>
                <span className="text-[10px] uppercase tracking-wider text-teal-400 opacity-0 group-hover:opacity-100 transition-opacity">Select →</span>
              </div>
              <p className="text-xs text-muted-foreground mt-1">{t.tagline}</p>
            </div>
          </button>
        ))}
      </div>
    </div>
  );
}

/* -------------- Builder tab -------------- */

type BuilderValues = {
  primary: string; secondary: string; name: string; tagline: string;
  headline: string; sub: string; cta: string;
};
type BuilderSetters = {
  setPrimary: (v: string) => void; setSecondary: (v: string) => void;
  setName: (v: string) => void; setTagline: (v: string) => void;
  setHeadline: (v: string) => void; setSub: (v: string) => void;
  setCta: (v: string) => void;
};

function BuilderTab({
  template, onChangeTemplate, onEdit, values, setters,
}: {
  template: Template; onChangeTemplate: () => void; onEdit: () => void;
  values: BuilderValues; setters: BuilderSetters;
}) {
  const [device, setDevice] = useState<"desktop" | "mobile">("desktop");
  const { primary, secondary, name, tagline, headline, sub, cta } = values;
  const { setPrimary, setSecondary, setName, setTagline, setHeadline, setSub, setCta } = setters;

  const update = (fn: () => void) => { fn(); onEdit(); };

  return (
    <div className="grid grid-cols-1 xl:grid-cols-[380px_1fr] gap-6">
      {/* Content panel */}
      <div className="space-y-3">
        <div className="flex items-center justify-between rounded-lg border border-border bg-card p-3">
          <div className="flex items-center gap-2 text-sm">
            <Sparkles className="h-4 w-4 text-teal-400" />
            <span className="capitalize font-medium">{template} template</span>
          </div>
          <Button variant="ghost" size="sm" onClick={onChangeTemplate}>Change</Button>
        </div>

        <Section icon={Palette} title="Branding" defaultOpen>
          <Field label="Coach Name">
            <Input value={name} onChange={(e) => update(() => setName(e.target.value))} />
          </Field>
          <Field label="Tagline">
            <Input value={tagline} onChange={(e) => update(() => setTagline(e.target.value))} />
          </Field>
          <Field label="Logo / Monogram">
            <Button variant="outline" size="sm" className="w-full"><Upload className="h-4 w-4 mr-1.5" /> Upload PNG/SVG</Button>
          </Field>
          <div className="grid grid-cols-2 gap-2">
            <Field label="Primary Color">
              <div className="flex gap-2">
                <input type="color" value={primary} onChange={(e) => update(() => setPrimary(e.target.value))} className="h-9 w-12 rounded border border-border bg-transparent" />
                <Input value={primary} onChange={(e) => update(() => setPrimary(e.target.value))} className="font-mono text-xs" />
              </div>
            </Field>
            <Field label="Secondary Color">
              <div className="flex gap-2">
                <input type="color" value={secondary} onChange={(e) => update(() => setSecondary(e.target.value))} className="h-9 w-12 rounded border border-border bg-transparent" />
                <Input value={secondary} onChange={(e) => update(() => setSecondary(e.target.value))} className="font-mono text-xs" />
              </div>
            </Field>
          </div>
          <Field label="Favicon">
            <Button variant="outline" size="sm" className="w-full"><Upload className="h-4 w-4 mr-1.5" /> Upload Favicon (.ico/.png)</Button>
          </Field>
        </Section>

        <Section icon={ImageIcon} title="Hero Section">
          <Field label="Hero Images (up to 3 — auto slideshow)">
            <div className="grid grid-cols-3 gap-2">
              {[0,1,2].map((i) => (
                <button key={i} className="aspect-video rounded-md border-2 border-dashed border-border hover:border-teal-500 hover:text-teal-400 text-muted-foreground flex items-center justify-center">
                  <Upload className="h-4 w-4" />
                </button>
              ))}
            </div>
          </Field>
          <Field label="Or Video URL">
            <Input placeholder="https://youtube.com/..." onChange={onEdit} />
          </Field>
          <Field label="Headline"><Input value={headline} onChange={(e) => update(() => setHeadline(e.target.value))} /></Field>
          <Field label="Subheadline"><Textarea rows={2} value={sub} onChange={(e) => update(() => setSub(e.target.value))} /></Field>
          <div className="grid grid-cols-2 gap-2">
            <Field label="CTA Label"><Input value={cta} onChange={(e) => update(() => setCta(e.target.value))} /></Field>
            <Field label="CTA Link">
              <Select defaultValue="book">
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="book">Book Now</SelectItem>
                  <SelectItem value="camps">Camps</SelectItem>
                  <SelectItem value="privates">Private Sessions</SelectItem>
                  <SelectItem value="contact">Contact</SelectItem>
                  <SelectItem value="custom">Custom URL…</SelectItem>
                </SelectContent>
              </Select>
            </Field>
          </div>
        </Section>

        <Section icon={Type} title="About">
          <Field label="Coaching Bio"><Textarea rows={4} placeholder="My approach to developing skaters…" onChange={onEdit} /></Field>
          <Field label="Certifications"><Textarea rows={2} placeholder="Hockey Canada Level 4, USA Hockey Level 5…" onChange={onEdit} /></Field>
          <Field label="Years Coaching"><Input placeholder="12" onChange={onEdit} /></Field>
          <Field label="Notable Athletes / Results (optional)"><Textarea rows={3} placeholder="Coached players now with…" onChange={onEdit} /></Field>
        </Section>

        <Section icon={Mail} title="Contact & Social">
          <Field label="Home Rink / Location"><IconInput icon={MapPin} placeholder="8 Rinks, Vancouver BC" onChange={onEdit} /></Field>
          <Field label="Email"><IconInput icon={Mail} placeholder="jordan@pxfhockey.com" onChange={onEdit} /></Field>
          <Field label="Phone"><IconInput icon={Phone} placeholder="(604) 555-0100" onChange={onEdit} /></Field>
          <div className="grid grid-cols-2 gap-2">
            <Field label="Twitter / X"><IconInput icon={Twitter} placeholder="https://x.com/…" onChange={onEdit} /></Field>
            <Field label="Facebook"><IconInput icon={Facebook} placeholder="https://facebook.com/…" onChange={onEdit} /></Field>
            <Field label="Instagram"><IconInput icon={Instagram} placeholder="https://instagram.com/…" onChange={onEdit} /></Field>
            <Field label="YouTube"><IconInput icon={Youtube} placeholder="https://youtube.com/…" onChange={onEdit} /></Field>
          </div>
        </Section>
      </div>

      {/* Live preview */}
      <div className="space-y-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <span className="text-xs uppercase tracking-wider text-muted-foreground">Live Preview</span>
            <span className="inline-flex items-center gap-1 rounded bg-amber-500/15 text-amber-400 px-1.5 py-0.5 text-[9px] font-bold uppercase">Draft</span>
          </div>
          <div className="flex items-center gap-1 rounded-md border border-border bg-card p-0.5">
            <button onClick={() => setDevice("desktop")} className={cn("p-1.5 rounded", device === "desktop" ? "bg-accent text-foreground" : "text-muted-foreground")}>
              <Monitor className="h-4 w-4" />
            </button>
            <button onClick={() => setDevice("mobile")} className={cn("p-1.5 rounded", device === "mobile" ? "bg-accent text-foreground" : "text-muted-foreground")}>
              <Smartphone className="h-4 w-4" />
            </button>
          </div>
        </div>
        <div className="rounded-xl border border-border bg-card p-4 flex justify-center">
          <SitePreview template={template} device={device} primary={primary} secondary={secondary} name={name} tagline={tagline} headline={headline} sub={sub} cta={cta} />
        </div>
      </div>
    </div>
  );
}

function SitePreview({
  template, device, primary, secondary, name, tagline, headline, sub, cta,
}: { template: Template; device: "desktop" | "mobile"; primary: string; secondary: string; name: string; tagline: string; headline: string; sub: string; cta: string }) {
  const width = device === "desktop" ? "100%" : 360;
  const maxWidth = device === "desktop" ? "100%" : 360;

  const baseStyles = template === "classic"
    ? { bg: "bg-slate-900", text: "text-white", header: "bg-slate-950" }
    : template === "minimal"
    ? { bg: "bg-white", text: "text-slate-900", header: "bg-white border-b border-slate-200" }
    : { bg: "bg-gradient-to-br from-slate-900 via-teal-950 to-emerald-950", text: "text-white", header: "bg-slate-950/50 backdrop-blur" };

  return (
    <div className="rounded-lg overflow-hidden border border-border shadow-xl" style={{ width, maxWidth }}>
      <div className={cn("flex items-center justify-between px-5 py-3", baseStyles.header, baseStyles.text)}>
        <div className="flex items-center gap-2">
          <div className="h-7 w-7 rounded-full" style={{ background: `linear-gradient(135deg, ${primary}, ${secondary})` }} />
          <div className="flex flex-col leading-tight">
            <span className="font-bold text-sm">{name}</span>
            <span className="opacity-70 text-[10px]">{tagline}</span>
          </div>
        </div>
        {device === "desktop" && (
          <nav className="flex gap-4 text-xs">
            {["Home","About","Camps","Privates","Book"].map((n) => <span key={n} className="opacity-80">{n}</span>)}
          </nav>
        )}
      </div>

      <div className={cn("relative px-6 py-12 text-center", baseStyles.bg, baseStyles.text)}>
        {template === "modern" && (
          <div className="absolute inset-0 opacity-20" style={{ background: `radial-gradient(circle at 30% 50%, ${primary}, transparent 60%)` }} />
        )}
        <div className="relative">
          <h1 className={cn("font-black leading-tight", device === "desktop" ? "text-3xl" : "text-2xl", template === "modern" && "tracking-tight")}>
            {headline}
          </h1>
          <p className={cn("mt-3 mx-auto max-w-md", template === "minimal" ? "text-slate-600 text-sm" : "opacity-80 text-sm")}>
            {sub}
          </p>
          <button
            className="mt-5 rounded-md px-5 py-2 text-sm font-semibold text-white shadow-lg"
            style={{ background: `linear-gradient(135deg, ${primary}, ${secondary})` }}
          >
            {cta}
          </button>
        </div>
      </div>

      <div className={cn("grid grid-cols-3 gap-3 p-5", template === "minimal" ? "bg-slate-50" : baseStyles.bg)}>
        {["Camps","Privates","Schedule"].map((label) => (
          <div key={label} className={cn(
            "rounded-lg p-3 text-center",
            template === "minimal" ? "bg-white border border-slate-200 text-slate-900" : "bg-white/5 ring-1 ring-white/10 text-white"
          )}>
            <div className="h-6 w-6 mx-auto rounded-md mb-2" style={{ background: primary, opacity: 0.3 }} />
            <div className="text-xs font-semibold">{label}</div>
          </div>
        ))}
      </div>

      {/* Featured Camps */}
      <div className={cn("px-5 pb-6", template === "minimal" ? "bg-slate-50" : baseStyles.bg, baseStyles.text)}>
        <div className="flex items-center justify-between mb-3">
          <h3 className={cn("text-sm font-bold", template === "minimal" && "text-slate-900")}>Upcoming Camps</h3>
          <span
            className="text-[10px] font-semibold uppercase tracking-wider"
            style={{ color: primary }}
          >
            View all →
          </span>
        </div>
        <div className={cn(
          "rounded-lg overflow-hidden border",
          template === "minimal" ? "bg-white border-slate-200" : "bg-white/5 border-white/10"
        )}>
          <div
            className="h-16 relative"
            style={{ background: `linear-gradient(135deg, ${primary}, ${secondary})` }}
          >
            <span className="absolute top-2 right-2 rounded-full bg-white/90 text-slate-900 px-2 py-0.5 text-[9px] font-bold uppercase tracking-wider">
              Enrolling
            </span>
          </div>
          <div className={cn("p-3", template === "minimal" ? "text-slate-900" : "text-white")}>
            <div className="flex items-start justify-between gap-2">
              <div className="min-w-0">
                <div className="text-sm font-bold truncate">Elite Skating Camp</div>
                <div className={cn("text-[11px] mt-0.5", template === "minimal" ? "text-slate-500" : "opacity-70")}>
                  Wed–Fri · 9:00–12:00 PM · Rink A
                </div>
                <div className={cn("text-[11px]", template === "minimal" ? "text-slate-500" : "opacity-70")}>
                  Ages 10–14 · 12 spots left
                </div>
              </div>
              <button
                className="shrink-0 rounded-md px-3 py-1.5 text-[11px] font-semibold text-white"
                style={{ background: `linear-gradient(135deg, ${primary}, ${secondary})` }}
              >
                Register
              </button>
            </div>
          </div>
        </div>
      </div>

    </div>
  );
}

function Section({ icon: Icon, title, children, defaultOpen = false }: { icon: typeof Globe; title: string; children: React.ReactNode; defaultOpen?: boolean }) {
  const [open, setOpen] = useState(defaultOpen);
  return (
    <div className="rounded-lg border border-border bg-card overflow-hidden">
      <button onClick={() => setOpen(!open)} className="w-full flex items-center justify-between px-4 py-3 hover:bg-accent/30">
        <div className="flex items-center gap-2">
          <Icon className="h-4 w-4 text-teal-400" />
          <span className="font-semibold text-sm">{title}</span>
        </div>
        {open ? <ChevronUp className="h-4 w-4 text-muted-foreground" /> : <ChevronDown className="h-4 w-4 text-muted-foreground" />}
      </button>
      {open && <div className="px-4 py-3 space-y-3 border-t border-border">{children}</div>}
    </div>
  );
}

function Field({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <div className="space-y-1.5">
      <Label className="text-xs">{label}</Label>
      {children}
    </div>
  );
}

function IconInput({ icon: Icon, ...props }: { icon: typeof Globe } & React.InputHTMLAttributes<HTMLInputElement>) {
  return (
    <div className="relative">
      <Icon className="absolute left-3 top-1/2 -translate-y-1/2 h-3.5 w-3.5 text-muted-foreground" />
      <Input {...props} className="pl-9" />
    </div>
  );
}

/* -------------- Pages tab -------------- */

function PagesTab({ onChange }: { onChange: () => void }) {
  const [pages, setPages] = useState(DEFAULT_PAGES);

  const toggle = (id: string) => {
    if (id === "home") return;
    setPages((p) => p.map((x) => x.id === id ? { ...x, visible: !x.visible } : x));
    onChange();
  };

  const sourceBadge = (src: PageDef["source"]) => {
    const styles = {
      auto: "bg-teal-500/15 text-teal-400 ring-teal-500/30",
      manual: "bg-blue-500/15 text-blue-400 ring-blue-500/30",
      mixed: "bg-violet-500/15 text-violet-400 ring-violet-500/30",
    };
    return <span className={cn("rounded-full px-2 py-0.5 text-[10px] font-semibold uppercase tracking-wider ring-1", styles[src])}>{src}</span>;
  };

  return (
    <div className="space-y-4">
      <div className="rounded-lg border border-teal-500/30 bg-teal-500/5 p-4 text-sm">
        <div className="flex items-start gap-2">
          <Sparkles className="h-4 w-4 text-teal-400 mt-0.5 shrink-0" />
          <div>
            <strong className="text-teal-400">No double entry.</strong> <span className="text-muted-foreground">Auto-populated pages pull live from Camps, Ice Times, Private Sessions, and Bookings. Edit content there — it appears here automatically.</span>
          </div>
        </div>
      </div>

      <div className="rounded-lg border border-border bg-card divide-y divide-border">
        {pages.map((page) => (
          <div key={page.id} className="flex items-center gap-4 p-4">
            <div className="flex-1 min-w-0">
              <div className="flex items-center gap-2">
                <h4 className="font-semibold text-sm">{page.name}</h4>
                {sourceBadge(page.source)}
                {page.id === "home" && <span className="text-[10px] text-muted-foreground">(always visible)</span>}
              </div>
              <p className="text-xs text-muted-foreground mt-0.5">{page.description}</p>
            </div>
            <Button variant="ghost" size="sm" onClick={() => toast.message(`Editing ${page.name}`, { description: page.source === "auto" ? "Auto content cannot be edited here." : "Inline editor opening…" })}>
              <Edit3 className="h-3.5 w-3.5 mr-1" /> Edit
            </Button>
            <div className="flex items-center gap-2">
              <Switch checked={page.visible} onCheckedChange={() => toggle(page.id)} disabled={page.id === "home"} />
              <span className="text-xs text-muted-foreground w-12">{page.visible ? "Visible" : "Hidden"}</span>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

/* -------------- Settings tab -------------- */

function SettingsTab({ siteUrl, onChange }: { siteUrl: string; onChange: () => void }) {
  const [visibility, setVisibility] = useState<Visibility>("public");
  const [navOrder, setNavOrder] = useState(["Home","About","Camps","Privates","Schedule","Testimonials","Gallery","Book","Contact"]);
  const [hideBadge, setHideBadge] = useState(false);
  const [cookieBanner, setCookieBanner] = useState(true);
  const [customDomain, setCustomDomain] = useState("");

  const move = (from: number, to: number) => {
    if (to < 0 || to >= navOrder.length) return;
    const next = [...navOrder];
    const [item] = next.splice(from, 1);
    next.splice(to, 0, item);
    setNavOrder(next);
    onChange();
  };

  return (
    <div className="grid grid-cols-2 gap-6">
      {/* URL & Domain */}
      <Card title="Page URL & Domain" icon={Globe}>
        <Field label="PXF URL (auto-assigned)">
          <div className="flex gap-2">
            <Input readOnly value={siteUrl} className="font-mono text-xs" />
            <Button variant="outline" size="sm" onClick={() => { navigator.clipboard.writeText(siteUrl); toast.success("Copied"); }}>
              <Copy className="h-3.5 w-3.5" />
            </Button>
          </div>
        </Field>
        <Field label="Custom Domain">
          <Input placeholder="www.jordandoehockey.com" value={customDomain} onChange={(e) => { setCustomDomain(e.target.value); onChange(); }} />
        </Field>
        {customDomain && (
          <div className="rounded-md bg-muted/30 border border-border p-3 text-xs space-y-1">
            <div className="font-semibold text-foreground">DNS Setup</div>
            <div className="font-mono text-muted-foreground">
              CNAME <strong>{customDomain.replace(/^www\./, "www")}</strong> → <strong>coaches.pxfhockey.com</strong>
            </div>
            <div className="font-mono text-muted-foreground">
              TXT <strong>_pxf-verify</strong> → <strong>pxf=abc123…</strong>
            </div>
            <Button variant="link" size="sm" className="h-auto p-0 text-teal-400">
              <ExternalLink className="h-3 w-3 mr-1" /> DNS instructions
            </Button>
          </div>
        )}
      </Card>

      {/* Visibility */}
      <Card title="Page Visibility" icon={Lock}>
        <div className="space-y-2">
          {([
            ["public","Public","Anyone with the link can view"],
            ["password","Password Protected","Requires a shared password"],
            ["draft","Draft (not published)","Only you can view"],
          ] as const).map(([val, label, desc]) => (
            <label key={val} className={cn(
              "flex items-start gap-3 rounded-md border p-3 cursor-pointer transition-colors",
              visibility === val ? "border-teal-500 bg-teal-500/5" : "border-border hover:bg-accent/30"
            )}>
              <input type="radio" name="vis" checked={visibility === val} onChange={() => { setVisibility(val); onChange(); }} className="mt-1 accent-teal-500" />
              <div className="flex-1">
                <div className="text-sm font-semibold">{label}</div>
                <div className="text-xs text-muted-foreground">{desc}</div>
              </div>
            </label>
          ))}
        </div>
        {visibility === "password" && (
          <Field label="Page Password"><Input type="password" placeholder="••••••••" /></Field>
        )}
      </Card>

      {/* Navigation */}
      <Card title="Navigation Order" icon={GripVertical}>
        <p className="text-xs text-muted-foreground">Drag to reorder. Click the eye to hide from nav without deleting the page.</p>
        <div className="space-y-1.5">
          {navOrder.map((item, i) => (
            <div key={item} className="flex items-center gap-2 rounded-md border border-border bg-background/50 px-3 py-2">
              <GripVertical className="h-4 w-4 text-muted-foreground cursor-move" />
              <span className="flex-1 text-sm font-medium">{item}</span>
              <div className="flex gap-1">
                <button onClick={() => move(i, i - 1)} className="text-muted-foreground hover:text-foreground p-1"><ChevronUp className="h-3 w-3" /></button>
                <button onClick={() => move(i, i + 1)} className="text-muted-foreground hover:text-foreground p-1"><ChevronDown className="h-3 w-3" /></button>
                <button className="text-muted-foreground hover:text-foreground p-1"><EyeOff className="h-3 w-3" /></button>
              </div>
            </div>
          ))}
        </div>
      </Card>

      {/* Footer & Branding */}
      <Card title="Footer & Branding" icon={Type}>
        <Field label="Custom Footer Text">
          <Textarea rows={2} placeholder="© 2026 Jordan Doe Hockey. All rights reserved." onChange={onChange} />
        </Field>
        <div className="flex items-center justify-between rounded-md border border-border p-3">
          <div>
            <div className="text-sm font-semibold">Hide "Powered by PXF Hockey" badge</div>
            <div className="text-xs text-muted-foreground">Available on paid plans</div>
          </div>
          <Switch checked={hideBadge} onCheckedChange={(v) => { setHideBadge(v); onChange(); }} />
        </div>
      </Card>

      {/* Analytics & Cookies */}
      <Card title="Analytics & Privacy" icon={Sparkles}>
        <Field label="Google Analytics 4 Measurement ID">
          <Input placeholder="G-XXXXXXXXXX" onChange={onChange} />
        </Field>
        <div className="flex items-center justify-between rounded-md border border-border p-3">
          <div>
            <div className="text-sm font-semibold">Cookie Consent Banner</div>
            <div className="text-xs text-muted-foreground">Show GDPR / CCPA consent</div>
          </div>
          <Switch checked={cookieBanner} onCheckedChange={(v) => { setCookieBanner(v); onChange(); }} />
        </div>
      </Card>

      {/* SEO */}
      <Card title="SEO Defaults" icon={Globe}>
        <p className="text-xs text-muted-foreground">Per-page meta titles and descriptions can be edited in the Pages tab.</p>
        <Field label="Default Meta Title">
          <Input defaultValue="Jordan Doe — Elite Skating Coach" onChange={onChange} />
        </Field>
        <Field label="Default Meta Description">
          <Textarea rows={2} defaultValue="Book camps and private sessions with Jordan Doe — 12 years developing elite skaters." onChange={onChange} />
        </Field>
      </Card>
    </div>
  );
}

function Card({ title, icon: Icon, children }: { title: string; icon: typeof Globe; children: React.ReactNode }) {
  return (
    <div className="rounded-lg border border-border bg-card p-5 space-y-4">
      <div className="flex items-center gap-2">
        <Icon className="h-4 w-4 text-teal-400" />
        <h3 className="font-semibold text-sm">{title}</h3>
      </div>
      {children}
    </div>
  );
}
