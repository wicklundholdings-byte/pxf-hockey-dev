import { useState } from "react";
import { Plus, MapPin, Calendar, ArrowRight, X, Users, User, Search } from "lucide-react";
import { Link } from "@tanstack/react-router";

type EventType = "CAMP" | "PRIVATE" | "PRACTICE" | "CLINIC";
type EventStatus = "DRAFT" | "PUBLISHED" | "ACTIVE" | "COMPLETE" | "UPCOMING";

type EventItem = {
  id: string;
  type: EventType;
  name: string;
  location: string;
  dates: string;
  filled?: number;
  capacity?: number;
  revenue?: number;
  revenueLabel?: string;
  status: EventStatus;
  next?: string;
};

const EVENTS: EventItem[] = [
  {
    id: "1",
    type: "CAMP",
    name: "Elite Skating Camp",
    location: "Rink A",
    dates: "Jul 1 – Jul 5",
    filled: 38,
    capacity: 40,
    revenue: 5700,
    status: "ACTIVE",
    next: "Fri Jul 4 · 9:00 AM · Rink A",
  },
  {
    id: "2",
    type: "PRIVATE",
    name: "Emma Wilson",
    location: "Studio B",
    dates: "Recurring Tue / Thu",
    filled: 1,
    capacity: 1,
    revenueLabel: "$180/session",
    status: "ACTIVE",
    next: "Tue Jul 8 · 4:30 PM · Studio B",
  },
  {
    id: "3",
    type: "CAMP",
    name: "Goalie Development",
    location: "Rink B",
    dates: "Jul 8 – Jul 10",
    filled: 12,
    capacity: 14,
    revenue: 1800,
    status: "PUBLISHED",
    next: "Mon Jul 8 · 8:00 AM · Rink B",
  },
  {
    id: "4",
    type: "CAMP",
    name: "Power Skating",
    location: "Rink C",
    dates: "Jun 15 – Jun 19",
    filled: 30,
    capacity: 30,
    revenue: 4500,
    status: "COMPLETE",
  },
];

const typeBadge: Record<EventType, string> = {
  CAMP: "bg-teal-500/15 text-teal-400 ring-teal-500/30",
  PRIVATE: "bg-purple-500/15 text-purple-400 ring-purple-500/30",
  PRACTICE: "bg-blue-500/15 text-blue-400 ring-blue-500/30",
  CLINIC: "bg-orange-500/15 text-orange-400 ring-orange-500/30",
};

const statusBadge: Record<EventStatus, string> = {
  DRAFT: "bg-muted text-muted-foreground ring-border",
  PUBLISHED: "bg-sky-500/15 text-sky-400 ring-sky-500/30",
  ACTIVE: "bg-emerald-500/15 text-emerald-400 ring-emerald-500/30",
  UPCOMING: "bg-blue-500/15 text-blue-400 ring-blue-500/30",
  COMPLETE: "bg-slate-500/15 text-slate-400 ring-slate-500/30",
};

const FILTERS = ["All", "Camps", "Privates"] as const;
type Filter = (typeof FILTERS)[number];

const filterToType: Record<Filter, EventType | "ALL"> = {
  All: "ALL",
  Camps: "CAMP",
  Privates: "PRIVATE",
};

export function AssociationCamps() {
  const [tab, setTab] = useState<"events" | "series">("events");
  const [createOpen, setCreateOpen] = useState(false);

  return (
    <div className="space-y-5">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <h2 className="text-xl font-semibold tracking-tight">Camps & Privates</h2>
          <p className="text-sm text-muted-foreground">
            Manage your paid camps and private sessions.
          </p>
        </div>
        {tab === "events" && (
          <button
            onClick={() => setCreateOpen(true)}
            className="inline-flex items-center gap-1.5 rounded-md bg-gradient-to-r from-teal-500 to-emerald-500 px-3 py-2 text-xs font-semibold text-white shadow-sm hover:opacity-90"
          >
            <Plus className="h-3.5 w-3.5" /> Create
          </button>
        )}
      </div>

      {createOpen && <CreateModal onClose={() => setCreateOpen(false)} />}

      {/* Tabs */}
      <div className="flex items-center gap-1 border-b border-border">
        {(["events", "series"] as const).map((t) => (
          <button
            key={t}
            onClick={() => setTab(t)}
            className={`relative px-4 py-2 text-sm font-medium transition ${
              tab === t
                ? "text-foreground after:absolute after:bottom-0 after:left-0 after:right-0 after:h-0.5 after:bg-gradient-to-r after:from-teal-500 after:to-emerald-500"
                : "text-muted-foreground hover:text-foreground"
            }`}
          >
            {t === "events" ? "Events" : "Series"}
          </button>
        ))}
      </div>

      {tab === "events" ? <EventsTab /> : <SeriesTab />}
    </div>
  );
}

function EventsTab() {
  const [filter, setFilter] = useState<Filter>("All");

  const filtered = EVENTS.filter((e) => {
    const t = filterToType[filter];
    return t === "ALL" || e.type === t;
  });

  return (
    <div className="space-y-4">
      {/* Filter chips */}
      <div className="flex flex-wrap items-center gap-1.5">
        {FILTERS.map((f) => (
          <button
            key={f}
            onClick={() => setFilter(f)}
            className={`rounded-full px-3 py-1 text-xs font-semibold ring-1 ring-inset transition ${
              filter === f
                ? "bg-gradient-to-r from-teal-500 to-emerald-500 text-white ring-transparent"
                : "bg-card text-muted-foreground ring-border hover:text-foreground"
            }`}
          >
            {f}
          </button>
        ))}
      </div>

      {/* Event cards */}
      <div className="space-y-2.5">
        {filtered.map((e) => (
          <EventCard key={e.id} event={e} />
        ))}
      </div>
    </div>
  );
}

function EventCard({ event: e }: { event: EventItem }) {
  const pct = e.capacity ? Math.round(((e.filled ?? 0) / e.capacity) * 100) : 0;
  const showProgress = e.type === "CAMP" && e.capacity !== undefined;

  const isPrivate = e.type === "PRIVATE";
  return (
    <Link
      to={isPrivate ? "/privates/$privateId" : "/camps/$campId"}
      params={isPrivate ? { privateId: e.id } : { campId: e.id }}
      className="block rounded-lg border border-border bg-card p-4 transition hover:border-teal-500/40 hover:bg-teal-500/[0.03] cursor-pointer"
    >
      <div className="flex items-start justify-between gap-3">
        <div className="min-w-0 flex-1">
          <div className="flex items-center gap-2 flex-wrap">
            <span className={`rounded px-1.5 py-0.5 text-[10px] font-bold ring-1 ring-inset ${typeBadge[e.type]}`}>
              {e.type}
            </span>
            <span className={`rounded px-1.5 py-0.5 text-[10px] font-bold ring-1 ring-inset ${statusBadge[e.status]}`}>
              {e.status}
            </span>
          </div>
          <div className="mt-1.5 flex flex-wrap items-baseline gap-x-2 gap-y-0.5">
            <span className="font-semibold text-foreground">{e.name}</span>
            <span className="text-xs text-muted-foreground flex items-center gap-1">
              <MapPin className="h-3 w-3" /> {e.location}
            </span>
          </div>
          <div className="mt-0.5 text-[11px] text-muted-foreground flex items-center gap-1">
            <Calendar className="h-3 w-3" /> {e.dates}
          </div>
        </div>

        <div className="text-right shrink-0">
          {e.revenue !== undefined && (
            <div className="text-sm font-semibold text-teal-400 tabular-nums">
              ${e.revenue.toLocaleString()}
            </div>
          )}
          {e.revenueLabel && (
            <div className="text-sm font-semibold text-teal-400 tabular-nums">{e.revenueLabel}</div>
          )}
        </div>
      </div>

      {showProgress && (
        <div className="mt-3">
          <div className="flex justify-between text-[11px] mb-1">
            <span className="text-muted-foreground uppercase tracking-wider font-semibold">Spots</span>
            <span className="font-medium tabular-nums">{e.filled}/{e.capacity}</span>
          </div>
          <div className="h-1 rounded-full bg-muted overflow-hidden">
            <div
              className="h-full bg-gradient-to-r from-teal-500 to-emerald-500"
              style={{ width: `${pct}%` }}
            />
          </div>
        </div>
      )}

      <div className="mt-3 border-t border-border pt-2.5 text-[11px] text-muted-foreground">
        {e.next ? <><span className="font-semibold uppercase tracking-wider">Next:</span> {e.next}</> : <span className="italic">No upcoming sessions</span>}
      </div>
    </Link>
  );
}

function SeriesTab() {
  return (
    <div className="rounded-lg border border-dashed border-border bg-card p-10 text-center">
      <h3 className="font-semibold">Manage series templates</h3>
      <p className="mt-2 text-sm text-muted-foreground">
        Reusable session templates for recurring camps, clinics, and practices live in the Playbook.
      </p>
      <Link
        to="/playbook"
        className="mt-4 inline-flex items-center gap-1 text-xs font-semibold text-teal-400 hover:text-teal-300"
      >
        Playbook → Series <ArrowRight className="h-3 w-3" />
      </Link>
    </div>
  );
}

// ================= Create modal =================

type CreateStep = "choose" | "camp" | "private";

function CreateModal({ onClose }: { onClose: () => void }) {
  const [step, setStep] = useState<CreateStep>("choose");

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
      <div
        className="absolute inset-0 bg-black/70 backdrop-blur-sm"
        onClick={onClose}
      />
      <div className="relative w-full max-w-2xl max-h-[90vh] overflow-y-auto rounded-xl border border-border bg-card shadow-2xl">
        <div className="flex items-center justify-between border-b border-border px-5 py-4">
          <h2 className="text-base font-semibold">
            {step === "choose"
              ? "What would you like to create?"
              : step === "camp"
                ? "Create Camp"
                : "Create Private Sessions"}
          </h2>
          <button
            onClick={onClose}
            className="rounded-md p-1 text-muted-foreground hover:bg-muted hover:text-foreground"
          >
            <X className="h-4 w-4" />
          </button>
        </div>

        <div className="p-5">
          {step === "choose" && <ChooseStep onPick={setStep} />}
          {step === "camp" && <CampForm onBack={() => setStep("choose")} onDone={onClose} />}
          {step === "private" && <PrivateForm onBack={() => setStep("choose")} onDone={onClose} />}
        </div>
      </div>
    </div>
  );
}

function ChooseStep({ onPick }: { onPick: (s: CreateStep) => void }) {
  return (
    <div className="grid gap-3 sm:grid-cols-2">
      <button
        onClick={() => onPick("camp")}
        className="group flex flex-col items-start gap-3 rounded-lg border border-border bg-background p-5 text-left transition hover:border-teal-500/50 hover:bg-teal-500/[0.04]"
      >
        <div className="rounded-md bg-teal-500/15 p-2.5 ring-1 ring-inset ring-teal-500/30">
          <Users className="h-5 w-5 text-teal-400" />
        </div>
        <div>
          <div className="flex items-center gap-2">
            <span className="rounded px-1.5 py-0.5 text-[10px] font-bold ring-1 ring-inset bg-teal-500/15 text-teal-400 ring-teal-500/30">
              CAMP
            </span>
            <span className="font-semibold">Camp</span>
          </div>
          <p className="mt-1.5 text-xs text-muted-foreground">
            Multi-session group event with registration
          </p>
        </div>
      </button>

      <button
        onClick={() => onPick("private")}
        className="group flex flex-col items-start gap-3 rounded-lg border border-border bg-background p-5 text-left transition hover:border-purple-500/50 hover:bg-purple-500/[0.04]"
      >
        <div className="rounded-md bg-purple-500/15 p-2.5 ring-1 ring-inset ring-purple-500/30">
          <User className="h-5 w-5 text-purple-400" />
        </div>
        <div>
          <div className="flex items-center gap-2">
            <span className="rounded px-1.5 py-0.5 text-[10px] font-bold ring-1 ring-inset bg-purple-500/15 text-purple-400 ring-purple-500/30">
              PRIVATE
            </span>
            <span className="font-semibold">Private Sessions</span>
          </div>
          <p className="mt-1.5 text-xs text-muted-foreground">
            1-on-1 or small group recurring sessions
          </p>
        </div>
      </button>
    </div>
  );
}

const inputCls =
  "w-full rounded-md border border-border bg-background px-3 py-2 text-sm text-foreground placeholder:text-muted-foreground focus:border-teal-500/50 focus:outline-none focus:ring-1 focus:ring-teal-500/40";

const labelCls = "block text-xs font-semibold uppercase tracking-wider text-muted-foreground mb-1.5";

const submitCls =
  "inline-flex items-center justify-center gap-1.5 rounded-md bg-gradient-to-r from-teal-500 to-emerald-500 px-4 py-2 text-sm font-semibold text-white shadow-sm hover:opacity-90";

const backCls =
  "inline-flex items-center gap-1.5 rounded-md border border-border bg-background px-3 py-2 text-xs font-medium text-muted-foreground hover:text-foreground";

function CampForm({ onBack, onDone }: { onBack: () => void; onDone: () => void }) {
  return (
    <form
      onSubmit={(e) => {
        e.preventDefault();
        onDone();
      }}
      className="space-y-4"
    >
      <div>
        <label className={labelCls}>Camp Name</label>
        <input className={inputCls} placeholder="e.g. Elite Skating Camp" required />
      </div>

      <div className="grid gap-3 sm:grid-cols-2">
        <div>
          <label className={labelCls}>Start Date</label>
          <input type="date" className={inputCls} required />
        </div>
        <div>
          <label className={labelCls}>End Date</label>
          <input type="date" className={inputCls} required />
        </div>
      </div>

      <div>
        <label className={labelCls}>Location</label>
        <input className={inputCls} placeholder="e.g. Rink A" required />
      </div>

      <div className="grid gap-3 sm:grid-cols-2">
        <div>
          <label className={labelCls}>Capacity</label>
          <input type="number" min={1} className={inputCls} placeholder="40" required />
        </div>
        <div>
          <label className={labelCls}>Price per Athlete</label>
          <input type="number" min={0} step="0.01" className={inputCls} placeholder="150" required />
        </div>
      </div>

      <div>
        <label className={labelCls}>Apply Series Template</label>
        <select className={inputCls} defaultValue="">
          <option value="">None</option>
          <option>Skating Level 1</option>
          <option>Skating Level 2</option>
          <option>Goalie Development</option>
          <option>Power Skating</option>
        </select>
      </div>

      <div>
        <label className={labelCls}>Description</label>
        <textarea
          rows={3}
          className={inputCls}
          placeholder="Brief description of the camp..."
        />
      </div>

      <div className="flex items-center justify-between pt-2">
        <button type="button" onClick={onBack} className={backCls}>
          ← Back
        </button>
        <button type="submit" className={submitCls}>
          Create Camp
        </button>
      </div>
    </form>
  );
}

const DAYS = ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"] as const;

function PrivateForm({ onBack, onDone }: { onBack: () => void; onDone: () => void }) {
  const [days, setDays] = useState<Record<string, boolean>>({});
  const toggle = (d: string) => setDays((prev) => ({ ...prev, [d]: !prev[d] }));

  return (
    <form
      onSubmit={(e) => {
        e.preventDefault();
        onDone();
      }}
      className="space-y-4"
    >
      <div>
        <label className={labelCls}>Athlete Name</label>
        <div className="relative">
          <Search className="pointer-events-none absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
          <input className={`${inputCls} pl-8`} placeholder="Search athletes..." required />
        </div>
      </div>

      <div>
        <label className={labelCls}>Schedule</label>
        <div className="flex flex-wrap gap-1.5">
          {DAYS.map((d) => {
            const on = !!days[d];
            return (
              <label
                key={d}
                className={`cursor-pointer rounded-full px-3 py-1 text-xs font-semibold ring-1 ring-inset transition ${
                  on
                    ? "bg-gradient-to-r from-teal-500 to-emerald-500 text-white ring-transparent"
                    : "bg-background text-muted-foreground ring-border hover:text-foreground"
                }`}
              >
                <input
                  type="checkbox"
                  className="sr-only"
                  checked={on}
                  onChange={() => toggle(d)}
                />
                {d}
              </label>
            );
          })}
        </div>
      </div>

      <div className="grid gap-3 sm:grid-cols-2">
        <div>
          <label className={labelCls}>Time</label>
          <input type="time" className={inputCls} required />
        </div>
        <div>
          <label className={labelCls}>Location</label>
          <input className={inputCls} placeholder="e.g. Studio B" required />
        </div>
      </div>

      <div className="grid gap-3 sm:grid-cols-2">
        <div>
          <label className={labelCls}>Rate per Session</label>
          <input type="number" min={0} step="0.01" className={inputCls} placeholder="180" required />
        </div>
        <div>
          <label className={labelCls}>Start Date</label>
          <input type="date" className={inputCls} required />
        </div>
      </div>

      <div className="flex items-center justify-between pt-2">
        <button type="button" onClick={onBack} className={backCls}>
          ← Back
        </button>
        <button type="submit" className={submitCls}>
          Create Private
        </button>
      </div>
    </form>
  );
}
