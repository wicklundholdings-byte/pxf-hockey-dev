import { useMemo, useState } from "react";
import { Search, Plus, X, Mail, Send, ShieldCheck, UserMinus, Clock } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import {
  Table, TableBody, TableCell, TableHead, TableHeader, TableRow,
} from "@/components/ui/table";
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from "@/components/ui/select";
import { Sheet, SheetContent, SheetHeader, SheetTitle } from "@/components/ui/sheet";
import { Badge } from "@/components/ui/badge";
import { cn } from "@/lib/utils";
import { toast } from "sonner";

type Role =
  | "President"
  | "Vice President"
  | "Treasurer"
  | "Secretary"
  | "Registrar"
  | "Ice Allocator"
  | "Coach Coordinator"
  | "Safe Sport Officer"
  | "Director at Large"
  | "Custom";

type Status = "ACTIVE" | "INACTIVE" | "PENDING";

type Member = {
  id: string;
  first: string;
  last: string;
  email: string;
  phone: string;
  role: Role;
  customRole?: string;
  termStart: string;
  termEnd: string;
  status: Status;
  invitedAt?: string;
  notes?: string;
  initials: string;
};

const ROLES: Role[] = [
  "President", "Vice President", "Treasurer", "Secretary", "Registrar",
  "Ice Allocator", "Coach Coordinator", "Safe Sport Officer", "Director at Large", "Custom",
];

type Section =
  | "Dashboard" | "Teams" | "Camps" | "Registrations" | "Coaches" | "Athletes"
  | "Referees" | "Ice Times" | "Financials" | "Safety & Incidents"
  | "Communications" | "Apparel" | "Website" | "Board & Staff" | "Settings";

const ALL_SECTIONS: Section[] = [
  "Dashboard", "Teams", "Camps", "Registrations", "Coaches", "Athletes",
  "Referees", "Ice Times", "Financials", "Safety & Incidents",
  "Communications", "Apparel", "Website", "Board & Staff", "Settings",
];

type Access = "full" | "read" | "none";

function permsForRole(role: Role): Record<Section, Access> {
  const all = (a: Access) => Object.fromEntries(ALL_SECTIONS.map((s) => [s, a])) as Record<Section, Access>;
  switch (role) {
    case "President":
    case "Vice President":
      return all("full");
    case "Treasurer": {
      const p = all("read"); p["Financials"] = "full"; return p;
    }
    case "Registrar": {
      const p = all("read"); p["Registrations"] = "full"; p["Athletes"] = "full"; return p;
    }
    case "Ice Allocator": {
      const p = all("read"); p["Ice Times"] = "full"; p["Teams"] = "read"; return p;
    }
    case "Coach Coordinator": {
      const p = all("read"); p["Coaches"] = "full"; p["Teams"] = "read"; return p;
    }
    case "Safe Sport Officer": {
      const p = all("read"); p["Safety & Incidents"] = "full"; return p;
    }
    case "Director at Large": {
      const p = all("none"); p["Dashboard"] = "read"; p["Teams"] = "read"; return p;
    }
    default:
      return all("none");
  }
}

const SEED: Member[] = [
  { id: "m1", first: "Karen", last: "Doyle", email: "kdoyle@nlh.ca", phone: "(204) 555-0101", role: "President", termStart: "2024-09-01", termEnd: "2026-08-31", status: "ACTIVE", initials: "KD", notes: "Board chair, signing officer." },
  { id: "m2", first: "Anthony", last: "Russo", email: "arusso@nlh.ca", phone: "(204) 555-0142", role: "Vice President", termStart: "2024-09-01", termEnd: "2026-08-31", status: "ACTIVE", initials: "AR" },
  { id: "m3", first: "Sandra", last: "Petros", email: "spetros@nlh.ca", phone: "(204) 555-0163", role: "Treasurer", termStart: "2024-09-01", termEnd: "2026-08-31", status: "ACTIVE", initials: "SP" },
  { id: "m4", first: "Dale", last: "MacKay", email: "dmackay@nlh.ca", phone: "(204) 555-0177", role: "Secretary", termStart: "2024-09-01", termEnd: "2026-08-31", status: "ACTIVE", initials: "DM" },
  { id: "m5", first: "Lena", last: "Park", email: "lpark@nlh.ca", phone: "(204) 555-0118", role: "Registrar", termStart: "2024-09-01", termEnd: "2026-08-31", status: "ACTIVE", initials: "LP" },
  { id: "m6", first: "Marcus", last: "Bell", email: "mbell@nlh.ca", phone: "(204) 555-0123", role: "Ice Allocator", termStart: "2025-01-15", termEnd: "2026-12-31", status: "ACTIVE", initials: "MB" },
  { id: "m7", first: "Priya", last: "Singh", email: "psingh@nlh.ca", phone: "(204) 555-0188", role: "Coach Coordinator", termStart: "2024-09-01", termEnd: "2026-08-31", status: "ACTIVE", initials: "PS" },
  { id: "m8", first: "Janet", last: "Holloway", email: "jholloway@nlh.ca", phone: "(204) 555-0199", role: "Safe Sport Officer", termStart: "2024-09-01", termEnd: "2027-08-31", status: "ACTIVE", initials: "JH", notes: "Confidential reporting lead." },
  { id: "m9", first: "Owen", last: "Tremblay", email: "otremblay@nlh.ca", phone: "(204) 555-0211", role: "Director at Large", termStart: "2025-09-01", termEnd: "2027-08-31", status: "ACTIVE", initials: "OT" },
  { id: "m10", first: "Riley", last: "Chen", email: "rchen@nlh.ca", phone: "(204) 555-0234", role: "Director at Large", termStart: "2025-11-04", termEnd: "2027-08-31", status: "PENDING", invitedAt: "2025-11-04", initials: "RC" },
  { id: "m11", first: "Carl", last: "Whitman", email: "cwhitman@nlh.ca", phone: "(204) 555-0277", role: "Treasurer", termStart: "2022-09-01", termEnd: "2024-08-31", status: "INACTIVE", initials: "CW", notes: "Previous treasurer, term ended Aug 2024." },
];

function StatusBadge({ s }: { s: Status }) {
  const map: Record<Status, string> = {
    ACTIVE: "bg-emerald-500/15 text-emerald-400 ring-emerald-500/30",
    PENDING: "bg-amber-500/15 text-amber-400 ring-amber-500/30",
    INACTIVE: "bg-muted text-muted-foreground ring-border",
  };
  return (
    <span className={cn("inline-block rounded-full px-2 py-0.5 text-[10px] font-semibold uppercase tracking-wider ring-1", map[s])}>
      {s}
    </span>
  );
}

function daysSince(iso?: string) {
  if (!iso) return 0;
  return Math.floor((Date.now() - new Date(iso).getTime()) / 86400000);
}

export function AssociationBoard() {
  const [members, setMembers] = useState<Member[]>(SEED);
  const [q, setQ] = useState("");
  const [roleFilter, setRoleFilter] = useState<string>("all");
  const [statusFilter, setStatusFilter] = useState<string>("all");
  const [selectedId, setSelectedId] = useState<string | null>(null);
  const [inviteOpen, setInviteOpen] = useState(false);

  const filtered = useMemo(() => {
    return members.filter((m) => {
      if (roleFilter !== "all" && m.role !== roleFilter) return false;
      if (statusFilter !== "all" && m.status !== statusFilter) return false;
      if (q) {
        const t = q.toLowerCase();
        if (!`${m.first} ${m.last} ${m.email}`.toLowerCase().includes(t)) return false;
      }
      return true;
    });
  }, [members, q, roleFilter, statusFilter]);

  const selected = members.find((m) => m.id === selectedId) ?? null;

  function deactivate(id: string) {
    setMembers((arr) => arr.map((m) => (m.id === id ? { ...m, status: "INACTIVE" } : m)));
    toast.success("Member deactivated. Portal access revoked.");
  }
  function resendInvite(m: Member) {
    setMembers((arr) => arr.map((x) => (x.id === m.id ? { ...x, invitedAt: new Date().toISOString().slice(0, 10) } : x)));
    toast.success(`Invite re-sent to ${m.email} via Resend.`);
  }
  function addInvite(payload: Omit<Member, "id" | "status" | "initials" | "invitedAt">) {
    const initials = (payload.first[0] ?? "") + (payload.last[0] ?? "");
    const m: Member = {
      ...payload,
      id: `m${Date.now()}`,
      status: "PENDING",
      invitedAt: new Date().toISOString().slice(0, 10),
      initials: initials.toUpperCase(),
    };
    setMembers((arr) => [m, ...arr]);
    toast.success(`Invite sent to ${m.email} via Resend.`);
    setInviteOpen(false);
  }

  return (
    <div className="space-y-4">
      {/* Toolbar */}
      <div className="flex flex-wrap items-center gap-3">
        <div className="relative flex-1 min-w-[240px] max-w-md">
          <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
          <Input value={q} onChange={(e) => setQ(e.target.value)} placeholder="Search name or email" className="pl-8" />
        </div>
        <Select value={roleFilter} onValueChange={setRoleFilter}>
          <SelectTrigger className="w-[200px]"><SelectValue placeholder="Role" /></SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All roles</SelectItem>
            {ROLES.map((r) => <SelectItem key={r} value={r}>{r}</SelectItem>)}
          </SelectContent>
        </Select>
        <Select value={statusFilter} onValueChange={setStatusFilter}>
          <SelectTrigger className="w-[160px]"><SelectValue placeholder="Status" /></SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All status</SelectItem>
            <SelectItem value="ACTIVE">Active</SelectItem>
            <SelectItem value="PENDING">Pending</SelectItem>
            <SelectItem value="INACTIVE">Inactive</SelectItem>
          </SelectContent>
        </Select>
        <div className="ml-auto">
          <Button onClick={() => setInviteOpen(true)} className="bg-teal-500 hover:bg-teal-600 text-white">
            <Plus className="h-4 w-4 mr-1.5" /> Invite Member
          </Button>
        </div>
      </div>

      {/* Table */}
      <div className="rounded-lg border border-border bg-card">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Name</TableHead>
              <TableHead>Role</TableHead>
              <TableHead>Email</TableHead>
              <TableHead>Phone</TableHead>
              <TableHead>Term Start</TableHead>
              <TableHead>Term End</TableHead>
              <TableHead>Status</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {filtered.map((m) => (
              <TableRow key={m.id} onClick={() => setSelectedId(m.id)} className="cursor-pointer">
                <TableCell>
                  <div className="flex items-center gap-2.5">
                    <div className="flex h-8 w-8 items-center justify-center rounded-full bg-gradient-to-br from-teal-500/30 to-emerald-500/30 text-xs font-semibold text-emerald-300 ring-1 ring-emerald-500/30">
                      {m.initials}
                    </div>
                    <div>
                      <div className="font-medium text-sm">{m.first} {m.last}</div>
                      {m.status === "PENDING" && m.invitedAt && daysSince(m.invitedAt) >= 7 && (
                        <div className="text-[10px] text-amber-400 flex items-center gap-1 mt-0.5">
                          <Clock className="h-3 w-3" /> Invite stale ({daysSince(m.invitedAt)}d)
                        </div>
                      )}
                    </div>
                  </div>
                </TableCell>
                <TableCell><span className="text-sm">{m.role === "Custom" ? m.customRole ?? "Custom" : m.role}</span></TableCell>
                <TableCell className="text-sm text-muted-foreground">{m.email}</TableCell>
                <TableCell className="text-sm text-muted-foreground">{m.phone}</TableCell>
                <TableCell className="text-sm">{m.termStart}</TableCell>
                <TableCell className="text-sm">{m.termEnd}</TableCell>
                <TableCell><StatusBadge s={m.status} /></TableCell>
              </TableRow>
            ))}
            {filtered.length === 0 && (
              <TableRow><TableCell colSpan={7} className="text-center text-sm text-muted-foreground py-10">No members match these filters.</TableCell></TableRow>
            )}
          </TableBody>
        </Table>
      </div>

      <MemberPanel
        member={selected}
        onClose={() => setSelectedId(null)}
        onDeactivate={deactivate}
        onResend={resendInvite}
        onSaveNotes={(id, notes) => setMembers((arr) => arr.map((m) => m.id === id ? { ...m, notes } : m))}
      />

      <InviteDrawer open={inviteOpen} onClose={() => setInviteOpen(false)} onInvite={addInvite} />
    </div>
  );
}

function MemberPanel({
  member, onClose, onDeactivate, onResend, onSaveNotes,
}: {
  member: Member | null;
  onClose: () => void;
  onDeactivate: (id: string) => void;
  onResend: (m: Member) => void;
  onSaveNotes: (id: string, notes: string) => void;
}) {
  const [notes, setNotes] = useState("");

  if (!member) return null;
  const perms = permsForRole(member.role);

  return (
    <Sheet open={!!member} onOpenChange={(o) => !o && onClose()}>
      <SheetContent side="right" className="w-full sm:max-w-[520px] overflow-y-auto">
        <SheetHeader>
          <div className="flex items-start gap-3">
            <div className="flex h-14 w-14 items-center justify-center rounded-full bg-gradient-to-br from-teal-500/30 to-emerald-500/30 text-base font-bold text-emerald-300 ring-1 ring-emerald-500/30">
              {member.initials}
            </div>
            <div className="flex-1 min-w-0">
              <SheetTitle className="text-lg">{member.first} {member.last}</SheetTitle>
              <div className="flex items-center gap-2 mt-1">
                <Badge variant="outline" className="text-[10px] uppercase tracking-wider">
                  {member.role === "Custom" ? member.customRole ?? "Custom" : member.role}
                </Badge>
                <StatusBadge s={member.status} />
              </div>
            </div>
          </div>
        </SheetHeader>

        <div className="mt-6 space-y-6">
          <div className="grid grid-cols-2 gap-3 text-sm">
            <div>
              <div className="text-[11px] uppercase tracking-wider text-muted-foreground">Email</div>
              <div className="truncate">{member.email}</div>
            </div>
            <div>
              <div className="text-[11px] uppercase tracking-wider text-muted-foreground">Phone</div>
              <div>{member.phone}</div>
            </div>
            <div>
              <div className="text-[11px] uppercase tracking-wider text-muted-foreground">Term Start</div>
              <div>{member.termStart}</div>
            </div>
            <div>
              <div className="text-[11px] uppercase tracking-wider text-muted-foreground">Term End</div>
              <div>{member.termEnd}</div>
            </div>
          </div>

          {/* Permissions */}
          <div>
            <div className="flex items-center gap-2 mb-2">
              <ShieldCheck className="h-4 w-4 text-emerald-400" />
              <h4 className="text-sm font-semibold">Portal Permissions</h4>
              <span className="text-[10px] text-muted-foreground">(set automatically by role)</span>
            </div>
            <div className="rounded-md border border-border divide-y divide-border">
              {ALL_SECTIONS.map((s) => {
                const a = perms[s];
                return (
                  <div key={s} className="flex items-center justify-between px-3 py-1.5 text-xs">
                    <span>{s}</span>
                    <span className={cn(
                      "rounded px-1.5 py-0.5 text-[10px] font-semibold uppercase",
                      a === "full" && "bg-emerald-500/15 text-emerald-400",
                      a === "read" && "bg-blue-500/15 text-blue-400",
                      a === "none" && "bg-muted text-muted-foreground",
                    )}>
                      {a === "full" ? "Full" : a === "read" ? "Read-only" : "—"}
                    </span>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Notes */}
          <div>
            <Label className="text-xs uppercase tracking-wider text-muted-foreground">Internal Notes</Label>
            <Textarea
              className="mt-1.5"
              rows={3}
              placeholder="Internal only — not shared with the member."
              defaultValue={member.notes ?? ""}
              onChange={(e) => setNotes(e.target.value)}
            />
            <div className="flex justify-end mt-2">
              <Button size="sm" variant="outline" onClick={() => { onSaveNotes(member.id, notes || member.notes || ""); toast.success("Notes saved."); }}>
                Save notes
              </Button>
            </div>
          </div>

          {/* Actions */}
          <div className="flex flex-wrap gap-2 pt-2 border-t border-border">
            {member.status === "PENDING" && (
              <Button size="sm" variant="outline" onClick={() => onResend(member)}>
                <Mail className="h-4 w-4 mr-1.5" /> Resend invite
              </Button>
            )}
            {member.status !== "INACTIVE" && (
              <Button size="sm" variant="outline" className="text-red-400 border-red-500/40 hover:bg-red-500/10" onClick={() => onDeactivate(member.id)}>
                <UserMinus className="h-4 w-4 mr-1.5" /> Deactivate
              </Button>
            )}
            <Button size="sm" variant="ghost" className="ml-auto" onClick={onClose}>
              <X className="h-4 w-4 mr-1.5" /> Close
            </Button>
          </div>
        </div>
      </SheetContent>
    </Sheet>
  );
}

function InviteDrawer({
  open, onClose, onInvite,
}: {
  open: boolean;
  onClose: () => void;
  onInvite: (m: Omit<Member, "id" | "status" | "initials" | "invitedAt">) => void;
}) {
  const [first, setFirst] = useState("");
  const [last, setLast] = useState("");
  const [email, setEmail] = useState("");
  const [phone, setPhone] = useState("");
  const [role, setRole] = useState<Role>("Director at Large");
  const [customRole, setCustomRole] = useState("");
  const [termStart, setTermStart] = useState("");
  const [termEnd, setTermEnd] = useState("");

  function reset() {
    setFirst(""); setLast(""); setEmail(""); setPhone("");
    setRole("Director at Large"); setCustomRole(""); setTermStart(""); setTermEnd("");
  }

  function submit() {
    if (!first || !last || !email || !termStart || !termEnd) {
      toast.error("Fill in name, email, and term dates.");
      return;
    }
    if (role === "Custom" && !customRole) {
      toast.error("Enter a custom role name.");
      return;
    }
    onInvite({ first, last, email, phone, role, customRole: role === "Custom" ? customRole : undefined, termStart, termEnd });
    reset();
  }

  const perms = permsForRole(role);

  return (
    <Sheet open={open} onOpenChange={(o) => { if (!o) { onClose(); reset(); } }}>
      <SheetContent side="right" className="w-full sm:max-w-[520px] overflow-y-auto">
        <SheetHeader>
          <SheetTitle>Invite Board / Staff Member</SheetTitle>
        </SheetHeader>

        <div className="mt-6 space-y-4">
          <div className="grid grid-cols-2 gap-3">
            <div>
              <Label>First name</Label>
              <Input value={first} onChange={(e) => setFirst(e.target.value)} className="mt-1.5" />
            </div>
            <div>
              <Label>Last name</Label>
              <Input value={last} onChange={(e) => setLast(e.target.value)} className="mt-1.5" />
            </div>
          </div>
          <div>
            <Label>Email</Label>
            <Input type="email" value={email} onChange={(e) => setEmail(e.target.value)} className="mt-1.5" />
          </div>
          <div>
            <Label>Phone</Label>
            <Input value={phone} onChange={(e) => setPhone(e.target.value)} className="mt-1.5" />
          </div>
          <div>
            <Label>Role</Label>
            <Select value={role} onValueChange={(v) => setRole(v as Role)}>
              <SelectTrigger className="mt-1.5"><SelectValue /></SelectTrigger>
              <SelectContent>
                {ROLES.map((r) => <SelectItem key={r} value={r}>{r}</SelectItem>)}
              </SelectContent>
            </Select>
          </div>
          {role === "Custom" && (
            <div>
              <Label>Custom role name</Label>
              <Input value={customRole} onChange={(e) => setCustomRole(e.target.value)} className="mt-1.5" />
            </div>
          )}
          <div className="grid grid-cols-2 gap-3">
            <div>
              <Label>Term start</Label>
              <Input type="date" value={termStart} onChange={(e) => setTermStart(e.target.value)} className="mt-1.5" />
            </div>
            <div>
              <Label>Term end</Label>
              <Input type="date" value={termEnd} onChange={(e) => setTermEnd(e.target.value)} className="mt-1.5" />
            </div>
          </div>

          <div className="rounded-md border border-border bg-muted/30 p-3">
            <div className="flex items-center gap-2 mb-2">
              <ShieldCheck className="h-4 w-4 text-emerald-400" />
              <span className="text-xs font-semibold">Permissions preview</span>
            </div>
            <div className="grid grid-cols-2 gap-x-3 gap-y-1 text-[11px]">
              {ALL_SECTIONS.map((s) => (
                <div key={s} className="flex items-center justify-between">
                  <span className="text-muted-foreground">{s}</span>
                  <span className={cn(
                    "font-semibold",
                    perms[s] === "full" && "text-emerald-400",
                    perms[s] === "read" && "text-blue-400",
                    perms[s] === "none" && "text-muted-foreground",
                  )}>
                    {perms[s] === "full" ? "Full" : perms[s] === "read" ? "Read" : "—"}
                  </span>
                </div>
              ))}
            </div>
          </div>

          <div className="flex justify-end gap-2 pt-2 border-t border-border">
            <Button variant="ghost" onClick={() => { onClose(); reset(); }}>Cancel</Button>
            <Button onClick={submit} className="bg-teal-500 hover:bg-teal-600 text-white">
              <Send className="h-4 w-4 mr-1.5" /> Send invite via Resend
            </Button>
          </div>
        </div>
      </SheetContent>
    </Sheet>
  );
}
