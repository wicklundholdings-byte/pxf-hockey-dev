import { useState, useRef } from "react";
import { User, Users, Snowflake, Globe, Bell, CreditCard, Save, Camera, Plus, Pencil, Upload, FileText, X } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter,
} from "@/components/ui/dialog";
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from "@/components/ui/select";
import { Switch } from "@/components/ui/switch";
import {
  Table, TableBody, TableCell, TableHead, TableHeader, TableRow,
} from "@/components/ui/table";
import { cn } from "@/lib/utils";
import { CoachWebsite } from "@/components/coach-website";
import { toast } from "sonner";


type TabKey = "profile" | "staff" | "ice" | "website" | "notifications" | "billing";

const TABS: { key: TabKey; label: string; icon: React.ElementType }[] = [
  { key: "profile", label: "Profile", icon: User },
  { key: "staff", label: "Staff & Rates", icon: Users },
  { key: "ice", label: "Ice Allocation", icon: Snowflake },
  { key: "website", label: "Website", icon: Globe },
  { key: "notifications", label: "Notifications", icon: Bell },
  { key: "billing", label: "Billing", icon: CreditCard },
];

export function CoachSettings() {
  const [activeTab, setActiveTab] = useState<TabKey>("profile");

  return (
    <div className="mx-auto max-w-[1200px]">
      <div className="mb-6">
        <h1 className="text-2xl font-semibold tracking-tight text-foreground">Settings</h1>
        <p className="mt-1 text-sm text-muted-foreground">Manage your profile, staff, ice, and portal preferences.</p>
      </div>

      <div className="grid grid-cols-[220px_1fr] gap-6 items-start">
        <aside className="sticky top-4 rounded-lg border border-border bg-card p-2">
          <ul className="space-y-0.5">
            {TABS.map((tab) => {
              const Icon = tab.icon;
              const active = activeTab === tab.key;
              return (
                <li key={tab.key}>
                  <button
                    onClick={() => setActiveTab(tab.key)}
                    className={cn(
                      "w-full flex items-center gap-2.5 rounded-md px-3 py-2 text-sm font-medium transition-colors text-left",
                      active && "bg-gradient-to-r from-teal-500 to-teal-400 text-teal-950",
                      !active && "text-muted-foreground hover:bg-muted hover:text-foreground"
                    )}
                  >
                    <Icon className="h-4 w-4" />
                    {tab.label}
                  </button>
                </li>
              );
            })}
          </ul>
        </aside>

        <div className="min-w-0">
          {activeTab === "profile" && <ProfileSection />}
          {activeTab === "staff" && <StaffRatesSection />}
          {activeTab === "ice" && <IceAllocationSection />}
          {activeTab === "website" && <CoachWebsite />}
          {activeTab === "notifications" && <NotificationsSection />}
          {activeTab === "billing" && <BillingSection />}
        </div>
      </div>
    </div>
  );
}

function Card({ title, desc, children, actions }: { title: string; desc?: string; children: React.ReactNode; actions?: React.ReactNode }) {
  return (
    <section className="rounded-lg border border-border bg-card p-6">
      <header className="flex items-start justify-between gap-4 mb-5">
        <div>
          <h3 className="text-base font-semibold">{title}</h3>
          {desc && <p className="text-xs text-muted-foreground mt-1">{desc}</p>}
        </div>
        {actions}
      </header>
      {children}
    </section>
  );
}


function Field({ label, children, hint }: { label: string; children: React.ReactNode; hint?: string }) {
  return (
    <div>
      <Label className="text-xs font-medium">{label}</Label>
      <div className="mt-1.5">{children}</div>
      {hint && <p className="text-[11px] text-muted-foreground mt-1">{hint}</p>}
    </div>
  );
}

function ProfileSection() {
  const [firstName, setFirstName] = useState("Jordan");
  const [lastName, setLastName] = useState("Doe");
  const [email, setEmail] = useState("jordan@pxfhockey.com");
  const [phone, setPhone] = useState("604-555-0100");
  const [bio, setBio] = useState(
    "Elite skating coach with 12 years experience specializing in edge work and speed development."
  );
  const [certifications, setCertifications] = useState("Hockey Canada Level 4");
  const [location, setLocation] = useState("Vancouver, BC");
  const [yearsExperience, setYearsExperience] = useState("12");
  const [photoPreview, setPhotoPreview] = useState<string | null>(null);
  const fileInputRef = useRef<HTMLInputElement | null>(null);

  const handlePhotoChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = (event) => setPhotoPreview(event.target?.result as string);
    reader.readAsDataURL(file);
  };

  const handleSave = () => {
    toast.success("Profile changes saved.");
  };

  return (
    <Card title="Profile" desc="Update your public profile and contact details.">
      <div className="space-y-5">
        <div className="flex items-center gap-4">
          <div className="relative h-20 w-20 rounded-full overflow-hidden bg-muted border border-border flex items-center justify-center shrink-0">
            {photoPreview ? (
              <img src={photoPreview} alt="Profile preview" className="h-full w-full object-cover" />
            ) : (
              <User className="h-8 w-8 text-muted-foreground" />
            )}
          </div>
          <div>
            <input
              ref={fileInputRef}
              type="file"
              accept="image/*"
              hidden
              onChange={handlePhotoChange}
            />
            <Button
              variant="outline"
              size="sm"
              onClick={() => fileInputRef.current?.click()}
            >
              <Camera className="h-4 w-4 mr-1.5" />
              Upload Photo
            </Button>
            <p className="text-[11px] text-muted-foreground mt-1">JPG or PNG, recommended 400×400</p>
          </div>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <Field label="First Name">
            <Input value={firstName} onChange={(e) => setFirstName(e.target.value)} />
          </Field>
          <Field label="Last Name">
            <Input value={lastName} onChange={(e) => setLastName(e.target.value)} />
          </Field>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <Field label="Email">
            <Input type="email" value={email} onChange={(e) => setEmail(e.target.value)} />
          </Field>
          <Field label="Phone">
            <Input type="tel" value={phone} onChange={(e) => setPhone(e.target.value)} />
          </Field>
        </div>

        <Field label="Bio" hint="Brief summary shown on your public profile.">
          <Textarea rows={4} value={bio} onChange={(e) => setBio(e.target.value)} />
        </Field>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <Field label="Certifications">
            <Input value={certifications} onChange={(e) => setCertifications(e.target.value)} />
          </Field>
          <Field label="Years Experience">
            <Input value={yearsExperience} onChange={(e) => setYearsExperience(e.target.value)} />
          </Field>
        </div>

        <Field label="Location">
          <Input value={location} onChange={(e) => setLocation(e.target.value)} />
        </Field>

        <div className="flex justify-end pt-4 border-t border-border">
          <Button
            onClick={handleSave}
            className="bg-gradient-to-r from-teal-500 to-teal-400 hover:from-teal-400 hover:to-teal-300 text-teal-950"
          >
            <Save className="h-4 w-4 mr-1.5" />
            Save Changes
          </Button>
        </div>
      </div>
    </Card>
  );
}

type StaffMember = {
  id: string;
  name: string;
  email: string;
  role: string;
  rateType: "Per Session" | "Hourly";
  rate: number;
  status: "ACTIVE" | "INVITED";
};

const ROLES = [
  "Head Coach",
  "Asst. Coach",
  "Skating Coach",
  "Goalie Coach",
  "Instructor",
];

const INITIAL_STAFF: StaffMember[] = [
  { id: "1", name: "Jordan Doe", email: "jordan@pxfhockey.com", role: "Head Coach", rateType: "Per Session", rate: 200, status: "ACTIVE" },
  { id: "2", name: "Mark Ellis", email: "mark@pxfhockey.com", role: "Asst. Coach", rateType: "Per Session", rate: 100, status: "ACTIVE" },
  { id: "3", name: "Sara Reid", email: "sara@pxfhockey.com", role: "Skating Coach", rateType: "Hourly", rate: 75, status: "ACTIVE" },
  { id: "4", name: "Tom Kim", email: "tom@pxfhockey.com", role: "Goalie Coach", rateType: "Per Session", rate: 125, status: "ACTIVE" },
];

function StaffRatesSection() {
  const [staff, setStaff] = useState<StaffMember[]>(INITIAL_STAFF);
  const [open, setOpen] = useState(false);
  const [editing, setEditing] = useState<StaffMember | null>(null);

  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [role, setRole] = useState("Head Coach");
  const [rateType, setRateType] = useState<"Per Session" | "Hourly">("Per Session");
  const [rate, setRate] = useState<string>("");

  const resetForm = () => {
    setName("");
    setEmail("");
    setRole("Head Coach");
    setRateType("Per Session");
    setRate("");
    setEditing(null);
  };

  const openAdd = () => {
    resetForm();
    setOpen(true);
  };

  const openEdit = (member: StaffMember) => {
    setEditing(member);
    setName(member.name);
    setEmail(member.email);
    setRole(member.role);
    setRateType(member.rateType);
    setRate(String(member.rate));
    setOpen(true);
  };

  const handleSave = () => {
    if (!name.trim() || !email.trim() || !rate.trim()) {
      toast.error("Please fill out all required fields.");
      return;
    }
    const rateNum = Number(rate);
    if (Number.isNaN(rateNum) || rateNum < 0) {
      toast.error("Rate must be a valid number.");
      return;
    }
    if (editing) {
      setStaff((prev) =>
        prev.map((s) =>
          s.id === editing.id
            ? { ...s, name: name.trim(), email: email.trim(), role, rateType, rate: rateNum }
            : s
        )
      );
      toast.success("Staff member updated.");
    } else {
      const newMember: StaffMember = {
        id: `staff-${Date.now()}`,
        name: name.trim(),
        email: email.trim(),
        role,
        rateType,
        rate: rateNum,
        status: "INVITED",
      };
      setStaff((prev) => [...prev, newMember]);
      toast.success("Invitation sent to join the school.");
    }
    setOpen(false);
    resetForm();
  };

  const formatRate = (member: StaffMember) => {
    if (member.rateType === "Hourly") return `$${member.rate}/hr`;
    return `$${member.rate}`;
  };

  const isValid = name.trim() && email.trim() && rate.trim() && !Number.isNaN(Number(rate)) && Number(rate) >= 0;

  return (
    <Card
      title="Staff & Rates"
      desc="Manage your coaching staff, pay rates, and invitations."
      actions={
        <Button onClick={openAdd} className="bg-teal-500 hover:bg-teal-400 text-teal-950">
          <Plus className="h-4 w-4 mr-1.5" />
          Add Staff Member
        </Button>
      }
    >
      <div className="rounded-md border border-border overflow-hidden">
        <Table>
          <TableHeader>
            <TableRow className="hover:bg-transparent">
              <TableHead>Name</TableHead>
              <TableHead>Role</TableHead>
              <TableHead>Rate Type</TableHead>
              <TableHead>Rate</TableHead>
              <TableHead>Status</TableHead>
              <TableHead className="text-right">Actions</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {staff.map((member) => (
              <TableRow key={member.id} className="hover:bg-muted/40">
                <TableCell className="font-medium">{member.name}</TableCell>
                <TableCell>{member.role}</TableCell>
                <TableCell>{member.rateType}</TableCell>
                <TableCell>{formatRate(member)}</TableCell>
                <TableCell>
                  <span className={cn(
                    "inline-flex rounded-full px-2 py-0.5 text-[11px] font-semibold",
                    member.status === "ACTIVE" ? "bg-emerald-500/15 text-emerald-400" : "bg-amber-500/15 text-amber-400"
                  )}>
                    {member.status}
                  </span>
                </TableCell>
                <TableCell className="text-right">
                  <Button variant="ghost" size="sm" onClick={() => openEdit(member)}>
                    <Pencil className="h-3.5 w-3.5 mr-1.5" />
                    Edit
                  </Button>
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </div>

      <p className="text-[11px] text-muted-foreground mt-4">
        Staff rates are used to auto-calculate costs in camp Financials.
      </p>

      <Dialog open={open} onOpenChange={setOpen}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>{editing ? "Edit Staff Member" : "Add Staff Member"}</DialogTitle>
          </DialogHeader>
          <div className="space-y-4 py-2">
            <Field label="Name">
              <Input value={name} onChange={(e) => setName(e.target.value)} placeholder="Full name" />
            </Field>
            <Field label="Email">
              <Input type="email" value={email} onChange={(e) => setEmail(e.target.value)} placeholder="email@example.com" />
            </Field>
            <Field label="Role">
              <Select value={role} onValueChange={setRole}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {ROLES.map((r) => (
                    <SelectItem key={r} value={r}>{r}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </Field>
            <Field label="Rate Type">
              <div className="grid grid-cols-2 gap-2 rounded-md border border-border p-1">
                {(["Per Session", "Hourly"] as const).map((type) => (
                  <button
                    key={type}
                    type="button"
                    onClick={() => setRateType(type)}
                    className={cn(
                      "px-3 py-1.5 rounded text-sm font-medium transition-colors",
                      rateType === type
                        ? "bg-teal-500 text-teal-950"
                        : "text-muted-foreground hover:text-foreground hover:bg-muted"
                    )}
                  >
                    {type}
                  </button>
                ))}
              </div>
            </Field>
            <Field label="Rate">
              <div className="relative">
                <span className="absolute left-3 top-1/2 -translate-y-1/2 text-sm text-muted-foreground">$</span>
                <Input
                  type="number"
                  min={0}
                  value={rate}
                  onChange={(e) => setRate(e.target.value)}
                  placeholder="0.00"
                  className="pl-6"
                />
              </div>
            </Field>
          </div>
          <DialogFooter>
            <Button variant="ghost" onClick={() => { setOpen(false); resetForm(); }}>
              Cancel
            </Button>
            <Button
              onClick={handleSave}
              disabled={!isValid}
              className="bg-gradient-to-r from-teal-500 to-teal-400 hover:from-teal-400 hover:to-teal-300 text-teal-950 disabled:opacity-50"
            >
              {editing ? "Save Changes" : "Invite Staff Member"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </Card>
  );
}

function PlaceholderSection({ title, desc }: { title: string; desc: string }) {
  return (
    <Card title={title} desc={desc}>
      <div className="py-10 text-center">
        <p className="text-sm text-muted-foreground">This section is coming soon.</p>
      </div>
    </Card>
  );
}

type EmailNotifications = {
  newCampRegistration: boolean;
  paymentReceived: boolean;
  paymentOverdue: boolean;
  newParentMessage: boolean;
  sessionStarting1Hour: boolean;
  drylandComplete: boolean;
  weeklySummary: boolean;
};

type PushNotifications = {
  newMessage: boolean;
  sessionStarting30Min: boolean;
  paymentReceived: boolean;
  newCampRegistration: boolean;
};

function NotificationsSection() {
  const [email, setEmail] = useState<EmailNotifications>({
    newCampRegistration: true,
    paymentReceived: true,
    paymentOverdue: true,
    newParentMessage: true,
    sessionStarting1Hour: false,
    drylandComplete: false,
    weeklySummary: true,
  });

  const [push, setPush] = useState<PushNotifications>({
    newMessage: true,
    sessionStarting30Min: true,
    paymentReceived: true,
    newCampRegistration: true,
  });

  const updateEmail = (key: keyof EmailNotifications, value: boolean) => {
    setEmail((prev) => ({ ...prev, [key]: value }));
  };

  const updatePush = (key: keyof PushNotifications, value: boolean) => {
    setPush((prev) => ({ ...prev, [key]: value }));
  };

  const handleSave = () => {
    toast.success("Notification preferences saved.");
  };

  const emailRows: { key: keyof EmailNotifications; label: string }[] = [
    { key: "newCampRegistration", label: "New registration for a camp" },
    { key: "paymentReceived", label: "Payment received" },
    { key: "paymentOverdue", label: "Payment overdue" },
    { key: "newParentMessage", label: "New message from parent" },
    { key: "sessionStarting1Hour", label: "Session starting in 1 hour" },
    { key: "drylandComplete", label: "Athlete completes dryland session" },
    { key: "weeklySummary", label: "Weekly summary report" },
  ];

  const pushRows: { key: keyof PushNotifications; label: string }[] = [
    { key: "newMessage", label: "New message" },
    { key: "sessionStarting30Min", label: "Session starting in 30 min" },
    { key: "paymentReceived", label: "Payment received" },
    { key: "newCampRegistration", label: "New camp registration" },
  ];

  return (
    <Card title="Notifications" desc="Choose when and how you receive alerts and reminders.">
      <div className="space-y-6">
        <section>
          <h4 className="mb-3 text-xs font-semibold uppercase tracking-wider text-muted-foreground">
            Email Notifications
          </h4>
          <div className="rounded-md border border-border overflow-hidden">
            {emailRows.map(({ key, label }, index) => (
              <div
                key={key}
                className={cn(
                  "flex items-center justify-between px-4 py-3.5",
                  index !== emailRows.length - 1 && "border-b border-border"
                )}
              >
                <span className="text-sm text-foreground">{label}</span>
                <Switch
                  checked={email[key]}
                  onCheckedChange={(checked) => updateEmail(key, checked)}
                  className="data-[state=checked]:bg-teal-500"
                />
              </div>
            ))}
          </div>
        </section>

        <section>
          <h4 className="mb-3 text-xs font-semibold uppercase tracking-wider text-muted-foreground">
            Push Notifications (mobile app)
          </h4>
          <div className="rounded-md border border-border overflow-hidden">
            {pushRows.map(({ key, label }, index) => (
              <div
                key={key}
                className={cn(
                  "flex items-center justify-between px-4 py-3.5",
                  index !== pushRows.length - 1 && "border-b border-border"
                )}
              >
                <span className="text-sm text-foreground">{label}</span>
                <Switch
                  checked={push[key]}
                  onCheckedChange={(checked) => updatePush(key, checked)}
                  className="data-[state=checked]:bg-teal-500"
                />
              </div>
            ))}
          </div>
        </section>

        <div className="flex justify-end pt-2">
          <Button
            onClick={handleSave}
            className="bg-gradient-to-r from-teal-500 to-teal-400 hover:from-teal-400 hover:to-teal-300 text-teal-950"
          >
            <Save className="h-4 w-4 mr-1.5" />
            Save Preferences
          </Button>
        </div>
      </div>
    </Card>
  );
}

function BillingSection() {
  return (
    <Card title="Billing" desc="Review your plan, payment method, and billing history.">
      <div className="space-y-6">
        <section>
          <h4 className="mb-3 text-xs font-semibold uppercase tracking-wider text-muted-foreground">
            Current Plan
          </h4>
          <div className="rounded-lg border border-border bg-card p-5">
            <div className="flex items-center gap-3 mb-2">
              <span className="inline-flex rounded-full bg-teal-500/15 px-3 py-1 text-xs font-semibold text-teal-400">
                ELITE COACH
              </span>
            </div>
            <p className="text-lg font-semibold text-foreground">Founding Member — Free until Dec 31, 2027</p>
            <ul className="mt-4 space-y-2">
              {[
                "Unlimited camps & privates",
                "Up to 150 athletes",
                "Website builder",
                "Dryland access",
                "Staff management",
                "Priority support",
              ].map((feature) => (
                <li key={feature} className="flex items-center gap-2 text-sm text-muted-foreground">
                  <span className="text-teal-400">✓</span>
                  {feature}
                </li>
              ))}
            </ul>
            <div className="mt-5">
              <Button variant="outline">
                Manage Subscription
              </Button>
            </div>
          </div>
        </section>

        <section>
          <h4 className="mb-3 text-xs font-semibold uppercase tracking-wider text-muted-foreground">
            Payment Method
          </h4>
          <div className="rounded-lg border border-border bg-card p-5">
            <div className="flex items-center justify-between gap-4">
              <div>
                <p className="text-sm font-medium text-foreground">Card on file: Visa ending 4242</p>
                <p className="text-xs text-muted-foreground mt-0.5">Expiry: 12/28</p>
              </div>
              <Button variant="outline">Update Card</Button>
            </div>
          </div>
        </section>

        <section>
          <h4 className="mb-3 text-xs font-semibold uppercase tracking-wider text-muted-foreground">
            Billing History
          </h4>
          <div className="rounded-md border border-border overflow-hidden">
            <Table>
              <TableHeader>
                <TableRow className="hover:bg-transparent">
                  <TableHead>Date</TableHead>
                  <TableHead>Description</TableHead>
                  <TableHead>Amount</TableHead>
                  <TableHead className="text-right">Receipt</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                <TableRow className="hover:bg-muted/40">
                  <TableCell className="font-medium">Jan 1 2027</TableCell>
                  <TableCell>Elite Coach Annual</TableCell>
                  <TableCell>$599</TableCell>
                  <TableCell className="text-right">
                    <Button variant="ghost" size="sm">Receipt</Button>
                  </TableCell>
                </TableRow>
                <TableRow className="hover:bg-muted/40">
                  <TableCell className="font-medium">Jan 1 2026</TableCell>
                  <TableCell>Elite Coach Annual</TableCell>
                  <TableCell>$599</TableCell>
                  <TableCell className="text-right">
                    <Button variant="ghost" size="sm">Receipt</Button>
                  </TableCell>
                </TableRow>
              </TableBody>
            </Table>
          </div>
        </section>

        <p className="text-[11px] text-muted-foreground">
          You are currently in your free founding member period. Billing begins Jan 1, 2028.
        </p>
      </div>
    </Card>
  );
}

type IceSlot = {
  id: string;
  day: string;
  time: string;
  rink: string;
  assignment: string | null;
};

const INITIAL_ICE: IceSlot[] = [
  { id: "1", day: "Mon", time: "6:00–8:00 PM", rink: "Rink A", assignment: null },
  { id: "2", day: "Tue", time: "7:00–9:00 AM", rink: "Rink A", assignment: null },
  { id: "3", day: "Wed", time: "9:00–12:00 PM", rink: "Rink A", assignment: "Elite Skating Camp" },
  { id: "4", day: "Thu", time: "9:00–12:00 PM", rink: "Rink A", assignment: "Elite Skating Camp" },
  { id: "5", day: "Fri", time: "9:00–12:00 PM", rink: "Rink A", assignment: "Elite Skating Camp" },
  { id: "6", day: "Sat", time: "8:00–10:00 AM", rink: "Rink B", assignment: null },
];

const CAMP_OPTIONS = [
  "Elite Skating Camp",
  "Goalie Development Camp",
  "Summer Skills Camp",
  "Team Practice",
  "Private Sessions",
];

function IceAllocationSection() {
  const [slots, setSlots] = useState<IceSlot[]>(INITIAL_ICE);
  const [contractName, setContractName] = useState<string | null>("Rink A Contract 2026-27.pdf");
  const [isDragging, setIsDragging] = useState(false);
  const [assignOpen, setAssignOpen] = useState(false);
  const [assignSlot, setAssignSlot] = useState<IceSlot | null>(null);
  const [assignChoice, setAssignChoice] = useState<string>(CAMP_OPTIONS[0]);
  const fileInputRef = useRef<HTMLInputElement | null>(null);

  const handleFile = (file: File) => {
    setContractName(file.name);
    toast.success("Contract uploaded. AI extracting ice times…");
  };

  const onDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
    const file = e.dataTransfer.files?.[0];
    if (file) handleFile(file);
  };

  const openAssign = (slot: IceSlot) => {
    setAssignSlot(slot);
    setAssignChoice(CAMP_OPTIONS[0]);
    setAssignOpen(true);
  };

  const saveAssignment = () => {
    if (!assignSlot) return;
    setSlots((prev) => prev.map((s) => (s.id === assignSlot.id ? { ...s, assignment: assignChoice } : s)));
    toast.success(`Assigned to ${assignChoice}.`);
    setAssignOpen(false);
    setAssignSlot(null);
  };

  const total = slots.length;
  const assigned = slots.filter((s) => s.assignment).length;
  const unassigned = total - assigned;

  return (
    <Card
      title="Ice Allocation"
      desc="Upload your ice contract and allocate slots to camps, teams, and privates."
      actions={
        <Button
          onClick={() => fileInputRef.current?.click()}
          className="bg-teal-500 hover:bg-teal-400 text-teal-950"
        >
          <Upload className="h-4 w-4 mr-1.5" />
          Upload Contract
        </Button>
      }
    >
      <input
        ref={fileInputRef}
        type="file"
        accept=".pdf,.doc,.docx,.xlsx,.xls"
        hidden
        onChange={(e) => {
          const f = e.target.files?.[0];
          if (f) handleFile(f);
        }}
      />

      <div
        onDragOver={(e) => { e.preventDefault(); setIsDragging(true); }}
        onDragLeave={() => setIsDragging(false)}
        onDrop={onDrop}
        onClick={() => fileInputRef.current?.click()}
        className={cn(
          "rounded-lg border-2 border-dashed p-8 text-center cursor-pointer transition-colors",
          isDragging ? "border-teal-400 bg-teal-500/5" : "border-border hover:border-teal-500/50 hover:bg-muted/30"
        )}
      >
        <div className="mx-auto flex h-12 w-12 items-center justify-center rounded-full bg-teal-500/10 mb-3">
          <Upload className="h-5 w-5 text-teal-400" />
        </div>
        <p className="text-sm font-medium text-foreground">Upload your ice contract PDF</p>
        <p className="text-xs text-muted-foreground mt-1">AI will extract all ice times automatically</p>
        <p className="text-xs text-muted-foreground mt-3">Drag & drop or click to upload</p>
        <p className="text-[11px] text-muted-foreground mt-2">Accepted: PDF, DOC, XLSX</p>

        {contractName && (
          <div
            className="mt-4 inline-flex items-center gap-2 rounded-md border border-border bg-background/60 px-3 py-1.5 text-xs"
            onClick={(e) => e.stopPropagation()}
          >
            <FileText className="h-3.5 w-3.5 text-teal-400" />
            <span className="text-foreground">{contractName}</span>
            <button
              onClick={() => setContractName(null)}
              className="text-muted-foreground hover:text-foreground"
              aria-label="Remove contract"
            >
              <X className="h-3.5 w-3.5" />
            </button>
          </div>
        )}
      </div>

      <div className="mt-6">
        <div className="flex items-baseline justify-between mb-3">
          <div>
            <h4 className="text-sm font-semibold">Allocated Ice</h4>
            <p className="text-xs text-muted-foreground mt-0.5">Facility: Rink A · Season: 2026-27</p>
          </div>
          <div className="text-xs text-muted-foreground">
            {total} slots · <span className="text-emerald-400">{assigned} assigned</span> ·{" "}
            <span className="text-amber-400">{unassigned} unassigned</span>
          </div>
        </div>

        <div className="rounded-md border border-border overflow-hidden">
          <Table>
            <TableHeader>
              <TableRow className="hover:bg-transparent">
                <TableHead className="w-16">Day</TableHead>
                <TableHead>Time</TableHead>
                <TableHead>Rink</TableHead>
                <TableHead>Assignment</TableHead>
                <TableHead className="text-right">Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {slots.map((slot) => {
                const isUnassigned = !slot.assignment;
                return (
                  <TableRow
                    key={slot.id}
                    className={cn(
                      "hover:bg-muted/40",
                      isUnassigned && "bg-amber-500/5 hover:bg-amber-500/10"
                    )}
                  >
                    <TableCell className="font-medium">{slot.day}</TableCell>
                    <TableCell>{slot.time}</TableCell>
                    <TableCell>{slot.rink}</TableCell>
                    <TableCell>
                      {slot.assignment ? (
                        <span className="inline-flex rounded-full bg-teal-500/15 px-2 py-0.5 text-[11px] font-semibold text-teal-400">
                          {slot.assignment}
                        </span>
                      ) : (
                        <span className="inline-flex rounded-full bg-amber-500/15 px-2 py-0.5 text-[11px] font-semibold text-amber-400">
                          Unassigned
                        </span>
                      )}
                    </TableCell>
                    <TableCell className="text-right">
                      {isUnassigned ? (
                        <Button
                          size="sm"
                          onClick={() => openAssign(slot)}
                          className="bg-teal-500 hover:bg-teal-400 text-teal-950 h-7"
                        >
                          Assign
                        </Button>
                      ) : (
                        <Button variant="ghost" size="sm" onClick={() => openAssign(slot)}>
                          <Pencil className="h-3.5 w-3.5 mr-1.5" />
                          Change
                        </Button>
                      )}
                    </TableCell>
                  </TableRow>
                );
              })}
            </TableBody>
          </Table>
        </div>

        <p className="text-[11px] text-muted-foreground mt-4">
          Unassigned ice appears on your Schedule in orange.
        </p>
      </div>

      <Dialog open={assignOpen} onOpenChange={setAssignOpen}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>Assign Ice Slot</DialogTitle>
          </DialogHeader>
          {assignSlot && (
            <div className="space-y-4 py-2">
              <div className="rounded-md border border-border bg-muted/30 p-3 text-sm">
                <div className="font-medium">{assignSlot.day} · {assignSlot.time}</div>
                <div className="text-xs text-muted-foreground mt-0.5">{assignSlot.rink}</div>
              </div>
              <Field label="Assign to">
                <Select value={assignChoice} onValueChange={setAssignChoice}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {CAMP_OPTIONS.map((c) => (
                      <SelectItem key={c} value={c}>{c}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </Field>
            </div>
          )}
          <DialogFooter>
            <Button variant="ghost" onClick={() => setAssignOpen(false)}>Cancel</Button>
            <Button
              onClick={saveAssignment}
              className="bg-gradient-to-r from-teal-500 to-teal-400 hover:from-teal-400 hover:to-teal-300 text-teal-950"
            >
              Save Assignment
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </Card>
  );
}


