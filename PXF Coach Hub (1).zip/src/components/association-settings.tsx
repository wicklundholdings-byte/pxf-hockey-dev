import { useState } from "react";
import {
  Building2, CalendarRange, Link2, Layers, DollarSign, Bell, CreditCard,
  ShieldAlert, AlertTriangle, Upload, Plus, Trash2, Check, X, Save,
  Download, ExternalLink, Archive, Snowflake,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Switch } from "@/components/ui/switch";
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from "@/components/ui/select";
import {
  Table, TableBody, TableCell, TableHead, TableHeader, TableRow,
} from "@/components/ui/table";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { cn } from "@/lib/utils";
import { toast } from "sonner";

type SectionKey =
  | "profile" | "season" | "governing" | "divisions" | "fees"
  | "notifications" | "billing" | "data" | "danger";

const SECTIONS: { key: SectionKey; label: string; icon: any }[] = [
  { key: "profile", label: "Association Profile", icon: Building2 },
  { key: "season", label: "Season Management", icon: CalendarRange },
  { key: "governing", label: "Governing Body", icon: Link2 },
  { key: "divisions", label: "Divisions & Age Groups", icon: Layers },
  { key: "fees", label: "Referee Fee Schedule", icon: DollarSign },
  { key: "notifications", label: "Notifications", icon: Bell },
  { key: "billing", label: "Payment & Billing", icon: CreditCard },
  { key: "data", label: "Data & Privacy", icon: ShieldAlert },
  { key: "danger", label: "Danger Zone", icon: AlertTriangle },
];

const ASSOCIATION_NAME = "Northern Lights Hockey Association";

export function AssociationSettings() {
  const [section, setSection] = useState<SectionKey>("profile");

  return (
    <div className="grid grid-cols-[220px_1fr] gap-6">
      {/* Sub-nav */}
      <aside className="rounded-lg border border-border bg-card p-2 h-fit sticky top-4">
        <ul className="space-y-0.5">
          {SECTIONS.map((s) => {
            const Icon = s.icon;
            const active = section === s.key;
            const danger = s.key === "danger";
            return (
              <li key={s.key}>
                <button
                  onClick={() => setSection(s.key)}
                  className={cn(
                    "w-full flex items-center gap-2.5 rounded-md px-3 py-2 text-sm font-medium transition-colors text-left",
                    active && !danger && "bg-gradient-to-r from-teal-500 to-emerald-500 text-white",
                    active && danger && "bg-red-500/15 text-red-400 ring-1 ring-red-500/30",
                    !active && "text-muted-foreground hover:bg-muted hover:text-foreground",
                    !active && danger && "text-red-400/80 hover:text-red-400",
                  )}
                >
                  <Icon className="h-4 w-4" />
                  {s.label}
                </button>
              </li>
            );
          })}
        </ul>
      </aside>

      <div className="min-w-0">
        {section === "profile" && <ProfileSection />}
        {section === "season" && <SeasonSection />}
        {section === "governing" && <GoverningSection />}
        {section === "divisions" && <DivisionsSection />}
        {section === "fees" && <FeesSection />}
        {section === "notifications" && <NotificationsSection />}
        {section === "billing" && <BillingSection />}
        {section === "data" && <DataSection />}
        {section === "danger" && <DangerSection />}
      </div>
    </div>
  );
}

/* ---------- Reusable ---------- */
function Card({ title, desc, children, actions }: { title: string; desc?: string; children: React.ReactNode; actions?: React.ReactNode }) {
  return (
    <section className="rounded-lg border border-border bg-card p-6">
      <header className="flex items-start justify-between gap-4 mb-5">
        <div>
          <h3 className="text-base font-semibold">{title}</h3>
          {desc && <p className="text-xs text-muted-foreground mt-1">{desc}</p>}
        </div>
        {actions}
      </header>
      {children}
    </section>
  );
}

function Field({ label, children, hint }: { label: string; children: React.ReactNode; hint?: string }) {
  return (
    <div>
      <Label className="text-xs font-medium">{label}</Label>
      <div className="mt-1.5">{children}</div>
      {hint && <p className="text-[11px] text-muted-foreground mt-1">{hint}</p>}
    </div>
  );
}

/* ---------- 1. Profile ---------- */
function ProfileSection() {
  const [primary, setPrimary] = useState("#10b981");
  const [secondary, setSecondary] = useState("#14b8a6");

  return (
    <Card title="Association Profile" desc="Branding and contact info used across the portal and your public website.">
      <div className="space-y-5">
        <div className="grid grid-cols-2 gap-4">
          <Field label="Association name">
            <Input defaultValue={ASSOCIATION_NAME} />
          </Field>
          <Field label="Association type">
            <Select defaultValue="Minor">
              <SelectTrigger><SelectValue /></SelectTrigger>
              <SelectContent>
                {["Minor Hockey Association", "Rep Association", "Junior", "Senior", "Female", "Mixed"].map((v) => (
                  <SelectItem key={v} value={v}>{v}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </Field>
        </div>

        <Field label="Logo" hint="PNG or SVG, recommended 512×512">
          <div className="flex items-center gap-3">
            <div className="h-16 w-16 rounded-md bg-gradient-to-br from-teal-500 to-emerald-500 flex items-center justify-center text-white font-bold">NLH</div>
            <Button variant="outline" size="sm"><Upload className="h-4 w-4 mr-1.5" /> Upload logo</Button>
          </div>
        </Field>

        <div className="grid grid-cols-2 gap-4">
          <Field label="Primary color" hint="Used for active states, CTAs">
            <div className="flex items-center gap-2">
              <input type="color" value={primary} onChange={(e) => setPrimary(e.target.value)} className="h-9 w-12 rounded border border-border bg-transparent cursor-pointer" />
              <Input value={primary} onChange={(e) => setPrimary(e.target.value)} className="font-mono text-xs" />
            </div>
          </Field>
          <Field label="Secondary color" hint="Used for accents, gradients">
            <div className="flex items-center gap-2">
              <input type="color" value={secondary} onChange={(e) => setSecondary(e.target.value)} className="h-9 w-12 rounded border border-border bg-transparent cursor-pointer" />
              <Input value={secondary} onChange={(e) => setSecondary(e.target.value)} className="font-mono text-xs" />
            </div>
          </Field>
        </div>

        <div className="grid grid-cols-2 gap-4">
          <Field label="Governing body">
            <Select defaultValue="Hockey Canada">
              <SelectTrigger><SelectValue /></SelectTrigger>
              <SelectContent>
                <SelectItem value="Hockey Canada">Hockey Canada</SelectItem>
                <SelectItem value="USA Hockey">USA Hockey</SelectItem>
                <SelectItem value="Other">Other</SelectItem>
              </SelectContent>
            </Select>
          </Field>
          <Field label="Region / Province / State">
            <Input defaultValue="Manitoba, Canada" />
          </Field>
        </div>

        <Field label="Mailing address">
          <Textarea rows={2} defaultValue={"PO Box 1144\nWinnipeg, MB R3C 2W7"} />
        </Field>

        <div className="grid grid-cols-2 gap-4">
          <Field label="Main contact email"><Input type="email" defaultValue="admin@nlh.ca" /></Field>
          <Field label="Main contact phone"><Input defaultValue="(204) 555-0100" /></Field>
        </div>

        <Field label="Website URL" hint="Auto-filled with your PXF site. Editable if a custom domain is set.">
          <Input defaultValue="https://nlh.pxfhockey.com" />
        </Field>

        <div className="grid grid-cols-2 gap-4">
          <Field label="Twitter / X"><Input placeholder="@nlhockey" /></Field>
          <Field label="Facebook"><Input placeholder="facebook.com/nlhockey" /></Field>
          <Field label="Instagram"><Input placeholder="@nlhockey" /></Field>
          <Field label="YouTube"><Input placeholder="youtube.com/@nlhockey" /></Field>
        </div>

        <div className="flex justify-end pt-2 border-t border-border">
          <Button onClick={() => toast.success("Profile saved.")} className="bg-teal-500 hover:bg-teal-600 text-white">
            <Save className="h-4 w-4 mr-1.5" /> Save changes
          </Button>
        </div>
      </div>
    </Card>
  );
}

/* ---------- 2. Season ---------- */
function SeasonSection() {
  const [startOpen, setStartOpen] = useState(false);
  const [carryTeams, setCarryTeams] = useState(true);
  const [carryRosters, setCarryRosters] = useState(false);
  const [carryCoaches, setCarryCoaches] = useState(true);
  const [newName, setNewName] = useState("2026-27");

  const previous = [
    { name: "2024-25", start: "2024-09-01", end: "2025-04-30" },
    { name: "2023-24", start: "2023-09-01", end: "2024-04-30" },
    { name: "2022-23", start: "2022-09-01", end: "2023-04-30" },
  ];

  return (
    <div className="space-y-4">
      <Card title="Current Season" desc="The season all live data is recorded against." actions={
        <Button onClick={() => setStartOpen(true)} className="bg-teal-500 hover:bg-teal-600 text-white">
          <Plus className="h-4 w-4 mr-1.5" /> Start New Season
        </Button>
      }>
        <div className="grid grid-cols-3 gap-4">
          <Field label="Season name"><Input defaultValue="2025-26" /></Field>
          <Field label="Start date"><Input type="date" defaultValue="2025-09-01" /></Field>
          <Field label="End date"><Input type="date" defaultValue="2026-04-30" /></Field>
        </div>
      </Card>

      <Card title="Previous Seasons" desc="Archived seasons — all historical data is preserved and viewable read-only.">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Season</TableHead><TableHead>Start</TableHead><TableHead>End</TableHead><TableHead></TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {previous.map((s) => (
              <TableRow key={s.name}>
                <TableCell className="font-medium">{s.name}</TableCell>
                <TableCell>{s.start}</TableCell>
                <TableCell>{s.end}</TableCell>
                <TableCell className="text-right">
                  <Button size="sm" variant="ghost">View archive <ExternalLink className="h-3.5 w-3.5 ml-1" /></Button>
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </Card>

      <Dialog open={startOpen} onOpenChange={setStartOpen}>
        <DialogContent>
          <DialogHeader><DialogTitle>Start new season</DialogTitle></DialogHeader>
          <div className="space-y-4 pt-2">
            <Field label="New season name"><Input value={newName} onChange={(e) => setNewName(e.target.value)} /></Field>
            <div className="rounded-md border border-border p-3 space-y-3">
              <p className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">Carry over from 2025-26</p>
              <div className="flex items-center justify-between"><span className="text-sm">Teams</span><Switch checked={carryTeams} onCheckedChange={setCarryTeams} /></div>
              <div className="flex items-center justify-between"><span className="text-sm">Rosters</span><Switch checked={carryRosters} onCheckedChange={setCarryRosters} /></div>
              <div className="flex items-center justify-between"><span className="text-sm">Coaches</span><Switch checked={carryCoaches} onCheckedChange={setCarryCoaches} /></div>
            </div>
            <p className="text-[11px] text-muted-foreground">All historical data from the previous season is preserved and remains accessible under Previous Seasons.</p>
          </div>
          <DialogFooter>
            <Button variant="ghost" onClick={() => setStartOpen(false)}>Cancel</Button>
            <Button className="bg-teal-500 hover:bg-teal-600 text-white" onClick={() => { setStartOpen(false); toast.success(`Started new season ${newName}. 2025-26 archived.`); }}>
              Start season
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}

/* ---------- 3. Governing Body ---------- */
function GoverningSection() {
  return (
    <Card title="Governing Body Connection" desc="Connect to your sanctioning body to verify registered players.">
      <div className="space-y-5">
        <div className="grid grid-cols-2 gap-4">
          <Field label="Governing body">
            <Select defaultValue="Hockey Canada">
              <SelectTrigger><SelectValue /></SelectTrigger>
              <SelectContent>
                <SelectItem value="Hockey Canada">Hockey Canada</SelectItem>
                <SelectItem value="USA Hockey">USA Hockey</SelectItem>
              </SelectContent>
            </Select>
          </Field>
          <Field label="Association registration number"><Input defaultValue="HC-MB-0042" /></Field>
        </div>

        <div className="rounded-md border border-border p-4 flex items-center justify-between">
          <div>
            <div className="flex items-center gap-2">
              <span className="inline-block h-2 w-2 rounded-full bg-amber-400" />
              <span className="text-sm font-medium">API connection: Not connected</span>
            </div>
            <p className="text-xs text-muted-foreground mt-1">Use manual CSV upload below as a fallback.</p>
          </div>
          <Button variant="outline" size="sm">Connect API</Button>
        </div>

        <Field label="Upload registered player list" hint="CSV from Hockey Canada portal — used to validate registrations.">
          <Button variant="outline" size="sm"><Upload className="h-4 w-4 mr-1.5" /> Upload CSV</Button>
        </Field>

        <div className="rounded-md bg-muted/40 px-3 py-2 text-xs text-muted-foreground flex items-center justify-between">
          <span>Last sync: <span className="text-foreground font-medium">Nov 12, 2025 · 4:18 PM</span></span>
          <span className="text-emerald-400 font-medium flex items-center gap-1"><Check className="h-3.5 w-3.5" /> 412 records matched</span>
        </div>
      </div>
    </Card>
  );
}

/* ---------- 4. Divisions ---------- */
type Division = { id: string; name: string; age: string; level: string; minCert: string; refCert: string };
const SEED_DIVS: Division[] = [
  { id: "d1", name: "U18 AAA", age: "U18", level: "AAA", minCert: "Development 1", refCert: "Level 4" },
  { id: "d2", name: "U15 AAA", age: "U15", level: "AAA", minCert: "Development 1", refCert: "Level 3" },
  { id: "d3", name: "U13 AA", age: "U13", level: "AA", minCert: "Trained", refCert: "Level 2" },
  { id: "d4", name: "U11 A", age: "U11", level: "A", minCert: "Trained", refCert: "Level 2" },
  { id: "d5", name: "U9 House", age: "U9", level: "House", minCert: "Community", refCert: "Level 1" },
];

function DivisionsSection() {
  const [rows, setRows] = useState<Division[]>(SEED_DIVS);
  return (
    <Card title="Divisions & Age Groups" desc="Used across Teams, Coach compliance, and Referee assignment." actions={
      <Button size="sm" variant="outline" onClick={() => setRows((r) => [...r, { id: `d${Date.now()}`, name: "New", age: "U—", level: "—", minCert: "Community", refCert: "Level 1" }])}>
        <Plus className="h-4 w-4 mr-1.5" /> Add division
      </Button>
    }>
      <Table>
        <TableHeader>
          <TableRow>
            <TableHead>Name</TableHead><TableHead>Age</TableHead><TableHead>Level</TableHead>
            <TableHead>Min coach cert</TableHead><TableHead>Min ref cert</TableHead><TableHead></TableHead>
          </TableRow>
        </TableHeader>
        <TableBody>
          {rows.map((d) => (
            <TableRow key={d.id}>
              <TableCell><Input className="h-8" defaultValue={d.name} /></TableCell>
              <TableCell><Input className="h-8 w-20" defaultValue={d.age} /></TableCell>
              <TableCell>
                <Select defaultValue={d.level}>
                  <SelectTrigger className="h-8 w-24"><SelectValue /></SelectTrigger>
                  <SelectContent>{["AAA","AA","A","B","C","House"].map((l) => <SelectItem key={l} value={l}>{l}</SelectItem>)}</SelectContent>
                </Select>
              </TableCell>
              <TableCell>
                <Select defaultValue={d.minCert}>
                  <SelectTrigger className="h-8 w-40"><SelectValue /></SelectTrigger>
                  <SelectContent>{["Community","Trained","Development 1","Development 2","High Performance 1"].map((l) => <SelectItem key={l} value={l}>{l}</SelectItem>)}</SelectContent>
                </Select>
              </TableCell>
              <TableCell>
                <Select defaultValue={d.refCert}>
                  <SelectTrigger className="h-8 w-28"><SelectValue /></SelectTrigger>
                  <SelectContent>{["Level 1","Level 2","Level 3","Level 4","Level 5","Level 6"].map((l) => <SelectItem key={l} value={l}>{l}</SelectItem>)}</SelectContent>
                </Select>
              </TableCell>
              <TableCell className="text-right">
                <Button size="icon" variant="ghost" onClick={() => setRows((r) => r.filter((x) => x.id !== d.id))}>
                  <Trash2 className="h-4 w-4 text-red-400" />
                </Button>
              </TableCell>
            </TableRow>
          ))}
        </TableBody>
      </Table>
    </Card>
  );
}

/* ---------- 5. Fees ---------- */
type Fee = { id: string; division: string; type: "Regular" | "Playoff" | "Tournament"; amount: number };
const SEED_FEES: Fee[] = [
  { id: "f1", division: "U11 House", type: "Regular", amount: 35 },
  { id: "f2", division: "U13 AA", type: "Regular", amount: 50 },
  { id: "f3", division: "U15 AAA", type: "Regular", amount: 70 },
  { id: "f4", division: "U18 AAA", type: "Regular", amount: 85 },
  { id: "f5", division: "U18 AAA", type: "Playoff", amount: 95 },
  { id: "f6", division: "U15 AAA", type: "Tournament", amount: 80 },
];

function FeesSection() {
  const [rows, setRows] = useState<Fee[]>(SEED_FEES);
  return (
    <Card title="Referee Fee Schedule" desc="Fees auto-apply when a game is marked complete and the referee payment is queued." actions={
      <Button size="sm" variant="outline" onClick={() => setRows((r) => [...r, { id: `f${Date.now()}`, division: "U—", type: "Regular", amount: 0 }])}>
        <Plus className="h-4 w-4 mr-1.5" /> Add fee row
      </Button>
    }>
      <Table>
        <TableHeader>
          <TableRow>
            <TableHead>Division</TableHead><TableHead>Game type</TableHead><TableHead>Fee per referee</TableHead><TableHead></TableHead>
          </TableRow>
        </TableHeader>
        <TableBody>
          {rows.map((f) => (
            <TableRow key={f.id}>
              <TableCell><Input className="h-8 w-40" defaultValue={f.division} /></TableCell>
              <TableCell>
                <Select defaultValue={f.type}>
                  <SelectTrigger className="h-8 w-36"><SelectValue /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="Regular">Regular season</SelectItem>
                    <SelectItem value="Playoff">Playoff</SelectItem>
                    <SelectItem value="Tournament">Tournament</SelectItem>
                  </SelectContent>
                </Select>
              </TableCell>
              <TableCell>
                <div className="relative w-28">
                  <span className="absolute left-2.5 top-1.5 text-muted-foreground text-sm">$</span>
                  <Input className="h-8 pl-6" type="number" defaultValue={f.amount} />
                </div>
              </TableCell>
              <TableCell className="text-right">
                <Button size="icon" variant="ghost" onClick={() => setRows((r) => r.filter((x) => x.id !== f.id))}>
                  <Trash2 className="h-4 w-4 text-red-400" />
                </Button>
              </TableCell>
            </TableRow>
          ))}
        </TableBody>
      </Table>
    </Card>
  );
}

/* ---------- 6. Notifications ---------- */
function NotificationsSection() {
  const items = [
    { k: "cert", label: "Coach certification expiring", hint: "60 / 30 / 7 days before expiry" },
    { k: "bg", label: "Background check expiring", hint: "60 / 30 / 7 days before expiry" },
    { k: "ref", label: "Game with no referee assigned", hint: "48-hour and 24-hour warnings" },
    { k: "unpaid", label: "Unpaid registration fees reminder", hint: "Frequency configurable below" },
    { k: "concussion", label: "Concussion protocol step stalled", hint: "Triggers after 7 days without progression" },
    { k: "safesport", label: "New Safe Sport report filed", hint: "Routes to Safe Sport Officer only" },
    { k: "incident", label: "New incident report filed", hint: "All incidents" },
  ];
  const [state, setState] = useState<Record<string, boolean>>(Object.fromEntries(items.map((i) => [i.k, true])));

  return (
    <div className="space-y-4">
      <Card title="Automatic Notifications" desc="Choose which automated alerts your admins receive.">
        <div className="divide-y divide-border">
          {items.map((it) => (
            <div key={it.k} className="flex items-start justify-between py-3 gap-4">
              <div>
                <div className="text-sm font-medium">{it.label}</div>
                <div className="text-[11px] text-muted-foreground">{it.hint}</div>
              </div>
              <Switch checked={state[it.k]} onCheckedChange={(v) => setState((s) => ({ ...s, [it.k]: v }))} />
            </div>
          ))}
        </div>
      </Card>

      <Card title="Reminder Frequency & Defaults">
        <div className="grid grid-cols-2 gap-4">
          <Field label="Unpaid fees reminder frequency">
            <Select defaultValue="weekly">
              <SelectTrigger><SelectValue /></SelectTrigger>
              <SelectContent>
                <SelectItem value="weekly">Weekly</SelectItem>
                <SelectItem value="3days">Every 3 days</SelectItem>
                <SelectItem value="daily">Daily</SelectItem>
              </SelectContent>
            </Select>
          </Field>
          <Field label="Default notification email">
            <Input type="email" defaultValue="admin@nlh.ca" />
          </Field>
        </div>
      </Card>
    </div>
  );
}

/* ---------- 7. Billing ---------- */
function BillingSection() {
  const payouts = [
    { d: "Nov 18, 2025", a: 12480.40 },
    { d: "Nov 11, 2025", a: 8294.10 },
    { d: "Nov 04, 2025", a: 15203.55 },
    { d: "Oct 28, 2025", a: 9120.00 },
    { d: "Oct 21, 2025", a: 11402.88 },
    { d: "Oct 14, 2025", a: 7841.20 },
    { d: "Oct 07, 2025", a: 6502.75 },
    { d: "Sep 30, 2025", a: 18402.12 },
    { d: "Sep 23, 2025", a: 4108.00 },
    { d: "Sep 16, 2025", a: 2245.00 },
  ];
  return (
    <div className="space-y-4">
      <Card title="Stripe Connection" desc="Online registrations, camp fees, and apparel orders settle through Stripe.">
        <div className="rounded-md border border-border p-4 flex items-center justify-between">
          <div>
            <div className="flex items-center gap-2">
              <span className="inline-block h-2 w-2 rounded-full bg-emerald-400" />
              <span className="text-sm font-medium">Connected — Northern Lights Hockey (acct_1Q8x…2Fp)</span>
            </div>
            <p className="text-xs text-muted-foreground mt-1">Payout schedule: Weekly · Tuesdays</p>
          </div>
          <Button variant="outline" size="sm">Manage in Stripe <ExternalLink className="h-3.5 w-3.5 ml-1.5" /></Button>
        </div>

        <div className="mt-4 rounded-md bg-muted/40 px-3 py-2 text-xs">
          <span className="text-muted-foreground">PXF platform fee:</span>{" "}
          <span className="font-semibold">2.9% + $0.30 per transaction</span>
          <span className="text-muted-foreground"> · shown for transparency</span>
        </div>
      </Card>

      <Card title="Recent Payouts" desc="Last 10 payouts from Stripe.">
        <Table>
          <TableHeader>
            <TableRow><TableHead>Date</TableHead><TableHead className="text-right">Amount</TableHead></TableRow>
          </TableHeader>
          <TableBody>
            {payouts.map((p) => (
              <TableRow key={p.d}>
                <TableCell className="text-sm">{p.d}</TableCell>
                <TableCell className="text-right font-mono text-sm">${p.a.toLocaleString(undefined, { minimumFractionDigits: 2 })}</TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </Card>
    </div>
  );
}

/* ---------- 8. Data & Privacy ---------- */
function DataSection() {
  return (
    <div className="space-y-4">
      <Card title="Data Retention" desc="How long inactive records are kept after a season ends.">
        <Field label="Retention policy">
          <Select defaultValue="3">
            <SelectTrigger className="w-60"><SelectValue /></SelectTrigger>
            <SelectContent>
              <SelectItem value="1">1 year after season end</SelectItem>
              <SelectItem value="3">3 years after season end</SelectItem>
              <SelectItem value="7">7 years after season end</SelectItem>
            </SelectContent>
          </Select>
        </Field>
      </Card>

      <Card title="Export Data" desc="Full GDPR / PIPEDA-compliant export of your association's data.">
        <Button variant="outline" onClick={() => toast.success("Export queued — you'll get an email when the ZIP is ready.")}>
          <Download className="h-4 w-4 mr-1.5" /> Export all association data (.zip)
        </Button>
      </Card>

      <Card title="Delete Association Account" desc="Requires President role. Confirmation email sent. 30-day grace period before permanent deletion.">
        <Button variant="outline" className="text-red-400 border-red-500/40 hover:bg-red-500/10">
          <Trash2 className="h-4 w-4 mr-1.5" /> Request account deletion
        </Button>
      </Card>
    </div>
  );
}

/* ---------- 9. Danger ---------- */
function DangerSection() {
  const [confirmAction, setConfirmAction] = useState<null | { title: string; desc: string; onConfirm: () => void }>(null);
  const [typed, setTyped] = useState("");

  const open = (title: string, desc: string, onConfirm: () => void) => {
    setTyped("");
    setConfirmAction({ title, desc, onConfirm });
  };

  return (
    <div className="space-y-4">
      <div className="rounded-lg border border-red-500/30 bg-red-500/5 p-4 flex items-start gap-3">
        <AlertTriangle className="h-5 w-5 text-red-400 mt-0.5" />
        <div className="text-xs">
          <div className="font-semibold text-red-400">Danger Zone</div>
          <div className="text-muted-foreground mt-0.5">These actions affect every team, athlete, and admin in the association. Every action requires you to type the association name to confirm.</div>
        </div>
      </div>

      <section className="rounded-lg border border-red-500/30 bg-card p-5 flex items-center justify-between">
        <div>
          <div className="font-semibold text-sm flex items-center gap-2"><Archive className="h-4 w-4" /> Archive current season manually</div>
          <div className="text-xs text-muted-foreground mt-1">Locks the current season as read-only without starting a new one.</div>
        </div>
        <Button variant="outline" className="text-red-400 border-red-500/40 hover:bg-red-500/10"
          onClick={() => open("Archive current season", "The 2025-26 season will be locked as read-only.", () => toast.success("Current season archived."))}>
          Archive season
        </Button>
      </section>

      <section className="rounded-lg border border-red-500/30 bg-card p-5 flex items-center justify-between">
        <div>
          <div className="font-semibold text-sm flex items-center gap-2"><Snowflake className="h-4 w-4" /> Reset all ice time allocations</div>
          <div className="text-xs text-muted-foreground mt-1">Wipes every team's ice assignments for the current season. Cannot be undone.</div>
        </div>
        <Button variant="outline" className="text-red-400 border-red-500/40 hover:bg-red-500/10"
          onClick={() => open("Reset ice allocations", "Every team's ice assignments for 2025-26 will be cleared.", () => toast.success("Ice allocations reset."))}>
          Reset allocations
        </Button>
      </section>

      <Dialog open={!!confirmAction} onOpenChange={(o) => !o && setConfirmAction(null)}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle className="text-red-400 flex items-center gap-2"><AlertTriangle className="h-4 w-4" /> {confirmAction?.title}</DialogTitle>
          </DialogHeader>
          <div className="space-y-3 pt-1 text-sm">
            <p>{confirmAction?.desc}</p>
            <div>
              <Label className="text-xs">Type <span className="font-mono text-red-400">{ASSOCIATION_NAME}</span> to confirm</Label>
              <Input className="mt-1.5 font-mono" value={typed} onChange={(e) => setTyped(e.target.value)} placeholder={ASSOCIATION_NAME} />
            </div>
          </div>
          <DialogFooter>
            <Button variant="ghost" onClick={() => setConfirmAction(null)}><X className="h-4 w-4 mr-1.5" /> Cancel</Button>
            <Button
              disabled={typed !== ASSOCIATION_NAME}
              className="bg-red-500 hover:bg-red-600 text-white disabled:opacity-40"
              onClick={() => { confirmAction?.onConfirm(); setConfirmAction(null); }}
            >
              Confirm
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
