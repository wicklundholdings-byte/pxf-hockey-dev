import { Bell, Megaphone, Siren, Shield, LogOut } from "lucide-react";
import { useRouterState, useNavigate } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { useAccount } from "./account-provider";
import { useAuth } from "./auth-provider";

const titles: Record<string, string> = {
  "/": "Dashboard",
  "/dashboard": "Dashboard",
  "/schedule": "Schedule",
  "/operations": "Operations",
  "/camps": "Camps & Privates",
  "/financials": "Financials",
  "/ice-times": "Ice Times",
  "/teams": "Teams",
  "/playbook": "Playbook",
  "/athletes": "Athletes",
  "/inbox": "Inbox",
  "/settings": "Settings",
  "/registrations": "Registrations",
  "/coaches": "Coaches",
  "/referees": "Referees",
  "/safety": "Safety & Incidents",
  "/communications": "Communications",
  "/apparel": "Apparel",
  "/website": "Website",
  "/board": "Board & Staff",
};

export function AppTopbar() {
  const path = useRouterState({ select: (r) => r.location.pathname });
  const title = titles[path] ?? "Dashboard";
  const { account } = useAccount();
  const { user, signOut } = useAuth();
  const navigate = useNavigate();
  const [date, setDate] = useState("");
  useEffect(() => {
    setDate(
      new Date().toLocaleDateString(undefined, {
        weekday: "long",
        month: "long",
        day: "numeric",
        year: "numeric",
      })
    );
  }, []);

  const isAdmin = account.role === "association-admin";

  return (
    <header className="sticky top-0 z-10 flex h-16 items-center justify-between border-b border-border bg-background/80 px-6 backdrop-blur">
      <div className="flex-1 flex items-center gap-3 min-w-0">
        {isAdmin && (
          <div className="flex items-center gap-2 pr-3 border-r border-border">
            <div className="h-8 w-8 rounded-md bg-gradient-to-br from-indigo-500 to-blue-600 flex items-center justify-center text-white">
              <Shield className="h-4 w-4" />
            </div>
            <div className="leading-tight">
              <div className="text-[11px] uppercase tracking-wider text-muted-foreground">Association</div>
              <div className="text-xs font-semibold truncate">Northern Lights Hockey</div>
            </div>
          </div>
        )}
        <h1 className="text-lg font-semibold tracking-tight truncate">{title}</h1>
      </div>
      <div className="flex-1 text-center text-sm text-muted-foreground font-medium" suppressHydrationWarning>
        {date}
      </div>
      <div className="flex-1 flex items-center justify-end gap-2">
        {isAdmin && (
          <button className="inline-flex items-center gap-1.5 rounded-md bg-gradient-to-r from-red-600 to-rose-600 px-3 py-1.5 text-xs font-semibold text-white shadow-sm hover:opacity-90 transition ring-1 ring-red-500/50">
            <Siren className="h-3.5 w-3.5" />
            Emergency Broadcast
          </button>
        )}
        <button className="inline-flex items-center gap-1.5 rounded-md bg-gradient-to-r from-teal-500 to-emerald-500 px-3 py-1.5 text-xs font-semibold text-white shadow-sm hover:opacity-90 transition">
          <Megaphone className="h-3.5 w-3.5" />
          Broadcast
        </button>
        <button className="relative rounded-md p-2 hover:bg-accent transition" aria-label="Notifications">
          <Bell className="h-4 w-4" />
          <span className="absolute right-1.5 top-1.5 h-1.5 w-1.5 rounded-full bg-emerald-500" />
        </button>
        <div
          title={user?.email ?? account.name}
          className="h-9 w-9 rounded-full bg-gradient-to-br from-teal-400 to-emerald-500 flex items-center justify-center text-white text-xs font-bold ml-1"
        >
          {account.initials}
        </div>
        <button
          onClick={async () => {
            await signOut();
            navigate({ to: "/login", replace: true });
          }}
          className="inline-flex items-center gap-1.5 rounded-md border border-border px-2.5 py-1.5 text-xs font-medium text-muted-foreground hover:bg-accent hover:text-foreground transition"
          aria-label="Sign out"
        >
          <LogOut className="h-3.5 w-3.5" />
          Sign out
        </button>
      </div>
    </header>
  );
}
