import { useState } from "react";
import {
  Download,
  Mail,
  Check,
  Plus,
  ArrowRightLeft,
  ClipboardList,
  Trophy,
  Hourglass,
  CreditCard,
  AlertCircle,
  Eye,
} from "lucide-react";

type Tab = "season" | "tryouts" | "transfers" | "waitlist" | "payment";

const tabs: { id: Tab; label: string; icon: React.ComponentType<{ className?: string }> }[] = [
  { id: "season", label: "Season Registration", icon: ClipboardList },
  { id: "tryouts", label: "Tryouts", icon: Trophy },
  { id: "transfers", label: "Transfers", icon: ArrowRightLeft },
  { id: "waitlist", label: "Waitlist", icon: Hourglass },
  { id: "payment", label: "Payment Tracking", icon: CreditCard },
];

export function AssociationRegistrations() {
  const [tab, setTab] = useState<Tab>("season");

  return (
    <div className="space-y-5">
      <div className="border-b border-border">
        <div className="flex flex-wrap gap-1">
          {tabs.map(({ id, label, icon: Icon }) => (
            <button
              key={id}
              onClick={() => setTab(id)}
              className={`inline-flex items-center gap-1.5 border-b-2 px-3 py-2 text-sm font-medium transition ${
                tab === id
                  ? "border-emerald-500 text-foreground"
                  : "border-transparent text-muted-foreground hover:text-foreground"
              }`}
            >
              <Icon className="h-3.5 w-3.5" /> {label}
            </button>
          ))}
        </div>
      </div>

      {tab === "season" && <SeasonTab />}
      {tab === "tryouts" && <TryoutsTab />}
      {tab === "transfers" && <TransfersTab />}
      {tab === "waitlist" && <WaitlistTab />}
      {tab === "payment" && <PaymentTab />}
    </div>
  );
}

/* -------------------- Season Registration -------------------- */

const seasonRegs = [
  { name: "Liam O'Connor", age: "U14", div: "AAA", date: "Jun 27", payment: "PAID", approval: "PENDING" },
  { name: "Ava Thompson", age: "U10", div: "House", date: "Jun 27", payment: "PENDING", approval: "PENDING" },
  { name: "Noah Patel", age: "U16", div: "AA", date: "Jun 26", payment: "PAID", approval: "APPROVED" },
  { name: "Mia Rodriguez", age: "U12", div: "A", date: "Jun 25", payment: "OVERDUE", approval: "PENDING" },
  { name: "Ethan Kim", age: "U18", div: "AAA", date: "Jun 25", payment: "PAID", approval: "APPROVED" },
  { name: "Sofia Hayes", age: "U14", div: "A", date: "Jun 24", payment: "PAID", approval: "PENDING" },
];

function SeasonTab() {
  const [selected, setSelected] = useState<string[]>([]);
  const toggle = (n: string) =>
    setSelected((s) => (s.includes(n) ? s.filter((x) => x !== n) : [...s, n]));

  return (
    <div className="space-y-4">
      <div className="flex flex-wrap items-center justify-between gap-2">
        <div>
          <h3 className="text-base font-semibold">2026 Season Registration</h3>
          <p className="text-xs text-muted-foreground">Window: Jun 1 – Jul 31 · 6 age groups · 387 submitted</p>
        </div>
        <div className="flex gap-2">
          <button className="inline-flex items-center gap-1.5 rounded-md border border-border px-2.5 py-1.5 text-xs font-semibold hover:bg-accent">
            <Plus className="h-3.5 w-3.5" /> Create Registration Event
          </button>
          <button className="inline-flex items-center gap-1.5 rounded-md border border-border px-2.5 py-1.5 text-xs font-semibold hover:bg-accent">
            <Download className="h-3.5 w-3.5" /> Export CSV
          </button>
        </div>
      </div>

      {/* Bulk bar */}
      <div className="flex items-center justify-between rounded-md border border-border bg-card px-3 py-2 text-xs">
        <span className="text-muted-foreground">{selected.length} selected</span>
        <div className="flex gap-2">
          <button disabled={!selected.length} className="inline-flex items-center gap-1 rounded bg-gradient-to-r from-teal-500 to-emerald-500 px-2.5 py-1 font-semibold text-white disabled:opacity-40">
            <Check className="h-3 w-3" /> Bulk Approve
          </button>
          <button disabled={!selected.length} className="inline-flex items-center gap-1 rounded border border-border px-2.5 py-1 font-semibold hover:bg-accent disabled:opacity-40">
            <Mail className="h-3 w-3" /> Send Payment Reminders
          </button>
        </div>
      </div>

      <div className="overflow-hidden rounded-lg border border-border bg-card">
        <table className="w-full text-sm">
          <thead className="text-left text-[11px] uppercase tracking-wider text-muted-foreground">
            <tr>
              <th className="px-3 py-2 w-8"></th>
              <th className="px-3 py-2">Athlete</th>
              <th className="px-3 py-2">Age</th>
              <th className="px-3 py-2">Division</th>
              <th className="px-3 py-2">Submitted</th>
              <th className="px-3 py-2">Payment</th>
              <th className="px-3 py-2">Approval</th>
            </tr>
          </thead>
          <tbody>
            {seasonRegs.map((r) => (
              <tr key={r.name} className="border-t border-border/60 hover:bg-accent/40">
                <td className="px-3 py-2">
                  <input type="checkbox" checked={selected.includes(r.name)} onChange={() => toggle(r.name)} />
                </td>
                <td className="px-3 py-2 font-medium">{r.name}</td>
                <td className="px-3 py-2 text-muted-foreground">{r.age}</td>
                <td className="px-3 py-2 text-muted-foreground">{r.div}</td>
                <td className="px-3 py-2 text-muted-foreground">{r.date}</td>
                <td className="px-3 py-2">
                  <PayBadge value={r.payment} />
                </td>
                <td className="px-3 py-2">
                  <ApprovalBadge value={r.approval} />
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}

/* -------------------- Tryouts -------------------- */

const tryoutAthletes = [
  { name: "Liam O'Connor", pos: "F", scores: [4.6, 4.4, 4.7, 4.8, 4.5], decision: "Accept" },
  { name: "Noah Patel", pos: "F", scores: [4.4, 4.3, 4.5, 4.4, 4.6], decision: "Accept" },
  { name: "Ethan Kim", pos: "D", scores: [4.2, 4.5, 4.3, 4.1, 4.4], decision: "Accept" },
  { name: "Mason Hill", pos: "F", scores: [3.9, 4.1, 4.0, 3.8, 4.2], decision: "Waitlist" },
  { name: "Owen Reyes", pos: "G", scores: [4.1, 3.9, 4.0, 4.2, 4.0], decision: "Accept" },
  { name: "Caleb Brooks", pos: "D", scores: [3.4, 3.6, 3.5, 3.3, 3.7], decision: "Not Selected" },
];

function TryoutsTab() {
  return (
    <div className="grid grid-cols-1 gap-4 xl:grid-cols-3">
      <div className="xl:col-span-2 space-y-4">
        <div className="rounded-lg border border-border bg-card">
          <div className="flex items-center justify-between border-b border-border px-4 py-3">
            <div>
              <h3 className="font-semibold">U14 AAA Tryout · Jul 14–16</h3>
              <p className="text-xs text-muted-foreground">Civic Arena · 3 evaluators · Blind scoring locked</p>
            </div>
            <button className="rounded-md bg-gradient-to-r from-teal-500 to-emerald-500 px-3 py-1.5 text-xs font-semibold text-white">
              <Plus className="h-3.5 w-3.5 inline -mt-0.5 mr-1" /> Create Tryout
            </button>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead className="text-left text-[11px] uppercase tracking-wider text-muted-foreground">
                <tr>
                  <th className="px-3 py-2">Rank</th>
                  <th className="px-3 py-2">Athlete</th>
                  <th className="px-3 py-2">Pos</th>
                  <th className="px-3 py-2">Skate</th>
                  <th className="px-3 py-2">Puck</th>
                  <th className="px-3 py-2">Sense</th>
                  <th className="px-3 py-2">Compete</th>
                  <th className="px-3 py-2">Coach</th>
                  <th className="px-3 py-2">Weighted</th>
                  <th className="px-3 py-2">Decision</th>
                </tr>
              </thead>
              <tbody>
                {tryoutAthletes.map((a, i) => {
                  const weighted = (
                    (a.scores[0] * 0.25 + a.scores[1] * 0.2 + a.scores[2] * 0.25 + a.scores[3] * 0.2 + a.scores[4] * 0.1)
                  ).toFixed(2);
                  const cut = i < 4;
                  return (
                    <tr key={a.name} className={`border-t border-border/60 ${cut ? "bg-emerald-500/5" : ""}`}>
                      <td className="px-3 py-2 font-bold">{i + 1}</td>
                      <td className="px-3 py-2 font-medium">{a.name}</td>
                      <td className="px-3 py-2 text-muted-foreground">{a.pos}</td>
                      {a.scores.map((s, j) => (
                        <td key={j} className="px-3 py-2 text-muted-foreground">{s.toFixed(1)}</td>
                      ))}
                      <td className="px-3 py-2 font-bold">{weighted}</td>
                      <td className="px-3 py-2">
                        <DecisionBadge value={a.decision} />
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>

          <div className="flex items-center justify-between border-t border-border bg-background/40 px-4 py-2 text-[11px] text-muted-foreground">
            <span>Top 4 / position highlighted as suggested cut line</span>
            <div className="flex gap-2">
              <button className="rounded border border-border px-2 py-1 font-semibold hover:bg-accent">Notify Parents</button>
              <button className="rounded bg-gradient-to-r from-teal-500 to-emerald-500 px-2 py-1 font-semibold text-white">Assign to Team</button>
            </div>
          </div>
        </div>
      </div>

      <div className="space-y-4">
        <div className="rounded-lg border border-border bg-card p-4">
          <h4 className="text-xs font-bold uppercase tracking-wider text-muted-foreground">Scorecard Criteria</h4>
          <ul className="mt-2 space-y-1.5 text-sm">
            {[
              ["Skating", 25], ["Puck Handling", 20], ["Hockey Sense", 25], ["Compete Level", 20], ["Coachability", 10],
            ].map(([k, w]) => (
              <li key={k} className="flex justify-between"><span>{k}</span><span className="text-muted-foreground">{w}%</span></li>
            ))}
          </ul>
        </div>

        <div className="rounded-lg border border-amber-500/40 bg-amber-500/5 p-4">
          <div className="flex items-center gap-2 text-amber-400">
            <AlertCircle className="h-4 w-4" />
            <h4 className="text-xs font-bold uppercase tracking-wider">Bias Detection</h4>
          </div>
          <p className="mt-2 text-xs">
            Evaluator <span className="font-semibold text-foreground">D. Walsh</span> scored consistently 0.6 above average across 18 athletes. Consider review.
          </p>
        </div>

        <div className="rounded-lg border border-border bg-card p-4">
          <h4 className="text-xs font-bold uppercase tracking-wider text-muted-foreground">Workflow</h4>
          <ol className="mt-2 space-y-2 text-xs">
            <li className="flex gap-2"><span className="text-emerald-400">✓</span> Registration open</li>
            <li className="flex gap-2"><span className="text-emerald-400">✓</span> Evaluators submit blind scores</li>
            <li className="flex gap-2"><span className="text-emerald-400">✓</span> Weighted rankings generated</li>
            <li className="flex gap-2"><span className="text-amber-400">●</span> Decisions in progress</li>
            <li className="flex gap-2"><span className="text-muted-foreground">○</span> Parent notifications</li>
            <li className="flex gap-2"><span className="text-muted-foreground">○</span> 48hr appeal window</li>
            <li className="flex gap-2"><span className="text-muted-foreground">○</span> Team assignment</li>
          </ol>
        </div>
      </div>
    </div>
  );
}

/* -------------------- Transfers -------------------- */

const transfers = [
  { athlete: "Jaxon Mills", from: "U14 AA Foxes", to: "U14 AAA Blades", reason: "Caliber progression", stage: "Receiving Coach" },
  { athlete: "Hannah Webb", from: "U12 A Lightning", to: "U12 House Penguins", reason: "Schedule conflict", stage: "Association Admin" },
  { athlete: "Cole Tanner", from: "U16 A Hawks", to: "U16 AA Wolves", reason: "Family relocation", stage: "Releasing Coach" },
];

function TransfersTab() {
  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <div>
          <h3 className="text-base font-semibold">Player Transfers</h3>
          <p className="text-xs text-muted-foreground">Releasing → Receiving → Association → Governing Body</p>
        </div>
        <button className="rounded-md bg-gradient-to-r from-teal-500 to-emerald-500 px-3 py-1.5 text-xs font-semibold text-white">
          <Plus className="h-3.5 w-3.5 inline -mt-0.5 mr-1" /> New Transfer Request
        </button>
      </div>

      <div className="space-y-2">
        {transfers.map((t) => {
          const stages = ["Releasing Coach", "Receiving Coach", "Association Admin", "Governing Body"];
          const idx = stages.indexOf(t.stage);
          return (
            <div key={t.athlete} className="rounded-lg border border-border bg-card p-4">
              <div className="flex items-start justify-between gap-3">
                <div>
                  <div className="font-semibold">{t.athlete}</div>
                  <div className="text-xs text-muted-foreground mt-0.5">
                    {t.from} <ArrowRightLeft className="h-3 w-3 inline mx-1" /> {t.to}
                  </div>
                  <div className="text-[11px] text-muted-foreground mt-0.5">Reason: {t.reason}</div>
                </div>
                <button className="text-[11px] font-semibold text-teal-400">View History</button>
              </div>
              <div className="mt-3 flex items-center gap-1">
                {stages.map((s, i) => (
                  <div key={s} className="flex-1">
                    <div className={`h-1.5 rounded-full ${i <= idx ? "bg-gradient-to-r from-teal-500 to-emerald-500" : "bg-muted"}`} />
                    <div className={`mt-1 text-[10px] ${i === idx ? "text-amber-400 font-semibold" : "text-muted-foreground"}`}>{s}</div>
                  </div>
                ))}
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}

/* -------------------- Waitlist -------------------- */

const waitlist = [
  { athlete: "Ryan Foster", team: "U14 AAA Blades", age: "U14", div: "AAA", since: "Jun 18" },
  { athlete: "Emma Vance", team: "U12 A Lightning", age: "U12", div: "A", since: "Jun 20" },
  { athlete: "Aiden Park", team: "U16 AA Wolves", age: "U16", div: "AA", since: "Jun 22" },
  { athlete: "Zoe Marin", team: "U10 Mites", age: "U10", div: "House", since: "Jun 24" },
];

function WaitlistTab() {
  const [window, setWindow] = useState("48hr");
  const [autoPromote, setAutoPromote] = useState(true);

  return (
    <div className="space-y-4">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <h3 className="text-base font-semibold">Waitlist</h3>
          <p className="text-xs text-muted-foreground">{waitlist.length} athletes waiting across 4 teams</p>
        </div>
        <div className="flex items-center gap-3 text-xs">
          <label className="flex items-center gap-2">
            <input type="checkbox" checked={autoPromote} onChange={(e) => setAutoPromote(e.target.checked)} />
            Auto-promote when spots open
          </label>
          <select value={window} onChange={(e) => setWindow(e.target.value)} className="rounded border border-border bg-background px-2 py-1">
            <option>24hr</option>
            <option>48hr</option>
            <option>72hr</option>
          </select>
        </div>
      </div>

      <div className="overflow-hidden rounded-lg border border-border bg-card">
        <table className="w-full text-sm">
          <thead className="text-left text-[11px] uppercase tracking-wider text-muted-foreground">
            <tr>
              <th className="px-3 py-2">Athlete</th>
              <th className="px-3 py-2">Team</th>
              <th className="px-3 py-2">Age</th>
              <th className="px-3 py-2">Division</th>
              <th className="px-3 py-2">Waiting Since</th>
              <th className="px-3 py-2 text-right">Actions</th>
            </tr>
          </thead>
          <tbody>
            {waitlist.map((w) => (
              <tr key={w.athlete} className="border-t border-border/60 hover:bg-accent/40">
                <td className="px-3 py-2 font-medium">{w.athlete}</td>
                <td className="px-3 py-2 text-muted-foreground">{w.team}</td>
                <td className="px-3 py-2 text-muted-foreground">{w.age}</td>
                <td className="px-3 py-2 text-muted-foreground">{w.div}</td>
                <td className="px-3 py-2 text-muted-foreground">{w.since}</td>
                <td className="px-3 py-2 text-right">
                  <button className="rounded bg-gradient-to-r from-teal-500 to-emerald-500 px-2 py-1 text-[11px] font-semibold text-white">
                    Promote
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}

/* -------------------- Payment Tracking -------------------- */

const payments = [
  { family: "O'Connor Family", athlete: "Liam O'Connor", type: "Season Reg", amount: 850, status: "PAID", due: "Jun 30" },
  { family: "Thompson Family", athlete: "Ava Thompson", type: "Season Reg", amount: 425, status: "PENDING", due: "Jul 5" },
  { family: "Patel Family", athlete: "Noah Patel", type: "Tryout Fee", amount: 75, status: "PAID", due: "Jul 1" },
  { family: "Rodriguez Family", athlete: "Mia Rodriguez", type: "Season Reg", amount: 625, status: "OVERDUE", due: "Jun 15" },
  { family: "Hayes Family", athlete: "Sofia Hayes", type: "Season Reg", amount: 625, status: "PENDING", due: "Jul 10" },
  { family: "Brooks Family", athlete: "Tyler Brooks", type: "Tournament", amount: 200, status: "OVERDUE", due: "Jun 10" },
];

function PaymentTab() {
  const [filter, setFilter] = useState<"ALL" | "PAID" | "PENDING" | "OVERDUE">("ALL");
  const [selected, setSelected] = useState<string[]>([]);
  const list = payments.filter((p) => filter === "ALL" || p.status === filter);
  const toggle = (n: string) =>
    setSelected((s) => (s.includes(n) ? s.filter((x) => x !== n) : [...s, n]));

  return (
    <div className="space-y-4">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div className="flex items-center gap-1 rounded-md border border-border bg-card p-0.5">
          {(["ALL", "PAID", "PENDING", "OVERDUE"] as const).map((f) => (
            <button
              key={f}
              onClick={() => setFilter(f)}
              className={`px-2.5 py-1 text-[11px] font-semibold rounded ${
                filter === f ? "bg-gradient-to-r from-teal-500 to-emerald-500 text-white" : "text-muted-foreground hover:text-foreground"
              }`}
            >
              {f}
            </button>
          ))}
        </div>
        <div className="flex gap-2">
          <button disabled={!selected.length} className="inline-flex items-center gap-1 rounded border border-border px-2.5 py-1 text-xs font-semibold hover:bg-accent disabled:opacity-40">
            <Mail className="h-3 w-3" /> Send Reminders ({selected.length})
          </button>
          <button className="inline-flex items-center gap-1 rounded border border-border px-2.5 py-1 text-xs font-semibold hover:bg-accent">
            <Download className="h-3 w-3" /> Export Report
          </button>
        </div>
      </div>

      <div className="overflow-hidden rounded-lg border border-border bg-card">
        <table className="w-full text-sm">
          <thead className="text-left text-[11px] uppercase tracking-wider text-muted-foreground">
            <tr>
              <th className="px-3 py-2 w-8"></th>
              <th className="px-3 py-2">Family</th>
              <th className="px-3 py-2">Athlete</th>
              <th className="px-3 py-2">Type</th>
              <th className="px-3 py-2">Amount</th>
              <th className="px-3 py-2">Status</th>
              <th className="px-3 py-2">Due</th>
              <th className="px-3 py-2 text-right">Actions</th>
            </tr>
          </thead>
          <tbody>
            {list.map((p) => (
              <tr key={p.family + p.type} className="border-t border-border/60 hover:bg-accent/40">
                <td className="px-3 py-2">
                  <input type="checkbox" checked={selected.includes(p.family)} onChange={() => toggle(p.family)} />
                </td>
                <td className="px-3 py-2 font-medium">{p.family}</td>
                <td className="px-3 py-2 text-muted-foreground">{p.athlete}</td>
                <td className="px-3 py-2 text-muted-foreground">{p.type}</td>
                <td className="px-3 py-2">${p.amount}</td>
                <td className="px-3 py-2"><PayBadge value={p.status} /></td>
                <td className="px-3 py-2 text-muted-foreground">{p.due}</td>
                <td className="px-3 py-2 text-right">
                  <button className="inline-flex items-center gap-1 rounded border border-border px-2 py-1 text-[11px] font-semibold hover:bg-accent">
                    <Eye className="h-3 w-3" /> Refund
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}

/* -------------------- shared badges -------------------- */

function PayBadge({ value }: { value: string }) {
  const map: Record<string, string> = {
    PAID: "bg-emerald-500/15 text-emerald-400 ring-emerald-500/30",
    PENDING: "bg-amber-500/15 text-amber-400 ring-amber-500/30",
    OVERDUE: "bg-red-500/15 text-red-400 ring-red-500/30",
  };
  return <span className={`rounded px-1.5 py-0.5 text-[10px] font-bold ring-1 ring-inset ${map[value]}`}>{value}</span>;
}

function ApprovalBadge({ value }: { value: string }) {
  const map: Record<string, string> = {
    APPROVED: "bg-emerald-500/15 text-emerald-400 ring-emerald-500/30",
    PENDING: "bg-amber-500/15 text-amber-400 ring-amber-500/30",
    DECLINED: "bg-red-500/15 text-red-400 ring-red-500/30",
  };
  return <span className={`rounded px-1.5 py-0.5 text-[10px] font-bold ring-1 ring-inset ${map[value]}`}>{value}</span>;
}

function DecisionBadge({ value }: { value: string }) {
  const map: Record<string, string> = {
    Accept: "bg-emerald-500/15 text-emerald-400 ring-emerald-500/30",
    Waitlist: "bg-amber-500/15 text-amber-400 ring-amber-500/30",
    "Not Selected": "bg-red-500/15 text-red-400 ring-red-500/30",
  };
  return <span className={`rounded px-1.5 py-0.5 text-[10px] font-bold ring-1 ring-inset ${map[value]}`}>{value}</span>;
}
