import { useMemo, useState } from "react";
import {
  Download,
  Mail,
  Plus,
  Search,
  X,
  Upload,
  ExternalLink,
  AlertTriangle,
  CheckCircle2,
  Clock,
  ShieldCheck,
  FileSignature,
  Bell,
  UserPlus,
  Send,
} from "lucide-react";

type Compliance = "compliant" | "action" | "non-compliant";

type Coach = {
  id: string;
  name: string;
  initials: string;
  email: string;
  phone: string;
  role: "HEAD COACH" | "ASSISTANT" | "GOALIE COACH" | "TRAINER";
  teams: string[];
  cert: { level: string; body: "Hockey Canada" | "USA Hockey"; issued: string; expiry: string };
  background: { status: "Clear" | "Pending" | "Review Required" | "Failed"; provider: string; expiry: string };
  vsc: { status: "On File" | "Missing" | "Expired"; issuedBy: string; issued: string; expiry: string };
  firstAid: { provider: string; level: string; issued: string; expiry: string };
  safeSport: { program: string; certNo: string; completed: string; expiry: string };
  coi: { season: string; signed: boolean; signedDate: string | null };
  pending?: boolean;
  daysToFirstExpiry: number;
  notifications: { ts: string; text: string; level: "info" | "warn" | "urgent" }[];
};

const COACHES: Coach[] = [
  {
    id: "c1", name: "Marcus Bell", initials: "MB", email: "mbell@nlh.ca", phone: "(204) 555-0123",
    role: "HEAD COACH", teams: ["U15 AAA"],
    cert: { level: "Development 1", body: "Hockey Canada", issued: "2023-09-12", expiry: "2027-09-12" },
    background: { status: "Clear", provider: "Checkr", expiry: "2027-02-04" },
    vsc: { status: "On File", issuedBy: "RCMP", issued: "2024-01-18", expiry: "2027-01-18" },
    firstAid: { provider: "Red Cross", level: "Standard First Aid", issued: "2024-03-02", expiry: "2027-03-02" },
    safeSport: { program: "Respect in Sport", certNo: "RIS-882134", completed: "2024-08-19", expiry: "2027-08-19" },
    coi: { season: "2025-26", signed: true, signedDate: "2025-09-01" },
    daysToFirstExpiry: 412,
    notifications: [
      { ts: "2025-09-01 10:14", text: "COI declaration signed for 2025-26 season", level: "info" },
    ],
  },
  {
    id: "c2", name: "Priya Singh", initials: "PS", email: "psingh@nlh.ca", phone: "(204) 555-0188",
    role: "ASSISTANT", teams: ["U13 AA", "U11 A"],
    cert: { level: "Trained", body: "Hockey Canada", issued: "2022-10-04", expiry: "2026-08-12" },
    background: { status: "Clear", provider: "Checkr", expiry: "2026-08-22" },
    vsc: { status: "On File", issuedBy: "Winnipeg Police", issued: "2023-08-22", expiry: "2026-08-22" },
    firstAid: { provider: "St. John Ambulance", level: "Emergency First Aid", issued: "2023-11-01", expiry: "2026-08-15" },
    safeSport: { program: "Respect in Sport", certNo: "RIS-771204", completed: "2023-09-10", expiry: "2026-09-10" },
    coi: { season: "2025-26", signed: false, signedDate: null },
    daysToFirstExpiry: 41,
    notifications: [
      { ts: "2025-10-12 08:00", text: "60-day expiry notice sent — First Aid", level: "info" },
      { ts: "2025-11-11 08:00", text: "30-day reminder sent — First Aid", level: "warn" },
    ],
  },
  {
    id: "c3", name: "Tom Reilly", initials: "TR", email: "treilly@nlh.ca", phone: "(204) 555-0144",
    role: "GOALIE COACH", teams: ["U18 AAA"],
    cert: { level: "Community", body: "Hockey Canada", issued: "2021-09-01", expiry: "2025-09-01" },
    background: { status: "Review Required", provider: "Checkr", expiry: "—" },
    vsc: { status: "Expired", issuedBy: "RCMP", issued: "2021-05-01", expiry: "2024-05-01" },
    firstAid: { provider: "Red Cross", level: "CPR only", issued: "2022-04-01", expiry: "2025-04-01" },
    safeSport: { program: "Respect in Sport", certNo: "RIS-554019", completed: "2022-06-12", expiry: "2025-06-12" },
    coi: { season: "2025-26", signed: false, signedDate: null },
    daysToFirstExpiry: -88,
    notifications: [
      { ts: "2025-04-01 08:00", text: "First Aid expired — flagged RED, admin alerted", level: "urgent" },
      { ts: "2025-05-01 08:00", text: "VSC expired — coach flagged non-compliant", level: "urgent" },
    ],
  },
  {
    id: "c4", name: "Sara Chen", initials: "SC", email: "schen@nlh.ca", phone: "(204) 555-0167",
    role: "TRAINER", teams: ["U15 AAA", "U18 AAA"],
    cert: { level: "Development 2", body: "Hockey Canada", issued: "2024-02-10", expiry: "2028-02-10" },
    background: { status: "Clear", provider: "Checkr", expiry: "2027-06-04" },
    vsc: { status: "On File", issuedBy: "RCMP", issued: "2024-06-04", expiry: "2027-06-04" },
    firstAid: { provider: "Red Cross", level: "Standard First Aid", issued: "2025-01-22", expiry: "2028-01-22" },
    safeSport: { program: "Respect in Sport", certNo: "RIS-998812", completed: "2024-10-04", expiry: "2027-10-04" },
    coi: { season: "2025-26", signed: true, signedDate: "2025-08-19" },
    daysToFirstExpiry: 720,
    notifications: [],
  },
  {
    id: "c5", name: "Derek Olson", initials: "DO", email: "dolson@nlh.ca", phone: "(204) 555-0199",
    role: "HEAD COACH", teams: ["U11 A"],
    cert: { level: "Intro", body: "Hockey Canada", issued: "2024-09-01", expiry: "2028-09-01" },
    background: { status: "Pending", provider: "Checkr", expiry: "—" },
    vsc: { status: "Missing", issuedBy: "—", issued: "—", expiry: "—" },
    firstAid: { provider: "—", level: "—", issued: "—", expiry: "—" },
    safeSport: { program: "Respect in Sport", certNo: "—", completed: "—", expiry: "—" },
    coi: { season: "2025-26", signed: false, signedDate: null },
    pending: true,
    daysToFirstExpiry: 0,
    notifications: [
      { ts: "2025-11-20 09:00", text: "Invite sent — awaiting account creation", level: "info" },
    ],
  },
];

function complianceOf(c: Coach): Compliance {
  if (c.pending) return "action";
  if (c.daysToFirstExpiry < 0) return "non-compliant";
  if (
    c.background.status === "Failed" ||
    c.vsc.status === "Expired" || c.vsc.status === "Missing" ||
    c.firstAid.expiry === "—" || c.safeSport.expiry === "—"
  ) return "non-compliant";
  if (c.daysToFirstExpiry <= 60 || !c.coi.signed || c.background.status !== "Clear") return "action";
  return "compliant";
}

const ComplianceBadge = ({ c }: { c: Compliance }) => {
  const map = {
    compliant: { label: "COMPLIANT", cls: "bg-emerald-500/15 text-emerald-400 border-emerald-500/30" },
    action: { label: "ACTION REQUIRED", cls: "bg-amber-500/15 text-amber-400 border-amber-500/30" },
    "non-compliant": { label: "NON-COMPLIANT", cls: "bg-red-500/15 text-red-400 border-red-500/30" },
  }[c];
  return (
    <span className={`inline-flex items-center gap-1 rounded-md border px-2 py-0.5 text-[10px] font-semibold ${map.cls}`}>
      {map.label}
    </span>
  );
};

const StatusPill = ({ status }: { status: string }) => {
  const ok = ["Clear", "On File"].includes(status);
  const warn = ["Pending", "Review Required"].includes(status);
  const bad = ["Failed", "Expired", "Missing"].includes(status);
  const cls = ok
    ? "bg-emerald-500/15 text-emerald-400"
    : warn
    ? "bg-amber-500/15 text-amber-400"
    : bad
    ? "bg-red-500/15 text-red-400"
    : "bg-muted text-muted-foreground";
  return <span className={`rounded px-1.5 py-0.5 text-[10px] font-medium ${cls}`}>{status}</span>;
};

const TEAMS = ["U11 A", "U13 AA", "U15 AAA", "U18 AAA"];

export function AssociationCoaches() {
  const [selected, setSelected] = useState<Coach | null>(null);
  const [showInvite, setShowInvite] = useState(false);
  const [search, setSearch] = useState("");
  const [filterTeam, setFilterTeam] = useState("all");
  const [filterStatus, setFilterStatus] = useState<"all" | Compliance>("all");
  const [filterLevel, setFilterLevel] = useState("all");
  const [sortKey, setSortKey] = useState<"name" | "expiry" | "compliance">("compliance");
  const [picked, setPicked] = useState<Set<string>>(new Set());

  const rows = useMemo(() => {
    let r = COACHES.filter((c) => {
      if (search && !c.name.toLowerCase().includes(search.toLowerCase())) return false;
      if (filterTeam !== "all" && !c.teams.includes(filterTeam)) return false;
      if (filterStatus !== "all" && complianceOf(c) !== filterStatus) return false;
      if (filterLevel !== "all" && c.cert.level !== filterLevel) return false;
      return true;
    });
    const order: Record<Compliance, number> = { "non-compliant": 0, action: 1, compliant: 2 };
    if (sortKey === "name") r = [...r].sort((a, b) => a.name.localeCompare(b.name));
    if (sortKey === "expiry") r = [...r].sort((a, b) => a.daysToFirstExpiry - b.daysToFirstExpiry);
    if (sortKey === "compliance") r = [...r].sort((a, b) => order[complianceOf(a)] - order[complianceOf(b)]);
    return r;
  }, [search, filterTeam, filterStatus, filterLevel, sortKey]);

  const togglePick = (id: string) =>
    setPicked((p) => {
      const n = new Set(p);
      n.has(id) ? n.delete(id) : n.add(id);
      return n;
    });

  return (
    <div className="space-y-5">
      {/* Toolbar */}
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div className="flex flex-wrap items-center gap-2">
          <div className="relative">
            <Search className="absolute left-2 top-1/2 h-3.5 w-3.5 -translate-y-1/2 text-muted-foreground" />
            <input
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="Search coach…"
              className="h-8 w-56 rounded-md border border-border bg-background pl-7 pr-2 text-xs"
            />
          </div>
          <select value={filterTeam} onChange={(e) => setFilterTeam(e.target.value)}
            className="h-8 rounded-md border border-border bg-background px-2 text-xs">
            <option value="all">All teams</option>
            {TEAMS.map((t) => <option key={t} value={t}>{t}</option>)}
          </select>
          <select value={filterStatus} onChange={(e) => setFilterStatus(e.target.value as never)}
            className="h-8 rounded-md border border-border bg-background px-2 text-xs">
            <option value="all">All compliance</option>
            <option value="compliant">Compliant</option>
            <option value="action">Action required</option>
            <option value="non-compliant">Non-compliant</option>
          </select>
          <select value={filterLevel} onChange={(e) => setFilterLevel(e.target.value)}
            className="h-8 rounded-md border border-border bg-background px-2 text-xs">
            <option value="all">All cert levels</option>
            {["Intro", "Community", "Trained", "Development 1", "Development 2", "High Performance"].map((l) =>
              <option key={l} value={l}>{l}</option>)}
          </select>
          <select value={sortKey} onChange={(e) => setSortKey(e.target.value as never)}
            className="h-8 rounded-md border border-border bg-background px-2 text-xs">
            <option value="compliance">Sort: Compliance</option>
            <option value="name">Sort: Name</option>
            <option value="expiry">Sort: Next expiry</option>
          </select>
        </div>
        <div className="flex items-center gap-2">
          <button className="inline-flex h-8 items-center gap-1.5 rounded-md border border-border bg-background px-3 text-xs hover:bg-accent">
            <Mail className="h-3.5 w-3.5" /> Send reminders
          </button>
          <button className="inline-flex h-8 items-center gap-1.5 rounded-md border border-border bg-background px-3 text-xs hover:bg-accent">
            <Download className="h-3.5 w-3.5" /> Export CSV
          </button>
          <button className="inline-flex h-8 items-center gap-1.5 rounded-md border border-border bg-background px-3 text-xs hover:bg-accent">
            <UserPlus className="h-3.5 w-3.5" /> Assign to team
          </button>
          <button
            onClick={() => setShowInvite(true)}
            className="inline-flex h-8 items-center gap-1.5 rounded-md bg-gradient-to-r from-teal-500 to-emerald-500 px-3 text-xs font-medium text-white hover:opacity-90">
            <Plus className="h-3.5 w-3.5" /> Invite Coach
          </button>
        </div>
      </div>

      {picked.size > 0 && (
        <div className="flex items-center justify-between rounded-md border border-emerald-500/30 bg-emerald-500/10 px-3 py-2 text-xs">
          <span>{picked.size} coach{picked.size > 1 ? "es" : ""} selected</span>
          <div className="flex gap-2">
            <button className="rounded border border-border bg-background px-2 py-1 hover:bg-accent">Send reminder</button>
            <button className="rounded border border-border bg-background px-2 py-1 hover:bg-accent">Assign team</button>
          </div>
        </div>
      )}

      {/* Table */}
      <div className="overflow-hidden rounded-lg border border-border">
        <table className="w-full text-sm">
          <thead className="bg-muted/40 text-xs uppercase text-muted-foreground">
            <tr>
              <th className="w-8 px-2 py-2"></th>
              <th className="px-3 py-2 text-left">Name</th>
              <th className="px-3 py-2 text-left">Team(s)</th>
              <th className="px-3 py-2 text-left">Cert Level</th>
              <th className="px-3 py-2 text-left">Cert Expiry</th>
              <th className="px-3 py-2 text-left">Background</th>
              <th className="px-3 py-2 text-left">VSC</th>
              <th className="px-3 py-2 text-left">First Aid</th>
              <th className="px-3 py-2 text-left">Safe Sport</th>
              <th className="px-3 py-2 text-left">Compliance</th>
            </tr>
          </thead>
          <tbody>
            {rows.map((c) => {
              const comp = complianceOf(c);
              return (
                <tr
                  key={c.id}
                  onClick={() => setSelected(c)}
                  className="cursor-pointer border-t border-border hover:bg-accent/40"
                >
                  <td className="px-2 py-2" onClick={(e) => e.stopPropagation()}>
                    <input
                      type="checkbox"
                      checked={picked.has(c.id)}
                      onChange={() => togglePick(c.id)}
                      className="h-3.5 w-3.5 accent-emerald-500"
                    />
                  </td>
                  <td className="px-3 py-2">
                    <div className="flex items-center gap-2">
                      <div className="flex h-7 w-7 items-center justify-center rounded-full bg-gradient-to-br from-teal-500 to-emerald-500 text-[10px] font-semibold text-white">
                        {c.initials}
                      </div>
                      <div>
                        <div className="font-medium">{c.name}</div>
                        <div className="text-[11px] text-muted-foreground">{c.role}{c.pending ? " · PENDING" : ""}</div>
                      </div>
                    </div>
                  </td>
                  <td className="px-3 py-2 text-xs text-muted-foreground">{c.teams.join(", ")}</td>
                  <td className="px-3 py-2 text-xs">{c.cert.level}</td>
                  <td className="px-3 py-2 text-xs">{c.cert.expiry}</td>
                  <td className="px-3 py-2"><StatusPill status={c.background.status} /></td>
                  <td className="px-3 py-2"><StatusPill status={c.vsc.status} /></td>
                  <td className="px-3 py-2 text-xs">{c.firstAid.expiry}</td>
                  <td className="px-3 py-2 text-xs">{c.safeSport.expiry}</td>
                  <td className="px-3 py-2"><ComplianceBadge c={comp} /></td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>

      {selected && <CoachPanel coach={selected} onClose={() => setSelected(null)} />}
      {showInvite && <InviteDrawer onClose={() => setShowInvite(false)} />}
    </div>
  );
}

/* -------------------- Detail Panel -------------------- */

function CoachPanel({ coach, onClose }: { coach: Coach; onClose: () => void }) {
  return (
    <>
      <div onClick={onClose} className="fixed inset-0 z-40 bg-black/50" />
      <aside className="fixed right-0 top-0 z-50 h-full w-full max-w-xl overflow-y-auto border-l border-border bg-background shadow-2xl">
        <div className="sticky top-0 z-10 flex items-center justify-between border-b border-border bg-background px-5 py-3">
          <h3 className="text-sm font-semibold">Coach details</h3>
          <button onClick={onClose} className="rounded p-1 hover:bg-accent"><X className="h-4 w-4" /></button>
        </div>

        {/* Header */}
        <div className="border-b border-border p-5">
          <div className="flex items-start gap-3">
            <div className="flex h-14 w-14 items-center justify-center rounded-full bg-gradient-to-br from-teal-500 to-emerald-500 text-lg font-semibold text-white">
              {coach.initials}
            </div>
            <div className="flex-1">
              <div className="flex items-center gap-2">
                <h2 className="text-lg font-semibold">{coach.name}</h2>
                <span className="rounded border border-border bg-muted px-1.5 py-0.5 text-[10px] font-medium">{coach.role}</span>
              </div>
              <div className="mt-1 space-y-0.5 text-xs text-muted-foreground">
                <div>{coach.email} · {coach.phone}</div>
                <div>Teams: {coach.teams.join(", ") || "—"}</div>
              </div>
              <div className="mt-2"><ComplianceBadge c={complianceOf(coach)} /></div>
            </div>
          </div>

          {coach.cert.level === "Community" && coach.teams.includes("U18 AAA") && (
            <div className="mt-3 flex items-start gap-2 rounded-md border border-red-500/30 bg-red-500/10 p-2 text-xs text-red-400">
              <AlertTriangle className="mt-0.5 h-3.5 w-3.5" />
              <span>This team requires <strong>Development 1</strong> minimum — coach does not qualify as head coach.</span>
            </div>
          )}
        </div>

        {/* Checklist */}
        <div className="space-y-3 p-5">
          <ChecklistCard
            icon={ShieldCheck}
            title="Certification Level"
            status={coach.cert.expiry !== "—" ? "ok" : "warn"}
            rows={[
              ["Body", coach.cert.body],
              ["Level", coach.cert.level],
              ["Issued", coach.cert.issued],
              ["Expiry", coach.cert.expiry],
            ]}
            action={
              <a className="inline-flex items-center gap-1 text-emerald-400 hover:underline" href="#">
                Renewal portal <ExternalLink className="h-3 w-3" />
              </a>
            }
          />

          <ChecklistCard
            icon={CheckCircle2}
            title="Background Check"
            status={coach.background.status === "Clear" ? "ok" : coach.background.status === "Failed" ? "bad" : "warn"}
            rows={[
              ["Status", coach.background.status],
              ["Provider", coach.background.provider],
              ["Expiry", coach.background.expiry],
            ]}
            action={
              <button className="inline-flex items-center gap-1 rounded border border-border bg-background px-2 py-1 hover:bg-accent">
                <Send className="h-3 w-3" /> Initiate check (Checkr)
              </button>
            }
          />

          <ChecklistCard
            icon={ShieldCheck}
            title="Vulnerable Sector Check"
            status={coach.vsc.status === "On File" ? "ok" : "bad"}
            rows={[
              ["Status", coach.vsc.status],
              ["Authority", coach.vsc.issuedBy],
              ["Issued", coach.vsc.issued],
              ["Expiry", coach.vsc.expiry],
            ]}
            action={<UploadButton />}
          />

          <ChecklistCard
            icon={CheckCircle2}
            title="First Aid / CPR"
            status={coach.firstAid.expiry === "—" ? "bad" : "ok"}
            rows={[
              ["Provider", coach.firstAid.provider],
              ["Level", coach.firstAid.level],
              ["Issued", coach.firstAid.issued],
              ["Expiry", coach.firstAid.expiry],
            ]}
            action={<UploadButton />}
          />

          <ChecklistCard
            icon={ShieldCheck}
            title="Safe Sport Training"
            status={coach.safeSport.expiry === "—" ? "bad" : "ok"}
            rows={[
              ["Program", coach.safeSport.program],
              ["Certificate #", coach.safeSport.certNo],
              ["Completed", coach.safeSport.completed],
              ["Expiry", coach.safeSport.expiry],
            ]}
            action={<UploadButton />}
          />

          <ChecklistCard
            icon={FileSignature}
            title={`Conflict of Interest — ${coach.coi.season}`}
            status={coach.coi.signed ? "ok" : "warn"}
            rows={[
              ["Status", coach.coi.signed ? "Signed" : "Not Signed"],
              ["Date", coach.coi.signedDate ?? "—"],
            ]}
            action={
              <button className="inline-flex items-center gap-1 rounded border border-border bg-background px-2 py-1 hover:bg-accent">
                <Mail className="h-3 w-3" /> Send declaration
              </button>
            }
          />

          {/* Notifications */}
          <div className="rounded-lg border border-border p-3">
            <div className="mb-2 flex items-center gap-1.5 text-xs font-semibold">
              <Bell className="h-3.5 w-3.5" /> Notification log
            </div>
            {coach.notifications.length === 0 ? (
              <div className="text-xs text-muted-foreground">No notifications yet.</div>
            ) : (
              <ul className="space-y-1.5">
                {coach.notifications.map((n, i) => (
                  <li key={i} className="flex items-start gap-2 text-xs">
                    <Clock className={`mt-0.5 h-3 w-3 ${
                      n.level === "urgent" ? "text-red-400" : n.level === "warn" ? "text-amber-400" : "text-muted-foreground"
                    }`} />
                    <div>
                      <div className="text-muted-foreground">{n.ts}</div>
                      <div>{n.text}</div>
                    </div>
                  </li>
                ))}
              </ul>
            )}
            <div className="mt-2 text-[11px] text-muted-foreground">
              Auto-cadence: 60d · 30d · 7d · day-of (coach + admin)
            </div>
          </div>
        </div>
      </aside>
    </>
  );
}

function ChecklistCard({
  icon: Icon, title, status, rows, action,
}: {
  icon: React.ComponentType<{ className?: string }>;
  title: string;
  status: "ok" | "warn" | "bad";
  rows: [string, string][];
  action?: React.ReactNode;
}) {
  const cls = status === "ok" ? "border-emerald-500/30" : status === "warn" ? "border-amber-500/30" : "border-red-500/30";
  const dot = status === "ok" ? "bg-emerald-500" : status === "warn" ? "bg-amber-500" : "bg-red-500";
  return (
    <div className={`rounded-lg border ${cls} p-3`}>
      <div className="mb-2 flex items-center justify-between">
        <div className="flex items-center gap-2">
          <Icon className="h-3.5 w-3.5" />
          <span className="text-xs font-semibold">{title}</span>
          <span className={`h-1.5 w-1.5 rounded-full ${dot}`} />
        </div>
        {action}
      </div>
      <dl className="grid grid-cols-2 gap-x-3 gap-y-1 text-xs">
        {rows.map(([k, v]) => (
          <div key={k} className="contents">
            <dt className="text-muted-foreground">{k}</dt>
            <dd>{v}</dd>
          </div>
        ))}
      </dl>
    </div>
  );
}

function UploadButton() {
  return (
    <button className="inline-flex items-center gap-1 rounded border border-border bg-background px-2 py-1 text-xs hover:bg-accent">
      <Upload className="h-3 w-3" /> Upload
    </button>
  );
}

/* -------------------- Invite Drawer -------------------- */

function InviteDrawer({ onClose }: { onClose: () => void }) {
  const [team, setTeam] = useState("U13 AA");
  const [role, setRole] = useState("ASSISTANT");
  const [override, setOverride] = useState(false);
  const requiresOverride = team === "U18 AAA" && role === "HEAD COACH";

  return (
    <>
      <div onClick={onClose} className="fixed inset-0 z-40 bg-black/50" />
      <aside className="fixed right-0 top-0 z-50 h-full w-full max-w-md overflow-y-auto border-l border-border bg-background shadow-2xl">
        <div className="flex items-center justify-between border-b border-border px-5 py-3">
          <h3 className="text-sm font-semibold">Invite Coach</h3>
          <button onClick={onClose} className="rounded p-1 hover:bg-accent"><X className="h-4 w-4" /></button>
        </div>
        <div className="space-y-3 p-5 text-sm">
          <div className="grid grid-cols-2 gap-2">
            <Field label="First name"><input className="input" placeholder="Jane" /></Field>
            <Field label="Last name"><input className="input" placeholder="Doe" /></Field>
          </div>
          <Field label="Email"><input className="input" type="email" placeholder="jane@team.com" /></Field>
          <Field label="Role">
            <select className="input" value={role} onChange={(e) => setRole(e.target.value)}>
              <option>HEAD COACH</option><option>ASSISTANT</option><option>GOALIE COACH</option><option>TRAINER</option>
            </select>
          </Field>
          <Field label="Team assignment">
            <select className="input" value={team} onChange={(e) => setTeam(e.target.value)}>
              {TEAMS.map((t) => <option key={t}>{t}</option>)}
            </select>
          </Field>

          {requiresOverride && (
            <div className="rounded-md border border-red-500/30 bg-red-500/10 p-2 text-xs text-red-400">
              <div className="flex items-start gap-2">
                <AlertTriangle className="mt-0.5 h-3.5 w-3.5" />
                <div>
                  U18 AAA requires <strong>Development 1</strong> minimum for head coach. Invitee's certification will need verification.
                  <label className="mt-2 flex items-center gap-1.5">
                    <input type="checkbox" checked={override} onChange={(e) => setOverride(e.target.checked)} className="accent-red-500" />
                    Override and log (audit trail)
                  </label>
                </div>
              </div>
            </div>
          )}

          <div className="rounded-md bg-muted/50 p-2 text-[11px] text-muted-foreground">
            Invite sent via Resend. Coach creates an account, gets auto-tied to the association, and shows as <strong>PENDING</strong> until accepted. Resend option available after 7 days.
          </div>

          <div className="flex justify-end gap-2 pt-2">
            <button onClick={onClose} className="rounded-md border border-border bg-background px-3 py-1.5 text-xs hover:bg-accent">Cancel</button>
            <button
              disabled={requiresOverride && !override}
              className="rounded-md bg-gradient-to-r from-teal-500 to-emerald-500 px-3 py-1.5 text-xs font-medium text-white disabled:opacity-50"
            >
              Send Invite
            </button>
          </div>
        </div>
      </aside>
      <style>{`.input{width:100%;height:32px;border-radius:6px;border:1px solid hsl(var(--border));background:hsl(var(--background));padding:0 8px;font-size:12px;}`}</style>
    </>
  );
}

function Field({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <label className="block">
      <span className="mb-1 block text-[11px] font-medium text-muted-foreground">{label}</span>
      {children}
    </label>
  );
}
