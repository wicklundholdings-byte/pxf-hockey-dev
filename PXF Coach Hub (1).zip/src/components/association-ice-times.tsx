import { useMemo, useState } from "react";
import {
  Calendar as CalendarIcon,
  List,
  Plus,
  FileUp,
  Download,
  X,
  AlertTriangle,
  MapPin,
  Clock,
  DollarSign,
  Sparkles,
  Building2,
  Edit3,
  Trash2,
  ChevronLeft,
  ChevronRight,
  Wand2,
  Check,
  ArrowRight,
  ArrowLeft,
  Loader2,
  Repeat,
  ChevronDown,
} from "lucide-react";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";


// ============================================================
// Types & Mock Data
// ============================================================

type AllocationType = "practice" | "game" | "camp" | "unallocated" | "blocked";

type IceSlot = {
  id: string;
  date: string; // YYYY-MM-DD
  start: string; // HH:mm
  end: string;
  rinkId: string;
  surface: string;
  type: AllocationType;
  team?: string;
  camp?: string;
  notes?: string;
};

type Rink = {
  id: string;
  name: string;
  address: string;
  surfaces: string[];
  dressingRooms: number;
  contact: string;
  costPerHour: number;
  notes: string;
};

const RINKS: Rink[] = [
  {
    id: "r1",
    name: "Centennial Arena",
    address: "1200 Maple Ave, Burnaby BC",
    surfaces: ["NHL Sheet", "Practice Sheet"],
    dressingRooms: 6,
    contact: "(604) 555-0182 · ops@centennial.ca",
    costPerHour: 285,
    notes: "Parking lot B after 6pm. Zamboni every 90 min. Use west entry for equipment.",
  },
  {
    id: "r2",
    name: "Riverside Twin Pad",
    address: "88 Riverside Dr, Coquitlam BC",
    surfaces: ["East Pad", "West Pad"],
    dressingRooms: 8,
    contact: "(604) 555-0144 · bookings@riverside.ca",
    costPerHour: 320,
    notes: "Door code 4421. Pro-shop closes 9pm.",
  },
  {
    id: "r3",
    name: "Northgate Community Rink",
    address: "455 Northgate Way, Surrey BC",
    surfaces: ["Main Surface"],
    dressingRooms: 4,
    contact: "(604) 555-0199",
    costPerHour: 240,
    notes: "No food in dressing rooms. Lights auto-off at 11pm.",
  },
];

const TEAMS = ["U13 AAA Sharks", "U15 AA Titans", "U11 A Wolves", "U18 AAA Storm", "U13 AA Comets"];
const CAMPS = ["Spring Power Skating Camp", "Summer Elite Camp", "Goalie Intensive"];

function todayISO(offset = 0) {
  const d = new Date();
  d.setDate(d.getDate() + offset);
  return d.toISOString().slice(0, 10);
}

const SEED_SLOTS: IceSlot[] = [
  { id: "s1", date: todayISO(0), start: "16:00", end: "17:30", rinkId: "r1", surface: "NHL Sheet", type: "practice", team: "U13 AAA Sharks" },
  { id: "s2", date: todayISO(0), start: "18:00", end: "19:30", rinkId: "r1", surface: "NHL Sheet", type: "game", team: "U15 AA Titans" },
  { id: "s3", date: todayISO(1), start: "07:00", end: "08:30", rinkId: "r2", surface: "East Pad", type: "camp", camp: "Spring Power Skating Camp" },
  { id: "s4", date: todayISO(1), start: "17:00", end: "18:30", rinkId: "r2", surface: "West Pad", type: "unallocated" },
  { id: "s5", date: todayISO(2), start: "19:00", end: "20:30", rinkId: "r3", surface: "Main Surface", type: "practice", team: "U11 A Wolves" },
  { id: "s6", date: todayISO(3), start: "06:00", end: "07:30", rinkId: "r1", surface: "Practice Sheet", type: "blocked", notes: "Maintenance" },
  { id: "s7", date: todayISO(3), start: "20:00", end: "21:30", rinkId: "r2", surface: "East Pad", type: "unallocated" },
  { id: "s8", date: todayISO(4), start: "17:30", end: "19:00", rinkId: "r1", surface: "NHL Sheet", type: "game", team: "U18 AAA Storm" },
  { id: "s9", date: todayISO(5), start: "08:00", end: "10:00", rinkId: "r2", surface: "West Pad", type: "camp", camp: "Summer Elite Camp" },
  { id: "s10", date: todayISO(6), start: "16:00", end: "17:30", rinkId: "r3", surface: "Main Surface", type: "unallocated" },
  { id: "s11", date: todayISO(-1), start: "17:00", end: "18:30", rinkId: "r1", surface: "NHL Sheet", type: "practice", team: "U13 AA Comets" },
  { id: "s12", date: todayISO(7), start: "18:00", end: "19:30", rinkId: "r2", surface: "East Pad", type: "unallocated" },
];

// ============================================================
// Helpers
// ============================================================

function durationHours(start: string, end: string) {
  const [sh, sm] = start.split(":").map(Number);
  const [eh, em] = end.split(":").map(Number);
  return (eh * 60 + em - (sh * 60 + sm)) / 60;
}

function rinkById(id: string) {
  return RINKS.find((r) => r.id === id);
}

function slotCost(s: IceSlot) {
  const r = rinkById(s.rinkId);
  if (!r) return 0;
  return r.costPerHour * durationHours(s.start, s.end);
}

const TYPE_META: Record<AllocationType, { label: string; bg: string; border: string; chip: string; dot: string }> = {
  practice: { label: "Team Practice", bg: "bg-teal-500/20", border: "border-teal-500/50", chip: "bg-teal-500/20 text-teal-300 border border-teal-500/40", dot: "bg-teal-400" },
  game: { label: "Game", bg: "bg-blue-500/20", border: "border-blue-500/50", chip: "bg-blue-500/20 text-blue-300 border border-blue-500/40", dot: "bg-blue-400" },
  camp: { label: "Camp", bg: "bg-emerald-500/20", border: "border-emerald-500/50", chip: "bg-emerald-500/20 text-emerald-300 border border-emerald-500/40", dot: "bg-emerald-400" },
  unallocated: { label: "Unallocated", bg: "bg-orange-500/20", border: "border-orange-500/50", chip: "bg-orange-500/20 text-orange-300 border border-orange-500/40", dot: "bg-orange-400" },
  blocked: { label: "Blocked", bg: "bg-muted/60", border: "border-border", chip: "bg-muted text-muted-foreground border border-border", dot: "bg-muted-foreground" },
};

function slotsOverlap(a: IceSlot, b: IceSlot) {
  if (a.id === b.id) return false;
  if (a.date !== b.date || a.rinkId !== b.rinkId || a.surface !== b.surface) return false;
  return a.start < b.end && b.start < a.end;
}

// ============================================================
// Main Component
// ============================================================

export function AssociationIceTimes() {
  const [tab, setTab] = useState<"schedule" | "rinks">("schedule");
  const [view, setView] = useState<"calendar" | "list">("calendar");
  const [slots, setSlots] = useState<IceSlot[]>(SEED_SLOTS);
  const [selectedSlot, setSelectedSlot] = useState<IceSlot | null>(null);
  const [addOpen, setAddOpen] = useState(false);
  const [distributeOpen, setDistributeOpen] = useState(false);
  const [wizardOpen, setWizardOpen] = useState(false);

  // Cost tracking summary
  const summary = useMemo(() => {
    const now = new Date();
    const monthSlots = slots.filter((s) => {
      const d = new Date(s.date);
      return d.getMonth() === now.getMonth() && d.getFullYear() === now.getFullYear() && s.type !== "blocked" && s.type !== "unallocated";
    });
    const totalHours = monthSlots.reduce((sum, s) => sum + durationHours(s.start, s.end), 0);
    const totalCost = monthSlots.reduce((sum, s) => sum + slotCost(s), 0);
    const byTeam: Record<string, { hours: number; cost: number }> = {};
    monthSlots.forEach((s) => {
      const key = s.team || s.camp || "—";
      if (!byTeam[key]) byTeam[key] = { hours: 0, cost: 0 };
      byTeam[key].hours += durationHours(s.start, s.end);
      byTeam[key].cost += slotCost(s);
    });
    const unallocated = slots.filter((s) => s.type === "unallocated").length;
    return { totalSlots: monthSlots.length, totalHours, totalCost, byTeam, unallocated };
  }, [slots]);

  const updateSlot = (id: string, patch: Partial<IceSlot>) => {
    setSlots((prev) => prev.map((s) => (s.id === id ? { ...s, ...patch } : s)));
    if (selectedSlot?.id === id) setSelectedSlot({ ...selectedSlot, ...patch });
  };

  const addSlot = (slot: Omit<IceSlot, "id">) => {
    setSlots((prev) => [...prev, { ...slot, id: `s${Date.now()}` }]);
  };

  return (
    <div className="space-y-6">
      {/* Top bar */}
      <div className="grid grid-cols-3 items-center border-b border-border pb-3">
        {/* Left: section tabs */}
        <div className="flex gap-1 justify-self-start">
          {(["schedule", "rinks"] as const).map((t) => (
            <button
              key={t}
              onClick={() => setTab(t)}
              className={`rounded-md px-4 py-2 text-sm font-medium transition ${
                tab === t ? "bg-gradient-to-r from-teal-500 to-emerald-500 text-white" : "text-muted-foreground hover:bg-muted/50"
              }`}
            >
              {t === "schedule" ? "Ice Schedule" : "Rinks & Facilities"}
            </button>
          ))}
        </div>

        {/* Center: view toggle */}
        {tab === "schedule" && (
          <div className="flex justify-self-center rounded-md border border-border p-0.5">
            <button
              onClick={() => setView("calendar")}
              aria-label="Calendar view"
              className={`rounded p-2 transition ${
                view === "calendar" ? "bg-muted text-foreground" : "text-muted-foreground hover:bg-muted/50"
              }`}
            >
              <CalendarIcon className="h-4 w-4" />
            </button>
            <button
              onClick={() => setView("list")}
              aria-label="List view"
              className={`rounded p-2 transition ${
                view === "list" ? "bg-muted text-foreground" : "text-muted-foreground hover:bg-muted/50"
              }`}
            >
              <List className="h-4 w-4" />
            </button>
          </div>
        )}
        {tab === "rinks" && <div />}

        {/* Right: primary actions */}
        {tab === "schedule" && (
          <div className="flex items-center gap-2 justify-self-end">
            <button
              onClick={() => setWizardOpen(true)}
              className="flex items-center gap-2 rounded-md bg-gradient-to-r from-teal-500 to-emerald-500 px-4 py-2 text-sm font-semibold text-white shadow-sm hover:from-teal-400 hover:to-emerald-400"
            >
              <Wand2 className="h-4 w-4" /> AI Schedule Wizard
            </button>
            <button
              onClick={() => setAddOpen(true)}
              className="flex items-center gap-1.5 rounded-md bg-teal-500 px-3 py-2 text-sm font-semibold text-white hover:bg-teal-400"
            >
              <Plus className="h-4 w-4" /> Add Ice Time
            </button>
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <button className="flex items-center gap-1.5 rounded-md border border-border bg-card px-3 py-2 text-sm font-medium hover:bg-muted/50">
                  Actions <ChevronDown className="h-4 w-4" />
                </button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end" className="w-48">
                <DropdownMenuItem onClick={() => setDistributeOpen(true)} className="cursor-pointer">
                  <Sparkles className="h-4 w-4" /> Distribute Ice
                </DropdownMenuItem>
                <DropdownMenuItem className="cursor-pointer">
                  <FileUp className="h-4 w-4" /> Import PDF
                </DropdownMenuItem>
                <DropdownMenuItem className="cursor-pointer">
                  <Download className="h-4 w-4" /> Export CSV
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          </div>
        )}
        {tab === "rinks" && <div />}
      </div>


      {tab === "schedule" ? (
        <>
          {/* Cost summary */}
          <CostSummary summary={summary} />

          {/* Legend */}
          <div className="flex flex-wrap items-center gap-4 text-xs text-muted-foreground">
            {(Object.keys(TYPE_META) as AllocationType[]).map((t) => (
              <div key={t} className="flex items-center gap-1.5">
                <span className={`h-2.5 w-2.5 rounded-sm ${TYPE_META[t].dot}`} />
                {TYPE_META[t].label}
              </div>
            ))}
          </div>

          {view === "calendar" ? (
            <CalendarView slots={slots} onSelect={setSelectedSlot} />
          ) : (
            <ListView slots={slots} onSelect={setSelectedSlot} />
          )}
        </>
      ) : (
        <RinksTab />
      )}

      {selectedSlot && (
        <SlotPanel
          slot={selectedSlot}
          allSlots={slots}
          onClose={() => setSelectedSlot(null)}
          onUpdate={updateSlot}
        />
      )}
      {addOpen && <AddSlotDrawer onClose={() => setAddOpen(false)} onAdd={addSlot} />}
      {distributeOpen && (
        <DistributeDrawer
          slots={slots}
          onClose={() => setDistributeOpen(false)}
          onAllocate={(id, team) => updateSlot(id, { type: "practice", team })}
        />
      )}
      {wizardOpen && <ScheduleWizard onClose={() => setWizardOpen(false)} />}
    </div>
  );
}

// ============================================================
// Cost Summary
// ============================================================

function CostSummary({ summary }: { summary: { totalSlots: number; totalHours: number; totalCost: number; byTeam: Record<string, { hours: number; cost: number }>; unallocated: number } }) {
  return (
    <div className="grid grid-cols-12 gap-4">
      <div className="col-span-3 rounded-lg border border-border bg-card p-4">
        <div className="text-xs uppercase tracking-wide text-muted-foreground">Total Ice This Month</div>
        <div className="mt-2 text-2xl font-bold">{summary.totalSlots} slots</div>
        <div className="text-xs text-muted-foreground">{summary.totalHours.toFixed(1)} hours</div>
      </div>
      <div className="col-span-3 rounded-lg border border-border bg-card p-4">
        <div className="text-xs uppercase tracking-wide text-muted-foreground">Total Cost</div>
        <div className="mt-2 text-2xl font-bold text-emerald-400">${summary.totalCost.toLocaleString()}</div>
        <div className="text-xs text-muted-foreground">Auto-feeds Financials</div>
      </div>
      <div className="col-span-3 rounded-lg border border-border bg-card p-4">
        <div className="text-xs uppercase tracking-wide text-muted-foreground">Unallocated</div>
        <div className="mt-2 text-2xl font-bold text-orange-400">{summary.unallocated}</div>
        <div className="text-xs text-muted-foreground">Need assignment</div>
      </div>
      <div className="col-span-3 rounded-lg border border-border bg-card p-4">
        <div className="text-xs uppercase tracking-wide text-muted-foreground">Cost Breakdown</div>
        <div className="mt-2 max-h-16 space-y-1 overflow-y-auto text-xs">
          {Object.entries(summary.byTeam).slice(0, 3).map(([t, v]) => (
            <div key={t} className="flex justify-between">
              <span className="truncate text-muted-foreground">{t}</span>
              <span className="font-medium">${v.cost.toLocaleString()}</span>
            </div>
          ))}
          {Object.keys(summary.byTeam).length === 0 && <div className="text-muted-foreground">No allocations yet</div>}
        </div>
      </div>
    </div>
  );
}

// ============================================================
// Calendar View (week grid)
// ============================================================

function CalendarView({ slots, onSelect }: { slots: IceSlot[]; onSelect: (s: IceSlot) => void }) {
  const [weekOffset, setWeekOffset] = useState(0);

  const weekStart = useMemo(() => {
    const d = new Date();
    d.setDate(d.getDate() - d.getDay() + weekOffset * 7);
    d.setHours(0, 0, 0, 0);
    return d;
  }, [weekOffset]);

  const days = Array.from({ length: 7 }, (_, i) => {
    const d = new Date(weekStart);
    d.setDate(d.getDate() + i);
    return d;
  });

  const label = `${weekStart.toLocaleDateString(undefined, { month: "short", day: "numeric" })} – ${days[6].toLocaleDateString(undefined, { month: "short", day: "numeric", year: "numeric" })}`;

  return (
    <div className="rounded-lg border border-border bg-card">
      <div className="flex items-center justify-between border-b border-border px-4 py-3">
        <div className="flex items-center gap-2">
          <button onClick={() => setWeekOffset((o) => o - 1)} className="rounded-md border border-border p-1 hover:bg-muted/50">
            <ChevronLeft className="h-4 w-4" />
          </button>
          <button onClick={() => setWeekOffset(0)} className="rounded-md border border-border px-3 py-1 text-xs hover:bg-muted/50">
            Today
          </button>
          <button onClick={() => setWeekOffset((o) => o + 1)} className="rounded-md border border-border p-1 hover:bg-muted/50">
            <ChevronRight className="h-4 w-4" />
          </button>
          <div className="ml-3 text-sm font-semibold">{label}</div>
        </div>
      </div>

      <div className="grid grid-cols-7 divide-x divide-border">
        {days.map((d, i) => {
          const iso = d.toISOString().slice(0, 10);
          const daySlots = slots.filter((s) => s.date === iso).sort((a, b) => a.start.localeCompare(b.start));
          const isToday = iso === todayISO(0);
          return (
            <div key={i} className="min-h-[280px]">
              <div className={`border-b border-border px-2 py-2 text-center ${isToday ? "bg-gradient-to-r from-teal-500/10 to-emerald-500/10" : ""}`}>
                <div className="text-[10px] uppercase tracking-wide text-muted-foreground">
                  {d.toLocaleDateString(undefined, { weekday: "short" })}
                </div>
                <div className={`text-lg font-semibold ${isToday ? "text-teal-400" : ""}`}>{d.getDate()}</div>
              </div>
              <div className="space-y-1 p-1.5">
                {daySlots.map((s) => {
                  const meta = TYPE_META[s.type];
                  return (
                    <button
                      key={s.id}
                      onClick={() => onSelect(s)}
                      className={`w-full rounded-md border ${meta.bg} ${meta.border} p-2 text-left text-[11px] transition hover:scale-[1.02]`}
                    >
                      <div className="font-semibold">{s.start}–{s.end}</div>
                      <div className="truncate text-muted-foreground">{rinkById(s.rinkId)?.name}</div>
                      <div className="truncate font-medium">{s.team || s.camp || meta.label}</div>
                    </button>
                  );
                })}
                {daySlots.length === 0 && <div className="px-2 py-4 text-center text-[10px] text-muted-foreground">—</div>}
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}

// ============================================================
// List View
// ============================================================

function ListView({ slots, onSelect }: { slots: IceSlot[]; onSelect: (s: IceSlot) => void }) {
  const [filterType, setFilterType] = useState<"all" | AllocationType>("all");
  const [filterRink, setFilterRink] = useState<"all" | string>("all");

  const filtered = slots
    .filter((s) => filterType === "all" || s.type === filterType)
    .filter((s) => filterRink === "all" || s.rinkId === filterRink)
    .sort((a, b) => (a.date + a.start).localeCompare(b.date + b.start));

  return (
    <div className="space-y-3">
      <div className="flex gap-2">
        <select
          value={filterType}
          onChange={(e) => setFilterType(e.target.value as never)}
          className="rounded-md border border-border bg-card px-3 py-1.5 text-xs"
        >
          <option value="all">All allocations</option>
          {(Object.keys(TYPE_META) as AllocationType[]).map((t) => (
            <option key={t} value={t}>{TYPE_META[t].label}</option>
          ))}
        </select>
        <select
          value={filterRink}
          onChange={(e) => setFilterRink(e.target.value)}
          className="rounded-md border border-border bg-card px-3 py-1.5 text-xs"
        >
          <option value="all">All rinks</option>
          {RINKS.map((r) => (
            <option key={r.id} value={r.id}>{r.name}</option>
          ))}
        </select>
      </div>
      <div className="overflow-hidden rounded-lg border border-border bg-card">
        <table className="w-full text-sm">
          <thead className="bg-muted/50 text-xs uppercase tracking-wide text-muted-foreground">
            <tr>
              <th className="px-3 py-2 text-left">Date</th>
              <th className="px-3 py-2 text-left">Time</th>
              <th className="px-3 py-2 text-left">Duration</th>
              <th className="px-3 py-2 text-left">Rink / Surface</th>
              <th className="px-3 py-2 text-left">Allocated To</th>
              <th className="px-3 py-2 text-right">Cost</th>
              <th className="px-3 py-2 text-left">Status</th>
            </tr>
          </thead>
          <tbody>
            {filtered.map((s) => {
              const meta = TYPE_META[s.type];
              const r = rinkById(s.rinkId);
              return (
                <tr
                  key={s.id}
                  onClick={() => onSelect(s)}
                  className="cursor-pointer border-t border-border hover:bg-muted/30"
                >
                  <td className="px-3 py-2">{s.date}</td>
                  <td className="px-3 py-2">{s.start}–{s.end}</td>
                  <td className="px-3 py-2">{durationHours(s.start, s.end).toFixed(1)}h</td>
                  <td className="px-3 py-2">
                    <div>{r?.name}</div>
                    <div className="text-xs text-muted-foreground">{s.surface}</div>
                  </td>
                  <td className="px-3 py-2">{s.team || s.camp || <span className="text-muted-foreground">—</span>}</td>
                  <td className="px-3 py-2 text-right font-mono">${slotCost(s).toFixed(0)}</td>
                  <td className="px-3 py-2">
                    <span className={`rounded-full px-2 py-0.5 text-[10px] ${meta.chip}`}>{meta.label}</span>
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>
    </div>
  );
}

// ============================================================
// Slot Detail Panel
// ============================================================

function SlotPanel({
  slot,
  allSlots,
  onClose,
  onUpdate,
}: {
  slot: IceSlot;
  allSlots: IceSlot[];
  onClose: () => void;
  onUpdate: (id: string, patch: Partial<IceSlot>) => void;
}) {
  const [type, setType] = useState<AllocationType>(slot.type);
  const [team, setTeam] = useState(slot.team || "");
  const [camp, setCamp] = useState(slot.camp || "");
  const [notes, setNotes] = useState(slot.notes || "");

  const conflict = allSlots.find((s) => slotsOverlap(slot, s));
  const meta = TYPE_META[type];
  const rink = rinkById(slot.rinkId);

  const save = () => {
    const patch: Partial<IceSlot> = { type, notes };
    if (type === "practice" || type === "game") {
      patch.team = team;
      patch.camp = undefined;
    } else if (type === "camp") {
      patch.camp = camp;
      patch.team = undefined;
    } else {
      patch.team = undefined;
      patch.camp = undefined;
    }
    onUpdate(slot.id, patch);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex justify-end bg-background/60 backdrop-blur-sm" onClick={onClose}>
      <div className="h-full w-full max-w-md overflow-y-auto border-l border-border bg-card shadow-2xl" onClick={(e) => e.stopPropagation()}>
        <div className="flex items-center justify-between border-b border-border p-4">
          <div>
            <div className={`mb-1 inline-block rounded-full px-2 py-0.5 text-[10px] ${meta.chip}`}>{meta.label}</div>
            <h3 className="text-lg font-bold">{slot.start} – {slot.end}</h3>
            <div className="text-xs text-muted-foreground">{slot.date} · {durationHours(slot.start, slot.end).toFixed(1)}h</div>
          </div>
          <button onClick={onClose} className="rounded-md p-1 hover:bg-muted/50">
            <X className="h-4 w-4" />
          </button>
        </div>

        <div className="space-y-5 p-4">
          {conflict && (
            <div className="flex gap-2 rounded-md border border-red-500/50 bg-red-500/10 p-3 text-xs text-red-300">
              <AlertTriangle className="h-4 w-4 flex-none" />
              <div>
                <div className="font-semibold">Schedule conflict</div>
                <div className="mt-0.5">{rink?.name} · {conflict.surface} is also booked {conflict.start}–{conflict.end} for {conflict.team || conflict.camp}.</div>
              </div>
            </div>
          )}

          <div className="space-y-2 rounded-md border border-border bg-muted/30 p-3 text-xs">
            <div className="flex items-center gap-2"><MapPin className="h-3.5 w-3.5 text-muted-foreground" /><span className="font-medium">{rink?.name}</span> · {slot.surface}</div>
            <div className="text-muted-foreground">{rink?.address}</div>
            <div className="flex items-center gap-2"><DollarSign className="h-3.5 w-3.5 text-muted-foreground" /> ${rink?.costPerHour}/hr · Total <span className="font-semibold text-foreground">${slotCost(slot).toFixed(0)}</span></div>
          </div>

          <div>
            <label className="mb-1 block text-xs font-medium uppercase tracking-wide text-muted-foreground">Allocation Type</label>
            <div className="grid grid-cols-2 gap-2">
              {(["practice", "game", "camp", "unallocated"] as AllocationType[]).map((t) => (
                <button
                  key={t}
                  onClick={() => setType(t)}
                  className={`rounded-md border px-3 py-2 text-xs font-medium transition ${
                    type === t ? `${TYPE_META[t].bg} ${TYPE_META[t].border}` : "border-border hover:bg-muted/50"
                  }`}
                >
                  {TYPE_META[t].label}
                </button>
              ))}
            </div>
          </div>

          {(type === "practice" || type === "game") && (
            <div>
              <label className="mb-1 block text-xs font-medium uppercase tracking-wide text-muted-foreground">Team</label>
              <select value={team} onChange={(e) => setTeam(e.target.value)} className="w-full rounded-md border border-border bg-background px-3 py-2 text-sm">
                <option value="">Select team…</option>
                {TEAMS.map((t) => <option key={t}>{t}</option>)}
              </select>
              {team && <div className="mt-1 text-[11px] text-muted-foreground">Head coach auto-assigned from team profile</div>}
            </div>
          )}

          {type === "camp" && (
            <div>
              <label className="mb-1 block text-xs font-medium uppercase tracking-wide text-muted-foreground">Camp</label>
              <select value={camp} onChange={(e) => setCamp(e.target.value)} className="w-full rounded-md border border-border bg-background px-3 py-2 text-sm">
                <option value="">Select camp…</option>
                {CAMPS.map((c) => <option key={c}>{c}</option>)}
              </select>
            </div>
          )}

          <div>
            <label className="mb-1 block text-xs font-medium uppercase tracking-wide text-muted-foreground">Notes</label>
            <textarea
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              rows={3}
              className="w-full rounded-md border border-border bg-background px-3 py-2 text-sm"
              placeholder="Any special instructions…"
            />
          </div>

          <div className="flex gap-2 pt-2">
            <button onClick={onClose} className="flex-1 rounded-md border border-border bg-card px-3 py-2 text-sm hover:bg-muted/50">Cancel</button>
            <button
              onClick={save}
              disabled={!!conflict}
              className="flex-1 rounded-md bg-gradient-to-r from-teal-500 to-emerald-500 px-3 py-2 text-sm font-semibold text-white disabled:opacity-40"
            >
              {conflict ? "Resolve conflict" : "Save"}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}

// ============================================================
// Add Slot Drawer
// ============================================================

function AddSlotDrawer({ onClose, onAdd }: { onClose: () => void; onAdd: (s: Omit<IceSlot, "id">) => void }) {
  const [date, setDate] = useState(todayISO(1));
  const [start, setStart] = useState("17:00");
  const [end, setEnd] = useState("18:30");
  const [rinkId, setRinkId] = useState(RINKS[0].id);
  const [surface, setSurface] = useState(RINKS[0].surfaces[0]);

  const rink = rinkById(rinkId)!;
  const cost = rink.costPerHour * durationHours(start, end);

  return (
    <div className="fixed inset-0 z-50 flex justify-end bg-background/60 backdrop-blur-sm" onClick={onClose}>
      <div className="h-full w-full max-w-md overflow-y-auto border-l border-border bg-card shadow-2xl" onClick={(e) => e.stopPropagation()}>
        <div className="flex items-center justify-between border-b border-border p-4">
          <h3 className="text-lg font-bold">Add Ice Time</h3>
          <button onClick={onClose} className="rounded-md p-1 hover:bg-muted/50"><X className="h-4 w-4" /></button>
        </div>
        <div className="space-y-4 p-4">
          <Field label="Date">
            <input type="date" value={date} onChange={(e) => setDate(e.target.value)} className="w-full rounded-md border border-border bg-background px-3 py-2 text-sm" />
          </Field>
          <div className="grid grid-cols-2 gap-3">
            <Field label="Start"><input type="time" value={start} onChange={(e) => setStart(e.target.value)} className="w-full rounded-md border border-border bg-background px-3 py-2 text-sm" /></Field>
            <Field label="End"><input type="time" value={end} onChange={(e) => setEnd(e.target.value)} className="w-full rounded-md border border-border bg-background px-3 py-2 text-sm" /></Field>
          </div>
          <Field label="Rink">
            <select value={rinkId} onChange={(e) => { setRinkId(e.target.value); setSurface(rinkById(e.target.value)!.surfaces[0]); }} className="w-full rounded-md border border-border bg-background px-3 py-2 text-sm">
              {RINKS.map((r) => <option key={r.id} value={r.id}>{r.name}</option>)}
            </select>
          </Field>
          <Field label="Surface">
            <select value={surface} onChange={(e) => setSurface(e.target.value)} className="w-full rounded-md border border-border bg-background px-3 py-2 text-sm">
              {rink.surfaces.map((s) => <option key={s}>{s}</option>)}
            </select>
          </Field>
          <div className="rounded-md border border-border bg-muted/30 p-3 text-xs">
            <div className="flex justify-between"><span className="text-muted-foreground">Duration</span><span className="font-medium">{durationHours(start, end).toFixed(1)}h</span></div>
            <div className="mt-1 flex justify-between"><span className="text-muted-foreground">Estimated cost</span><span className="font-semibold text-emerald-400">${cost.toFixed(0)}</span></div>
          </div>
          <div className="flex gap-2 pt-2">
            <button onClick={onClose} className="flex-1 rounded-md border border-border bg-card px-3 py-2 text-sm hover:bg-muted/50">Cancel</button>
            <button
              onClick={() => { onAdd({ date, start, end, rinkId, surface, type: "unallocated" }); onClose(); }}
              className="flex-1 rounded-md bg-gradient-to-r from-teal-500 to-emerald-500 px-3 py-2 text-sm font-semibold text-white"
            >
              Add Slot
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}

function Field({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <div>
      <label className="mb-1 block text-xs font-medium uppercase tracking-wide text-muted-foreground">{label}</label>
      {children}
    </div>
  );
}

// ============================================================
// Distribute Ice Drawer
// ============================================================

function DistributeDrawer({
  slots,
  onClose,
  onAllocate,
}: {
  slots: IceSlot[];
  onClose: () => void;
  onAllocate: (id: string, team: string) => void;
}) {
  const unallocated = slots.filter((s) => s.type === "unallocated");
  const [assignments, setAssignments] = useState<Record<string, string>>({});

  const autoDistribute = () => {
    const next: Record<string, string> = {};
    unallocated.forEach((s, i) => {
      next[s.id] = TEAMS[i % TEAMS.length];
    });
    setAssignments(next);
  };

  const apply = () => {
    Object.entries(assignments).forEach(([id, team]) => team && onAllocate(id, team));
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex justify-end bg-background/60 backdrop-blur-sm" onClick={onClose}>
      <div className="h-full w-full max-w-3xl overflow-y-auto border-l border-border bg-card shadow-2xl" onClick={(e) => e.stopPropagation()}>
        <div className="flex items-center justify-between border-b border-border p-4">
          <div>
            <h3 className="text-lg font-bold">Distribute Ice to Teams</h3>
            <p className="text-xs text-muted-foreground">{unallocated.length} unallocated slots · auto-suggest uses team ice preferences</p>
          </div>
          <div className="flex items-center gap-2">
            <button onClick={autoDistribute} className="flex items-center gap-1.5 rounded-md border border-border px-3 py-1.5 text-xs hover:bg-muted/50">
              <Sparkles className="h-3.5 w-3.5" /> Auto-distribute
            </button>
            <button onClick={onClose} className="rounded-md p-1 hover:bg-muted/50"><X className="h-4 w-4" /></button>
          </div>
        </div>

        <div className="grid grid-cols-2 gap-4 p-4">
          <div>
            <h4 className="mb-2 text-xs font-semibold uppercase tracking-wide text-muted-foreground">Unallocated Slots</h4>
            <div className="space-y-2">
              {unallocated.map((s) => {
                const r = rinkById(s.rinkId);
                return (
                  <div key={s.id} className="rounded-md border border-orange-500/40 bg-orange-500/10 p-2 text-xs">
                    <div className="font-semibold">{s.date} · {s.start}–{s.end}</div>
                    <div className="text-muted-foreground">{r?.name} · {s.surface}</div>
                    <select
                      value={assignments[s.id] || ""}
                      onChange={(e) => setAssignments((a) => ({ ...a, [s.id]: e.target.value }))}
                      className="mt-2 w-full rounded-md border border-border bg-background px-2 py-1 text-xs"
                    >
                      <option value="">Assign to team…</option>
                      {TEAMS.map((t) => <option key={t}>{t}</option>)}
                    </select>
                  </div>
                );
              })}
              {unallocated.length === 0 && <div className="rounded-md border border-dashed border-border p-6 text-center text-xs text-muted-foreground">All slots are allocated 🎉</div>}
            </div>
          </div>

          <div>
            <h4 className="mb-2 text-xs font-semibold uppercase tracking-wide text-muted-foreground">Teams · Suggested Allocation</h4>
            <div className="space-y-2">
              {TEAMS.map((t) => {
                const count = Object.values(assignments).filter((a) => a === t).length;
                return (
                  <div key={t} className="flex items-center justify-between rounded-md border border-border bg-muted/30 p-2 text-xs">
                    <span className="font-medium">{t}</span>
                    <span className={`rounded-full px-2 py-0.5 ${count > 0 ? "bg-teal-500/20 text-teal-300" : "text-muted-foreground"}`}>{count} slots</span>
                  </div>
                );
              })}
            </div>
          </div>
        </div>

        <div className="sticky bottom-0 flex gap-2 border-t border-border bg-card p-4">
          <button onClick={onClose} className="flex-1 rounded-md border border-border px-3 py-2 text-sm hover:bg-muted/50">Cancel</button>
          <button onClick={apply} className="flex-1 rounded-md bg-gradient-to-r from-teal-500 to-emerald-500 px-3 py-2 text-sm font-semibold text-white">
            Apply Allocations
          </button>
        </div>
      </div>
    </div>
  );
}

// ============================================================
// Rinks Tab
// ============================================================

function RinksTab() {
  const [rinks, setRinks] = useState<Rink[]>(RINKS);
  const [editing, setEditing] = useState<Rink | null>(null);

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <div>
          <h3 className="text-lg font-semibold">Rinks & Facilities</h3>
          <p className="text-xs text-muted-foreground">Master list of venues used for ice allocation</p>
        </div>
        <button
          onClick={() => setEditing({ id: `r${Date.now()}`, name: "", address: "", surfaces: ["Main Surface"], dressingRooms: 0, contact: "", costPerHour: 0, notes: "" })}
          className="flex items-center gap-1.5 rounded-md bg-gradient-to-r from-teal-500 to-emerald-500 px-3 py-1.5 text-xs font-semibold text-white"
        >
          <Plus className="h-3.5 w-3.5" /> Add Rink
        </button>
      </div>

      <div className="grid grid-cols-2 gap-4">
        {rinks.map((r) => (
          <div key={r.id} className="rounded-lg border border-border bg-card p-4">
            <div className="mb-3 flex items-start justify-between">
              <div>
                <div className="flex items-center gap-2">
                  <Building2 className="h-4 w-4 text-teal-400" />
                  <h4 className="font-semibold">{r.name}</h4>
                </div>
                <div className="mt-1 text-xs text-muted-foreground">{r.address}</div>
              </div>
              <div className="flex gap-1">
                <button onClick={() => setEditing(r)} className="rounded-md p-1.5 text-muted-foreground hover:bg-muted/50"><Edit3 className="h-3.5 w-3.5" /></button>
                <button onClick={() => setRinks((p) => p.filter((x) => x.id !== r.id))} className="rounded-md p-1.5 text-red-400 hover:bg-red-500/10"><Trash2 className="h-3.5 w-3.5" /></button>
              </div>
            </div>
            <div className="grid grid-cols-3 gap-2 border-t border-border pt-3 text-xs">
              <div>
                <div className="text-muted-foreground">Surfaces</div>
                <div className="font-semibold">{r.surfaces.length}</div>
              </div>
              <div>
                <div className="text-muted-foreground">Rooms</div>
                <div className="font-semibold">{r.dressingRooms}</div>
              </div>
              <div>
                <div className="text-muted-foreground">Cost/hr</div>
                <div className="font-semibold text-emerald-400">${r.costPerHour}</div>
              </div>
            </div>
            <div className="mt-3 space-y-1 text-xs">
              <div className="flex flex-wrap gap-1">
                {r.surfaces.map((s) => (
                  <span key={s} className="rounded-full bg-muted px-2 py-0.5 text-[10px]">{s}</span>
                ))}
              </div>
              <div className="flex items-center gap-1.5 pt-1 text-muted-foreground"><Clock className="h-3 w-3" /> {r.contact}</div>
              <p className="text-muted-foreground">{r.notes}</p>
            </div>
          </div>
        ))}
      </div>

      {editing && (
        <RinkEditDrawer
          rink={editing}
          onClose={() => setEditing(null)}
          onSave={(r) => {
            setRinks((prev) => (prev.find((x) => x.id === r.id) ? prev.map((x) => (x.id === r.id ? r : x)) : [...prev, r]));
            setEditing(null);
          }}
        />
      )}
    </div>
  );
}

function RinkEditDrawer({ rink, onClose, onSave }: { rink: Rink; onClose: () => void; onSave: (r: Rink) => void }) {
  const [r, setR] = useState(rink);
  const update = <K extends keyof Rink>(k: K, v: Rink[K]) => setR((p) => ({ ...p, [k]: v }));

  return (
    <div className="fixed inset-0 z-50 flex justify-end bg-background/60 backdrop-blur-sm" onClick={onClose}>
      <div className="h-full w-full max-w-md overflow-y-auto border-l border-border bg-card shadow-2xl" onClick={(e) => e.stopPropagation()}>
        <div className="flex items-center justify-between border-b border-border p-4">
          <h3 className="text-lg font-bold">{rink.name ? "Edit Rink" : "Add Rink"}</h3>
          <button onClick={onClose} className="rounded-md p-1 hover:bg-muted/50"><X className="h-4 w-4" /></button>
        </div>
        <div className="space-y-4 p-4">
          <Field label="Name"><input value={r.name} onChange={(e) => update("name", e.target.value)} className="w-full rounded-md border border-border bg-background px-3 py-2 text-sm" /></Field>
          <Field label="Address"><input value={r.address} onChange={(e) => update("address", e.target.value)} className="w-full rounded-md border border-border bg-background px-3 py-2 text-sm" /></Field>
          <Field label="Surfaces (comma separated)">
            <input value={r.surfaces.join(", ")} onChange={(e) => update("surfaces", e.target.value.split(",").map((s) => s.trim()).filter(Boolean))} className="w-full rounded-md border border-border bg-background px-3 py-2 text-sm" />
          </Field>
          <div className="grid grid-cols-2 gap-3">
            <Field label="Dressing rooms"><input type="number" value={r.dressingRooms} onChange={(e) => update("dressingRooms", Number(e.target.value))} className="w-full rounded-md border border-border bg-background px-3 py-2 text-sm" /></Field>
            <Field label="Cost / hour"><input type="number" value={r.costPerHour} onChange={(e) => update("costPerHour", Number(e.target.value))} className="w-full rounded-md border border-border bg-background px-3 py-2 text-sm" /></Field>
          </div>
          <Field label="Contact"><input value={r.contact} onChange={(e) => update("contact", e.target.value)} className="w-full rounded-md border border-border bg-background px-3 py-2 text-sm" /></Field>
          <Field label="Notes (parking, entry, Zamboni)">
            <textarea value={r.notes} onChange={(e) => update("notes", e.target.value)} rows={4} className="w-full rounded-md border border-border bg-background px-3 py-2 text-sm" />
          </Field>
          <div className="flex gap-2 pt-2">
            <button onClick={onClose} className="flex-1 rounded-md border border-border px-3 py-2 text-sm hover:bg-muted/50">Cancel</button>
            <button onClick={() => onSave(r)} className="flex-1 rounded-md bg-gradient-to-r from-teal-500 to-emerald-500 px-3 py-2 text-sm font-semibold text-white">Save Rink</button>
          </div>
        </div>
      </div>
    </div>
  );
}

// ============================================================
// AI Schedule Wizard
// ============================================================

type AgeGroup = "U7" | "U9" | "U11" | "U13" | "U15" | "U18" | "Senior";
type Division = "House" | "Rep" | "AAA";

type TeamGroup = {
  id: string;
  age: AgeGroup;
  division: Division;
  count: number; // number of teams in this group
};

const SEED_GROUPS: TeamGroup[] = [
  { id: "g1", age: "U7", division: "House", count: 6 },
  { id: "g2", age: "U9", division: "House", count: 8 },
  { id: "g3", age: "U11", division: "House", count: 6 },
  { id: "g4", age: "U11", division: "Rep", count: 2 },
  { id: "g5", age: "U13", division: "House", count: 4 },
  { id: "g6", age: "U13", division: "Rep", count: 2 },
  { id: "g7", age: "U15", division: "Rep", count: 2 },
  { id: "g8", age: "U15", division: "AAA", count: 1 },
  { id: "g9", age: "U18", division: "Rep", count: 2 },
];

type GroupRules = {
  practicesPerWeek: 1 | 2 | 3 | 4;
  gamesPerWeek: 0 | 1 | 2;
  allowEarly: boolean; // before 8am
  allowLate: boolean; // after 9pm
  preferredDays: string[]; // Mon..Sun
  minRest: 12 | 24 | 48;
  practiceDayBeforeGame: boolean;
  preferredRinks: string[];
};

const DAYS = ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"];

const DEFAULT_RULES: GroupRules = {
  practicesPerWeek: 2,
  gamesPerWeek: 1,
  allowEarly: false,
  allowLate: false,
  preferredDays: ["Mon", "Wed", "Sat"],
  minRest: 24,
  practiceDayBeforeGame: false,
  preferredRinks: [],
};

type GlobalRules = {
  blackoutStart: string;
  blackoutEnd: string;
  sharedIce: boolean;
  bufferMin: 15 | 30 | 45;
  consistentWeekly: boolean;
};

const DEFAULT_GLOBAL: GlobalRules = {
  blackoutStart: "2026-12-22",
  blackoutEnd: "2026-01-04",
  sharedIce: false,
  bufferMin: 30,
  consistentWeekly: true,
};

function ScheduleWizard({ onClose }: { onClose: () => void }) {
  const [step, setStep] = useState(1);
  const [groups, setGroups] = useState<TeamGroup[]>(SEED_GROUPS);
  const [groupIdx, setGroupIdx] = useState(0);
  const [rules, setRules] = useState<Record<string, GroupRules>>(
    Object.fromEntries(SEED_GROUPS.map((g) => [g.id, { ...DEFAULT_RULES }])),
  );
  const [global, setGlobal] = useState<GlobalRules>(DEFAULT_GLOBAL);
  const [generating, setGenerating] = useState(false);
  const [generated, setGenerated] = useState(false);

  const totalSteps = 4;
  const currentGroup = groups[groupIdx];
  const currentRules = currentGroup ? rules[currentGroup.id] : null;

  const updateRules = (patch: Partial<GroupRules>) => {
    if (!currentGroup) return;
    setRules((prev) => ({ ...prev, [currentGroup.id]: { ...prev[currentGroup.id], ...patch } }));
  };

  const runGeneration = () => {
    setGenerating(true);
    setTimeout(() => {
      setGenerating(false);
      setGenerated(true);
    }, 2200);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 p-6">
      <div className="flex h-[88vh] w-full max-w-5xl flex-col overflow-hidden rounded-xl border border-border bg-card shadow-2xl">
        {/* Header */}
        <div className="flex items-center justify-between border-b border-border bg-gradient-to-r from-violet-500/15 to-fuchsia-500/10 px-6 py-4">
          <div className="flex items-center gap-3">
            <div className="flex h-9 w-9 items-center justify-center rounded-lg bg-violet-500/20 text-violet-300">
              <Wand2 className="h-5 w-5" />
            </div>
            <div>
              <h2 className="text-lg font-bold">AI Schedule Wizard</h2>
              <p className="text-xs text-muted-foreground">Generate a full season schedule across every team</p>
            </div>
          </div>
          <button onClick={onClose} className="rounded-md p-1.5 hover:bg-muted/50"><X className="h-4 w-4" /></button>
        </div>

        {/* Stepper */}
        <div className="flex items-center gap-2 border-b border-border bg-muted/20 px-6 py-3">
          {["Confirm Teams", "Per-Group Rules", "Global Rules", "Generate"].map((label, i) => {
            const n = i + 1;
            const active = step === n;
            const done = step > n;
            return (
              <div key={label} className="flex flex-1 items-center gap-2">
                <div className={`flex h-6 w-6 shrink-0 items-center justify-center rounded-full text-[10px] font-bold ${
                  done ? "bg-emerald-500 text-white" : active ? "bg-violet-500 text-white" : "bg-muted text-muted-foreground"
                }`}>
                  {done ? <Check className="h-3 w-3" /> : n}
                </div>
                <span className={`text-xs ${active ? "font-semibold text-foreground" : "text-muted-foreground"}`}>{label}</span>
                {n < totalSteps && <div className="h-px flex-1 bg-border" />}
              </div>
            );
          })}
        </div>

        {/* Body */}
        <div className="flex-1 overflow-y-auto p-6">
          {step === 1 && (
            <div className="space-y-4">
              <div>
                <h3 className="text-base font-semibold">Confirm teams in scheduler</h3>
                <p className="text-sm text-muted-foreground">AI pulled {groups.reduce((a, g) => a + g.count, 0)} teams across {groups.length} groups. Edit before continuing.</p>
              </div>
              <div className="grid grid-cols-2 gap-3">
                {groups.map((g) => (
                  <div key={g.id} className="flex items-center justify-between rounded-md border border-border bg-background p-3">
                    <div>
                      <div className="text-sm font-semibold">{g.age} {g.division}</div>
                      <div className="text-xs text-muted-foreground">{g.count} {g.count === 1 ? "team" : "teams"}</div>
                    </div>
                    <button
                      onClick={() => setGroups((p) => p.filter((x) => x.id !== g.id))}
                      className="rounded-md p-1.5 text-muted-foreground hover:bg-muted/50 hover:text-red-400"
                    ><Trash2 className="h-3.5 w-3.5" /></button>
                  </div>
                ))}
              </div>
            </div>
          )}

          {step === 2 && currentGroup && currentRules && (
            <div className="space-y-5">
              <div className="flex items-center justify-between">
                <div>
                  <div className="text-xs uppercase tracking-wide text-muted-foreground">Group {groupIdx + 1} of {groups.length}</div>
                  <h3 className="text-lg font-bold">{currentGroup.age} {currentGroup.division} League</h3>
                </div>
                <div className="text-xs text-muted-foreground">{groupIdx} of {groups.length} configured</div>
              </div>
              <div className="h-1.5 rounded-full bg-muted">
                <div className="h-full rounded-full bg-gradient-to-r from-violet-500 to-fuchsia-500 transition-all" style={{ width: `${(groupIdx / groups.length) * 100}%` }} />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <WizardField label="Practices per week">
                  <Segmented value={String(currentRules.practicesPerWeek)} options={["1","2","3","4"]} onChange={(v) => updateRules({ practicesPerWeek: Number(v) as 1 })} />
                </WizardField>
                <WizardField label="Home games per week">
                  <Segmented value={String(currentRules.gamesPerWeek)} options={["0","1","2"]} onChange={(v) => updateRules({ gamesPerWeek: Number(v) as 0 })} />
                </WizardField>
                <WizardField label="Allow ice before 8am">
                  <Toggle on={currentRules.allowEarly} onChange={(b) => updateRules({ allowEarly: b })} />
                </WizardField>
                <WizardField label="Allow ice after 9pm">
                  <Toggle on={currentRules.allowLate} onChange={(b) => updateRules({ allowLate: b })} />
                </WizardField>
                <WizardField label="Minimum rest between sessions">
                  <Segmented value={String(currentRules.minRest)} options={["12","24","48"]} onChange={(v) => updateRules({ minRest: Number(v) as 12 })} suffix="hr" />
                </WizardField>
                <WizardField label="Practice day before a game">
                  <Toggle on={currentRules.practiceDayBeforeGame} onChange={(b) => updateRules({ practiceDayBeforeGame: b })} />
                </WizardField>
              </div>

              <WizardField label="Preferred days">
                <div className="flex flex-wrap gap-2">
                  {DAYS.map((d) => {
                    const on = currentRules.preferredDays.includes(d);
                    return (
                      <button key={d}
                        onClick={() => updateRules({ preferredDays: on ? currentRules.preferredDays.filter((x) => x !== d) : [...currentRules.preferredDays, d] })}
                        className={`rounded-md border px-3 py-1.5 text-xs font-medium ${on ? "border-violet-500 bg-violet-500/15 text-violet-200" : "border-border text-muted-foreground hover:bg-muted/30"}`}
                      >{d}</button>
                    );
                  })}
                </div>
              </WizardField>

              <WizardField label="Preferred rinks">
                <div className="flex flex-wrap gap-2">
                  {RINKS.map((r) => {
                    const on = currentRules.preferredRinks.includes(r.id);
                    return (
                      <button key={r.id}
                        onClick={() => updateRules({ preferredRinks: on ? currentRules.preferredRinks.filter((x) => x !== r.id) : [...currentRules.preferredRinks, r.id] })}
                        className={`rounded-md border px-3 py-1.5 text-xs font-medium ${on ? "border-violet-500 bg-violet-500/15 text-violet-200" : "border-border text-muted-foreground hover:bg-muted/30"}`}
                      >{r.name}</button>
                    );
                  })}
                </div>
              </WizardField>

              <div className="flex justify-between border-t border-border pt-4">
                <button
                  onClick={() => setGroupIdx((i) => Math.max(0, i - 1))}
                  disabled={groupIdx === 0}
                  className="flex items-center gap-1.5 rounded-md border border-border px-3 py-1.5 text-xs disabled:opacity-40"
                ><ArrowLeft className="h-3.5 w-3.5" /> Previous group</button>
                {groupIdx < groups.length - 1 ? (
                  <button onClick={() => setGroupIdx((i) => i + 1)} className="flex items-center gap-1.5 rounded-md bg-violet-500 px-3 py-1.5 text-xs font-semibold text-white">Next group <ArrowRight className="h-3.5 w-3.5" /></button>
                ) : (
                  <div className="text-xs text-emerald-400">All groups configured · click Next to continue</div>
                )}
              </div>
            </div>
          )}

          {step === 3 && (
            <div className="space-y-5">
              <div>
                <h3 className="text-base font-semibold">Global rules</h3>
                <p className="text-sm text-muted-foreground">Applied across every team in the schedule.</p>
              </div>

              {/* Consistent weekly schedule — featured */}
              <div className="rounded-lg border border-violet-500/40 bg-gradient-to-br from-violet-500/10 to-fuchsia-500/5 p-4">
                <div className="flex items-start justify-between gap-4">
                  <div className="flex items-start gap-3">
                    <div className="flex h-8 w-8 items-center justify-center rounded-md bg-violet-500/20 text-violet-300">
                      <Repeat className="h-4 w-4" />
                    </div>
                    <div>
                      <div className="flex items-center gap-2">
                        <div className="text-sm font-semibold">Consistent weekly schedule</div>
                        <span className="rounded bg-violet-500/20 px-1.5 py-0.5 text-[9px] font-bold uppercase text-violet-200">Recommended</span>
                      </div>
                      <p className="mt-1 text-xs text-muted-foreground">
                        Lock each team to the same days and times every week for the whole season. If a slot becomes unavailable due to a conflict, rink closure, or blackout date, the AI picks the closest available time and flags it as an <span className="font-semibold text-amber-400">EXCEPTION</span>. Consistent weeks show a <span className="font-semibold text-emerald-400">CONSISTENT</span> badge on the calendar.
                      </p>
                    </div>
                  </div>
                  <Toggle on={global.consistentWeekly} onChange={(b) => setGlobal({ ...global, consistentWeekly: b })} />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <WizardField label="Blackout start">
                  <input type="date" value={global.blackoutStart} onChange={(e) => setGlobal({ ...global, blackoutStart: e.target.value })} className="w-full rounded-md border border-border bg-background px-3 py-2 text-sm" />
                </WizardField>
                <WizardField label="Blackout end">
                  <input type="date" value={global.blackoutEnd} onChange={(e) => setGlobal({ ...global, blackoutEnd: e.target.value })} className="w-full rounded-md border border-border bg-background px-3 py-2 text-sm" />
                </WizardField>
                <WizardField label="Shared ice between age groups">
                  <Toggle on={global.sharedIce} onChange={(b) => setGlobal({ ...global, sharedIce: b })} />
                </WizardField>
                <WizardField label="Buffer between sessions (Zamboni)">
                  <Segmented value={String(global.bufferMin)} options={["15","30","45"]} onChange={(v) => setGlobal({ ...global, bufferMin: Number(v) as 15 })} suffix="min" />
                </WizardField>
              </div>
            </div>
          )}

          {step === 4 && (
            <div className="space-y-5">
              {!generated && !generating && (
                <div className="flex flex-col items-center justify-center py-10 text-center">
                  <div className="mb-4 flex h-14 w-14 items-center justify-center rounded-full bg-violet-500/20 text-violet-300"><Wand2 className="h-7 w-7" /></div>
                  <h3 className="text-lg font-bold">Ready to generate</h3>
                  <p className="mt-1 max-w-md text-sm text-muted-foreground">
                    AI will allocate {groups.reduce((a, g) => a + g.count, 0)} teams across your ice inventory using the rules you configured.
                    {global.consistentWeekly && <span className="block mt-2 text-violet-300">✓ Consistent weekly schedule is ON — teams will get the same slot every week.</span>}
                  </p>
                  <button onClick={runGeneration} className="mt-5 rounded-md bg-gradient-to-r from-violet-500 to-fuchsia-500 px-5 py-2.5 text-sm font-semibold text-white">Generate Schedule</button>
                </div>
              )}
              {generating && (
                <div className="flex flex-col items-center justify-center py-10 text-center">
                  <Loader2 className="mb-4 h-10 w-10 animate-spin text-violet-400" />
                  <h3 className="text-lg font-bold">Generating schedule…</h3>
                  <div className="mt-3 space-y-1 text-xs text-muted-foreground">
                    <div>Reading ice inventory…</div>
                    <div>Applying group rules across {groups.length} divisions…</div>
                    <div>{global.consistentWeekly ? "Locking weekly recurring slots…" : "Distributing slots…"}</div>
                    <div>Resolving conflicts…</div>
                  </div>
                </div>
              )}
              {generated && (
                <div className="space-y-4">
                  <div className="rounded-lg border border-emerald-500/30 bg-emerald-500/10 p-4">
                    <div className="flex items-center gap-2">
                      <Check className="h-4 w-4 text-emerald-400" />
                      <div className="text-sm font-semibold text-emerald-300">Schedule generated successfully</div>
                    </div>
                    <p className="mt-1 text-xs text-muted-foreground">
                      284 slots allocated · {global.consistentWeekly ? "92% consistent weekly · 8% flagged as exceptions" : "No consistency lock applied"} · 3 unresolvable conflicts
                    </p>
                  </div>

                  <div>
                    <div className="mb-2 text-xs font-semibold uppercase tracking-wide text-muted-foreground">Unresolvable conflicts</div>
                    <div className="space-y-2">
                      <ConflictRow team="U15 Rep" issue="Requires 3 practices/week — only 2 evening slots available" fix="Add 1 weekly slot at Centennial after 7pm, or reduce to 2 practices." />
                      <ConflictRow team="U11 House #4" issue="Saturday game conflicts with U13 House #2 at same rink/time" fix="Move U11 game to Sunday 10am at Olympic Oval." />
                      <ConflictRow team="U18 Rep" issue="Cannot satisfy 48hr rest with current game density" fix="Reduce min rest to 24hr or add a Friday slot." />
                    </div>
                  </div>

                  {global.consistentWeekly && (
                    <div className="rounded-md border border-amber-500/30 bg-amber-500/5 p-3">
                      <div className="flex items-center gap-2 text-xs font-semibold text-amber-300"><AlertTriangle className="h-3.5 w-3.5" /> 4 weekly exceptions flagged</div>
                      <p className="mt-1 text-xs text-muted-foreground">Holiday blackout (Dec 22 – Jan 4) shifts 4 teams from their consistent slot for that week only. Coaches will be notified.</p>
                    </div>
                  )}

                  <button className="w-full rounded-md bg-gradient-to-r from-emerald-500 to-teal-500 px-4 py-2.5 text-sm font-semibold text-white">Commit Schedule & Notify Coaches</button>
                </div>
              )}
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="flex items-center justify-between border-t border-border bg-muted/20 px-6 py-3">
          <button
            onClick={() => setStep((s) => Math.max(1, s - 1))}
            disabled={step === 1}
            className="flex items-center gap-1.5 rounded-md border border-border px-3 py-1.5 text-xs disabled:opacity-40"
          ><ArrowLeft className="h-3.5 w-3.5" /> Back</button>
          <div className="text-xs text-muted-foreground">Step {step} of {totalSteps}</div>
          {step < totalSteps ? (
            <button onClick={() => setStep((s) => s + 1)} className="flex items-center gap-1.5 rounded-md bg-violet-500 px-3 py-1.5 text-xs font-semibold text-white">Next <ArrowRight className="h-3.5 w-3.5" /></button>
          ) : (
            <button onClick={onClose} className="rounded-md border border-border px-3 py-1.5 text-xs">Close</button>
          )}
        </div>
      </div>
    </div>
  );
}

function WizardField({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <div>
      <div className="mb-1.5 text-xs font-medium text-muted-foreground">{label}</div>
      {children}
    </div>
  );
}

function Segmented({ value, options, onChange, suffix }: { value: string; options: string[]; onChange: (v: string) => void; suffix?: string }) {
  return (
    <div className="inline-flex rounded-md border border-border p-0.5">
      {options.map((o) => (
        <button key={o} onClick={() => onChange(o)}
          className={`rounded px-3 py-1.5 text-xs font-medium ${value === o ? "bg-violet-500 text-white" : "text-muted-foreground hover:bg-muted/40"}`}
        >{o}{suffix ? ` ${suffix}` : ""}</button>
      ))}
    </div>
  );
}

function Toggle({ on, onChange }: { on: boolean; onChange: (b: boolean) => void }) {
  return (
    <button onClick={() => onChange(!on)} className={`relative h-6 w-11 rounded-full transition ${on ? "bg-violet-500" : "bg-muted"}`}>
      <span className={`absolute top-0.5 h-5 w-5 rounded-full bg-white transition-all ${on ? "left-[22px]" : "left-0.5"}`} />
    </button>
  );
}

function ConflictRow({ team, issue, fix }: { team: string; issue: string; fix: string }) {
  return (
    <div className="rounded-md border border-red-500/30 bg-red-500/5 p-3">
      <div className="flex items-start gap-2">
        <AlertTriangle className="mt-0.5 h-3.5 w-3.5 text-red-400" />
        <div className="flex-1">
          <div className="text-xs font-semibold text-red-300">{team}</div>
          <div className="text-xs text-muted-foreground">{issue}</div>
          <div className="mt-1 text-xs"><span className="font-semibold text-emerald-400">Suggested fix:</span> <span className="text-muted-foreground">{fix}</span></div>
        </div>
      </div>
    </div>
  );
}
