import { Link, useRouterState } from "@tanstack/react-router";
import {
  LayoutDashboard,
  CalendarDays,
  Tent,
  DollarSign,
  Snowflake,
  Users,
  BookOpen,
  Trophy,
  Inbox,
  Settings,
  Sun,
  Moon,
  MonitorSmartphone,
  ClipboardList,
  Flag,
  Shield,
  MessageSquare,
  Shirt,
  Globe,
  Briefcase,
  UserCog,
  type LucideIcon,
} from "lucide-react";
import { useTheme, type Theme } from "./theme-provider";
import { cn } from "@/lib/utils";
import { useAccount, type AccountRole } from "./account-provider";

type NavItem = { title: string; url: string; icon: LucideIcon };

const eliteCoachNav: NavItem[] = [
  { title: "Dashboard", url: "/dashboard", icon: LayoutDashboard },
  { title: "Schedule", url: "/schedule", icon: CalendarDays },
  { title: "Teams", url: "/teams", icon: Users },
  { title: "Camps & Privates", url: "/camps", icon: Tent },
  { title: "Financials", url: "/financials", icon: DollarSign },
  { title: "Playbook", url: "/playbook", icon: BookOpen },
  { title: "Athletes", url: "/athletes", icon: Trophy },
  { title: "Inbox", url: "/inbox", icon: Inbox },
  { title: "Settings", url: "/settings", icon: Settings },
];

const associationAdminNav: NavItem[] = [
  { title: "Dashboard", url: "/dashboard", icon: LayoutDashboard },
  { title: "Teams", url: "/teams", icon: Users },
  { title: "Camps", url: "/camps", icon: Tent },
  { title: "Registrations", url: "/registrations", icon: ClipboardList },
  { title: "Coaches", url: "/coaches", icon: UserCog },
  { title: "Athletes", url: "/athletes", icon: Trophy },
  { title: "Referees", url: "/referees", icon: Flag },
  { title: "Ice Times", url: "/ice-times", icon: Snowflake },
  { title: "Financials", url: "/financials", icon: DollarSign },
  { title: "Safety & Incidents", url: "/safety", icon: Shield },
  { title: "Communications", url: "/communications", icon: MessageSquare },
  { title: "Apparel", url: "/apparel", icon: Shirt },
  { title: "Website", url: "/website", icon: Globe },
  { title: "Board & Staff", url: "/board", icon: Briefcase },
  { title: "Settings", url: "/settings", icon: Settings },
];

const teamCoachNav: NavItem[] = [
  { title: "Dashboard", url: "/dashboard", icon: LayoutDashboard },
  { title: "Teams", url: "/teams", icon: Users },
  { title: "Athletes", url: "/athletes", icon: Trophy },
  { title: "Ice Times", url: "/ice-times", icon: Snowflake },
  { title: "Playbook", url: "/playbook", icon: BookOpen },
  { title: "Inbox", url: "/inbox", icon: Inbox },
  { title: "Settings", url: "/settings", icon: Settings },
];

const navByRole: Record<AccountRole, NavItem[]> = {
  "elite-coach": eliteCoachNav,
  "association-admin": associationAdminNav,
  "team-coach": teamCoachNav,
  parent: [],
};

export function AppSidebar() {
  const currentPath = useRouterState({ select: (r) => r.location.pathname });
  const { theme, setTheme } = useTheme();
  const { account } = useAccount();
  const navItems = navByRole[account.role];

  const themeOptions: { value: Theme; icon: typeof Sun; label: string }[] = [
    { value: "light", icon: Sun, label: "Light" },
    { value: "dark", icon: Moon, label: "Dark" },
    { value: "auto", icon: MonitorSmartphone, label: "Auto" },
  ];

  return (
    <aside className="fixed inset-y-0 left-0 z-20 flex w-[220px] flex-col border-r border-sidebar-border bg-sidebar text-sidebar-foreground">
      {/* Logo */}
      <div className="px-5 py-5 border-b border-sidebar-border">
        <div className="text-[28px] font-black leading-none tracking-tight bg-gradient-to-r from-teal-400 to-emerald-400 bg-clip-text text-transparent">
          PXF
        </div>
        <div className="text-[10px] font-bold tracking-[0.28em] text-white/50 leading-none mt-0.5">
          HOCKEY
        </div>
      </div>

      {/* User */}
      <div className="flex items-center gap-3 px-5 py-4 border-b border-sidebar-border">
        <div className="flex h-9 w-9 items-center justify-center rounded-full bg-sidebar-accent text-sidebar-accent-foreground text-sm font-semibold">
          {account.initials}
        </div>
        <div className="leading-tight min-w-0">
          <div className="text-sm font-semibold truncate">{account.name}</div>
          <span className="inline-block mt-0.5 rounded-full bg-gradient-to-r from-teal-500/20 to-emerald-500/20 px-2 py-0.5 text-[10px] font-semibold uppercase tracking-wider text-emerald-400 ring-1 ring-emerald-500/30">
            {account.badge}
          </span>
        </div>
      </div>

      {/* Nav */}
      <nav className="flex-1 overflow-y-auto px-3 py-4">
        <ul className="space-y-1">
          {navItems.map((item) => {
            const active = currentPath === item.url;
            const Icon = item.icon;
            return (
              <li key={item.title}>
                <Link
                  to={item.url}
                  className={cn(
                    "flex items-center gap-3 rounded-md px-3 py-2 text-sm font-medium transition-all",
                    active
                      ? "bg-gradient-to-r from-teal-500 to-emerald-500 text-white shadow-sm shadow-emerald-500/20"
                      : "text-sidebar-foreground/70 hover:bg-sidebar-accent hover:text-sidebar-foreground"
                  )}
                >
                  <Icon className="h-4 w-4" />
                  <span>{item.title}</span>
                </Link>
              </li>
            );
          })}
        </ul>
      </nav>

      {/* Theme toggle */}
      <div className="border-t border-sidebar-border p-3">
        <div className="flex items-center gap-1 rounded-lg bg-sidebar-accent/50 p-1">
          {themeOptions.map((opt) => {
            const Icon = opt.icon;
            const active = theme === opt.value;
            return (
              <button
                key={opt.value}
                onClick={() => setTheme(opt.value)}
                className={cn(
                  "flex flex-1 flex-col items-center gap-0.5 rounded-md px-1 py-1.5 text-[10px] font-medium transition-colors",
                  active
                    ? "bg-background text-foreground shadow-sm"
                    : "text-muted-foreground hover:text-foreground"
                )}
                aria-label={opt.label}
              >
                <Icon className="h-3.5 w-3.5" />
                {opt.label}
              </button>
            );
          })}
        </div>
      </div>
    </aside>
  );
}
