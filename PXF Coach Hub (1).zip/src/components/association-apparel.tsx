import { useMemo, useState } from "react";
import {
  Shirt,
  Plus,
  X,
  Search,
  Download,
  Send,
  Upload,
  Image as ImageIcon,
  Package,
  CheckCircle2,
  Clock,
  AlertTriangle,
  ArrowLeft,
  Trash2,
  DollarSign,
  Users,
  ChevronRight,
  FileText,
  Bell,
  RefreshCw,
} from "lucide-react";
import { cn } from "@/lib/utils";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Checkbox } from "@/components/ui/checkbox";
import { Switch } from "@/components/ui/switch";
import {
  Drawer,
  DrawerContent,
  DrawerHeader,
  DrawerTitle,
  DrawerDescription,
  DrawerFooter,
} from "@/components/ui/drawer";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { toast } from "sonner";

type OrderStatus = "COLLECTING" | "CLOSED" | "SUBMITTED" | "DELIVERED";
type PayStatus = "PAID" | "PENDING" | "OVERDUE";

const SIZE_OPTIONS = [
  "YXS","YS","YM","YL","YXL","XS","S","M","L","XL","2XL","3XL",
] as const;

const ITEM_TYPES = ["Jersey","Hoodie","Jacket","Socks","Bag","Helmet","Custom"];

type Item = {
  id: string;
  name: string;
  type: string;
  description: string;
  price: number;
  sizes: string[];
  images: number;
  notes: string;
  nameCustom: boolean;
  numberCustom: boolean;
  minQty?: number;
};

type Submission = {
  id: string;
  athlete: string;
  team: string;
  items: { itemId: string; size: string; qty: number; name?: string; number?: string }[];
  payment: PayStatus;
  pickedUp: boolean;
};

type Order = {
  id: string;
  name: string;
  season: string;
  teams: string[];
  deadline: string;
  supplier: string;
  supplierContact: string;
  status: OrderStatus;
  items: Item[];
  submissions: Submission[];
  payCollect: boolean;
};

const SEED_ORDERS: Order[] = [
  {
    id: "o1",
    name: "Fall 2026 Team Apparel",
    season: "Fall 2026",
    teams: ["U13 AAA", "U13 AA", "U15 AAA"],
    deadline: "2026-09-15",
    supplier: "NorthStar Athletics",
    supplierContact: "orders@northstar.com",
    status: "COLLECTING",
    payCollect: true,
    items: [
      { id: "i1", name: "Home Jersey", type: "Jersey", description: "Pro-cut sublimated home jersey", price: 145, sizes: ["YM","YL","S","M","L","XL"], images: 3, notes: "Runs small — size up", nameCustom: true, numberCustom: true },
      { id: "i2", name: "Team Hoodie", type: "Hoodie", description: "Cotton-poly blend pullover", price: 65, sizes: ["YS","YM","YL","S","M","L","XL","2XL"], images: 2, notes: "", nameCustom: true, numberCustom: false },
      { id: "i3", name: "Equipment Bag", type: "Bag", description: "Wheeled hockey bag w/ logo", price: 110, sizes: ["L"], images: 1, notes: "", nameCustom: true, numberCustom: false },
    ],
    submissions: [
      { id: "s1", athlete: "Liam Carter", team: "U13 AAA", items: [{ itemId: "i1", size: "YL", qty: 1, name: "CARTER", number: "17" }, { itemId: "i2", size: "YL", qty: 1 }], payment: "PAID", pickedUp: false },
      { id: "s2", athlete: "Emma Reyes", team: "U13 AAA", items: [{ itemId: "i1", size: "YM", qty: 1, name: "REYES", number: "9" }], payment: "PENDING", pickedUp: false },
      { id: "s3", athlete: "Noah Patel", team: "U13 AA", items: [{ itemId: "i1", size: "S", qty: 1, name: "PATEL", number: "22" }, { itemId: "i2", size: "S", qty: 1 }, { itemId: "i3", size: "L", qty: 1 }], payment: "OVERDUE", pickedUp: false },
      { id: "s4", athlete: "Ava Thompson", team: "U15 AAA", items: [{ itemId: "i1", size: "M", qty: 1, name: "THOMPSON", number: "44" }, { itemId: "i2", size: "M", qty: 2 }], payment: "PAID", pickedUp: false },
      { id: "s5", athlete: "Mason Lee", team: "U15 AAA", items: [{ itemId: "i2", size: "L", qty: 1 }], payment: "PAID", pickedUp: false },
    ],
  },
  {
    id: "o2",
    name: "Spring Showcase Warmups",
    season: "Spring 2026",
    teams: ["U15 AAA", "U17 AAA"],
    deadline: "2026-04-01",
    supplier: "BladeWorks",
    supplierContact: "sales@bladeworks.io",
    status: "DELIVERED",
    payCollect: true,
    items: [
      { id: "i4", name: "Warmup Jacket", type: "Jacket", description: "Full-zip warmup jacket", price: 95, sizes: ["S","M","L","XL"], images: 2, notes: "", nameCustom: true, numberCustom: true },
    ],
    submissions: [
      { id: "s6", athlete: "Olivia Martin", team: "U17 AAA", items: [{ itemId: "i4", size: "M", qty: 1, name: "MARTIN", number: "11" }], payment: "PAID", pickedUp: true },
      { id: "s7", athlete: "Lucas Wong", team: "U15 AAA", items: [{ itemId: "i4", size: "L", qty: 1, name: "WONG", number: "8" }], payment: "PAID", pickedUp: false },
    ],
  },
  {
    id: "o3",
    name: "Tournament Travel Set",
    season: "Fall 2026",
    teams: ["U17 AAA"],
    deadline: "2026-08-20",
    supplier: "NorthStar Athletics",
    supplierContact: "orders@northstar.com",
    status: "SUBMITTED",
    payCollect: true,
    items: [
      { id: "i5", name: "Travel Polo", type: "Custom", description: "Embroidered team polo", price: 55, sizes: ["S","M","L","XL","2XL"], images: 1, notes: "", nameCustom: false, numberCustom: false },
    ],
    submissions: [],
  },
];

const statusStyles: Record<OrderStatus, string> = {
  COLLECTING: "bg-emerald-500/15 text-emerald-400 ring-1 ring-emerald-500/30",
  CLOSED: "bg-amber-500/15 text-amber-400 ring-1 ring-amber-500/30",
  SUBMITTED: "bg-blue-500/15 text-blue-400 ring-1 ring-blue-500/30",
  DELIVERED: "bg-violet-500/15 text-violet-400 ring-1 ring-violet-500/30",
};

const payStyles: Record<PayStatus, string> = {
  PAID: "bg-emerald-500/15 text-emerald-400 ring-1 ring-emerald-500/30",
  PENDING: "bg-amber-500/15 text-amber-400 ring-1 ring-amber-500/30",
  OVERDUE: "bg-red-500/15 text-red-400 ring-1 ring-red-500/30",
};

function calcTotal(sub: Submission, items: Item[]) {
  return sub.items.reduce((sum, li) => {
    const it = items.find((i) => i.id === li.itemId);
    return sum + (it?.price ?? 0) * li.qty;
  }, 0);
}

function orderTotals(o: Order) {
  const total = o.submissions.reduce((s, sub) => s + calcTotal(sub, o.items), 0);
  const collected = o.submissions
    .filter((s) => s.payment === "PAID")
    .reduce((s, sub) => s + calcTotal(sub, o.items), 0);
  return { total, collected, outstanding: total - collected };
}

export function AssociationApparel() {
  const [tab, setTab] = useState<"orders" | "settings">("orders");
  const [orders, setOrders] = useState<Order[]>(SEED_ORDERS);
  const [selected, setSelected] = useState<Order | null>(null);
  const [createOpen, setCreateOpen] = useState(false);

  return (
    <div className="space-y-6">
      {/* Top bar */}
      <div className="flex items-center justify-between gap-4">
        <div className="flex items-center gap-1 rounded-lg border border-border bg-card p-1">
          {(["orders","settings"] as const).map((t) => (
            <button
              key={t}
              onClick={() => setTab(t)}
              className={cn(
                "rounded-md px-4 py-1.5 text-sm font-medium transition-colors",
                tab === t
                  ? "bg-gradient-to-r from-teal-500 to-emerald-500 text-white"
                  : "text-muted-foreground hover:text-foreground"
              )}
            >
              {t === "orders" ? "Orders" : "Store Settings"}
            </button>
          ))}
        </div>
        {tab === "orders" && (
          <Button
            onClick={() => setCreateOpen(true)}
            className="bg-teal-500 hover:bg-teal-600 text-white"
          >
            <Plus className="h-4 w-4 mr-1.5" /> Create Order
          </Button>
        )}
      </div>

      {tab === "orders" ? (
        <OrdersTab orders={orders} onSelect={setSelected} />
      ) : (
        <StoreSettingsTab />
      )}

      <OrderDetailDrawer
        order={selected}
        onClose={() => setSelected(null)}
        onUpdate={(updated) => {
          setOrders((prev) => prev.map((o) => (o.id === updated.id ? updated : o)));
          setSelected(updated);
        }}
      />

      <CreateOrderDrawer
        open={createOpen}
        onClose={() => setCreateOpen(false)}
        onCreate={(o) => {
          setOrders((prev) => [o, ...prev]);
          setCreateOpen(false);
          toast.success("Order published — parents notified");
        }}
      />
    </div>
  );
}

/* ---------------- Orders list ---------------- */

function OrdersTab({ orders, onSelect }: { orders: Order[]; onSelect: (o: Order) => void }) {
  const [q, setQ] = useState("");
  const [statusFilter, setStatusFilter] = useState<string>("all");
  const [seasonFilter, setSeasonFilter] = useState<string>("all");

  const seasons = useMemo(
    () => Array.from(new Set(orders.map((o) => o.season))),
    [orders]
  );

  const filtered = orders.filter((o) => {
    if (statusFilter !== "all" && o.status !== statusFilter) return false;
    if (seasonFilter !== "all" && o.season !== seasonFilter) return false;
    if (q && !o.name.toLowerCase().includes(q.toLowerCase())) return false;
    return true;
  });

  return (
    <div className="space-y-4">
      {/* KPIs */}
      <div className="grid grid-cols-4 gap-4">
        <Kpi label="Active Orders" value={orders.filter((o) => o.status === "COLLECTING").length} icon={Package} tone="emerald" />
        <Kpi label="Total Submissions" value={orders.reduce((s, o) => s + o.submissions.length, 0)} icon={Users} tone="blue" />
        <Kpi label="Collected (Active)" value={`$${orders.filter((o) => o.status === "COLLECTING").reduce((s, o) => s + orderTotals(o).collected, 0).toLocaleString()}`} icon={DollarSign} tone="teal" />
        <Kpi label="Outstanding" value={`$${orders.reduce((s, o) => s + orderTotals(o).outstanding, 0).toLocaleString()}`} icon={AlertTriangle} tone="amber" />
      </div>

      {/* Filters */}
      <div className="flex flex-wrap items-center gap-3">
        <div className="relative flex-1 min-w-[240px]">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <Input
            value={q}
            onChange={(e) => setQ(e.target.value)}
            placeholder="Search order name…"
            className="pl-9"
          />
        </div>
        <Select value={statusFilter} onValueChange={setStatusFilter}>
          <SelectTrigger className="w-44"><SelectValue placeholder="Status" /></SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All Statuses</SelectItem>
            <SelectItem value="COLLECTING">Collecting</SelectItem>
            <SelectItem value="CLOSED">Closed</SelectItem>
            <SelectItem value="SUBMITTED">Submitted to Supplier</SelectItem>
            <SelectItem value="DELIVERED">Delivered</SelectItem>
          </SelectContent>
        </Select>
        <Select value={seasonFilter} onValueChange={setSeasonFilter}>
          <SelectTrigger className="w-44"><SelectValue placeholder="Season" /></SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All Seasons</SelectItem>
            {seasons.map((s) => (
              <SelectItem key={s} value={s}>{s}</SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>

      {/* Table */}
      <div className="rounded-lg border border-border bg-card">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Order Name</TableHead>
              <TableHead>Season</TableHead>
              <TableHead>Teams</TableHead>
              <TableHead className="text-right">Items</TableHead>
              <TableHead className="text-right">Submissions</TableHead>
              <TableHead className="text-right">Collected</TableHead>
              <TableHead>Status</TableHead>
              <TableHead className="w-10" />
            </TableRow>
          </TableHeader>
          <TableBody>
            {filtered.map((o) => {
              const t = orderTotals(o);
              return (
                <TableRow
                  key={o.id}
                  className="cursor-pointer hover:bg-accent/40"
                  onClick={() => onSelect(o)}
                >
                  <TableCell className="font-medium">{o.name}</TableCell>
                  <TableCell className="text-muted-foreground">{o.season}</TableCell>
                  <TableCell className="text-muted-foreground">{o.teams.join(", ")}</TableCell>
                  <TableCell className="text-right">{o.items.length}</TableCell>
                  <TableCell className="text-right">{o.submissions.length}</TableCell>
                  <TableCell className="text-right font-medium">${t.collected.toLocaleString()}</TableCell>
                  <TableCell>
                    <span className={cn("rounded-full px-2 py-0.5 text-[10px] font-semibold uppercase tracking-wider", statusStyles[o.status])}>
                      {o.status === "SUBMITTED" ? "Submitted" : o.status}
                    </span>
                  </TableCell>
                  <TableCell><ChevronRight className="h-4 w-4 text-muted-foreground" /></TableCell>
                </TableRow>
              );
            })}
            {filtered.length === 0 && (
              <TableRow>
                <TableCell colSpan={8} className="text-center py-10 text-muted-foreground">
                  No orders match these filters.
                </TableCell>
              </TableRow>
            )}
          </TableBody>
        </Table>
      </div>
    </div>
  );
}

function Kpi({ label, value, icon: Icon, tone }: { label: string; value: string | number; icon: typeof Package; tone: "emerald" | "blue" | "teal" | "amber" }) {
  const tones = {
    emerald: "text-emerald-400 bg-emerald-500/10",
    blue: "text-blue-400 bg-blue-500/10",
    teal: "text-teal-400 bg-teal-500/10",
    amber: "text-amber-400 bg-amber-500/10",
  };
  return (
    <div className="rounded-lg border border-border bg-card p-4">
      <div className="flex items-center justify-between">
        <span className="text-xs uppercase tracking-wider text-muted-foreground">{label}</span>
        <div className={cn("h-8 w-8 rounded-md flex items-center justify-center", tones[tone])}>
          <Icon className="h-4 w-4" />
        </div>
      </div>
      <div className="mt-2 text-2xl font-bold">{value}</div>
    </div>
  );
}

/* ---------------- Order detail ---------------- */

function OrderDetailDrawer({
  order,
  onClose,
  onUpdate,
}: {
  order: Order | null;
  onClose: () => void;
  onUpdate: (o: Order) => void;
}) {
  const [tab, setTab] = useState<"submissions" | "items" | "payments" | "distribution">("submissions");

  if (!order) return null;
  const totals = orderTotals(order);

  return (
    <Drawer open={!!order} onOpenChange={(o) => !o && onClose()} direction="right">
      <DrawerContent className="ml-auto h-full w-full max-w-5xl rounded-none border-l">
        <DrawerHeader className="border-b border-border">
          <div className="flex items-center justify-between gap-4">
            <button onClick={onClose} className="flex items-center gap-2 text-sm text-muted-foreground hover:text-foreground">
              <ArrowLeft className="h-4 w-4" /> Orders
            </button>
            <span className={cn("rounded-full px-3 py-1 text-[10px] font-semibold uppercase tracking-wider", statusStyles[order.status])}>
              {order.status}
            </span>
          </div>
          <DrawerTitle className="text-2xl mt-2">{order.name}</DrawerTitle>
          <DrawerDescription className="flex items-center gap-4 text-sm">
            <span>Deadline: <strong className="text-foreground">{order.deadline}</strong></span>
            <span>•</span>
            <span>Supplier: <strong className="text-foreground">{order.supplier}</strong></span>
            <span>•</span>
            <span>Teams: <strong className="text-foreground">{order.teams.join(", ")}</strong></span>
          </DrawerDescription>

          {/* Inner tabs */}
          <div className="flex items-center gap-1 mt-4 rounded-lg bg-muted/40 p-1 w-fit">
            {([
              ["submissions","Submissions"],
              ["items","Items"],
              ["payments","Payments"],
              ["distribution","Distribution"],
            ] as const).map(([k,l]) => (
              <button
                key={k}
                onClick={() => setTab(k)}
                className={cn(
                  "rounded-md px-3 py-1.5 text-xs font-medium transition-colors",
                  tab === k ? "bg-background shadow-sm text-foreground" : "text-muted-foreground hover:text-foreground"
                )}
              >
                {l}
              </button>
            ))}
          </div>
        </DrawerHeader>

        <div className="flex-1 overflow-y-auto p-6">
          {tab === "submissions" && <SubmissionsTab order={order} />}
          {tab === "items" && <ItemsTab order={order} />}
          {tab === "payments" && <PaymentsTab order={order} totals={totals} />}
          {tab === "distribution" && <DistributionTab order={order} onUpdate={onUpdate} />}
        </div>
      </DrawerContent>
    </Drawer>
  );
}

function SubmissionsTab({ order }: { order: Order }) {
  const [filter, setFilter] = useState<string>("all");
  const filtered = order.submissions.filter((s) => filter === "all" || s.payment === filter);

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between gap-3">
        <Select value={filter} onValueChange={setFilter}>
          <SelectTrigger className="w-44"><SelectValue /></SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All Payments</SelectItem>
            <SelectItem value="PAID">Paid</SelectItem>
            <SelectItem value="PENDING">Pending</SelectItem>
            <SelectItem value="OVERDUE">Overdue</SelectItem>
          </SelectContent>
        </Select>
        <div className="flex gap-2">
          <Button variant="outline" size="sm" onClick={() => toast.success("Reminders sent to unpaid families")}>
            <Bell className="h-4 w-4 mr-1.5" /> Remind Unpaid
          </Button>
          <Button variant="outline" size="sm" onClick={() => toast.success("Submissions CSV exported")}>
            <Download className="h-4 w-4 mr-1.5" /> Export CSV
          </Button>
          <Button size="sm" className="bg-teal-500 hover:bg-teal-600 text-white" onClick={() => toast.success("Supplier order sheet exported")}>
            <FileText className="h-4 w-4 mr-1.5" /> Supplier Sheet
          </Button>
        </div>
      </div>

      <div className="rounded-lg border border-border">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Athlete</TableHead>
              <TableHead>Team</TableHead>
              <TableHead>Items</TableHead>
              <TableHead>Customization</TableHead>
              <TableHead className="text-right">Total</TableHead>
              <TableHead>Payment</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {filtered.map((s) => {
              const total = calcTotal(s, order.items);
              const cust = s.items.filter((i) => i.name || i.number).map((i) => `${i.name ?? ""}${i.number ? ` #${i.number}` : ""}`).join(", ");
              return (
                <TableRow key={s.id}>
                  <TableCell className="font-medium">{s.athlete}</TableCell>
                  <TableCell className="text-muted-foreground">{s.team}</TableCell>
                  <TableCell className="text-sm">
                    {s.items.map((i, idx) => {
                      const it = order.items.find((x) => x.id === i.itemId);
                      return (
                        <div key={idx} className="text-muted-foreground">
                          {it?.name} <span className="text-foreground">({i.size}×{i.qty})</span>
                        </div>
                      );
                    })}
                  </TableCell>
                  <TableCell className="text-xs text-muted-foreground">{cust || "—"}</TableCell>
                  <TableCell className="text-right font-medium">${total}</TableCell>
                  <TableCell>
                    <span className={cn("rounded-full px-2 py-0.5 text-[10px] font-semibold uppercase tracking-wider", payStyles[s.payment])}>
                      {s.payment}
                    </span>
                  </TableCell>
                </TableRow>
              );
            })}
            {filtered.length === 0 && (
              <TableRow><TableCell colSpan={6} className="text-center py-8 text-muted-foreground">No submissions.</TableCell></TableRow>
            )}
          </TableBody>
        </Table>
      </div>
    </div>
  );
}

function ItemsTab({ order }: { order: Order }) {
  return (
    <div className="space-y-4">
      {order.items.map((item) => {
        const sizeBreakdown: Record<string, number> = {};
        order.submissions.forEach((s) =>
          s.items.filter((i) => i.itemId === item.id).forEach((i) => {
            sizeBreakdown[i.size] = (sizeBreakdown[i.size] ?? 0) + i.qty;
          })
        );
        const totalQty = Object.values(sizeBreakdown).reduce((a, b) => a + b, 0);
        const max = Math.max(1, ...Object.values(sizeBreakdown));
        return (
          <div key={item.id} className="rounded-lg border border-border bg-card p-5">
            <div className="flex gap-4">
              <div className="h-24 w-24 rounded-md bg-gradient-to-br from-teal-500/10 to-emerald-500/10 flex items-center justify-center text-teal-400 shrink-0">
                <Shirt className="h-10 w-10" />
              </div>
              <div className="flex-1">
                <div className="flex items-start justify-between gap-3">
                  <div>
                    <div className="flex items-center gap-2">
                      <h3 className="font-semibold">{item.name}</h3>
                      <Badge variant="outline" className="text-[10px]">{item.type}</Badge>
                    </div>
                    <p className="text-sm text-muted-foreground mt-1">{item.description}</p>
                    {item.notes && (
                      <p className="text-xs text-amber-400 mt-1">Note: {item.notes}</p>
                    )}
                  </div>
                  <div className="text-right">
                    <div className="text-lg font-bold">${item.price}</div>
                    <div className="text-xs text-muted-foreground">{totalQty} ordered</div>
                  </div>
                </div>

                <div className="mt-4">
                  <div className="text-xs uppercase tracking-wider text-muted-foreground mb-2">Size Distribution</div>
                  <div className="space-y-1">
                    {item.sizes.map((size) => {
                      const count = sizeBreakdown[size] ?? 0;
                      return (
                        <div key={size} className="flex items-center gap-2 text-xs">
                          <span className="w-10 text-muted-foreground">{size}</span>
                          <div className="flex-1 h-2 rounded-full bg-muted overflow-hidden">
                            <div
                              className="h-full bg-gradient-to-r from-teal-500 to-emerald-500"
                              style={{ width: `${(count / max) * 100}%` }}
                            />
                          </div>
                          <span className="w-8 text-right font-medium">{count}</span>
                        </div>
                      );
                    })}
                  </div>
                </div>
              </div>
            </div>
          </div>
        );
      })}
    </div>
  );
}

function PaymentsTab({ order, totals }: { order: Order; totals: ReturnType<typeof orderTotals> }) {
  const unpaid = order.submissions.filter((s) => s.payment !== "PAID");
  return (
    <div className="space-y-4">
      <div className="grid grid-cols-3 gap-4">
        <div className="rounded-lg border border-border bg-card p-4">
          <div className="text-xs uppercase tracking-wider text-muted-foreground">Total Collected</div>
          <div className="mt-2 text-2xl font-bold text-emerald-400">${totals.collected.toLocaleString()}</div>
        </div>
        <div className="rounded-lg border border-border bg-card p-4">
          <div className="text-xs uppercase tracking-wider text-muted-foreground">Outstanding</div>
          <div className="mt-2 text-2xl font-bold text-amber-400">${totals.outstanding.toLocaleString()}</div>
        </div>
        <div className="rounded-lg border border-border bg-card p-4">
          <div className="text-xs uppercase tracking-wider text-muted-foreground">Order Total</div>
          <div className="mt-2 text-2xl font-bold">${totals.total.toLocaleString()}</div>
        </div>
      </div>

      <div className="rounded-lg border border-border bg-card">
        <div className="flex items-center justify-between p-4 border-b border-border">
          <h3 className="font-semibold">Unpaid Families</h3>
          <Button size="sm" variant="outline" onClick={() => toast.success("Bulk reminders sent")}>
            <Bell className="h-4 w-4 mr-1.5" /> Bulk Remind
          </Button>
        </div>
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Family</TableHead>
              <TableHead>Team</TableHead>
              <TableHead className="text-right">Amount Owed</TableHead>
              <TableHead>Status</TableHead>
              <TableHead className="text-right">Actions</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {unpaid.map((s) => (
              <TableRow key={s.id}>
                <TableCell className="font-medium">{s.athlete}</TableCell>
                <TableCell className="text-muted-foreground">{s.team}</TableCell>
                <TableCell className="text-right font-medium">${calcTotal(s, order.items)}</TableCell>
                <TableCell>
                  <span className={cn("rounded-full px-2 py-0.5 text-[10px] font-semibold uppercase tracking-wider", payStyles[s.payment])}>
                    {s.payment}
                  </span>
                </TableCell>
                <TableCell className="text-right">
                  <Button size="sm" variant="ghost" onClick={() => toast.success(`Reminder sent to ${s.athlete}`)}>
                    <Send className="h-3.5 w-3.5 mr-1" /> Remind
                  </Button>
                  <Button size="sm" variant="ghost" className="text-red-400" onClick={() => toast.success("Refund issued")}>
                    <RefreshCw className="h-3.5 w-3.5 mr-1" /> Refund
                  </Button>
                </TableCell>
              </TableRow>
            ))}
            {unpaid.length === 0 && (
              <TableRow><TableCell colSpan={5} className="text-center py-8 text-muted-foreground">All families paid 🎉</TableCell></TableRow>
            )}
          </TableBody>
        </Table>
      </div>
    </div>
  );
}

function DistributionTab({ order, onUpdate }: { order: Order; onUpdate: (o: Order) => void }) {
  const outstanding = order.submissions.filter((s) => !s.pickedUp);
  const togglePickup = (id: string) => {
    onUpdate({
      ...order,
      submissions: order.submissions.map((s) =>
        s.id === id ? { ...s, pickedUp: !s.pickedUp } : s
      ),
    });
  };
  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between rounded-lg border border-border bg-card p-4">
        <div>
          <div className="font-semibold">Order Arrival</div>
          <div className="text-sm text-muted-foreground">
            {order.status === "DELIVERED" ? "Marked as received — distribute to families." : "Mark this order as delivered when it arrives."}
          </div>
        </div>
        <div className="flex gap-2">
          {order.status !== "DELIVERED" && (
            <Button variant="outline" size="sm" onClick={() => onUpdate({ ...order, status: "DELIVERED" })}>
              <CheckCircle2 className="h-4 w-4 mr-1.5" /> Mark Received
            </Button>
          )}
          <Button size="sm" className="bg-teal-500 hover:bg-teal-600 text-white" onClick={() => toast.success("Pickup notification sent to all families")}>
            <Bell className="h-4 w-4 mr-1.5" /> Notify Families
          </Button>
        </div>
      </div>

      <div className="rounded-lg border border-border bg-card">
        <div className="flex items-center justify-between p-4 border-b border-border">
          <h3 className="font-semibold">Distribution Checklist <span className="text-muted-foreground font-normal">({outstanding.length} outstanding)</span></h3>
          {outstanding.length > 0 && (
            <Button size="sm" variant="outline" onClick={() => toast.success("Pickup reminders sent")}>
              <Bell className="h-4 w-4 mr-1.5" /> Remind Outstanding
            </Button>
          )}
        </div>
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead className="w-10" />
              <TableHead>Family</TableHead>
              <TableHead>Team</TableHead>
              <TableHead>Items</TableHead>
              <TableHead>Status</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {order.submissions.map((s) => (
              <TableRow key={s.id}>
                <TableCell>
                  <Checkbox checked={s.pickedUp} onCheckedChange={() => togglePickup(s.id)} />
                </TableCell>
                <TableCell className="font-medium">{s.athlete}</TableCell>
                <TableCell className="text-muted-foreground">{s.team}</TableCell>
                <TableCell className="text-sm text-muted-foreground">
                  {s.items.reduce((sum, i) => sum + i.qty, 0)} items
                </TableCell>
                <TableCell>
                  {s.pickedUp ? (
                    <span className="inline-flex items-center gap-1 text-xs text-emerald-400">
                      <CheckCircle2 className="h-3.5 w-3.5" /> Picked Up
                    </span>
                  ) : (
                    <span className="inline-flex items-center gap-1 text-xs text-amber-400">
                      <Clock className="h-3.5 w-3.5" /> Not Yet
                    </span>
                  )}
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </div>
    </div>
  );
}

/* ---------------- Create Order ---------------- */

const ALL_TEAMS = ["U11 AA","U13 AAA","U13 AA","U15 AAA","U15 AA","U17 AAA","U17 AA"];

function CreateOrderDrawer({
  open,
  onClose,
  onCreate,
}: {
  open: boolean;
  onClose: () => void;
  onCreate: (o: Order) => void;
}) {
  const [name, setName] = useState("");
  const [season, setSeason] = useState("Fall 2026");
  const [teams, setTeams] = useState<string[]>([]);
  const [deadline, setDeadline] = useState("");
  const [supplier, setSupplier] = useState("");
  const [supplierContact, setSupplierContact] = useState("");
  const [payCollect, setPayCollect] = useState(true);
  const [items, setItems] = useState<Item[]>([]);

  const reset = () => {
    setName(""); setTeams([]); setDeadline(""); setSupplier(""); setSupplierContact(""); setItems([]);
  };

  const addItem = () => {
    setItems((p) => [...p, {
      id: `new-${Date.now()}`,
      name: "",
      type: "Jersey",
      description: "",
      price: 0,
      sizes: [],
      images: 0,
      notes: "",
      nameCustom: false,
      numberCustom: false,
    }]);
  };

  const updateItem = (id: string, patch: Partial<Item>) => {
    setItems((p) => p.map((i) => (i.id === id ? { ...i, ...patch } : i)));
  };

  const toggleSize = (id: string, size: string) => {
    setItems((p) => p.map((i) => i.id === id ? {
      ...i,
      sizes: i.sizes.includes(size) ? i.sizes.filter((s) => s !== size) : [...i.sizes, size],
    } : i));
  };

  const toggleTeam = (team: string) => {
    setTeams((p) => p.includes(team) ? p.filter((t) => t !== team) : [...p, team]);
  };

  const canPublish = name && teams.length > 0 && deadline && supplier && items.length > 0 && items.every((i) => i.name && i.price > 0 && i.sizes.length > 0);

  const publish = () => {
    onCreate({
      id: `o-${Date.now()}`,
      name, season, teams, deadline, supplier, supplierContact,
      status: "COLLECTING",
      payCollect,
      items,
      submissions: [],
    });
    reset();
  };

  return (
    <Drawer open={open} onOpenChange={(o) => !o && onClose()} direction="right">
      <DrawerContent className="ml-auto h-full w-full max-w-3xl rounded-none border-l">
        <DrawerHeader className="border-b border-border">
          <DrawerTitle>Create Apparel Order</DrawerTitle>
          <DrawerDescription>Publish a new apparel order to selected teams.</DrawerDescription>
        </DrawerHeader>

        <div className="flex-1 overflow-y-auto p-6 space-y-6">
          {/* Basics */}
          <section className="space-y-4">
            <h3 className="text-sm font-semibold uppercase tracking-wider text-muted-foreground">Order Details</h3>
            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label>Order Name</Label>
                <Input value={name} onChange={(e) => setName(e.target.value)} placeholder="Fall 2026 Team Apparel" />
              </div>
              <div>
                <Label>Season</Label>
                <Select value={season} onValueChange={setSeason}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="Fall 2026">Fall 2026</SelectItem>
                    <SelectItem value="Winter 2026">Winter 2026</SelectItem>
                    <SelectItem value="Spring 2026">Spring 2026</SelectItem>
                    <SelectItem value="Summer 2026">Summer 2026</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label>Submission Deadline</Label>
                <Input type="date" value={deadline} onChange={(e) => setDeadline(e.target.value)} />
              </div>
              <div className="flex items-end gap-3">
                <div className="flex-1">
                  <Label>Collect Payment Through App</Label>
                  <div className="h-10 flex items-center">
                    <Switch checked={payCollect} onCheckedChange={setPayCollect} />
                    <span className="ml-2 text-sm text-muted-foreground">{payCollect ? "Enabled" : "Disabled"}</span>
                  </div>
                </div>
              </div>
            </div>

            <div>
              <Label>Teams Included</Label>
              <div className="mt-2 grid grid-cols-3 gap-2">
                {ALL_TEAMS.map((t) => (
                  <label key={t} className="flex items-center gap-2 rounded-md border border-border p-2 text-sm cursor-pointer hover:bg-accent/30">
                    <Checkbox checked={teams.includes(t)} onCheckedChange={() => toggleTeam(t)} />
                    {t}
                  </label>
                ))}
              </div>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label>Supplier Name</Label>
                <Input value={supplier} onChange={(e) => setSupplier(e.target.value)} placeholder="NorthStar Athletics" />
              </div>
              <div>
                <Label>Supplier Contact</Label>
                <Input value={supplierContact} onChange={(e) => setSupplierContact(e.target.value)} placeholder="orders@supplier.com" />
              </div>
            </div>
          </section>

          {/* Items */}
          <section className="space-y-4">
            <div className="flex items-center justify-between">
              <h3 className="text-sm font-semibold uppercase tracking-wider text-muted-foreground">Items</h3>
              <Button variant="outline" size="sm" onClick={addItem}>
                <Plus className="h-4 w-4 mr-1.5" /> Add Item
              </Button>
            </div>

            {items.length === 0 && (
              <div className="rounded-lg border border-dashed border-border p-8 text-center text-sm text-muted-foreground">
                No items yet. Add at least one item to publish.
              </div>
            )}

            {items.map((item, idx) => (
              <div key={item.id} className="rounded-lg border border-border bg-card p-4 space-y-3">
                <div className="flex items-center justify-between">
                  <div className="text-sm font-semibold">Item {idx + 1}</div>
                  <Button variant="ghost" size="sm" onClick={() => setItems((p) => p.filter((i) => i.id !== item.id))}>
                    <Trash2 className="h-4 w-4 text-red-400" />
                  </Button>
                </div>

                <div className="grid grid-cols-3 gap-3">
                  <div>
                    <Label>Item Type</Label>
                    <Select value={item.type} onValueChange={(v) => updateItem(item.id, { type: v })}>
                      <SelectTrigger><SelectValue /></SelectTrigger>
                      <SelectContent>
                        {ITEM_TYPES.map((t) => <SelectItem key={t} value={t}>{t}</SelectItem>)}
                      </SelectContent>
                    </Select>
                  </div>
                  <div>
                    <Label>Name</Label>
                    <Input value={item.name} onChange={(e) => updateItem(item.id, { name: e.target.value })} placeholder="Home Jersey" />
                  </div>
                  <div>
                    <Label>Price ($)</Label>
                    <Input type="number" value={item.price || ""} onChange={(e) => updateItem(item.id, { price: Number(e.target.value) })} />
                  </div>
                </div>

                <div>
                  <Label>Description</Label>
                  <Textarea rows={2} value={item.description} onChange={(e) => updateItem(item.id, { description: e.target.value })} />
                </div>

                <div>
                  <Label>Available Sizes</Label>
                  <div className="mt-2 flex flex-wrap gap-1.5">
                    {SIZE_OPTIONS.map((s) => {
                      const on = item.sizes.includes(s);
                      return (
                        <button
                          key={s}
                          type="button"
                          onClick={() => toggleSize(item.id, s)}
                          className={cn(
                            "rounded-md px-2.5 py-1 text-xs font-medium border transition-colors",
                            on
                              ? "bg-teal-500 text-white border-teal-500"
                              : "border-border text-muted-foreground hover:text-foreground"
                          )}
                        >
                          {s}
                        </button>
                      );
                    })}
                  </div>
                </div>

                <div>
                  <Label>Product Images (up to 5)</Label>
                  <div className="mt-2 grid grid-cols-5 gap-2">
                    {Array.from({ length: 5 }).map((_, i) => {
                      const filled = i < item.images;
                      return (
                        <button
                          key={i}
                          type="button"
                          onClick={() => updateItem(item.id, { images: Math.min(5, item.images + 1) })}
                          className={cn(
                            "aspect-square rounded-md border-2 border-dashed flex items-center justify-center text-muted-foreground hover:text-foreground hover:border-teal-500",
                            filled ? "border-solid border-teal-500/40 bg-teal-500/5 text-teal-400" : "border-border"
                          )}
                        >
                          {filled ? <ImageIcon className="h-5 w-5" /> : <Upload className="h-4 w-4" />}
                        </button>
                      );
                    })}
                  </div>
                  <p className="text-xs text-muted-foreground mt-1">JPG/PNG/PDF · 10MB max each. First image is the primary display image.</p>
                </div>

                <div>
                  <Label>Notes to Parents (optional)</Label>
                  <Input value={item.notes} onChange={(e) => updateItem(item.id, { notes: e.target.value })} placeholder="This item runs small — we recommend sizing up" />
                </div>

                <div className="grid grid-cols-3 gap-3 pt-2">
                  <label className="flex items-center gap-2 text-sm">
                    <Switch checked={item.nameCustom} onCheckedChange={(v) => updateItem(item.id, { nameCustom: v })} />
                    Name customization
                  </label>
                  <label className="flex items-center gap-2 text-sm">
                    <Switch checked={item.numberCustom} onCheckedChange={(v) => updateItem(item.id, { numberCustom: v })} />
                    Number customization
                  </label>
                  <div>
                    <Label className="text-xs">Min Qty (optional)</Label>
                    <Input type="number" value={item.minQty ?? ""} onChange={(e) => updateItem(item.id, { minQty: e.target.value ? Number(e.target.value) : undefined })} />
                  </div>
                </div>
              </div>
            ))}
          </section>
        </div>

        <DrawerFooter className="border-t border-border flex-row justify-between">
          <Button variant="ghost" onClick={onClose}><X className="h-4 w-4 mr-1.5" /> Cancel</Button>
          <Button
            disabled={!canPublish}
            onClick={publish}
            className="bg-gradient-to-r from-teal-500 to-emerald-500 text-white"
          >
            Publish Order
          </Button>
        </DrawerFooter>
      </DrawerContent>
    </Drawer>
  );
}

/* ---------------- Store Settings ---------------- */

function StoreSettingsTab() {
  const [suppliers, setSuppliers] = useState([
    { id: "sup1", name: "NorthStar Athletics", contact: "orders@northstar.com" },
    { id: "sup2", name: "BladeWorks", contact: "sales@bladeworks.io" },
  ]);
  const [library] = useState([
    { id: "lib1", name: "Home Jersey", type: "Jersey", price: 145 },
    { id: "lib2", name: "Team Hoodie", type: "Hoodie", price: 65 },
    { id: "lib3", name: "Equipment Bag", type: "Bag", price: 110 },
    { id: "lib4", name: "Warmup Jacket", type: "Jacket", price: 95 },
  ]);

  return (
    <div className="grid grid-cols-2 gap-6">
      <div className="rounded-lg border border-border bg-card p-5 space-y-4">
        <div className="flex items-center justify-between">
          <h3 className="font-semibold">Default Suppliers</h3>
          <Button size="sm" variant="outline" onClick={() => {
            setSuppliers((p) => [...p, { id: `s-${Date.now()}`, name: "New Supplier", contact: "" }]);
            toast.success("Supplier added");
          }}>
            <Plus className="h-4 w-4 mr-1.5" /> Add
          </Button>
        </div>
        <div className="space-y-2">
          {suppliers.map((s) => (
            <div key={s.id} className="flex items-center justify-between rounded-md border border-border p-3">
              <div>
                <div className="font-medium text-sm">{s.name}</div>
                <div className="text-xs text-muted-foreground">{s.contact || "—"}</div>
              </div>
              <Button variant="ghost" size="sm" onClick={() => setSuppliers((p) => p.filter((x) => x.id !== s.id))}>
                <Trash2 className="h-4 w-4 text-red-400" />
              </Button>
            </div>
          ))}
        </div>
      </div>

      <div className="rounded-lg border border-border bg-card p-5 space-y-4">
        <div className="flex items-center justify-between">
          <h3 className="font-semibold">Standard Items Library</h3>
          <Button size="sm" variant="outline" onClick={() => toast.success("Item added to library")}>
            <Plus className="h-4 w-4 mr-1.5" /> Add Item
          </Button>
        </div>
        <div className="space-y-2">
          {library.map((it) => (
            <div key={it.id} className="flex items-center justify-between rounded-md border border-border p-3">
              <div className="flex items-center gap-3">
                <div className="h-10 w-10 rounded-md bg-teal-500/10 flex items-center justify-center text-teal-400">
                  <Shirt className="h-5 w-5" />
                </div>
                <div>
                  <div className="font-medium text-sm">{it.name}</div>
                  <div className="text-xs text-muted-foreground">{it.type}</div>
                </div>
              </div>
              <div className="text-sm font-semibold">${it.price}</div>
            </div>
          ))}
        </div>
      </div>

      <div className="rounded-lg border border-border bg-card p-5 space-y-4">
        <h3 className="font-semibold">Association Branding</h3>
        <div className="flex items-center gap-4">
          <div className="h-20 w-20 rounded-lg bg-gradient-to-br from-teal-500 to-emerald-500 flex items-center justify-center text-white font-black text-xl">PXF</div>
          <div className="space-y-2">
            <Button variant="outline" size="sm"><Upload className="h-4 w-4 mr-1.5" /> Upload Logo</Button>
            <p className="text-xs text-muted-foreground">Used as overlay when an item has no product image.</p>
          </div>
        </div>
      </div>

      <div className="rounded-lg border border-border bg-card p-5 space-y-4">
        <h3 className="font-semibold">Size Guide</h3>
        <p className="text-sm text-muted-foreground">Upload a sizing chart shown to parents during ordering.</p>
        <div className="flex gap-2">
          <Button variant="outline" size="sm"><Upload className="h-4 w-4 mr-1.5" /> Upload Chart</Button>
          <Input placeholder="Or paste a link to a size guide…" />
        </div>
      </div>
    </div>
  );
}
