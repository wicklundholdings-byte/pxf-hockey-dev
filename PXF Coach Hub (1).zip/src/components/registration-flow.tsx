import { useEffect, useState } from "react";
import { X, ChevronLeft, Plus, Check, Apple, Smartphone } from "lucide-react";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";
import type { BookingCamp } from "@/lib/booking-data";

/**
 * UI-only registration flow.
 * No Supabase writes, no Stripe — values are persisted to localStorage so the
 * flow feels real across sessions. Wire to real backend once SQL + Stripe are ready.
 */

type Step =
  | "auth-gate"
  | "sign-up"
  | "sign-in"
  | "select-athlete"
  | "add-athlete"
  | "review"
  | "payment"
  | "confirmed";

type Parent = {
  id: string;
  firstName: string;
  lastName: string;
  email: string;
  phone?: string;
};

type Athlete = {
  id: string;
  firstName: string;
  lastName: string;
  dob: string;
  position: "forward" | "defence" | "goalie";
  jersey?: string;
};

const PARENT_KEY = "pxf.parent";
const ATHLETES_KEY = "pxf.athletes";

function loadParent(): Parent | null {
  try {
    const raw = localStorage.getItem(PARENT_KEY);
    return raw ? JSON.parse(raw) : null;
  } catch {
    return null;
  }
}

function loadAthletes(parentId: string): Athlete[] {
  try {
    const raw = localStorage.getItem(`${ATHLETES_KEY}.${parentId}`);
    return raw ? JSON.parse(raw) : [];
  } catch {
    return [];
  }
}

function saveParent(p: Parent) {
  localStorage.setItem(PARENT_KEY, JSON.stringify(p));
}

function saveAthletes(parentId: string, a: Athlete[]) {
  localStorage.setItem(`${ATHLETES_KEY}.${parentId}`, JSON.stringify(a));
}

export function RegistrationFlow({
  camp,
  onClose,
}: {
  camp: BookingCamp;
  onClose: () => void;
}) {
  const [parent, setParent] = useState<Parent | null>(null);
  const [athletes, setAthletes] = useState<Athlete[]>([]);
  const [selectedAthleteId, setSelectedAthleteId] = useState<string | null>(null);
  const [step, setStep] = useState<Step>("auth-gate");
  const [plan, setPlan] = useState<"full" | "installments">("full");

  // Hydrate from localStorage
  useEffect(() => {
    const p = loadParent();
    if (p) {
      setParent(p);
      const a = loadAthletes(p.id);
      setAthletes(a);
      setStep(a.length > 0 ? "select-athlete" : "add-athlete");
    }
  }, []);

  const ebDays = (() => {
    if (!camp.earlyBirdDeadline) return null;
    const d = Math.ceil((new Date(camp.earlyBirdDeadline).getTime() - Date.now()) / 86400000);
    return d > 0 ? d : null;
  })();
  const activePrice = ebDays && camp.earlyBirdPrice ? camp.earlyBirdPrice : camp.price;
  const selectedAthlete = athletes.find((a) => a.id === selectedAthleteId) ?? null;

  function handleSignUpComplete(p: Parent) {
    saveParent(p);
    setParent(p);
    setStep("add-athlete");
  }

  function handleSignInComplete(p: Parent) {
    saveParent(p);
    setParent(p);
    const a = loadAthletes(p.id);
    setAthletes(a);
    setStep(a.length > 0 ? "select-athlete" : "add-athlete");
  }

  function handleAddAthlete(a: Athlete) {
    if (!parent) return;
    const next = [...athletes, a];
    setAthletes(next);
    saveAthletes(parent.id, next);
    setSelectedAthleteId(a.id);
    setStep("review");
  }

  const headerTitle: Record<Step, string> = {
    "auth-gate": "Register for this camp",
    "sign-up": "Create your PXF account",
    "sign-in": "Sign in to PXF",
    "select-athlete": "Choose athlete",
    "add-athlete": "Add an athlete",
    review: "Review & confirm",
    payment: "Payment",
    confirmed: "You're registered!",
  };

  const canGoBack =
    step === "sign-up" ||
    step === "sign-in" ||
    (step === "add-athlete" && athletes.length > 0) ||
    step === "review" ||
    step === "payment";

  function goBack() {
    if (step === "sign-up" || step === "sign-in") setStep("auth-gate");
    else if (step === "add-athlete") setStep("select-athlete");
    else if (step === "review") setStep(athletes.length > 0 ? "select-athlete" : "add-athlete");
    else if (step === "payment") setStep("review");
  }

  return (
    <div className="fixed inset-0 z-50 flex items-end justify-center bg-black/70 p-0 sm:items-center sm:p-4">
      <div className="flex max-h-[92vh] w-full max-w-lg flex-col overflow-hidden rounded-t-2xl bg-card text-card-foreground shadow-xl sm:rounded-2xl">
        {/* Header */}
        <div className="flex items-center justify-between border-b border-border px-5 py-4">
          <div className="flex items-center gap-2">
            {canGoBack && (
              <button
                onClick={goBack}
                className="text-muted-foreground hover:text-foreground"
                aria-label="Back"
              >
                <ChevronLeft className="h-5 w-5" />
              </button>
            )}
            <h3 className="font-bold">{headerTitle[step]}</h3>
          </div>
          <button onClick={onClose} className="text-muted-foreground hover:text-foreground" aria-label="Close">
            <X className="h-5 w-5" />
          </button>
        </div>

        {/* Step indicator */}
        {step !== "confirmed" && (
          <StepDots step={step} hasAccount={!!parent} />
        )}

        {/* Body */}
        <div className="flex-1 overflow-y-auto">
          {step === "auth-gate" && (
            <AuthGate
              camp={camp}
              onSignUp={() => setStep("sign-up")}
              onSignIn={() => setStep("sign-in")}
            />
          )}
          {step === "sign-up" && <SignUpForm onComplete={handleSignUpComplete} />}
          {step === "sign-in" && <SignInForm onComplete={handleSignInComplete} />}
          {step === "select-athlete" && parent && (
            <SelectAthlete
              athletes={athletes}
              selectedId={selectedAthleteId}
              onSelect={setSelectedAthleteId}
              onAddNew={() => setStep("add-athlete")}
              onContinue={() => setStep("review")}
            />
          )}
          {step === "add-athlete" && <AddAthleteForm onSave={handleAddAthlete} />}
          {step === "review" && selectedAthlete && (
            <ReviewStep
              camp={camp}
              athlete={selectedAthlete}
              parent={parent!}
              price={activePrice}
              plan={plan}
              onPlanChange={setPlan}
              onContinue={() => setStep("payment")}
            />
          )}
          {step === "payment" && selectedAthlete && (
            <PaymentStep
              total={plan === "full" ? activePrice : (camp.paymentPlan?.installments[0].amount ?? activePrice)}
              onPay={() => setStep("confirmed")}
            />
          )}
          {step === "confirmed" && selectedAthlete && (
            <ConfirmedStep
              camp={camp}
              athlete={selectedAthlete}
              parent={parent!}
              onClose={onClose}
            />
          )}
        </div>
      </div>
    </div>
  );
}

function StepDots({ step, hasAccount }: { step: Step; hasAccount: boolean }) {
  const order: Step[] = hasAccount
    ? ["select-athlete", "review", "payment"]
    : ["auth-gate", "sign-up", "select-athlete", "review", "payment"];
  // Normalize equivalents
  const normalized: Step =
    step === "sign-in" ? "sign-up" : step === "add-athlete" ? "select-athlete" : step;
  const idx = order.indexOf(normalized);
  if (idx < 0) return null;
  return (
    <div className="flex items-center gap-1.5 border-b border-border px-5 py-2">
      {order.map((s, i) => (
        <div
          key={s}
          className={cn(
            "h-1 flex-1 rounded-full transition-colors",
            i <= idx ? "bg-gradient-to-r from-teal-500 to-emerald-500" : "bg-muted",
          )}
        />
      ))}
    </div>
  );
}

function AuthGate({
  camp,
  onSignUp,
  onSignIn,
}: {
  camp: BookingCamp;
  onSignUp: () => void;
  onSignIn: () => void;
}) {
  return (
    <div className="space-y-5 p-5">
      <div className="rounded-xl border border-border bg-muted/30 p-4">
        <div className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">Registering for</div>
        <div className="mt-1 text-base font-bold">{camp.name}</div>
        <div className="text-xs text-muted-foreground">{camp.dateRange} · ${camp.price}</div>
      </div>
      <div>
        <h4 className="text-base font-bold">Create a free PXF account to register</h4>
        <p className="mt-1 text-sm text-muted-foreground">
          Your account stores your athletes, registration history, and lets you receive updates from your coach.
        </p>
      </div>
      <div className="space-y-2">
        <Button
          onClick={onSignUp}
          className="w-full bg-gradient-to-r from-teal-500 to-emerald-500 text-white hover:opacity-90"
        >
          Sign Up
        </Button>
        <Button onClick={onSignIn} variant="outline" className="w-full">
          I already have an account
        </Button>
      </div>
      <p className="text-[11px] text-muted-foreground">
        By creating an account you agree to PXF Hockey's Terms of Service and Privacy Policy.
      </p>
    </div>
  );
}

function SignUpForm({ onComplete }: { onComplete: (p: Parent) => void }) {
  const [firstName, setFirstName] = useState("");
  const [lastName, setLastName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [phone, setPhone] = useState("");
  const [submitting, setSubmitting] = useState(false);

  const valid =
    firstName.trim().length > 0 &&
    lastName.trim().length > 0 &&
    /^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(email) &&
    password.length >= 8;

  function submit(e: React.FormEvent) {
    e.preventDefault();
    if (!valid) return;
    setSubmitting(true);
    // Simulate async sign-up. Real impl will call supabase.auth.signUp + insert into profiles.
    setTimeout(() => {
      onComplete({
        id: `local_${Date.now()}`,
        firstName: firstName.trim(),
        lastName: lastName.trim(),
        email: email.trim().toLowerCase(),
        phone: phone.trim() || undefined,
      });
    }, 350);
  }

  return (
    <form onSubmit={submit} className="space-y-3 p-5">
      <div className="grid grid-cols-2 gap-2">
        <Field label="First name" value={firstName} onChange={setFirstName} autoFocus />
        <Field label="Last name" value={lastName} onChange={setLastName} />
      </div>
      <Field label="Email" type="email" value={email} onChange={setEmail} />
      <Field
        label="Password"
        type="password"
        value={password}
        onChange={setPassword}
        hint="At least 8 characters"
      />
      <Field label="Phone (optional)" type="tel" value={phone} onChange={setPhone} />
      <Button
        type="submit"
        disabled={!valid || submitting}
        className="w-full bg-gradient-to-r from-teal-500 to-emerald-500 text-white"
      >
        {submitting ? "Creating account…" : "Create account & continue"}
      </Button>
      <p className="text-[11px] text-muted-foreground">
        We'll send a verification email — you can register right away without waiting for it.
      </p>
    </form>
  );
}

function SignInForm({ onComplete }: { onComplete: (p: Parent) => void }) {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [submitting, setSubmitting] = useState(false);

  const valid = /^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(email) && password.length >= 1;

  function submit(e: React.FormEvent) {
    e.preventDefault();
    if (!valid) return;
    setSubmitting(true);
    setTimeout(() => {
      // Restore existing local parent if present, else create a placeholder.
      const existing = loadParent();
      if (existing && existing.email === email.trim().toLowerCase()) {
        onComplete(existing);
      } else {
        onComplete({
          id: `local_${Date.now()}`,
          firstName: "Parent",
          lastName: "",
          email: email.trim().toLowerCase(),
        });
      }
    }, 350);
  }

  return (
    <form onSubmit={submit} className="space-y-3 p-5">
      <Field label="Email" type="email" value={email} onChange={setEmail} autoFocus />
      <Field label="Password" type="password" value={password} onChange={setPassword} />
      <Button
        type="submit"
        disabled={!valid || submitting}
        className="w-full bg-gradient-to-r from-teal-500 to-emerald-500 text-white"
      >
        {submitting ? "Signing in…" : "Sign in & continue"}
      </Button>
      <button type="button" className="block w-full text-center text-xs text-muted-foreground hover:text-foreground">
        Forgot password?
      </button>
    </form>
  );
}

function SelectAthlete({
  athletes,
  selectedId,
  onSelect,
  onAddNew,
  onContinue,
}: {
  athletes: Athlete[];
  selectedId: string | null;
  onSelect: (id: string) => void;
  onAddNew: () => void;
  onContinue: () => void;
}) {
  return (
    <div className="space-y-3 p-5">
      <p className="text-sm text-muted-foreground">Select which athlete to register for this camp.</p>
      <div className="space-y-2">
        {athletes.map((a) => {
          const birthYear = a.dob ? new Date(a.dob).getFullYear() : "—";
          const selected = a.id === selectedId;
          return (
            <button
              key={a.id}
              onClick={() => onSelect(a.id)}
              className={cn(
                "flex w-full items-center justify-between rounded-xl border-2 p-3 text-left transition-colors",
                selected ? "border-emerald-500 bg-emerald-500/5" : "border-border hover:border-muted-foreground/40",
              )}
            >
              <div>
                <div className="font-semibold">
                  {a.firstName} {a.lastName}
                </div>
                <div className="text-xs text-muted-foreground capitalize">
                  Born {birthYear} · {a.position}
                  {a.jersey ? ` · #${a.jersey}` : ""}
                </div>
              </div>
              {selected && (
                <div className="flex h-6 w-6 items-center justify-center rounded-full bg-emerald-500 text-white">
                  <Check className="h-4 w-4" />
                </div>
              )}
            </button>
          );
        })}
      </div>
      <button
        onClick={onAddNew}
        className="flex w-full items-center justify-center gap-1.5 rounded-xl border-2 border-dashed border-border p-3 text-sm font-semibold text-muted-foreground hover:text-foreground"
      >
        <Plus className="h-4 w-4" /> Add a new athlete
      </button>
      <Button
        disabled={!selectedId}
        onClick={onContinue}
        className="w-full bg-gradient-to-r from-teal-500 to-emerald-500 text-white"
      >
        Continue
      </Button>
    </div>
  );
}

function AddAthleteForm({ onSave }: { onSave: (a: Athlete) => void }) {
  const [firstName, setFirstName] = useState("");
  const [lastName, setLastName] = useState("");
  const [dob, setDob] = useState("");
  const [position, setPosition] = useState<Athlete["position"]>("forward");
  const [jersey, setJersey] = useState("");

  const valid = firstName.trim() && lastName.trim() && dob;

  function submit(e: React.FormEvent) {
    e.preventDefault();
    if (!valid) return;
    onSave({
      id: `ath_${Date.now()}`,
      firstName: firstName.trim(),
      lastName: lastName.trim(),
      dob,
      position,
      jersey: jersey.trim() || undefined,
    });
  }

  return (
    <form onSubmit={submit} className="space-y-3 p-5">
      <div className="grid grid-cols-2 gap-2">
        <Field label="First name" value={firstName} onChange={setFirstName} autoFocus />
        <Field label="Last name" value={lastName} onChange={setLastName} />
      </div>
      <Field label="Date of birth" type="date" value={dob} onChange={setDob} />
      <div>
        <label className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">
          Position
        </label>
        <div className="mt-2 grid grid-cols-3 gap-2">
          {(["forward", "defence", "goalie"] as const).map((p) => (
            <button
              key={p}
              type="button"
              onClick={() => setPosition(p)}
              className={cn(
                "rounded-lg border-2 p-2 text-sm font-semibold capitalize",
                position === p ? "border-emerald-500 bg-emerald-500/5" : "border-border",
              )}
            >
              {p}
            </button>
          ))}
        </div>
      </div>
      <Field label="Jersey number (optional)" value={jersey} onChange={setJersey} />
      <Button
        type="submit"
        disabled={!valid}
        className="w-full bg-gradient-to-r from-teal-500 to-emerald-500 text-white"
      >
        Save athlete & continue
      </Button>
    </form>
  );
}

function ReviewStep({
  camp,
  athlete,
  parent,
  price,
  plan,
  onPlanChange,
  onContinue,
}: {
  camp: BookingCamp;
  athlete: Athlete;
  parent: Parent;
  price: number;
  plan: "full" | "installments";
  onPlanChange: (p: "full" | "installments") => void;
  onContinue: () => void;
}) {
  return (
    <div className="space-y-4 p-5">
      <div className="rounded-xl border border-border bg-muted/30 p-4">
        <div className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">Camp</div>
        <div className="mt-1 font-bold">{camp.name}</div>
        <div className="text-xs text-muted-foreground">
          {camp.dateRange} · {camp.times} · {camp.rink.name}
        </div>
      </div>
      <div className="rounded-xl border border-border bg-muted/30 p-4">
        <div className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">Athlete</div>
        <div className="mt-1 font-bold">
          {athlete.firstName} {athlete.lastName}
        </div>
        <div className="text-xs capitalize text-muted-foreground">
          {athlete.position}
          {athlete.jersey ? ` · #${athlete.jersey}` : ""}
        </div>
      </div>
      <div className="rounded-xl border border-border bg-muted/30 p-4">
        <div className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">Parent contact</div>
        <div className="mt-1 text-sm">
          {parent.firstName} {parent.lastName}
        </div>
        <div className="text-xs text-muted-foreground">{parent.email}</div>
      </div>

      {camp.paymentPlan && (
        <div>
          <div className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">
            Payment plan
          </div>
          <div className="mt-2 grid grid-cols-2 gap-2">
            <button
              onClick={() => onPlanChange("full")}
              className={cn(
                "rounded-lg border-2 p-3 text-left text-sm",
                plan === "full" ? "border-emerald-500 bg-emerald-500/5" : "border-border",
              )}
            >
              <div className="font-bold">Pay in full</div>
              <div className="text-xs text-muted-foreground">${price} today</div>
            </button>
            <button
              onClick={() => onPlanChange("installments")}
              className={cn(
                "rounded-lg border-2 p-3 text-left text-sm",
                plan === "installments" ? "border-emerald-500 bg-emerald-500/5" : "border-border",
              )}
            >
              <div className="font-bold">2 installments</div>
              <div className="text-xs text-muted-foreground">
                {camp.paymentPlan.installments.map((i) => `$${i.amount}`).join(" · ")}
              </div>
            </button>
          </div>
        </div>
      )}

      <div className="flex items-center justify-between border-t border-border pt-3">
        <div className="text-sm">
          <div className="text-muted-foreground">
            {plan === "full" ? "Total due today" : "Due today"}
          </div>
          <div className="text-2xl font-black">
            ${plan === "full" ? price : camp.paymentPlan?.installments[0].amount ?? price}
          </div>
        </div>
        <Button
          onClick={onContinue}
          className="bg-gradient-to-r from-teal-500 to-emerald-500 px-6 text-white"
        >
          Continue to payment
        </Button>
      </div>
    </div>
  );
}

function PaymentStep({ total, onPay }: { total: number; onPay: () => void }) {
  const [submitting, setSubmitting] = useState(false);

  function pay() {
    setSubmitting(true);
    setTimeout(() => onPay(), 600);
  }

  return (
    <div className="space-y-4 p-5">
      <div className="rounded-md border border-dashed border-border bg-muted/20 p-3 text-xs text-muted-foreground">
        Payment is in test mode. Stripe checkout will be wired once the coach
        connects their payout account — no card will be charged.
      </div>
      <div>
        <div className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">Card</div>
        <input
          placeholder="4242 4242 4242 4242"
          className="mt-2 w-full rounded-md border border-input bg-background px-3 py-2 text-sm"
        />
        <div className="mt-2 grid grid-cols-2 gap-2">
          <input
            placeholder="MM / YY"
            className="rounded-md border border-input bg-background px-3 py-2 text-sm"
          />
          <input
            placeholder="CVC"
            className="rounded-md border border-input bg-background px-3 py-2 text-sm"
          />
        </div>
      </div>
      <Button
        onClick={pay}
        disabled={submitting}
        className="w-full bg-gradient-to-r from-teal-500 to-emerald-500 text-white"
      >
        {submitting ? "Processing…" : `Pay $${total} (test)`}
      </Button>
      <p className="text-center text-[10px] text-muted-foreground">Secure payment by Stripe</p>
    </div>
  );
}

function ConfirmedStep({
  camp,
  athlete,
  parent,
  onClose,
}: {
  camp: BookingCamp;
  athlete: Athlete;
  parent: Parent;
  onClose: () => void;
}) {
  return (
    <div className="space-y-5 p-6 text-center">
      <div className="mx-auto flex h-16 w-16 items-center justify-center rounded-full bg-emerald-500/15">
        <Check className="h-8 w-8 text-emerald-500" />
      </div>
      <div>
        <h4 className="text-xl font-black">You're registered!</h4>
        <p className="mt-1 text-sm text-muted-foreground">
          A confirmation email is on its way to <span className="font-semibold text-foreground">{parent.email}</span>
          {" "}with camp details, location, and what to bring.
        </p>
      </div>

      <div className="rounded-xl border border-border bg-muted/30 p-4 text-left text-sm">
        <div className="font-bold">{camp.name}</div>
        <div className="text-xs text-muted-foreground">{camp.dateRange} · {camp.times}</div>
        <div className="mt-2 text-xs text-muted-foreground">{camp.rink.name}</div>
        <div className="mt-3 border-t border-border pt-3 text-xs">
          <span className="text-muted-foreground">Registered athlete: </span>
          <span className="font-semibold">
            {athlete.firstName} {athlete.lastName}
          </span>
        </div>
      </div>

      {/* App prompt */}
      <div className="rounded-2xl border border-border bg-gradient-to-br from-teal-500/10 to-emerald-500/10 p-5 text-left">
        <div className="text-xs font-bold uppercase tracking-wider text-emerald-500">Next step</div>
        <h5 className="mt-1 text-base font-bold">Get the PXF Hockey app</h5>
        <p className="mt-1 text-xs text-muted-foreground">
          Manage your athlete, RSVP to sessions, get coach updates, and track attendance — all in one place.
        </p>
        <div className="mt-3 grid grid-cols-2 gap-2">
          <a
            href="https://apps.apple.com/app/pxf-hockey"
            target="_blank"
            rel="noreferrer"
            className="flex items-center justify-center gap-2 rounded-lg bg-foreground px-3 py-2 text-xs font-bold text-background hover:opacity-90"
          >
            <Apple className="h-4 w-4" /> App Store
          </a>
          <a
            href="https://play.google.com/store/apps/details?id=com.pxfhockey"
            target="_blank"
            rel="noreferrer"
            className="flex items-center justify-center gap-2 rounded-lg bg-foreground px-3 py-2 text-xs font-bold text-background hover:opacity-90"
          >
            <Smartphone className="h-4 w-4" /> Google Play
          </a>
        </div>
      </div>

      <Button onClick={onClose} variant="outline" className="w-full">
        Done
      </Button>
    </div>
  );
}

function Field({
  label,
  value,
  onChange,
  type = "text",
  hint,
  autoFocus,
}: {
  label: string;
  value: string;
  onChange: (v: string) => void;
  type?: string;
  hint?: string;
  autoFocus?: boolean;
}) {
  return (
    <label className="block">
      <span className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">
        {label}
      </span>
      <input
        type={type}
        value={value}
        onChange={(e) => onChange(e.target.value)}
        autoFocus={autoFocus}
        className="mt-1 w-full rounded-md border border-input bg-background px-3 py-2 text-sm"
      />
      {hint && <span className="mt-1 block text-[11px] text-muted-foreground">{hint}</span>}
    </label>
  );
}
