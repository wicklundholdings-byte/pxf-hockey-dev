import { useState } from "react";
import { ArrowLeft, Copy, Calendar, DollarSign, Users, Clock, MapPin, User, Receipt, Bell, Pencil, Plus } from "lucide-react";
import { Link } from "@tanstack/react-router";

type Tab = "overview" | "sessions" | "payments";

const TABS: { id: Tab; label: string }[] = [
  { id: "overview", label: "Overview" },
  { id: "sessions", label: "Sessions" },
  { id: "payments", label: "Payments" },
];

type SessionStatus = "COMPLETE" | "TODAY" | "UPCOMING";
type PayStatus = "PAID" | "UNPAID";

type PrivateSession = {
  id: string;
  date: string;
  day: string;
  time: string;
  status: SessionStatus;
  amount: number;
  pay: PayStatus;
};

const SESSIONS: PrivateSession[] = [
  { id: "s4", date: "Jul 8", day: "Tue", time: "4:30 PM", status: "TODAY", amount: 180, pay: "UNPAID" },
  { id: "s3", date: "Jul 3", day: "Thu", time: "4:30 PM", status: "COMPLETE", amount: 180, pay: "PAID" },
  { id: "s2", date: "Jul 1", day: "Tue", time: "4:30 PM", status: "COMPLETE", amount: 180, pay: "PAID" },
  { id: "s1", date: "Jun 26", day: "Thu", time: "4:30 PM", status: "COMPLETE", amount: 180, pay: "PAID" },
];

const sessionStatusBadge: Record<SessionStatus, string> = {
  COMPLETE: "bg-slate-500/15 text-slate-400 ring-slate-500/30",
  TODAY: "bg-teal-500/15 text-teal-400 ring-teal-500/30",
  UPCOMING: "bg-blue-500/15 text-blue-400 ring-blue-500/30",
};

const payBadge: Record<PayStatus, string> = {
  PAID: "bg-emerald-500/15 text-emerald-400 ring-emerald-500/30",
  UNPAID: "bg-red-500/15 text-red-400 ring-red-500/30",
};

export function PrivateDetail({ privateId: _id }: { privateId: string }) {
  const [tab, setTab] = useState<Tab>("overview");
  const publicUrl = "https://pxfhockey.com/book/pxf/private/emma-wilson";

  return (
    <div className="space-y-5">
      <div>
        <Link
          to="/camps"
          className="inline-flex items-center gap-1 text-xs font-medium text-muted-foreground hover:text-foreground"
        >
          <ArrowLeft className="h-3.5 w-3.5" /> Camps & Privates
        </Link>

        <div className="mt-3 flex flex-wrap items-start justify-between gap-3">
          <div className="min-w-0">
            <h1 className="text-2xl font-semibold tracking-tight">Emma Wilson – Private Sessions</h1>
            <div className="mt-2 flex items-center gap-1.5 flex-wrap">
              <span className="rounded px-1.5 py-0.5 text-[10px] font-bold ring-1 ring-inset bg-purple-500/15 text-purple-400 ring-purple-500/30">
                PRIVATE
              </span>
              <span className="rounded px-1.5 py-0.5 text-[10px] font-bold ring-1 ring-inset bg-emerald-500/15 text-emerald-400 ring-emerald-500/30">
                ACTIVE
              </span>
            </div>
          </div>

          <button
            onClick={() => navigator.clipboard?.writeText(publicUrl)}
            className="inline-flex items-center gap-1.5 rounded-md bg-gradient-to-r from-teal-500 to-emerald-500 px-3 py-2 text-xs font-semibold text-white shadow-sm hover:opacity-90"
          >
            <Copy className="h-3.5 w-3.5" /> Copy Public Link
          </button>
        </div>
      </div>

      <div className="flex items-center gap-1 border-b border-border">
        {TABS.map((t) => (
          <button
            key={t.id}
            onClick={() => setTab(t.id)}
            className={`relative px-4 py-2 text-sm font-medium transition ${
              tab === t.id
                ? "text-foreground after:absolute after:bottom-0 after:left-0 after:right-0 after:h-0.5 after:bg-gradient-to-r after:from-teal-500 after:to-emerald-500"
                : "text-muted-foreground hover:text-foreground"
            }`}
          >
            {t.label}
          </button>
        ))}
      </div>

      {tab === "overview" && <OverviewTab />}
      {tab === "sessions" && <SessionsTab />}
      {tab === "payments" && <PaymentsTab />}
    </div>
  );
}

function StatCard({ icon, label, value, accent }: { icon: React.ReactNode; label: string; value: string; accent?: boolean }) {
  return (
    <div className="rounded-lg border border-border bg-card p-3">
      <div className="flex items-center gap-1.5 text-[11px] font-semibold uppercase tracking-wider text-muted-foreground">
        {icon} {label}
      </div>
      <div className={`mt-1.5 text-xl font-semibold tabular-nums ${accent ? "text-teal-400" : "text-foreground"}`}>
        {value}
      </div>
    </div>
  );
}

function DetailRow({ icon, label, value }: { icon: React.ReactNode; label: string; value: React.ReactNode }) {
  return (
    <div className="flex items-center justify-between gap-3 py-2.5 first:pt-0 last:pb-0">
      <div className="flex items-center gap-1.5 text-xs text-muted-foreground">
        {icon} {label}
      </div>
      <div className="text-sm text-foreground text-right">{value}</div>
    </div>
  );
}

function OverviewTab() {
  return (
    <div className="space-y-5">
      <div className="grid grid-cols-2 gap-3 sm:grid-cols-4">
        <StatCard icon={<User className="h-3.5 w-3.5" />} label="Athlete" value="Emma Wilson" />
        <StatCard icon={<DollarSign className="h-3.5 w-3.5" />} label="Rate" value="$180/session" accent />
        <StatCard icon={<Calendar className="h-3.5 w-3.5" />} label="Sessions" value="12 total" />
        <StatCard icon={<Clock className="h-3.5 w-3.5" />} label="Next Session" value="Tue Jul 8" />
      </div>

      <div className="rounded-lg border border-border bg-card p-4">
        <h3 className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">Details</h3>
        <dl className="mt-3 divide-y divide-border">
          <DetailRow icon={<Calendar className="h-3.5 w-3.5" />} label="Schedule" value="Every Tuesday & Thursday" />
          <DetailRow icon={<MapPin className="h-3.5 w-3.5" />} label="Location" value="Studio B" />
          <DetailRow icon={<Clock className="h-3.5 w-3.5" />} label="Started" value="May 1, 2026" />
          <DetailRow icon={<Users className="h-3.5 w-3.5" />} label="Coach" value="Jordan Doe" />
        </dl>
      </div>

      <AthleteNotes />
    </div>
  );
}

function AthleteNotes() {
  const notes = [
    {
      title: "Strengths",
      body: "Strong edges, explosive first step, excellent hockey sense",
    },
    {
      title: "Development Areas",
      body: "Crossovers need work on backhand side, struggles with tight turns at high speed",
    },
    {
      title: "Goals",
      body: "Make AAA Midget by next season, improve backward skating score to 85+",
    },
  ];

  return (
    <div className="rounded-lg border border-border bg-card p-4">
      <div className="flex items-center justify-between">
        <h3 className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">Athlete Notes</h3>
        <span className="text-[10px] text-muted-foreground">Visible to all coaches in this hockey school</span>
      </div>

      <div className="mt-4 space-y-4">
        {notes.map((note) => (
          <div key={note.title} className="space-y-1.5">
            <div className="flex items-center justify-between gap-2">
              <h4 className="text-[11px] font-semibold uppercase tracking-wider text-muted-foreground">{note.title}</h4>
              <button
                className="text-muted-foreground hover:text-foreground"
                aria-label={`Edit ${note.title}`}
              >
                <Pencil className="h-3 w-3" />
              </button>
            </div>
            <p className="text-sm text-foreground leading-relaxed">{note.body}</p>
            <p className="text-[10px] text-muted-foreground">Last updated by Jordan Doe · Jun 28, 2026</p>
          </div>
        ))}
      </div>

      <button className="mt-5 inline-flex items-center gap-1 rounded-md border border-border px-3 py-1.5 text-xs font-medium text-muted-foreground hover:text-foreground hover:border-teal-500/40">
        <Plus className="h-3.5 w-3.5" /> Add Note
      </button>
    </div>
  );
}

function SessionsTab() {
  return (
    <div className="rounded-lg border border-border bg-card overflow-hidden">
      <ul className="divide-y divide-border">
        {SESSIONS.map((s) => {
          const isToday = s.status === "TODAY";
          return (
            <li
              key={s.id}
              className={`flex flex-wrap items-center gap-3 p-4 ${isToday ? "border-l-2 border-l-teal-500 bg-teal-500/[0.04]" : ""}`}
            >
              <div className="min-w-0 flex-1">
                <div className="flex items-center gap-2 flex-wrap">
                  <span className="font-semibold text-foreground">{s.date}</span>
                  <span className="text-xs text-muted-foreground">· {s.day} ·</span>
                  <span className="text-sm text-foreground">{s.time}</span>
                  <span className={`rounded px-1.5 py-0.5 text-[10px] font-bold ring-1 ring-inset ${sessionStatusBadge[s.status]}`}>
                    {s.status}
                  </span>
                </div>
              </div>
              <div className="flex items-center gap-3 shrink-0">
                <span className="text-sm font-semibold text-foreground tabular-nums">${s.amount}</span>
                <span className={`rounded px-1.5 py-0.5 text-[10px] font-bold ring-1 ring-inset ${payBadge[s.pay]}`}>
                  {s.pay === "PAID" ? "Paid" : "Unpaid"}
                </span>
              </div>
            </li>
          );
        })}
      </ul>
    </div>
  );
}

function PaymentsTab() {
  const collected = SESSIONS.filter((s) => s.pay === "PAID").reduce((a, s) => a + s.amount, 0);
  const outstanding = SESSIONS.filter((s) => s.pay === "UNPAID").reduce((a, s) => a + s.amount, 0);
  const unpaidCount = SESSIONS.filter((s) => s.pay === "UNPAID").length;

  return (
    <div className="space-y-4">
      <div className="rounded-lg border border-border bg-card overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead className="bg-muted/40 text-[11px] font-semibold uppercase tracking-wider text-muted-foreground">
              <tr>
                <th className="px-4 py-2.5 text-left">Session</th>
                <th className="px-4 py-2.5 text-left">Date</th>
                <th className="px-4 py-2.5 text-right">Amount</th>
                <th className="px-4 py-2.5 text-right">Paid</th>
                <th className="px-4 py-2.5 text-right">Balance</th>
                <th className="px-4 py-2.5 text-left">Status</th>
                <th className="px-4 py-2.5 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-border">
              {SESSIONS.map((s) => {
                const paid = s.pay === "PAID" ? s.amount : 0;
                const balance = s.amount - paid;
                return (
                  <tr key={s.id} className="hover:bg-muted/20">
                    <td className="px-4 py-3 font-medium text-foreground">Private Session</td>
                    <td className="px-4 py-3 text-muted-foreground">{s.date} · {s.day}</td>
                    <td className="px-4 py-3 text-right tabular-nums">${s.amount}</td>
                    <td className="px-4 py-3 text-right tabular-nums">${paid}</td>
                    <td className="px-4 py-3 text-right tabular-nums">${balance}</td>
                    <td className="px-4 py-3">
                      <span className={`rounded px-1.5 py-0.5 text-[10px] font-bold ring-1 ring-inset ${payBadge[s.pay]}`}>
                        {s.pay}
                      </span>
                    </td>
                    <td className="px-4 py-3">
                      <div className="flex justify-end gap-2">
                        {s.pay === "PAID" ? (
                          <button className="inline-flex items-center gap-1 rounded-md border border-border px-2 py-1 text-[11px] font-medium text-muted-foreground hover:text-foreground hover:border-teal-500/40">
                            <Receipt className="h-3 w-3" /> Receipt
                          </button>
                        ) : (
                          <button className="inline-flex items-center gap-1 rounded-md border border-amber-500/40 bg-amber-500/10 px-2 py-1 text-[11px] font-semibold text-amber-400 hover:bg-amber-500/20">
                            <Bell className="h-3 w-3" /> Remind
                          </button>
                        )}
                      </div>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>

      <div className="rounded-lg border border-border bg-card p-4 flex flex-wrap items-center justify-between gap-3 text-sm">
        <div className="flex flex-wrap items-center gap-x-4 gap-y-1">
          <span><span className="text-muted-foreground">Total Revenue:</span> <span className="font-semibold tabular-nums">${collected + outstanding}</span></span>
          <span><span className="text-muted-foreground">Collected:</span> <span className="font-semibold text-emerald-400 tabular-nums">${collected}</span></span>
          <span><span className="text-muted-foreground">Outstanding:</span> <span className="font-semibold text-red-400 tabular-nums">${outstanding}</span></span>
        </div>
        <span className="text-xs text-muted-foreground">{unpaidCount} unpaid</span>
      </div>
    </div>
  );
}
