import {
  Plus,
  ClipboardList,
  ChevronRight,
  Users,
  CalendarClock,
  Video,
  Snowflake,
  Dumbbell,
  MapPin,
  MessageSquare,
  UserCheck,
  TrendingUp,
} from "lucide-react";
import { cn } from "@/lib/utils";

type EvtType = "PRACTICE" | "GAME" | "ICE";

const upcoming: {
  day: string;
  date: string;
  time: string;
  name: string;
  team: string;
  location: string;
  type: EvtType;
}[] = [
  { day: "TUE", date: "Jun 30", time: "5:30 PM", name: "Practice — Power Skating", team: "U13 AA Wolves", location: "Rink 2 · CCC", type: "PRACTICE" },
  { day: "WED", date: "Jul 1", time: "6:45 PM", name: "vs Riverside Stars", team: "U13 AA Wolves", location: "Rink 1 · CCC", type: "GAME" },
  { day: "THU", date: "Jul 2", time: "4:15 PM", name: "Skills Session", team: "U11 A Cubs", location: "Rink 3 · CCC", type: "PRACTICE" },
  { day: "FRI", date: "Jul 3", time: "5:00 PM", name: "Team Practice", team: "U13 AA Wolves", location: "Rink 2 · CCC", type: "PRACTICE" },
  { day: "SAT", date: "Jul 4", time: "8:00 AM", name: "Ice Block", team: "U13 AA Wolves", location: "Rink 2 · CCC", type: "ICE" },
  { day: "SUN", date: "Jul 5", time: "10:00 AM", name: "vs Northern Aces", team: "U11 A Cubs", location: "Civic Arena", type: "GAME" },
];

const teams = [
  { name: "U13 AA Wolves", division: "U13 · AA", players: 17, next: "Tue 5:30 PM" },
  { name: "U11 A Cubs", division: "U11 · A", players: 15, next: "Thu 4:15 PM" },
  { name: "U9 Mini Pack", division: "U9 · Dev", players: 12, next: "Sat 10:00 AM" },
];

const athletes = [
  { name: "Mason Clark", team: "U13 AA Wolves", pos: "C", active: "Today", initials: "MC" },
  { name: "Ethan Liu", team: "U13 AA Wolves", pos: "LW", active: "Yesterday", initials: "EL" },
  { name: "Noah Patel", team: "U11 A Cubs", pos: "D", active: "2d ago", initials: "NP" },
  { name: "Liam Brooks", team: "U13 AA Wolves", pos: "RW", active: "Today", initials: "LB" },
  { name: "Owen Reyes", team: "U11 A Cubs", pos: "G", active: "3d ago", initials: "OR" },
  { name: "Jack Morin", team: "U9 Mini Pack", pos: "C", active: "Today", initials: "JM" },
  { name: "Caleb Wong", team: "U13 AA Wolves", pos: "D", active: "Today", initials: "CW" },
  { name: "Isaac Park", team: "U11 A Cubs", pos: "C", active: "1d ago", initials: "IP" },
];

const dryland = [
  { name: "Lower-Body Strength", when: "Mon · 4:00 PM", count: 14 },
  { name: "Edge Work + Mobility", when: "Wed · 4:00 PM", count: 12 },
  { name: "Speed & Agility", when: "Fri · 4:30 PM", count: 16 },
];

const media = [
  { label: "Game Highlights", sub: "vs Hawks · 4:21", color: "from-orange-500/60 to-amber-500/60" },
  { label: "Practice Reel", sub: "Power Skate · 2:08", color: "from-teal-500/60 to-emerald-500/60" },
  { label: "Skills Clinic", sub: "Stickhandling · 1:45", color: "from-indigo-500/60 to-blue-500/60" },
  { label: "Team Photo", sub: "Jun 22", color: "from-rose-500/60 to-pink-500/60" },
];

const typeStyle: Record<EvtType, { border: string; chip: string; label: string }> = {
  PRACTICE: { border: "border-l-teal-500", chip: "bg-teal-500/15 text-teal-300 ring-teal-500/30", label: "Practice" },
  GAME: { border: "border-l-orange-500", chip: "bg-orange-500/15 text-orange-300 ring-orange-500/30", label: "Game" },
  ICE: { border: "border-l-blue-500", chip: "bg-blue-500/15 text-blue-300 ring-blue-500/30", label: "Ice Time" },
};

/* ---------- Shared card primitives (match Elite Coach) ---------- */

function KpiCard({
  label,
  value,
  sub,
  icon: Icon,
  iconClass = "from-teal-500 to-emerald-500",
  trend,
}: {
  label: string;
  value: string;
  sub?: React.ReactNode;
  icon: typeof Users;
  iconClass?: string;
  trend?: { dir: "up" | "down"; value: string };
}) {
  return (
    <div className="relative rounded-xl border border-border bg-card p-4 transition hover:border-emerald-500/40">
      <div className="flex items-start justify-between">
        <span className="text-xs font-medium uppercase tracking-wider text-muted-foreground">
          {label}
        </span>
        <div className={cn("flex h-8 w-8 items-center justify-center rounded-md bg-gradient-to-br text-white", iconClass)}>
          <Icon className="h-4 w-4" />
        </div>
      </div>
      <div className="mt-3 text-2xl font-bold tracking-tight">{value}</div>
      {sub && <div className="mt-1 text-xs text-muted-foreground">{sub}</div>}
      {trend && (
        <div className={cn("mt-2 inline-flex items-center gap-1 text-xs font-semibold", trend.dir === "up" ? "text-emerald-400" : "text-red-400")}>
          <TrendingUp className="h-3 w-3" />
          {trend.value}
        </div>
      )}
    </div>
  );
}

function SectionCard({
  title,
  action,
  children,
  className,
}: {
  title: string;
  action?: React.ReactNode;
  children: React.ReactNode;
  className?: string;
}) {
  return (
    <div className={cn("rounded-xl border border-border bg-card", className)}>
      <div className="flex items-center justify-between border-b border-border px-4 py-3">
        <h3 className="text-xs font-bold uppercase tracking-wider text-muted-foreground">{title}</h3>
        {action}
      </div>
      <div className="p-4">{children}</div>
    </div>
  );
}

function ViewAll() {
  return (
    <button className="inline-flex items-center gap-0.5 text-xs font-semibold text-emerald-400 hover:text-emerald-300">
      View All <ChevronRight className="h-3 w-3" />
    </button>
  );
}

export function TeamCoachDashboard() {
  return (
    <div className="space-y-6">
      {/* Action row */}
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <div className="text-[11px] font-medium uppercase tracking-widest text-muted-foreground">Team Coach</div>
          <h1 className="text-xl font-bold tracking-tight">My Coaching Hub</h1>
        </div>
        <div className="flex flex-wrap items-center gap-2">
          <button className="inline-flex items-center gap-2 rounded-lg bg-gradient-to-r from-teal-500 to-emerald-500 px-3.5 py-2 text-sm font-semibold text-white shadow-sm hover:opacity-90 transition">
            <Plus className="h-4 w-4" /> Create Session
          </button>
          <button className="inline-flex items-center gap-2 rounded-lg bg-gradient-to-r from-emerald-500 to-teal-500 px-3.5 py-2 text-sm font-semibold text-white shadow-sm hover:opacity-90 transition">
            <ClipboardList className="h-4 w-4" /> Create Drill
          </button>
          <button className="inline-flex items-center gap-2 rounded-lg border border-border bg-card px-3.5 py-2 text-sm font-semibold hover:bg-accent transition">
            <Snowflake className="h-4 w-4 text-blue-400" /> Add Ice Time
          </button>
        </div>
      </div>

      {/* Row 1 — KPIs */}
      <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-4">
        <KpiCard label="My Teams" value="3" sub="Across U9 · U11 · U13" icon={Users} />
        <KpiCard label="Total Athletes" value="44" sub="Active on rosters" icon={UserCheck} />
        <KpiCard label="Upcoming Sessions" value="6" sub="Next 7 days" icon={CalendarClock} />
        <KpiCard label="Unread Messages" value="4" sub="From parents & staff" icon={MessageSquare} iconClass="from-indigo-500 to-blue-500" />
      </div>

      {/* Row 2 — Two-column */}
      <div className="grid grid-cols-1 gap-4 lg:grid-cols-[1.85fr_1fr]">
        {/* Left column */}
        <div className="space-y-4">
          <SectionCard title="Next Up · Next 7 Days" action={<ViewAll />}>
            <ul className="space-y-2">
              {upcoming.map((e, i) => {
                const t = typeStyle[e.type];
                return (
                  <li
                    key={i}
                    className={cn(
                      "flex items-center gap-3 rounded-lg border-l-4 bg-muted/30 p-3 transition hover:bg-muted/50",
                      t.border
                    )}
                  >
                    <div className="flex w-14 flex-col items-center leading-tight">
                      <div className="text-[10px] font-bold uppercase tracking-wider text-muted-foreground">{e.day}</div>
                      <div className="text-xs font-semibold">{e.date}</div>
                    </div>
                    <div className="min-w-0 flex-1">
                      <div className="flex items-center gap-2">
                        <span className={cn("rounded-full px-1.5 py-0.5 text-[9px] font-bold uppercase ring-1", t.chip)}>
                          {t.label}
                        </span>
                        <span className="text-xs font-semibold text-muted-foreground">{e.time}</span>
                      </div>
                      <div className="mt-0.5 text-sm font-semibold truncate">{e.name}</div>
                      <div className="text-[11px] text-muted-foreground truncate">
                        {e.team} · <MapPin className="inline h-2.5 w-2.5" /> {e.location}
                      </div>
                    </div>
                    <ChevronRight className="h-4 w-4 text-muted-foreground" />
                  </li>
                );
              })}
            </ul>
          </SectionCard>

          <SectionCard title="My Athletes" action={<ViewAll />}>
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead>
                  <tr className="text-left text-[10px] uppercase tracking-wider text-muted-foreground">
                    <th className="px-2 pb-2 font-medium">Athlete</th>
                    <th className="px-2 pb-2 font-medium">Team</th>
                    <th className="px-2 pb-2 font-medium">Pos</th>
                    <th className="px-2 pb-2 font-medium text-right">Last Active</th>
                  </tr>
                </thead>
                <tbody>
                  {athletes.map((a) => (
                    <tr key={a.name} className="cursor-pointer border-t border-border/60 transition hover:bg-emerald-500/5">
                      <td className="px-2 py-2.5">
                        <div className="flex items-center gap-2.5">
                          <div className="flex h-8 w-8 items-center justify-center rounded-full bg-gradient-to-br from-teal-400 to-emerald-500 text-[11px] font-bold text-white">
                            {a.initials}
                          </div>
                          <span className="font-medium">{a.name}</span>
                        </div>
                      </td>
                      <td className="px-2 py-2.5 text-muted-foreground">{a.team}</td>
                      <td className="px-2 py-2.5 text-muted-foreground">{a.pos}</td>
                      <td className="px-2 py-2.5 text-right text-muted-foreground">{a.active}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </SectionCard>
        </div>

        {/* Right column */}
        <div className="space-y-4">
          <SectionCard title="My Teams" action={<ViewAll />}>
            <div className="space-y-3">
              {teams.map((t) => (
                <button
                  key={t.name}
                  className="block w-full rounded-lg border border-border/60 p-3 text-left transition hover:border-emerald-500/40"
                >
                  <div className="flex items-center gap-3">
                    <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-gradient-to-br from-teal-500 to-emerald-500 text-white">
                      <Users className="h-5 w-5" />
                    </div>
                    <div className="min-w-0 flex-1">
                      <div className="truncate text-sm font-semibold">{t.name}</div>
                      <div className="text-[11px] text-muted-foreground">{t.division} · {t.players} players</div>
                    </div>
                  </div>
                  <div className="mt-2 flex items-center justify-between text-[11px]">
                    <span className="text-muted-foreground">Next session</span>
                    <span className="font-semibold text-emerald-400">{t.next}</span>
                  </div>
                </button>
              ))}
            </div>
          </SectionCard>

          <SectionCard
            title="Dryland This Week"
            action={
              <span className="inline-flex items-center gap-1 text-[11px] text-muted-foreground">
                <Dumbbell className="h-3 w-3 text-emerald-400" /> {dryland.length} sessions
              </span>
            }
          >
            <ul className="space-y-2">
              {dryland.map((d) => (
                <li
                  key={d.name}
                  className="flex items-center justify-between rounded-lg bg-muted/30 px-3 py-2.5"
                >
                  <div className="min-w-0">
                    <div className="text-sm font-semibold truncate">{d.name}</div>
                    <div className="text-[11px] text-muted-foreground">{d.when}</div>
                  </div>
                  <div className="text-[11px] font-semibold text-muted-foreground">
                    {d.count} athletes
                  </div>
                </li>
              ))}
            </ul>
            <button className="mt-3 flex w-full items-center justify-center gap-2 rounded-lg border border-dashed border-emerald-500/40 px-3 py-2 text-xs font-semibold text-emerald-400 hover:bg-emerald-500/5 transition">
              <Plus className="h-3.5 w-3.5" /> Add Dryland Session
            </button>
          </SectionCard>

          <SectionCard
            title="Recent Media"
            action={<ViewAll />}
          >
            <div className="grid grid-cols-2 gap-2.5">
              {media.map((m) => (
                <button
                  key={m.label}
                  className="overflow-hidden rounded-lg border border-border/60 text-left transition hover:border-emerald-500/40"
                >
                  <div className={cn("flex h-20 items-center justify-center bg-gradient-to-br", m.color)}>
                    <Video className="h-5 w-5 text-white/90" />
                  </div>
                  <div className="p-2">
                    <div className="truncate text-xs font-semibold">{m.label}</div>
                    <div className="truncate text-[10px] text-muted-foreground">{m.sub}</div>
                  </div>
                </button>
              ))}
            </div>
          </SectionCard>
        </div>
      </div>
    </div>
  );
}
