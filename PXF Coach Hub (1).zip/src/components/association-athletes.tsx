import { useMemo, useState } from "react";
import {
  Plus, Search, X, Download, Mail, CheckCircle2, AlertTriangle,
  ShieldCheck, FileText, Heart, ClipboardList, History as HistoryIcon, StickyNote,
  Upload, BadgeCheck,
} from "lucide-react";

type Clearance = "CLEARED" | "PENDING" | "BLOCKED";

type Athlete = {
  id: string;
  name: string;
  initials: string;
  dob: string;
  age: number;
  position: "C" | "LW" | "RW" | "D" | "G";
  shoots: "L" | "R";
  height: string;
  weight: string;
  team: string;
  ageGroup: string;
  division: string;
  jersey: number;
  regNo: string;
  verified: boolean;
  regStatus: "Registered" | "Pending" | "Overdue";
  healthForm: "On File" | "Missing" | "Expired";
  parent: { name: string; email: string; phone: string };
  emergency: { name: string; phone: string }[];
  allergies: string;
  meds: string;
  conditions: string;
  physician: string;
  insurance: string;
  concussions: { date: string; note: string }[];
  compliance: {
    payment: "Paid" | "Pending" | "Overdue";
    waiver: { signed: boolean; date: string | null };
    birthCert: boolean;
    govReg: boolean;
    photoConsent: boolean;
  };
  history: { season: string; team: string; transfers?: string; discipline?: string; tryout?: string }[];
  scholarship: string;
  notes: { ts: string; admin: string; text: string }[];
};

const ATHLETES: Athlete[] = [
  {
    id: "a1", name: "Ethan Carter", initials: "EC", dob: "2010-03-14", age: 15, position: "C", shoots: "L",
    height: "5'9\"", weight: "150 lb", team: "U15 AAA", ageGroup: "U15", division: "AAA", jersey: 9,
    regNo: "HC-CA-7728140", verified: true, regStatus: "Registered", healthForm: "On File",
    parent: { name: "Sandra Carter", email: "scarter@email.com", phone: "(204) 555-0166" },
    emergency: [{ name: "Mike Carter", phone: "(204) 555-0167" }, { name: "Aunt Jo", phone: "(204) 555-0188" }],
    allergies: "Peanuts", meds: "EpiPen on bench", conditions: "—",
    physician: "Dr. R. Tan · (204) 555-0911", insurance: "Blue Cross #BC-882140",
    concussions: [{ date: "2024-02-11", note: "Cleared — protocol completed in 14 days" }],
    compliance: { payment: "Paid", waiver: { signed: true, date: "2025-08-12" }, birthCert: true, govReg: true, photoConsent: true },
    history: [
      { season: "2024-25", team: "U13 AA", tryout: "Ranked 4/38" },
      { season: "2023-24", team: "U13 A" },
    ],
    scholarship: "—", notes: [{ ts: "2025-09-04 14:22", admin: "A. Morgan", text: "Strong leadership candidate — assistant captain consideration." }],
  },
  {
    id: "a2", name: "Liam Brooks", initials: "LB", dob: "2012-07-02", age: 13, position: "LW", shoots: "R",
    height: "5'4\"", weight: "120 lb", team: "U13 AA", ageGroup: "U13", division: "AA", jersey: 17,
    regNo: "HC-CA-8810224", verified: true, regStatus: "Registered", healthForm: "Missing",
    parent: { name: "Daniel Brooks", email: "dbrooks@email.com", phone: "(204) 555-0231" },
    emergency: [{ name: "Lisa Brooks", phone: "(204) 555-0232" }],
    allergies: "—", meds: "—", conditions: "Mild asthma",
    physician: "Dr. P. Singh · (204) 555-0901", insurance: "Manitoba Health",
    concussions: [],
    compliance: { payment: "Paid", waiver: { signed: true, date: "2025-08-20" }, birthCert: true, govReg: true, photoConsent: true },
    history: [{ season: "2024-25", team: "U11 A" }],
    scholarship: "Partial — $250", notes: [],
  },
  {
    id: "a3", name: "Owen Tremblay", initials: "OT", dob: "2010-11-22", age: 15, position: "D", shoots: "L",
    height: "6'0\"", weight: "165 lb", team: "U15 AAA", ageGroup: "U15", division: "AAA", jersey: 4,
    regNo: "HC-CA-7728155", verified: false, regStatus: "Pending", healthForm: "Expired",
    parent: { name: "Marie Tremblay", email: "mtremblay@email.com", phone: "(204) 555-0301" },
    emergency: [{ name: "Paul Tremblay", phone: "(204) 555-0302" }],
    allergies: "—", meds: "—", conditions: "—",
    physician: "—", insurance: "—",
    concussions: [],
    compliance: { payment: "Pending", waiver: { signed: false, date: null }, birthCert: false, govReg: false, photoConsent: true },
    history: [{ season: "2024-25", team: "U13 AAA", transfers: "From River East HC" }],
    scholarship: "—", notes: [],
  },
  {
    id: "a4", name: "Caleb Wright", initials: "CW", dob: "2010-05-18", age: 15, position: "G", shoots: "L",
    height: "5'10\"", weight: "155 lb", team: "U15 AAA", ageGroup: "U15", division: "AAA", jersey: 31,
    regNo: "HC-CA-7728199", verified: true, regStatus: "Registered", healthForm: "On File",
    parent: { name: "Helen Wright", email: "hwright@email.com", phone: "(204) 555-0410" },
    emergency: [{ name: "Tom Wright", phone: "(204) 555-0411" }],
    allergies: "—", meds: "—", conditions: "—",
    physician: "Dr. L. Adebayo", insurance: "Sun Life #SL-119820",
    concussions: [],
    compliance: { payment: "Paid", waiver: { signed: true, date: "2025-08-04" }, birthCert: true, govReg: true, photoConsent: true },
    history: [{ season: "2024-25", team: "U13 AAA", discipline: "1-game suspension (game misconduct, Mar 2025)" }],
    scholarship: "—", notes: [],
  },
  {
    id: "a5", name: "Mia Rousseau", initials: "MR", dob: "2014-01-05", age: 11, position: "RW", shoots: "R",
    height: "4'10\"", weight: "85 lb", team: "U11 A", ageGroup: "U11", division: "A", jersey: 22,
    regNo: "HC-CA-9931004", verified: true, regStatus: "Overdue", healthForm: "On File",
    parent: { name: "Yves Rousseau", email: "yrousseau@email.com", phone: "(204) 555-0512" },
    emergency: [{ name: "Anne Rousseau", phone: "(204) 555-0513" }],
    allergies: "Tree nuts", meds: "EpiPen", conditions: "—",
    physician: "Dr. M. Lin", insurance: "Blue Cross #BC-552201",
    concussions: [],
    compliance: { payment: "Overdue", waiver: { signed: true, date: "2025-08-22" }, birthCert: true, govReg: true, photoConsent: false },
    history: [{ season: "2024-25", team: "U9 Initiation" }],
    scholarship: "—", notes: [],
  },
];

function clearanceOf(a: Athlete): Clearance {
  const c = a.compliance;
  if (!c.birthCert || !c.govReg || !c.waiver.signed || c.payment === "Overdue") return "BLOCKED";
  if (c.payment !== "Paid" || !c.photoConsent || a.healthForm !== "On File" || !a.verified) return "PENDING";
  return "CLEARED";
}

const ClearancePill = ({ c }: { c: Clearance }) => {
  const m = {
    CLEARED: "bg-emerald-500/15 text-emerald-400 border-emerald-500/30",
    PENDING: "bg-amber-500/15 text-amber-400 border-amber-500/30",
    BLOCKED: "bg-red-500/15 text-red-400 border-red-500/30",
  }[c];
  return <span className={`inline-flex rounded-md border px-2 py-0.5 text-[10px] font-semibold ${m}`}>{c}</span>;
};

const StatusPill = ({ s }: { s: string }) => {
  const ok = ["Paid", "Registered", "On File", "Yes"].includes(s);
  const warn = ["Pending"].includes(s);
  const bad = ["Overdue", "Missing", "Expired", "No"].includes(s);
  const cls = ok ? "bg-emerald-500/15 text-emerald-400" : warn ? "bg-amber-500/15 text-amber-400" : bad ? "bg-red-500/15 text-red-400" : "bg-muted text-muted-foreground";
  return <span className={`rounded px-1.5 py-0.5 text-[10px] font-medium ${cls}`}>{s}</span>;
};

const TEAMS = ["U11 A", "U13 AA", "U15 AAA", "U18 AAA"];

export function AssociationAthletes() {
  const [selected, setSelected] = useState<Athlete | null>(null);
  const [showAdd, setShowAdd] = useState(false);
  const [search, setSearch] = useState("");
  const [filterTeam, setFilterTeam] = useState("all");
  const [filterAge, setFilterAge] = useState("all");
  const [filterPos, setFilterPos] = useState("all");
  const [filterVerify, setFilterVerify] = useState("all");
  const [filterReg, setFilterReg] = useState("all");
  const [sortKey, setSortKey] = useState<"name" | "age" | "team">("name");
  const [picked, setPicked] = useState<Set<string>>(new Set());

  const rows = useMemo(() => {
    let r = ATHLETES.filter((a) => {
      if (search) {
        const q = search.toLowerCase();
        if (![a.name, String(a.jersey), a.regNo].some((v) => v.toLowerCase().includes(q))) return false;
      }
      if (filterTeam !== "all" && a.team !== filterTeam) return false;
      if (filterAge !== "all" && a.ageGroup !== filterAge) return false;
      if (filterPos !== "all" && a.position !== filterPos) return false;
      if (filterVerify === "verified" && !a.verified) return false;
      if (filterVerify === "unverified" && a.verified) return false;
      if (filterReg !== "all" && a.regStatus !== filterReg) return false;
      return true;
    });
    if (sortKey === "name") r = [...r].sort((a, b) => a.name.localeCompare(b.name));
    if (sortKey === "age") r = [...r].sort((a, b) => a.age - b.age);
    if (sortKey === "team") r = [...r].sort((a, b) => a.team.localeCompare(b.team));
    return r;
  }, [search, filterTeam, filterAge, filterPos, filterVerify, filterReg, sortKey]);

  const togglePick = (id: string) =>
    setPicked((p) => { const n = new Set(p); n.has(id) ? n.delete(id) : n.add(id); return n; });

  return (
    <div className="space-y-5">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div className="flex flex-wrap items-center gap-2">
          <div className="relative">
            <Search className="absolute left-2 top-1/2 h-3.5 w-3.5 -translate-y-1/2 text-muted-foreground" />
            <input value={search} onChange={(e) => setSearch(e.target.value)}
              placeholder="Search name, jersey, reg #…"
              className="h-8 w-64 rounded-md border border-border bg-background pl-7 pr-2 text-xs" />
          </div>
          <select value={filterTeam} onChange={(e) => setFilterTeam(e.target.value)} className="h-8 rounded-md border border-border bg-background px-2 text-xs">
            <option value="all">All teams</option>{TEAMS.map((t) => <option key={t}>{t}</option>)}
          </select>
          <select value={filterAge} onChange={(e) => setFilterAge(e.target.value)} className="h-8 rounded-md border border-border bg-background px-2 text-xs">
            <option value="all">All ages</option>{["U9", "U11", "U13", "U15", "U18"].map((a) => <option key={a}>{a}</option>)}
          </select>
          <select value={filterPos} onChange={(e) => setFilterPos(e.target.value)} className="h-8 rounded-md border border-border bg-background px-2 text-xs">
            <option value="all">All positions</option>{["C", "LW", "RW", "D", "G"].map((p) => <option key={p}>{p}</option>)}
          </select>
          <select value={filterVerify} onChange={(e) => setFilterVerify(e.target.value)} className="h-8 rounded-md border border-border bg-background px-2 text-xs">
            <option value="all">Any verification</option>
            <option value="verified">Verified</option>
            <option value="unverified">Unverified</option>
          </select>
          <select value={filterReg} onChange={(e) => setFilterReg(e.target.value)} className="h-8 rounded-md border border-border bg-background px-2 text-xs">
            <option value="all">Any registration</option>
            <option>Registered</option><option>Pending</option><option>Overdue</option>
          </select>
          <select value={sortKey} onChange={(e) => setSortKey(e.target.value as never)} className="h-8 rounded-md border border-border bg-background px-2 text-xs">
            <option value="name">Sort: Name</option><option value="age">Sort: Age</option><option value="team">Sort: Team</option>
          </select>
        </div>
        <div className="flex items-center gap-2">
          <button className="inline-flex h-8 items-center gap-1.5 rounded-md border border-border bg-background px-3 text-xs hover:bg-accent">
            <Download className="h-3.5 w-3.5" /> Export CSV
          </button>
          <button onClick={() => setShowAdd(true)} className="inline-flex h-8 items-center gap-1.5 rounded-md bg-gradient-to-r from-teal-500 to-emerald-500 px-3 text-xs font-medium text-white hover:opacity-90">
            <Plus className="h-3.5 w-3.5" /> Add Athlete
          </button>
        </div>
      </div>

      {picked.size > 0 && (
        <div className="flex flex-wrap items-center justify-between gap-2 rounded-md border border-emerald-500/30 bg-emerald-500/10 px-3 py-2 text-xs">
          <span>{picked.size} selected</span>
          <div className="flex flex-wrap gap-2">
            <button className="rounded border border-border bg-background px-2 py-1 hover:bg-accent">Send health form request</button>
            <button className="rounded border border-border bg-background px-2 py-1 hover:bg-accent">Send payment reminder</button>
            <button className="rounded border border-border bg-background px-2 py-1 hover:bg-accent">Verify against HC/USA Hockey</button>
            <button className="rounded border border-border bg-background px-2 py-1 hover:bg-accent">Export selected</button>
          </div>
        </div>
      )}

      <div className="overflow-hidden rounded-lg border border-border">
        <table className="w-full text-sm">
          <thead className="bg-muted/40 text-xs uppercase text-muted-foreground">
            <tr>
              <th className="w-8 px-2 py-2"></th>
              <th className="px-3 py-2 text-left">Name</th>
              <th className="px-3 py-2 text-left">Age</th>
              <th className="px-3 py-2 text-left">Pos</th>
              <th className="px-3 py-2 text-left">Team</th>
              <th className="px-3 py-2 text-left">Div</th>
              <th className="px-3 py-2 text-left">Reg Status</th>
              <th className="px-3 py-2 text-left">HC / USA #</th>
              <th className="px-3 py-2 text-left">Health</th>
              <th className="px-3 py-2 text-left">#</th>
              <th className="px-3 py-2 text-left">Clearance</th>
            </tr>
          </thead>
          <tbody>
            {rows.map((a) => (
              <tr key={a.id} onClick={() => setSelected(a)} className="cursor-pointer border-t border-border hover:bg-accent/40">
                <td className="px-2 py-2" onClick={(e) => e.stopPropagation()}>
                  <input type="checkbox" checked={picked.has(a.id)} onChange={() => togglePick(a.id)} className="h-3.5 w-3.5 accent-emerald-500" />
                </td>
                <td className="px-3 py-2">
                  <div className="flex items-center gap-2">
                    <div className="flex h-7 w-7 items-center justify-center rounded-full bg-gradient-to-br from-teal-500 to-emerald-500 text-[10px] font-semibold text-white">{a.initials}</div>
                    <span className="font-medium">{a.name}</span>
                  </div>
                </td>
                <td className="px-3 py-2 text-xs">{a.age}</td>
                <td className="px-3 py-2 text-xs">{a.position}</td>
                <td className="px-3 py-2 text-xs">{a.team}</td>
                <td className="px-3 py-2 text-xs">{a.division}</td>
                <td className="px-3 py-2"><StatusPill s={a.regStatus} /></td>
                <td className="px-3 py-2 text-xs">
                  <span className="font-mono">{a.regNo}</span>{" "}
                  {a.verified
                    ? <CheckCircle2 className="ml-1 inline h-3.5 w-3.5 text-emerald-400" />
                    : <AlertTriangle className="ml-1 inline h-3.5 w-3.5 text-amber-400" />}
                </td>
                <td className="px-3 py-2"><StatusPill s={a.healthForm} /></td>
                <td className="px-3 py-2 font-mono text-xs">{a.jersey}</td>
                <td className="px-3 py-2"><ClearancePill c={clearanceOf(a)} /></td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {selected && <AthletePanel athlete={selected} onClose={() => setSelected(null)} />}
      {showAdd && <AddAthleteDrawer onClose={() => setShowAdd(false)} />}
    </div>
  );
}

/* -------------------- Detail panel -------------------- */

type Tab = "profile" | "health" | "compliance" | "history" | "notes";

function AthletePanel({ athlete, onClose }: { athlete: Athlete; onClose: () => void }) {
  const [tab, setTab] = useState<Tab>("profile");
  const tabs: { id: Tab; label: string; icon: React.ComponentType<{ className?: string }> }[] = [
    { id: "profile", label: "Profile", icon: ClipboardList },
    { id: "health", label: "Health & Medical", icon: Heart },
    { id: "compliance", label: "Compliance", icon: ShieldCheck },
    { id: "history", label: "History", icon: HistoryIcon },
    { id: "notes", label: "Notes", icon: StickyNote },
  ];

  return (
    <>
      <div onClick={onClose} className="fixed inset-0 z-40 bg-black/50" />
      <aside className="fixed right-0 top-0 z-50 h-full w-full max-w-2xl overflow-y-auto border-l border-border bg-background shadow-2xl">
        <div className="sticky top-0 z-10 flex items-center justify-between border-b border-border bg-background px-5 py-3">
          <h3 className="text-sm font-semibold">Athlete details</h3>
          <button onClick={onClose} className="rounded p-1 hover:bg-accent"><X className="h-4 w-4" /></button>
        </div>

        <div className="border-b border-border p-5">
          <div className="flex items-start gap-3">
            <div className="flex h-14 w-14 items-center justify-center rounded-full bg-gradient-to-br from-teal-500 to-emerald-500 text-lg font-semibold text-white">{athlete.initials}</div>
            <div className="flex-1">
              <div className="flex flex-wrap items-center gap-2">
                <h2 className="text-lg font-semibold">{athlete.name}</h2>
                <span className="rounded border border-border bg-muted px-1.5 py-0.5 text-[10px] font-semibold">{athlete.division}</span>
                <span className="rounded bg-muted px-1.5 py-0.5 text-[10px] font-mono">#{athlete.jersey}</span>
              </div>
              <div className="mt-1 text-xs text-muted-foreground">
                Age {athlete.age} · {athlete.position} · {athlete.team}
              </div>
              <div className="mt-2"><ClearancePill c={clearanceOf(athlete)} /></div>
            </div>
          </div>
        </div>

        <div className="border-b border-border px-5">
          <div className="flex flex-wrap gap-1">
            {tabs.map(({ id, label, icon: Icon }) => (
              <button key={id} onClick={() => setTab(id)}
                className={`inline-flex items-center gap-1.5 border-b-2 px-3 py-2 text-xs font-medium transition ${
                  tab === id ? "border-emerald-500 text-foreground" : "border-transparent text-muted-foreground hover:text-foreground"
                }`}>
                <Icon className="h-3.5 w-3.5" /> {label}
              </button>
            ))}
          </div>
        </div>

        <div className="p-5">
          {tab === "profile" && <ProfileTab a={athlete} />}
          {tab === "health" && <HealthTab a={athlete} />}
          {tab === "compliance" && <ComplianceTab a={athlete} />}
          {tab === "history" && <HistoryTab a={athlete} />}
          {tab === "notes" && <NotesTab a={athlete} />}
        </div>
      </aside>
    </>
  );
}

function ProfileTab({ a }: { a: Athlete }) {
  return (
    <div className="space-y-4">
      <Card title="Athlete">
        <Grid rows={[
          ["DOB", `${a.dob} (born ${a.dob.slice(0, 4)})`],
          ["Position", a.position],
          ["Shoots", a.shoots],
          ["Height", a.height],
          ["Weight", a.weight],
        ]} />
      </Card>

      <Card title="Hockey Canada / USA Hockey">
        <div className="flex items-center justify-between">
          <div>
            <div className="font-mono text-sm">{a.regNo}</div>
            <div className="mt-1 text-[11px] text-muted-foreground">
              {a.verified ? "Verified against governing body database" : "Unverified — verify manually or via API"}
            </div>
          </div>
          <button className="inline-flex items-center gap-1 rounded border border-border bg-background px-2 py-1 text-xs hover:bg-accent">
            <BadgeCheck className="h-3.5 w-3.5" /> Verify Now
          </button>
        </div>
      </Card>

      <Card title="Parent / Guardian">
        <Grid rows={[["Name", a.parent.name], ["Email", a.parent.email], ["Phone", a.parent.phone]]} />
      </Card>

      <Card title="Emergency Contacts">
        <ul className="space-y-1 text-xs">
          {a.emergency.map((e, i) => (
            <li key={i} className="flex justify-between"><span>{e.name}</span><span className="text-muted-foreground">{e.phone}</span></li>
          ))}
        </ul>
      </Card>

      <div className="text-[11px] text-muted-foreground">Registered this season: 2025-09-01</div>
    </div>
  );
}

function HealthTab({ a }: { a: Athlete }) {
  return (
    <div className="space-y-4">
      <div className="flex items-start gap-2 rounded-md border border-amber-500/30 bg-amber-500/10 p-2 text-[11px] text-amber-400">
        <ShieldCheck className="mt-0.5 h-3.5 w-3.5" />
        <span>Restricted to association admin and coach roles. Never visible to other parents.</span>
      </div>

      <Card title="Medical">
        <Grid rows={[
          ["Allergies", a.allergies],
          ["Medications", a.meds],
          ["Conditions", a.conditions],
          ["Physician", a.physician],
          ["Insurance", a.insurance],
        ]} />
      </Card>

      <Card title="Medical Clearance Document">
        <div className="flex items-center justify-between">
          <StatusPill s={a.healthForm} />
          <div className="flex gap-2">
            <button className="inline-flex items-center gap-1 rounded border border-border bg-background px-2 py-1 text-xs hover:bg-accent"><Upload className="h-3 w-3" /> Upload</button>
            <button className="inline-flex items-center gap-1 rounded border border-border bg-background px-2 py-1 text-xs hover:bg-accent"><Mail className="h-3 w-3" /> Request Form</button>
          </div>
        </div>
      </Card>

      <Card title="Concussion History">
        {a.concussions.length === 0 ? (
          <div className="text-xs text-muted-foreground">No concussion history on file.</div>
        ) : (
          <ul className="space-y-1.5 text-xs">
            {a.concussions.map((c, i) => (
              <li key={i} className="flex justify-between gap-3">
                <span className="text-muted-foreground">{c.date}</span>
                <span className="flex-1">{c.note}</span>
              </li>
            ))}
          </ul>
        )}
      </Card>
    </div>
  );
}

function ComplianceTab({ a }: { a: Athlete }) {
  const c = a.compliance;
  const items: { label: string; ok: boolean; detail: string }[] = [
    { label: "Registration payment", ok: c.payment === "Paid", detail: c.payment },
    { label: "Waiver signed", ok: c.waiver.signed, detail: c.waiver.signed ? `Signed ${c.waiver.date}` : "Not signed" },
    { label: "Birth certificate verified", ok: c.birthCert, detail: c.birthCert ? "On file" : "Missing — upload required" },
    { label: "HC / USA Hockey registration", ok: c.govReg && a.verified, detail: a.verified ? "Verified" : "Unverified" },
    { label: "Photo consent", ok: c.photoConsent, detail: c.photoConsent ? "Granted" : "Not granted" },
  ];
  return (
    <div className="space-y-2">
      <div className="flex items-center justify-between rounded-lg border border-border bg-muted/30 p-3">
        <span className="text-xs font-medium">Overall clearance</span>
        <ClearancePill c={clearanceOf(a)} />
      </div>
      {items.map((it) => (
        <div key={it.label} className={`flex items-center justify-between rounded-lg border p-3 ${it.ok ? "border-emerald-500/30" : "border-amber-500/30"}`}>
          <div className="flex items-center gap-2">
            {it.ok ? <CheckCircle2 className="h-4 w-4 text-emerald-400" /> : <AlertTriangle className="h-4 w-4 text-amber-400" />}
            <div>
              <div className="text-sm font-medium">{it.label}</div>
              <div className="text-[11px] text-muted-foreground">{it.detail}</div>
            </div>
          </div>
          {!it.ok && (
            <button className="rounded border border-border bg-background px-2 py-1 text-[11px] hover:bg-accent">Fix</button>
          )}
        </div>
      ))}
      <div className="text-[11px] text-muted-foreground">BLOCKED athletes are flagged in the coach-side lineup builder.</div>
    </div>
  );
}

function HistoryTab({ a }: { a: Athlete }) {
  return (
    <div className="space-y-4">
      <Card title="Seasons">
        <ul className="divide-y divide-border text-xs">
          {a.history.map((h, i) => (
            <li key={i} className="py-2">
              <div className="flex justify-between">
                <span className="font-medium">{h.season}</span>
                <span className="text-muted-foreground">{h.team}</span>
              </div>
              {h.transfers && <div className="mt-1 text-amber-400">Transfer: {h.transfers}</div>}
              {h.discipline && <div className="mt-1 text-red-400">Discipline: {h.discipline}</div>}
              {h.tryout && <div className="mt-1 text-emerald-400">Tryout: {h.tryout}</div>}
            </li>
          ))}
        </ul>
      </Card>

      <Card title="Scholarship / Financial Assistance">
        <div className="text-xs">{a.scholarship}</div>
      </Card>

      <div className="text-[11px] text-muted-foreground">Tryout scores visible to admin only.</div>
    </div>
  );
}

function NotesTab({ a }: { a: Athlete }) {
  return (
    <div className="space-y-3">
      <div className="flex items-start gap-2 rounded-md border border-border bg-muted/30 p-2 text-[11px] text-muted-foreground">
        <FileText className="mt-0.5 h-3.5 w-3.5" />
        <span>Private to association admin — never visible to coaches, parents, or athletes.</span>
      </div>
      {a.notes.length === 0 ? (
        <div className="rounded-lg border border-dashed border-border p-6 text-center text-xs text-muted-foreground">No notes yet.</div>
      ) : (
        <ul className="space-y-2">
          {a.notes.map((n, i) => (
            <li key={i} className="rounded-lg border border-border p-3 text-xs">
              <div className="mb-1 flex justify-between text-[11px] text-muted-foreground">
                <span>{n.admin}</span><span>{n.ts}</span>
              </div>
              <div>{n.text}</div>
            </li>
          ))}
        </ul>
      )}
      <textarea className="w-full rounded-md border border-border bg-background p-2 text-xs" rows={3} placeholder="Add a private admin note…" />
      <div className="flex justify-end">
        <button className="rounded-md bg-gradient-to-r from-teal-500 to-emerald-500 px-3 py-1.5 text-xs font-medium text-white">Save Note</button>
      </div>
    </div>
  );
}

function Card({ title, children }: { title: string; children: React.ReactNode }) {
  return (
    <div className="rounded-lg border border-border p-3">
      <div className="mb-2 text-[11px] uppercase tracking-wide text-muted-foreground">{title}</div>
      {children}
    </div>
  );
}

function Grid({ rows }: { rows: [string, string][] }) {
  return (
    <dl className="grid grid-cols-2 gap-x-3 gap-y-1 text-xs">
      {rows.map(([k, v]) => (
        <div key={k} className="contents">
          <dt className="text-muted-foreground">{k}</dt>
          <dd>{v}</dd>
        </div>
      ))}
    </dl>
  );
}

/* -------------------- Add Athlete Drawer -------------------- */

function AddAthleteDrawer({ onClose }: { onClose: () => void }) {
  const [parentEmail, setParentEmail] = useState("");
  const linked = parentEmail.endsWith("@pxf.com");

  return (
    <>
      <div onClick={onClose} className="fixed inset-0 z-40 bg-black/50" />
      <aside className="fixed right-0 top-0 z-50 h-full w-full max-w-md overflow-y-auto border-l border-border bg-background shadow-2xl">
        <div className="flex items-center justify-between border-b border-border px-5 py-3">
          <h3 className="text-sm font-semibold">Add Athlete</h3>
          <button onClick={onClose} className="rounded p-1 hover:bg-accent"><X className="h-4 w-4" /></button>
        </div>
        <div className="space-y-3 p-5 text-sm">
          <div className="grid grid-cols-2 gap-2">
            <Field label="First name"><input className="input" placeholder="Jane" /></Field>
            <Field label="Last name"><input className="input" placeholder="Doe" /></Field>
          </div>
          <div className="grid grid-cols-2 gap-2">
            <Field label="Date of birth"><input type="date" className="input" /></Field>
            <Field label="Position">
              <select className="input">{["C", "LW", "RW", "D", "G"].map((p) => <option key={p}>{p}</option>)}</select>
            </Field>
          </div>
          <Field label="Assign to team">
            <select className="input">{TEAMS.map((t) => <option key={t}>{t}</option>)}</select>
          </Field>
          <Field label="Hockey Canada / USA Hockey #">
            <input className="input" placeholder="HC-CA-#######" />
          </Field>
          <Field label="Parent email">
            <input className="input" type="email" value={parentEmail} onChange={(e) => setParentEmail(e.target.value)} placeholder="parent@email.com" />
          </Field>

          {parentEmail && (
            <div className={`rounded-md border p-2 text-[11px] ${linked ? "border-emerald-500/30 bg-emerald-500/10 text-emerald-400" : "border-amber-500/30 bg-amber-500/10 text-amber-400"}`}>
              {linked
                ? "Existing PXF parent account found — athlete will link automatically."
                : "No PXF account found — Resend invite will be sent to this parent."}
            </div>
          )}

          <Field label="Registration fee">
            <input className="input" placeholder="$ 850.00" defaultValue="850.00" />
            <div className="mt-1 text-[11px] text-muted-foreground">Payment request will be triggered to the parent on save.</div>
          </Field>

          <div className="flex justify-end gap-2 pt-2">
            <button onClick={onClose} className="rounded-md border border-border bg-background px-3 py-1.5 text-xs hover:bg-accent">Cancel</button>
            <button className="rounded-md bg-gradient-to-r from-teal-500 to-emerald-500 px-3 py-1.5 text-xs font-medium text-white">Save & Send Invite</button>
          </div>
        </div>
        <style>{`.input{width:100%;height:32px;border-radius:6px;border:1px solid hsl(var(--border));background:hsl(var(--background));padding:0 8px;font-size:12px;}`}</style>
      </aside>
    </>
  );
}

function Field({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <label className="block">
      <span className="mb-1 block text-[11px] font-medium text-muted-foreground">{label}</span>
      {children}
    </label>
  );
}
