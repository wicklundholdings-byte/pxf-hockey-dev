import type { ReactNode } from "react";
import { useEffect } from "react";
import { useRouterState, useNavigate } from "@tanstack/react-router";
import { AppSidebar } from "./app-sidebar";
import { AppTopbar } from "./app-topbar";
import { useAuth } from "./auth-provider";

export function AppShell({ children }: { children: ReactNode }) {
  const pathname = useRouterState({ select: (r) => r.location.pathname });
  const isPublic =
    pathname === "/" ||
    pathname.startsWith("/book") ||
    pathname.startsWith("/preview") ||
    pathname.startsWith("/marketing") ||
    pathname === "/pricing" ||
    pathname === "/onboarding" ||
    pathname === "/features" ||
    pathname === "/about" ||
    pathname === "/blog" ||
    pathname === "/auth" ||
    pathname.startsWith("/auth/") ||
    pathname === "/login" ||
    pathname === "/signup";

  const { session, loading } = useAuth();
  const navigate = useNavigate();

  useEffect(() => {
    if (isPublic) return;
    if (!loading && !session) {
      navigate({ to: "/login", replace: true, search: { redirect: pathname } });
    }
  }, [isPublic, loading, session, navigate, pathname]);

  if (isPublic) {
    return <div className="min-h-screen bg-background text-foreground">{children}</div>;
  }

  if (loading || !session) {
    return (
      <div className="flex min-h-screen items-center justify-center bg-background text-sm text-muted-foreground">
        Loading…
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background text-foreground">
      <AppSidebar />
      <div className="ml-[220px] flex h-screen flex-col">
        <AppTopbar />
        <main className="flex-1 overflow-y-auto p-6">{children}</main>
      </div>
    </div>
  );
}
