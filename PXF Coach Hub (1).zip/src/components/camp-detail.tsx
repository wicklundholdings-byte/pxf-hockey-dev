import { useEffect, useRef, useState } from "react";
import { ArrowLeft, Copy, ExternalLink, MapPin, Calendar, DollarSign, Users, Activity, LayoutTemplate, Pencil, Clock, Search, Mail, Plus, X, UserPlus, Receipt, Bell } from "lucide-react";
import { Link } from "@tanstack/react-router";

type SessionStatus = "COMPLETE" | "TODAY" | "UPCOMING";

type Session = {
  day: number;
  date: string;
  time: string;
  location: string;
  practice: string;
  status: SessionStatus;
  attended?: number;
  capacity?: number;
};

const SESSIONS: Session[] = [
  { day: 1, date: "Tue Jul 1", time: "9:00 AM – 12:00 PM", location: "Rink A", practice: "Edge Work Fundamentals", status: "COMPLETE", attended: 37, capacity: 40 },
  { day: 2, date: "Wed Jul 2", time: "9:00 AM – 12:00 PM", location: "Rink A", practice: "Crossover Circuits", status: "COMPLETE", attended: 36, capacity: 40 },
  { day: 3, date: "Thu Jul 3", time: "9:00 AM – 12:00 PM", location: "Rink A", practice: "Speed & Agility", status: "COMPLETE", attended: 38, capacity: 40 },
  { day: 4, date: "Fri Jul 4", time: "9:00 AM – 12:00 PM", location: "Rink A", practice: "Battle Drills", status: "TODAY" },
  { day: 5, date: "Sat Jul 5", time: "9:00 AM – 12:00 PM", location: "Rink A", practice: "Scrimmage & Evaluation", status: "UPCOMING" },
];

const sessionStatusBadge: Record<SessionStatus, string> = {
  COMPLETE: "bg-slate-500/15 text-slate-400 ring-slate-500/30",
  TODAY: "bg-teal-500/15 text-teal-400 ring-teal-500/30",
  UPCOMING: "bg-blue-500/15 text-blue-400 ring-blue-500/30",
};

type RegistrationStatus = "CONFIRMED" | "WAITLIST";

type Registration = {
  id: string;
  athlete: string;
  parent: string;
  enrolledDate: string;
  status: RegistrationStatus;
  attended?: number;
  total?: number;
};

const REGISTRATIONS: Registration[] = [
  { id: "1", athlete: "Emma Wilson", parent: "Sarah Wilson", enrolledDate: "Jun 12", status: "CONFIRMED", attended: 3, total: 3 },
  { id: "2", athlete: "Jake Thompson", parent: "Mike Thompson", enrolledDate: "Jun 13", status: "CONFIRMED", attended: 2, total: 3 },
  { id: "3", athlete: "Olivia Chen", parent: "Amy Chen", enrolledDate: "Jun 14", status: "CONFIRMED", attended: 3, total: 3 },
  { id: "4", athlete: "Noah Williams", parent: "David Williams", enrolledDate: "Jun 15", status: "CONFIRMED", attended: 3, total: 3 },
  { id: "5", athlete: "Liam Brown", parent: "Karen Brown", enrolledDate: "Jun 20", status: "WAITLIST" },
];

const registrationStatusBadge: Record<RegistrationStatus, string> = {
  CONFIRMED: "bg-emerald-500/15 text-emerald-400 ring-emerald-500/30",
  WAITLIST: "bg-amber-500/15 text-amber-400 ring-amber-500/30",
};

type Tab = "overview" | "schedule" | "registrations" | "payments" | "financials";

const TABS: { id: Tab; label: string }[] = [
  { id: "overview", label: "Overview" },
  { id: "schedule", label: "Schedule" },
  { id: "registrations", label: "Registrations" },
  { id: "payments", label: "Payments" },
  { id: "financials", label: "Financials" },
];

export function CampDetail({ campId: _campId }: { campId: string }) {
  const [tab, setTab] = useState<Tab>("overview");

  const publicUrl = "https://pxfhockey.com/book/pxf/camp/elite-skating";

  return (
    <div className="space-y-5">
      {/* Header */}
      <div>
        <Link
          to="/camps"
          className="inline-flex items-center gap-1 text-xs font-medium text-muted-foreground hover:text-foreground"
        >
          <ArrowLeft className="h-3.5 w-3.5" /> Camps & Privates
        </Link>

        <div className="mt-3 flex flex-wrap items-start justify-between gap-3">
          <div className="min-w-0">
            <h1 className="text-2xl font-semibold tracking-tight">Elite Skating Camp</h1>
            <div className="mt-2 flex items-center gap-1.5 flex-wrap">
              <span className="rounded px-1.5 py-0.5 text-[10px] font-bold ring-1 ring-inset bg-emerald-500/15 text-emerald-400 ring-emerald-500/30">
                ACTIVE
              </span>
              <span className="rounded px-1.5 py-0.5 text-[10px] font-bold ring-1 ring-inset bg-teal-500/15 text-teal-400 ring-teal-500/30">
                CAMP
              </span>
            </div>
          </div>

          <button
            onClick={() => navigator.clipboard?.writeText(publicUrl)}
            className="inline-flex items-center gap-1.5 rounded-md bg-gradient-to-r from-teal-500 to-emerald-500 px-3 py-2 text-xs font-semibold text-white shadow-sm hover:opacity-90"
          >
            <Copy className="h-3.5 w-3.5" /> Copy Public Link
          </button>
        </div>
      </div>

      {/* Tabs */}
      <div className="flex items-center gap-1 border-b border-border">
        {TABS.map((t) => (
          <button
            key={t.id}
            onClick={() => setTab(t.id)}
            className={`relative px-4 py-2 text-sm font-medium transition ${
              tab === t.id
                ? "text-foreground after:absolute after:bottom-0 after:left-0 after:right-0 after:h-0.5 after:bg-gradient-to-r after:from-teal-500 after:to-emerald-500"
                : "text-muted-foreground hover:text-foreground"
            }`}
          >
            {t.label}
          </button>
        ))}
      </div>

      {tab === "overview" && <OverviewTab publicUrl={publicUrl} />}
      {tab === "schedule" && <ScheduleTab />}
      {tab === "registrations" && <RegistrationsTab />}
      {tab === "payments" && <PaymentsTab />}
      {tab === "financials" && <FinancialsTab />}
    </div>
  );
}

function OverviewTab({ publicUrl }: { publicUrl: string }) {
  return (
    <div className="space-y-5">
      {/* Stat cards */}
      <div className="grid grid-cols-2 gap-3 sm:grid-cols-4">
        <StatCard icon={<Users className="h-3.5 w-3.5" />} label="Enrolled" value="38/40" />
        <StatCard icon={<DollarSign className="h-3.5 w-3.5" />} label="Revenue" value="$5,700" accent />
        <StatCard icon={<Calendar className="h-3.5 w-3.5" />} label="Sessions" value="5 days" />
        <StatCard icon={<Activity className="h-3.5 w-3.5" />} label="Avg Attendance" value="92%" />
      </div>

      {/* Camp details */}
      <div className="rounded-lg border border-border bg-card p-4">
        <h3 className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">
          Camp Details
        </h3>
        <dl className="mt-3 divide-y divide-border">
          <DetailRow icon={<Calendar className="h-3.5 w-3.5" />} label="Dates" value="Jul 1–5, 2026" />
          <DetailRow icon={<MapPin className="h-3.5 w-3.5" />} label="Location" value="Rink A" />
          <DetailRow icon={<DollarSign className="h-3.5 w-3.5" />} label="Price" value="$150 / athlete" />
          <DetailRow
            icon={<LayoutTemplate className="h-3.5 w-3.5" />}
            label="Series Template"
            value={
              <Link
                to="/playbook"
                className="text-teal-400 hover:text-teal-300 font-medium"
              >
                Skating Level 2
              </Link>
            }
          />
        </dl>

        <div className="mt-4 border-t border-border pt-3">
          <div className="text-[11px] font-semibold uppercase tracking-wider text-muted-foreground">
            Description
          </div>
          <p className="mt-1.5 text-sm text-foreground/90 leading-relaxed">
            Intensive 5-day skating development camp focusing on edge work, crossovers, and speed.
          </p>
        </div>
      </div>

      {/* Staff */}
      <StaffCard />

      {/* Public registration link box */}
      <div className="rounded-lg border border-border bg-card p-4">
        <h3 className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">
          Public Registration Link
        </h3>
        <div className="mt-3 flex flex-col gap-3 sm:flex-row sm:items-center">
          <div className="flex-1 min-w-0 rounded-md border border-border bg-background px-3 py-2 text-xs font-mono text-muted-foreground truncate">
            {publicUrl}
          </div>
          <div className="flex items-center gap-2 shrink-0">
            <button
              onClick={() => navigator.clipboard?.writeText(publicUrl)}
              className="inline-flex items-center gap-1.5 rounded-md border border-teal-500/40 bg-teal-500/10 px-3 py-2 text-xs font-semibold text-teal-400 hover:bg-teal-500/20"
            >
              <Copy className="h-3.5 w-3.5" /> Copy Link
            </button>
            <a
              href={publicUrl}
              target="_blank"
              rel="noreferrer"
              className="inline-flex items-center gap-1.5 rounded-md border border-border bg-background px-3 py-2 text-xs font-semibold text-foreground hover:border-teal-500/40 hover:text-teal-400"
            >
              <ExternalLink className="h-3.5 w-3.5" /> Preview Booking Page
            </a>
          </div>
        </div>
      </div>
    </div>
  );
}

function StatCard({
  icon,
  label,
  value,
  accent,
}: {
  icon: React.ReactNode;
  label: string;
  value: string;
  accent?: boolean;
}) {
  return (
    <div className="rounded-lg border border-border bg-card p-3">
      <div className="flex items-center gap-1.5 text-[11px] font-semibold uppercase tracking-wider text-muted-foreground">
        {icon} {label}
      </div>
      <div
        className={`mt-1.5 text-xl font-semibold tabular-nums ${
          accent ? "text-teal-400" : "text-foreground"
        }`}
      >
        {value}
      </div>
    </div>
  );
}

function DetailRow({
  icon,
  label,
  value,
}: {
  icon: React.ReactNode;
  label: string;
  value: React.ReactNode;
}) {
  return (
    <div className="flex items-center justify-between gap-3 py-2.5 first:pt-0 last:pb-0">
      <div className="flex items-center gap-1.5 text-xs text-muted-foreground">
        {icon} {label}
      </div>
      <div className="text-sm text-foreground text-right">{value}</div>
    </div>
  );
}

function EmptyTab({ label }: { label: string }) {
  return (
    <div className="rounded-lg border border-dashed border-border bg-card p-10 text-center">
      <h3 className="font-semibold">{label}</h3>
      <p className="mt-2 text-sm text-muted-foreground">Coming soon.</p>
    </div>
  );
}

function ScheduleTab() {
  return (
    <div className="space-y-2.5">
      {SESSIONS.map((s) => {
        const pct = s.attended && s.capacity ? Math.round((s.attended / s.capacity) * 100) : null;
        const isToday = s.status === "TODAY";
        return (
          <div
            key={s.day}
            className={`rounded-lg border bg-card p-4 border-l-4 ${
              isToday ? "border-border border-l-teal-500" : "border-border border-l-border"
            }`}
          >
            <div className="flex items-start justify-between gap-3">
              <div className="min-w-0 flex-1">
                <div className="flex items-center gap-2 flex-wrap">
                  <span className="text-xs font-bold uppercase tracking-wider text-muted-foreground">
                    Day {s.day}
                  </span>
                  <span className="text-sm font-semibold text-foreground">{s.date}</span>
                  <span className={`rounded px-1.5 py-0.5 text-[10px] font-bold ring-1 ring-inset ${sessionStatusBadge[s.status]}`}>
                    {s.status}
                  </span>
                </div>
                <div className="mt-1 flex flex-wrap items-center gap-x-3 gap-y-0.5 text-[11px] text-muted-foreground">
                  <span className="inline-flex items-center gap-1">
                    <Clock className="h-3 w-3" /> {s.time}
                  </span>
                  <span className="inline-flex items-center gap-1">
                    <MapPin className="h-3 w-3" /> {s.location}
                  </span>
                </div>
                <div className="mt-2 text-sm">
                  <span className="text-muted-foreground">Practice: </span>
                  <a href="#" className="font-medium text-teal-400 hover:text-teal-300">
                    {s.practice}
                  </a>
                </div>
                <div className="mt-1 text-[11px] text-muted-foreground">
                  <span className="font-semibold uppercase tracking-wider">Attendance:</span>{" "}
                  {pct !== null ? (
                    <span className="tabular-nums text-foreground/90">
                      {s.attended}/{s.capacity} ({pct}%)
                    </span>
                  ) : (
                    <span>—</span>
                  )}
                </div>
              </div>

              <button className="inline-flex items-center gap-1 rounded-md border border-border bg-background px-2.5 py-1.5 text-xs font-semibold text-foreground hover:border-teal-500/40 hover:text-teal-400 shrink-0">
                <Pencil className="h-3 w-3" /> Edit
              </button>
            </div>
          </div>
        );
      })}
    </div>
  );
}

const REGISTRATION_FILTERS = ["All", "Confirmed", "Waitlist"] as const;
type RegistrationFilter = (typeof REGISTRATION_FILTERS)[number];

const filterToStatus: Record<RegistrationFilter, RegistrationStatus | "ALL"> = {
  All: "ALL",
  Confirmed: "CONFIRMED",
  Waitlist: "WAITLIST",
};

function RegistrationsTab() {
  const [query, setQuery] = useState("");
  const [filter, setFilter] = useState<RegistrationFilter>("All");

  const filtered = REGISTRATIONS.filter((r) => {
    const status = filterToStatus[filter];
    const matchesFilter = status === "ALL" || r.status === status;
    const matchesSearch =
      r.athlete.toLowerCase().includes(query.toLowerCase()) ||
      r.parent.toLowerCase().includes(query.toLowerCase());
    return matchesFilter && matchesSearch;
  });


  return (
    <div className="space-y-4">
      {/* Toolbar */}
      <div className="flex flex-col gap-3 lg:flex-row lg:items-center lg:justify-between">
        <div className="flex flex-col gap-3 sm:flex-row sm:items-center">
          <div className="relative max-w-xs">
            <Search className="absolute left-3 top-1/2 h-3.5 w-3.5 -translate-y-1/2 text-muted-foreground" />
            <input
              type="text"
              placeholder="Search athletes..."
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              className="w-full rounded-md border border-border bg-background pl-9 pr-3 py-2 text-sm text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-teal-500/30"
            />
          </div>
          <div className="flex items-center gap-1.5">
            {REGISTRATION_FILTERS.map((f) => (
              <button
                key={f}
                onClick={() => setFilter(f)}
                className={`rounded-full px-3 py-1 text-xs font-semibold ring-1 ring-inset transition ${
                  filter === f
                    ? "bg-gradient-to-r from-teal-500 to-emerald-500 text-white ring-transparent"
                    : "bg-card text-muted-foreground ring-border hover:text-foreground"
                }`}
              >
                {f}
              </button>
            ))}
          </div>
        </div>
        <button className="inline-flex items-center gap-1.5 rounded-md border border-border bg-background px-3 py-2 text-xs font-semibold text-foreground hover:border-teal-500/40 hover:text-teal-400 shrink-0">
          <ExternalLink className="h-3.5 w-3.5" /> Export
        </button>
      </div>

      {/* Table */}
      <div className="rounded-lg border border-border bg-card overflow-hidden">
        <table className="w-full text-sm">
          <thead className="bg-background/50 border-b border-border">
            <tr>
              <th className="px-4 py-3 text-left text-xs font-semibold uppercase tracking-wider text-muted-foreground">Athlete</th>
              <th className="px-4 py-3 text-left text-xs font-semibold uppercase tracking-wider text-muted-foreground">Parent</th>
              <th className="px-4 py-3 text-left text-xs font-semibold uppercase tracking-wider text-muted-foreground">Enrolled Date</th>
              <th className="px-4 py-3 text-left text-xs font-semibold uppercase tracking-wider text-muted-foreground">Status</th>
              <th className="px-4 py-3 text-left text-xs font-semibold uppercase tracking-wider text-muted-foreground">Attendance</th>
              <th className="px-4 py-3 text-right text-xs font-semibold uppercase tracking-wider text-muted-foreground">Actions</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-border">
            {filtered.map((r) => {
              const pct = r.attended && r.total ? Math.round((r.attended / r.total) * 100) : null;
              return (
                <tr key={r.id} className="hover:bg-teal-500/[0.03]">
                  <td className="px-4 py-3 font-medium text-foreground">{r.athlete}</td>
                  <td className="px-4 py-3 text-muted-foreground">{r.parent}</td>
                  <td className="px-4 py-3 text-muted-foreground">{r.enrolledDate}</td>
                  <td className="px-4 py-3">
                    <span className={`rounded px-1.5 py-0.5 text-[10px] font-bold ring-1 ring-inset ${registrationStatusBadge[r.status]}`}>
                      {r.status}
                    </span>
                  </td>
                  <td className="px-4 py-3 tabular-nums text-foreground/90">
                    {pct !== null ? `${r.attended}/${r.total} (${pct}%)` : "—"}
                  </td>
                  <td className="px-4 py-3 text-right">
                    <button className="inline-flex items-center gap-1 rounded-md border border-border bg-background px-2.5 py-1.5 text-xs font-semibold text-foreground hover:border-teal-500/40 hover:text-teal-400">
                      <Mail className="h-3 w-3" /> Message
                    </button>
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>

      {/* Summary bar */}
      <div className="flex flex-wrap items-center gap-3 rounded-lg border border-border bg-card px-4 py-3 text-sm">
        <span className="font-semibold text-foreground">38 Confirmed</span>
        <span className="text-muted-foreground">·</span>
        <span className="font-semibold text-foreground">2 Waitlist</span>
        <span className="text-muted-foreground">·</span>
        <span className="text-muted-foreground">2 spots remaining</span>
      </div>
    </div>
  );
}

// ------------------------ Payments ------------------------

type PaymentStatus = "PAID" | "PARTIAL" | "UNPAID";

type Payment = {
  id: string;
  athlete: string;
  parent: string;
  amount: number;
  paid: number;
  balance: number;
  status: PaymentStatus;
};

const PAYMENTS: Payment[] = [
  { id: "p1", athlete: "Emma Wilson", parent: "Sarah Wilson", amount: 150, paid: 150, balance: 0, status: "PAID" },
  { id: "p2", athlete: "Jake Thompson", parent: "Mike Thompson", amount: 150, paid: 75, balance: 75, status: "PARTIAL" },
  { id: "p3", athlete: "Olivia Chen", parent: "Amy Chen", amount: 150, paid: 150, balance: 0, status: "PAID" },
  { id: "p4", athlete: "Noah Williams", parent: "David Williams", amount: 150, paid: 0, balance: 150, status: "UNPAID" },
  { id: "p5", athlete: "Liam Brown", parent: "Karen Brown", amount: 150, paid: 150, balance: 0, status: "PAID" },
];

const paymentStatusBadge: Record<PaymentStatus, string> = {
  PAID: "bg-emerald-500/15 text-emerald-400 ring-emerald-500/30",
  PARTIAL: "bg-amber-500/15 text-amber-400 ring-amber-500/30",
  UNPAID: "bg-red-500/15 text-red-400 ring-red-500/30",
};

const PAYMENT_FILTERS = ["All", "Paid", "Partial", "Unpaid"] as const;
type PaymentFilter = (typeof PAYMENT_FILTERS)[number];

const filterToPaymentStatus: Record<PaymentFilter, PaymentStatus | "ALL"> = {
  All: "ALL",
  Paid: "PAID",
  Partial: "PARTIAL",
  Unpaid: "UNPAID",
};

const moneyStr = (n: number) => `$${n.toLocaleString("en-US")}`;

function PaymentsTab() {
  const [filter, setFilter] = useState<PaymentFilter>("All");

  const filtered = PAYMENTS.filter((p) => {
    const status = filterToPaymentStatus[filter];
    return status === "ALL" || p.status === status;
  });

  const totalRevenue = 5700;
  const collected = 5025;
  const outstanding = 675;
  const unpaidCount = 3;

  return (
    <div className="space-y-4">
      {/* Toolbar */}
      <div className="flex flex-col gap-3 lg:flex-row lg:items-center lg:justify-between">
        <div className="flex items-center gap-1.5">
          {PAYMENT_FILTERS.map((f) => (
            <button
              key={f}
              onClick={() => setFilter(f)}
              className={`rounded-full px-3 py-1 text-xs font-semibold ring-1 ring-inset transition ${
                filter === f
                  ? "bg-gradient-to-r from-teal-500 to-emerald-500 text-white ring-transparent"
                  : "bg-card text-muted-foreground ring-border hover:text-foreground"
              }`}
            >
              {f}
            </button>
          ))}
        </div>
        <button className="inline-flex items-center gap-1.5 rounded-md border border-teal-500/40 bg-teal-500/10 px-3 py-2 text-xs font-semibold text-teal-400 hover:bg-teal-500/20 shrink-0">
          <Bell className="h-3.5 w-3.5" /> Send All Reminders
        </button>
      </div>

      {/* Table */}
      <div className="rounded-lg border border-border bg-card overflow-hidden">
        <table className="w-full text-sm">
          <thead className="bg-background/50 border-b border-border">
            <tr>
              <th className="px-4 py-3 text-left text-xs font-semibold uppercase tracking-wider text-muted-foreground">Athlete</th>
              <th className="px-4 py-3 text-left text-xs font-semibold uppercase tracking-wider text-muted-foreground">Parent</th>
              <th className="px-4 py-3 text-right text-xs font-semibold uppercase tracking-wider text-muted-foreground">Amount</th>
              <th className="px-4 py-3 text-right text-xs font-semibold uppercase tracking-wider text-muted-foreground">Paid</th>
              <th className="px-4 py-3 text-right text-xs font-semibold uppercase tracking-wider text-muted-foreground">Balance</th>
              <th className="px-4 py-3 text-left text-xs font-semibold uppercase tracking-wider text-muted-foreground">Status</th>
              <th className="px-4 py-3 text-right text-xs font-semibold uppercase tracking-wider text-muted-foreground">Actions</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-border">
            {filtered.map((p) => (
              <tr key={p.id} className="hover:bg-teal-500/[0.03]">
                <td className="px-4 py-3 font-medium text-foreground">{p.athlete}</td>
                <td className="px-4 py-3 text-muted-foreground">{p.parent}</td>
                <td className="px-4 py-3 text-right tabular-nums text-foreground/90">{moneyStr(p.amount)}</td>
                <td className="px-4 py-3 text-right tabular-nums text-foreground/90">{moneyStr(p.paid)}</td>
                <td className="px-4 py-3 text-right tabular-nums text-foreground/90">{moneyStr(p.balance)}</td>
                <td className="px-4 py-3">
                  <span className={`rounded px-1.5 py-0.5 text-[10px] font-bold ring-1 ring-inset ${paymentStatusBadge[p.status]}`}>
                    {p.status}
                  </span>
                </td>
                <td className="px-4 py-3 text-right">
                  <div className="flex items-center justify-end gap-2">
                    {(p.status === "PAID" || p.status === "PARTIAL") && (
                      <button className="inline-flex items-center gap-1 rounded-md border border-border bg-background px-2.5 py-1.5 text-xs font-semibold text-foreground hover:border-teal-500/40 hover:text-teal-400">
                        <Receipt className="h-3 w-3" /> Receipt
                      </button>
                    )}
                    {(p.status === "PARTIAL" || p.status === "UNPAID") && (
                      <button className="inline-flex items-center gap-1 rounded-md border border-border bg-background px-2.5 py-1.5 text-xs font-semibold text-foreground hover:border-teal-500/40 hover:text-teal-400">
                        <Bell className="h-3 w-3" /> Remind
                      </button>
                    )}
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {/* Summary bar */}
      <div className="flex flex-wrap items-center gap-3 rounded-lg border border-border bg-card px-4 py-3 text-sm">
        <span className="text-muted-foreground">Total Revenue:</span>
        <span className="font-semibold text-foreground">{moneyStr(totalRevenue)}</span>
        <span className="text-muted-foreground">·</span>
        <span className="text-muted-foreground">Collected:</span>
        <span className="font-semibold text-emerald-400">{moneyStr(collected)}</span>
        <span className="text-muted-foreground">·</span>
        <span className="text-muted-foreground">Outstanding:</span>
        <span className="font-semibold text-red-400">{moneyStr(outstanding)}</span>
        <span className="text-muted-foreground">·</span>
        <span className="font-semibold text-foreground">{unpaidCount} unpaid</span>
      </div>
    </div>
  );
}

// ------------------------ Staff ------------------------

type StaffMember = { id: string; name: string; role: string };

const INITIAL_STAFF: StaffMember[] = [
  { id: "s1", name: "Jordan Doe", role: "Head Coach" },
  { id: "s2", name: "Mark Ellis", role: "Assistant Coach" },
];

const ROSTER: StaffMember[] = [
  { id: "r1", name: "Alex Rivera", role: "Head Coach" },
  { id: "r2", name: "Sam Patel", role: "Assistant Coach" },
  { id: "r3", name: "Taylor Kim", role: "Skating Instructor" },
  { id: "r4", name: "Jamie Chen", role: "Goalie Coach" },
  { id: "r5", name: "Morgan Lee", role: "Strength Coach" },
];

function StaffCard() {
  const [staff, setStaff] = useState<StaffMember[]>(INITIAL_STAFF);
  const [open, setOpen] = useState(false);
  const [query, setQuery] = useState("");
  const ref = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (!open) return;
    const handler = (e: MouseEvent) => {
      if (ref.current && !ref.current.contains(e.target as Node)) setOpen(false);
    };
    document.addEventListener("mousedown", handler);
    return () => document.removeEventListener("mousedown", handler);
  }, [open]);

  const available = ROSTER.filter(
    (r) =>
      !staff.some((s) => s.id === r.id) &&
      (r.name.toLowerCase().includes(query.toLowerCase()) ||
        r.role.toLowerCase().includes(query.toLowerCase())),
  );

  return (
    <div className="rounded-lg border border-border bg-card p-4">
      <div className="flex items-center justify-between gap-3">
        <h3 className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">
          Staff
        </h3>
        <div className="relative" ref={ref}>
          <button
            onClick={() => setOpen((v) => !v)}
            className="inline-flex items-center gap-1.5 rounded-md border border-teal-500/40 bg-teal-500/10 px-2.5 py-1.5 text-xs font-semibold text-teal-400 hover:bg-teal-500/20"
          >
            <UserPlus className="h-3.5 w-3.5" /> Assign Coach / Instructor
          </button>
          {open && (
            <div className="absolute right-0 top-full z-20 mt-1.5 w-72 rounded-md border border-border bg-popover shadow-lg">
              <div className="relative border-b border-border p-2">
                <Search className="absolute left-4 top-1/2 h-3.5 w-3.5 -translate-y-1/2 text-muted-foreground" />
                <input
                  autoFocus
                  type="text"
                  placeholder="Search roster..."
                  value={query}
                  onChange={(e) => setQuery(e.target.value)}
                  className="w-full rounded-md border border-border bg-background pl-8 pr-2 py-1.5 text-xs text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-teal-500/30"
                />
              </div>
              <div className="max-h-56 overflow-y-auto py-1">
                {available.length === 0 && (
                  <div className="px-3 py-2 text-xs text-muted-foreground">No matches.</div>
                )}
                {available.map((r) => (
                  <button
                    key={r.id}
                    onClick={() => {
                      setStaff((prev) => [...prev, r]);
                      setQuery("");
                      setOpen(false);
                    }}
                    className="flex w-full items-center justify-between gap-3 px-3 py-2 text-left text-xs hover:bg-teal-500/10"
                  >
                    <span className="font-medium text-foreground">{r.name}</span>
                    <span className="text-muted-foreground">{r.role}</span>
                  </button>
                ))}
              </div>
            </div>
          )}
        </div>
      </div>
      <ul className="mt-3 divide-y divide-border">
        {staff.length === 0 && (
          <li className="py-3 text-sm text-muted-foreground">No staff assigned yet.</li>
        )}
        {staff.map((s) => (
          <li key={s.id} className="flex items-center justify-between gap-3 py-2.5 first:pt-0 last:pb-0">
            <div className="min-w-0">
              <div className="text-sm font-medium text-foreground">{s.name}</div>
              <div className="text-[11px] text-muted-foreground">{s.role}</div>
            </div>
            <button
              onClick={() => setStaff((prev) => prev.filter((x) => x.id !== s.id))}
              aria-label={`Remove ${s.name}`}
              className="inline-flex h-6 w-6 items-center justify-center rounded-md border border-border bg-background text-muted-foreground hover:border-red-500/40 hover:text-red-400"
            >
              <X className="h-3 w-3" />
            </button>
          </li>
        ))}
      </ul>
    </div>
  );
}

// ------------------------ Financials ------------------------

function FinancialsTab() {
  return (
    <div className="space-y-5">
      <div className="grid grid-cols-3 gap-3">
        <StatCard icon={<DollarSign className="h-3.5 w-3.5" />} label="Revenue" value="$5,700" accent />
        <StatCard icon={<DollarSign className="h-3.5 w-3.5" />} label="Staff Costs" value="$1,500" />
        <StatCard icon={<DollarSign className="h-3.5 w-3.5" />} label="Ice Costs" value="$1,500" />
      </div>

      <div className="grid grid-cols-3 gap-3">
        <StatCard icon={<DollarSign className="h-3.5 w-3.5" />} label="Other Costs" value="$200" />
        <StatCard icon={<DollarSign className="h-3.5 w-3.5" />} label="Total Costs" value="$3,200" />
        <StatCard icon={<DollarSign className="h-3.5 w-3.5" />} label="Net Profit" value="$2,500" accent />
      </div>

      <p className="text-xs text-muted-foreground">
        Margin: 44% · Staff rates loaded from Settings · Ice costs from ice allocation · Revenue based on registrations
      </p>
    </div>
  );
}
