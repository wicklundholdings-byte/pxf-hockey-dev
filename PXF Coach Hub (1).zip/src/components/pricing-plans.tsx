import { useState } from "react";
import { Check, Star, Zap } from "lucide-react";
import { Link } from "@tanstack/react-router";
import { cn } from "@/lib/utils";

const plans = [
  {
    key: "team",
    name: "TEAM COACH",
    monthly: 35,
    annual: 350,
    audience: "Best for: Rep team coaches",
    founding: "$25/mo",
    features: [
      "3 teams · 1 staff coach",
      "Drill library + practice plans",
      "Session builder",
      "PXF hardware integration",
      "No camps",
    ],
    cta: "Start Free Trial",
    variant: "outline" as const,
    badge: null,
    extra: null,
  },
  {
    key: "elite",
    name: "ELITE COACH",
    monthly: 80,
    annual: 800,
    audience: "Best for: Hockey business operators",
    founding: "$50/mo",
    features: [
      "Everything in Team Coach",
      "Unlimited camps + privates",
      "Financials + gross profit tracking",
      "Public profile + marketplace listing",
      "QR check-in · 3 staff coaches",
    ],
    cta: "Start Free Trial",
    variant: "primary" as const,
    badge: "MOST POPULAR",
    extra: null,
  },
];

export function PricingPlans({ className }: { className?: string }) {
  const [billing, setBilling] = useState<"monthly" | "annual">("monthly");

  return (
    <div className={cn("mx-auto max-w-6xl px-4 sm:px-6 lg:px-8", className)}>
      {/* Header */}
      <div className="mx-auto max-w-2xl text-center">
        <div className="text-xs font-bold uppercase tracking-[0.2em] text-teal-400">
          Pricing
        </div>
        <h2 className="mt-3 text-3xl font-black text-white md:text-5xl">
          Simple pricing. <span className="text-teal-400">No surprises.</span>
        </h2>
      </div>

      {/* Billing toggle */}
      <div className="mt-10 flex items-center justify-center gap-3">
        <div className="inline-flex rounded-full border border-white/10 bg-white/5 p-1">
          {(["monthly", "annual"] as const).map((b) => (
            <button
              key={b}
              onClick={() => setBilling(b)}
              className={cn(
                "rounded-full px-4 py-1.5 text-sm font-semibold transition",
                billing === b
                  ? "bg-gradient-to-r from-emerald-500 to-teal-500 text-white shadow-lg"
                  : "text-white/60 hover:text-white"
              )}
            >
              {b === "monthly" ? "Monthly" : "Annual (2 months free)"}
            </button>
          ))}
        </div>
      </div>

      {/* Founding member banner */}
      <div className="mt-8 flex justify-center">
        <div className="inline-flex items-center gap-3 rounded-full bg-gradient-to-r from-emerald-500 to-teal-500 px-5 py-2.5 text-sm font-bold text-white shadow-lg shadow-teal-500/20">
          <Zap className="h-4 w-4 fill-white" />
          <span>First 250 coaches lock in 25% off for life</span>
          <span className="rounded-full bg-white/20 px-2.5 py-0.5 text-xs">187 spots remaining</span>
        </div>
      </div>

      {/* Cards */}
      <div className="mt-10 grid grid-cols-1 gap-6 md:grid-cols-2">
        {plans.map((plan) => {
          const price = billing === "monthly" ? `$${plan.monthly}/mo` : `$${plan.annual}/yr`;
          const period = billing === "monthly" ? "Billed monthly" : "Billed annually · 2 months free";
          const isPrimary = plan.variant === "primary";

          return (
            <div
              key={plan.key}
              className={cn(
                "relative flex flex-col rounded-2xl",
                isPrimary
                  ? "bg-gradient-to-b from-emerald-500 to-teal-500 p-[1px] shadow-xl shadow-teal-500/20"
                  : "border border-white/10 bg-neutral-950"
              )}
            >
              {plan.badge && (
                <div className="absolute -top-3 left-1/2 z-10 flex -translate-x-1/2 items-center gap-1.5 rounded-full bg-gradient-to-r from-emerald-500 to-teal-500 px-3 py-1 text-[10px] font-black uppercase tracking-widest text-white shadow-lg">
                  <Star className="h-3 w-3 fill-white" />
                  {plan.badge}
                </div>
              )}
              <div className={cn("flex flex-1 flex-col rounded-2xl p-6", isPrimary && "bg-neutral-950")}>
                <div className="text-xs font-bold uppercase tracking-widest text-teal-400">
                  {plan.name}
                </div>
                <div className="mt-3 flex items-baseline gap-1">
                  <span className="text-4xl font-black text-white">{price}</span>
                </div>
                <div className="mt-1 text-xs text-white/50">{period}</div>
                {billing === "monthly" && plan.founding && (
                  <div className="mt-3 inline-flex items-start gap-2 rounded-lg border border-teal-400/30 bg-gradient-to-r from-emerald-500/10 to-teal-500/10 px-3 py-2 text-xs font-semibold text-teal-300">
                    <span aria-hidden>🏒</span>
                    <span>
                      <span className="font-black text-teal-300">Founding Member: {plan.founding}</span>
                      <span className="ml-1 text-teal-300/80">— First 250 coaches, locked in for life</span>
                    </span>
                  </div>
                )}
                <p className="mt-3 text-sm font-medium text-white/70">{plan.audience}</p>
                <ul className="mt-6 flex-1 space-y-2.5">
                  {plan.features.map((feature) => (
                    <li key={feature} className="flex items-start gap-2 text-sm text-white/80">
                      <Check className="mt-0.5 h-4 w-4 shrink-0 text-teal-400" />
                      <span>{feature}</span>
                    </li>
                  ))}
                </ul>
                <div className="mt-6 space-y-3">
                  <Link
                    to="/dashboard"
                    className={cn(
                      "inline-flex w-full items-center justify-center rounded-md px-4 py-2.5 text-sm font-semibold transition",
                      isPrimary
                        ? "bg-gradient-to-r from-emerald-500 to-teal-500 text-white shadow-lg hover:opacity-95"
                        : "border border-white/15 bg-white/[0.03] text-white hover:border-teal-400/40 hover:bg-white/[0.06]"
                    )}
                  >
                    {plan.cta}
                  </Link>
                  {plan.extra && (
                    <a href="mailto:sales@pxfhockey.com" className="block w-full text-center text-xs font-semibold text-white/60 hover:text-teal-400">
                      {plan.extra}
                    </a>
                  )}
                </div>
              </div>
            </div>
          );
        })}
      </div>

      <p className="mt-10 text-center text-xs text-white/40">
        14-day free trial · No credit card required · Cancel anytime
      </p>
    </div>
  );
}
