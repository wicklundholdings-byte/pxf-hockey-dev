import { supabase } from "./supabase";

export type Role = "elite" | "team" | "parent";

export async function getRoleFromDB(userId: string): Promise<Role | null> {
  const { data } = await supabase
    .from("profiles")
    .select("role")
    .eq("id", userId)
    .maybeSingle();
  return (data?.role as Role | null) ?? null;
}

export function pathForRole(role: Role | null): string {
  if (role === "team") return "/team-coach";
  if (role === "parent") return "/parent";
  return "/dashboard"; // elite or null
}

