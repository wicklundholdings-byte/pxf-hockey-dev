// Mock data for public coach booking pages.
export type BookingCamp = {
  id: string;
  name: string;
  banner?: string;
  dateRange: string;
  startsAt: string;
  times: string;
  ageGroup: string;
  skillLevel: string;
  spotsTotal: number;
  spotsTaken: number;
  price: number;
  earlyBirdPrice?: number;
  earlyBirdDeadline?: string;
  description: string;
  whatToBring: string[];
  rink: { name: string; address: string };
  instructors: { name: string; photo: string; bio: string; credentials: string }[];
  paymentPlan?: { installments: { amount: number; label: string }[] };
  refundPolicy: string;
  reviews: { id: string; parent: string; stars: number; text: string; date: string }[];
};

export type SessionType = {
  id: string;
  name: string;
  duration: string;
  price: number;
  description: string;
};

export type StaffMember = { id: string; name: string; role: string; photo: string };

export type GalleryPhoto = { id: string; url: string; caption?: string };

export type Testimonial = { id: string; quote: string; parent: string; childLevel: string; stars: number };

export type TeamListingKind = "tryout" | "open-roster" | "coming-soon";
export type TeamListing = {
  id: string;
  kind: TeamListingKind;
  name: string;
  ageGroup: string;
  division: string;
  season?: string;
  dateLine: string;
  timeLine?: string;
  location?: string;
  fee?: number;
  spotsTotal?: number;
  spotsTaken?: number;
  banner?: string;
  description?: string;
  expectedOpenDate?: string;
};

export type SocialLinks = {
  instagram?: string;
  youtube?: string;
  tiktok?: string;
  facebook?: string;
};

export type CoachPage = {
  username: string;
  name: string;
  school: string;
  tagline: string;
  bio: string;
  philosophy: string;
  playingBackground: string;
  yearsCoaching: number;
  banner: string;
  avatar: string;
  video?: string;
  credentials: string[];
  contactEmail: string;
  staff: StaffMember[];
  gallery: GalleryPhoto[];
  testimonials: Testimonial[];
  social: SocialLinks;
  reviews: { id: string; parent: string; stars: number; text: string; date: string; camp: string }[];
  camps: BookingCamp[];
  teams: TeamListing[];
  sessions: SessionType[];
  openSlots: { date: string; times: string[] }[];
};

const sharedReviews = [
  { id: "r1", parent: "Sarah M.", stars: 5, text: "My son improved more in one week with Coach Maddox than a full season elsewhere. Incredibly organized and engaging.", date: "2 weeks ago", camp: "Elite Skating Camp" },
  { id: "r2", parent: "David L.", stars: 5, text: "Top tier instruction. The video review sessions were a game-changer for our daughter.", date: "1 month ago", camp: "Power Skating Intensive" },
  { id: "r3", parent: "Jenn K.", stars: 4, text: "Great camp, well run. Would have liked a bit more shooting work but skating drills were excellent.", date: "1 month ago", camp: "Elite Skating Camp" },
  { id: "r4", parent: "Marcus T.", stars: 5, text: "Coach is the real deal. Former OHL experience shows in every drill.", date: "2 months ago", camp: "Pre-Season Prep" },
];

export const coachPages: Record<string, CoachPage> = {
  "coach-maddox": {
    username: "coach-maddox",
    name: "Maddox Elite Skills",
    school: "Maddox Elite Skills",
    tagline: "Building the next generation of elite hockey players — one rep at a time.",
    bio: "Maddox Elite Skills is a Toronto-based hockey development program built for serious players. Our small-group format means every skater gets eyes on their stride, hands, and shot — every session, every rep.",
    philosophy: "We don't believe in volume for volume's sake. Every drill has a purpose, every rep is video-reviewed, and every skater leaves with measurable, position-specific improvement. High standards, high reps, zero filler.",
    playingBackground: "Former OHL player (2008-2012). Drafted to the AHL. Transitioned to coaching in 2014 after a career-ending injury.",
    yearsCoaching: 12,
    banner: "https://images.unsplash.com/photo-1515703407324-5f51c2ce99c2?w=1920&q=80",
    avatar: "https://images.unsplash.com/photo-1599566150163-29194dcaad36?w=400&q=80",
    video: "https://cdn.coverr.co/videos/coverr-ice-hockey-practice-7896/1080p.mp4",
    credentials: ["Hockey Canada Level 4", "NCCP Certified", "Former OHL Player", "12 Years Coaching"],
    contactEmail: "book@maddoxhockey.com",
    staff: [
      { id: "s1", name: "Coach Maddox", role: "Founder · Skills Lead", photo: "https://images.unsplash.com/photo-1599566150163-29194dcaad36?w=400&q=80" },
      { id: "s2", name: "Coach Reyes", role: "Power Skating Specialist", photo: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=400&q=80" },
      { id: "s3", name: "Coach Kovacs", role: "Goalie Coach", photo: "https://images.unsplash.com/photo-1517466787929-bc90951d0974?w=400&q=80" },
      { id: "s4", name: "Coach Lin", role: "Shooting & Scoring", photo: "https://images.unsplash.com/photo-1546484959-f9a381d1330d?w=400&q=80" },
    ],
    gallery: [
      { id: "g1", url: "https://images.unsplash.com/photo-1580692475446-c2fabbbe98cb?w=1200&q=80" },
      { id: "g2", url: "https://images.unsplash.com/photo-1551958219-acbc608c6377?w=1200&q=80" },
      { id: "g3", url: "https://images.unsplash.com/photo-1578926375605-eaf7559b1458?w=1200&q=80" },
      { id: "g4", url: "https://images.unsplash.com/photo-1526676037777-05a232554f77?w=1200&q=80" },
      { id: "g5", url: "https://images.unsplash.com/photo-1486286701208-1d58e9338013?w=1200&q=80" },
      { id: "g6", url: "https://images.unsplash.com/photo-1591491634026-77d1a7e60ddc?w=1200&q=80" },
    ],
    testimonials: [
      { id: "t1", quote: "My son improved more in one week with Coach Maddox than a full season elsewhere. The video review is a game-changer.", parent: "Sarah M.", childLevel: "Parent of U13 Rep player", stars: 5 },
      { id: "t2", quote: "Top tier instruction. Coach actually watches every rep and gives real feedback — not the cookie-cutter stuff you get at most camps.", parent: "David L.", childLevel: "Parent of U11 AAA player", stars: 5 },
      { id: "t3", quote: "Worth every dollar. Our daughter made her HPL team after one summer here.", parent: "Jenn K.", childLevel: "Parent of U13 HPL player", stars: 5 },
    ],
    social: {
      instagram: "https://instagram.com/maddoxhockey",
      youtube: "https://youtube.com/@maddoxhockey",
      tiktok: "https://tiktok.com/@maddoxhockey",
    },
    reviews: sharedReviews,
    camps: [
      {
        id: "elite-skating-aug",
        name: "Elite Skating Camp",
        banner: "https://images.unsplash.com/photo-1580692475446-c2fabbbe98cb?w=1600&q=80",
        dateRange: "Aug 12 – Aug 16, 2026",
        startsAt: "2026-08-12",
        times: "6:00 AM – 9:00 AM daily",
        ageGroup: "U11 – U13",
        skillLevel: "Rep/HPL · U11-U13 · Intermediate-Advanced",
        spotsTotal: 40,
        spotsTaken: 37,
        price: 595,
        earlyBirdPrice: 525,
        earlyBirdDeadline: "2026-07-15",
        description:
          "Five days of high-intensity skating development focused on edges, crossovers, and explosive starts. Daily video review sessions and on-ice mentorship from our staff. Built for Rep & HPL players preparing for tryouts.",
        whatToBring: ["Full hockey equipment", "Two sticks", "Water bottle (filled)", "Workout shirt for dryland", "Running shoes"],
        rink: { name: "Rink A — North York", address: "1 Hockey Way, North York, ON M2J 1A1" },
        instructors: [
          { name: "Coach Maddox", photo: "https://images.unsplash.com/photo-1599566150163-29194dcaad36?w=200", credentials: "Hockey Canada Level 4 · Former OHL", bio: "12 years coaching elite players." },
          { name: "Coach Reyes", photo: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=200", credentials: "NCCP Level 3", bio: "Power skating specialist." },
        ],
        paymentPlan: { installments: [{ amount: 325, label: "Today" }, { amount: 270, label: "One week before camp" }] },
        refundPolicy: "Full refund up to 14 days before camp. 50% refund within 14-7 days. No refunds within 7 days unless medical (with note).",
        reviews: sharedReviews.slice(0, 2),
      },
      {
        id: "shooting-clinic-sep",
        name: "Shooting & Scoring Clinic",
        banner: "https://images.unsplash.com/photo-1551958219-acbc608c6377?w=1600&q=80",
        dateRange: "Sep 7 – Sep 9, 2026",
        startsAt: "2026-09-07",
        times: "5:00 PM – 7:00 PM",
        ageGroup: "U13 – U15",
        skillLevel: "AA/AAA · U13-U15 · Advanced",
        spotsTotal: 24,
        spotsTaken: 24,
        price: 285,
        description: "Three-day shooting intensive — wrist shots, snap shots, one-timers, and tip drills. Includes shot tracking with radar.",
        whatToBring: ["Full equipment", "Stick (multiple recommended)", "Water"],
        rink: { name: "Rink B — Markham", address: "200 Ice Lane, Markham, ON L3R 4N9" },
        instructors: [{ name: "Coach Maddox", photo: "https://images.unsplash.com/photo-1599566150163-29194dcaad36?w=200", credentials: "Former OHL", bio: "Specializes in shot mechanics." }],
        refundPolicy: "Full refund up to 14 days before. No refunds within 7 days.",
        reviews: [],
      },
      {
        id: "goalie-camp-oct",
        name: "Goalie Development Camp",
        // intentionally no banner — tests gradient placeholder
        dateRange: "Oct 14 – Oct 18, 2026",
        startsAt: "2026-10-14",
        times: "7:00 AM – 9:00 AM",
        ageGroup: "U11 – U15",
        skillLevel: "All Levels · Goalie Only",
        spotsTotal: 14,
        spotsTaken: 9,
        price: 495,
        description: "Position-specific goalie training: angles, post integration, recovery, and tracking.",
        whatToBring: ["Full goalie gear", "Backup mask if available", "Water"],
        rink: { name: "Civic Arena", address: "55 Civic Plaza, Toronto, ON M5V 2T6" },
        instructors: [{ name: "Coach Kovacs", photo: "https://images.unsplash.com/photo-1517466787929-bc90951d0974?w=200", credentials: "Pro Goalie Coach", bio: "10 years pro goalie coaching." }],
        refundPolicy: "Full refund up to 21 days before camp.",
        reviews: [],
      },
    ],
    teams: [
      {
        id: "tryout-u13aa",
        kind: "tryout",
        name: "Maddox U13 AA",
        ageGroup: "U13",
        division: "AA",
        season: "2026-27 Season",
        dateLine: "Aug 22 – Aug 24, 2026",
        timeLine: "6:00 PM – 8:00 PM",
        location: "Rink A — North York",
        fee: 75,
        spotsTotal: 60,
        spotsTaken: 41,
        banner: "https://images.unsplash.com/photo-1526676037777-05a232554f77?w=1600&q=80",
        description: "Three-night tryout. Blind scoring, all evaluators independent.",
      },
      {
        id: "open-u11-spring",
        kind: "open-roster",
        name: "Maddox U11 Spring Select",
        ageGroup: "U11",
        division: "Select",
        season: "Spring 2026",
        dateLine: "Apr 5 – Jun 14, 2026",
        location: "Rink B — Markham",
        fee: 895,
        spotsTotal: 17,
        spotsTaken: 13,
        banner: "https://images.unsplash.com/photo-1578926375605-eaf7559b1458?w=1600&q=80",
        description: "10-week spring program with games and weekly practices.",
      },
      {
        id: "coming-u15aaa",
        kind: "coming-soon",
        name: "Maddox U15 AAA",
        ageGroup: "U15",
        division: "AAA",
        season: "2026-27 Season",
        dateLine: "Registration opens September 2026",
        expectedOpenDate: "2026-09-01",
        banner: "https://images.unsplash.com/photo-1551958219-acbc608c6377?w=1600&q=80",
        description: "Top-tier program for elite U15 prospects. Notify list opens now.",
      },
    ],
    sessions: [
      { id: "s1", name: "1-on-1 Private Lesson", duration: "60 min", price: 165, description: "On-ice private session, video reviewed." },
      { id: "s2", name: "Small Group (2-4 skaters)", duration: "60 min", price: 95, description: "Per skater. Build with friends or teammates." },
      { id: "s3", name: "5-Session Series", duration: "60 min × 5", price: 725, description: "Save vs single bookings. Scheduled at your pace." },
    ],
    openSlots: [
      { date: "Tue Jul 7", times: ["6:00 AM", "7:00 AM", "5:00 PM"] },
      { date: "Wed Jul 8", times: ["6:00 AM", "4:00 PM"] },
      { date: "Thu Jul 9", times: ["6:00 AM", "7:00 AM", "8:00 AM", "6:00 PM"] },
      { date: "Fri Jul 10", times: ["7:00 AM"] },
    ],
  },
};

export function getCoachPage(username: string): CoachPage | null {
  return coachPages[username] ?? null;
}
