import type { CoachPage } from "./booking-data";

const KEY = (username: string) => `pxf:booking:${username}`;

export type CoachOverrides = Partial<
  Pick<
    CoachPage,
    | "banner" | "avatar" | "name" | "school" | "tagline" | "video"
    | "bio" | "philosophy" | "playingBackground" | "yearsCoaching"
    | "credentials" | "gallery" | "testimonials" | "social" | "teams"
  >
>;

export function loadCoachOverrides(username: string): CoachOverrides | null {
  if (typeof window === "undefined") return null;
  try {
    const raw = window.localStorage.getItem(KEY(username));
    return raw ? (JSON.parse(raw) as CoachOverrides) : null;
  } catch {
    return null;
  }
}

export function saveCoachOverrides(username: string, data: CoachOverrides): { ok: boolean; error?: string } {
  if (typeof window === "undefined") return { ok: false, error: "No storage available" };
  try {
    window.localStorage.setItem(KEY(username), JSON.stringify(data));
    return { ok: true };
  } catch (e) {
    const msg = e instanceof Error ? e.message : "Save failed";
    return { ok: false, error: msg.includes("quota") ? "Too large to save in browser — uploaded video may exceed storage limit. Try a shorter clip or paste a YouTube/Vimeo URL." : msg };
  }
}

export function mergePage(seed: CoachPage, overrides: CoachOverrides | null): CoachPage {
  if (!overrides) return seed;
  return { ...seed, ...overrides, social: { ...seed.social, ...(overrides.social ?? {}) } };
}

/** Parses a video URL into something we can render. Returns null if unknown. */
export function parseVideoSource(url: string): { kind: "embed"; src: string } | { kind: "file"; src: string } | null {
  if (!url) return null;
  const trimmed = url.trim();
  // Blob/data — file
  if (trimmed.startsWith("blob:") || trimmed.startsWith("data:")) return { kind: "file", src: trimmed };
  // YouTube
  const yt = trimmed.match(/(?:youtube\.com\/(?:watch\?v=|embed\/|shorts\/)|youtu\.be\/)([\w-]{6,})/);
  if (yt) return { kind: "embed", src: `https://www.youtube.com/embed/${yt[1]}?autoplay=1&mute=1&loop=1&playlist=${yt[1]}&controls=1` };
  // Vimeo
  const vm = trimmed.match(/vimeo\.com\/(?:video\/)?(\d+)/);
  if (vm) return { kind: "embed", src: `https://player.vimeo.com/video/${vm[1]}?autoplay=1&muted=1&loop=1` };
  // Direct file URL
  if (/\.(mp4|webm|mov|m4v|ogg)(\?|$)/i.test(trimmed)) return { kind: "file", src: trimmed };
  // Fallback — treat as file and let <video> try
  return { kind: "file", src: trimmed };
}
