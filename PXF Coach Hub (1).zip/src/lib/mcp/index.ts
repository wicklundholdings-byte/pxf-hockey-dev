import { defineMcp } from "@lovable.dev/mcp-js";
import listCampsTool from "./tools/list-camps";
import todayScheduleTool from "./tools/today-schedule";

export default defineMcp({
  name: "pxf-coach-hub-mcp",
  title: "PXF Coach Hub MCP",
  version: "0.1.0",
  instructions:
    "Tools for PXF Hockey Coach Hub. Use `list_camps` to browse camps and `today_schedule` to view today's sessions.",
  tools: [listCampsTool, todayScheduleTool],
});
