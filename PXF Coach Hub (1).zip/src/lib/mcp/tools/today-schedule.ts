import { defineTool } from "@lovable.dev/mcp-js";
import { z } from "zod";

export default defineTool({
  name: "today_schedule",
  title: "Today's schedule",
  description: "Return today's PXF Hockey sessions (camps, practices, games, privates).",
  inputSchema: {
    type: z.enum(["CAMP", "PRACTICE", "GAME", "PRIVATE"]).optional().describe("Optional session-type filter."),
  },
  annotations: { readOnlyHint: true, idempotentHint: true, openWorldHint: false },
  handler: ({ type }) => {
    const events = [
      { time: "6:00 AM", name: "Elite Skating Camp · Day 5", type: "CAMP", location: "Rink A", attendance: "38/40" },
      { time: "9:30 AM", name: "Power Skating Private — L. Tremblay", type: "PRIVATE", location: "Rink C", attendance: "1/1" },
      { time: "5:30 PM", name: "U14 AA Practice", type: "PRACTICE", location: "Rink A", attendance: "19/20" },
    ];
    const rows = type ? events.filter((e) => e.type === type) : events;
    return {
      content: [{ type: "text", text: JSON.stringify(rows, null, 2) }],
      structuredContent: { events: rows },
    };
  },
});
