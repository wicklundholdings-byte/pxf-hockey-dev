import { defineTool } from "@lovable.dev/mcp-js";
import { z } from "zod";

const CAMPS = [
  { id: "camp-elite-skating", name: "Elite Skating Camp", ageGroup: "U14-U18", spots: 40, filled: 38 },
  { id: "camp-goalie-dev", name: "Goalie Development Camp", ageGroup: "U12-U16", spots: 14, filled: 12 },
  { id: "camp-power-skating", name: "Power Skating Intensive", ageGroup: "U10-U14", spots: 30, filled: 22 },
];

export default defineTool({
  name: "list_camps",
  title: "List camps",
  description: "List PXF Hockey camps with age group and enrollment.",
  inputSchema: {
    ageGroup: z.string().optional().describe("Optional age group substring filter, e.g. 'U14'."),
  },
  annotations: { readOnlyHint: true, idempotentHint: true, openWorldHint: false },
  handler: ({ ageGroup }) => {
    const rows = ageGroup
      ? CAMPS.filter((c) => c.ageGroup.toLowerCase().includes(ageGroup.toLowerCase()))
      : CAMPS;
    return {
      content: [{ type: "text", text: JSON.stringify(rows, null, 2) }],
      structuredContent: { camps: rows },
    };
  },
});
