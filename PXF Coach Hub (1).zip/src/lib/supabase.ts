import { createClient } from "@supabase/supabase-js";

// PXF Hockey — shared Supabase project with the mobile app.
const SUPABASE_URL = "https://kqamqlsimyelvzxqdnyp.supabase.co";
const SUPABASE_PUBLISHABLE_KEY = "sb_publishable_9D3N67geyAZu5diFC4hjCw_QpQTOH2n";

export const supabase = createClient(SUPABASE_URL, SUPABASE_PUBLISHABLE_KEY, {
  auth: {
    persistSession: true,
    autoRefreshToken: true,
    detectSessionInUrl: true,
  },
});
