## Goal
Link your existing Supabase project `rycxmlkuelbeoqxcjzdq` to this Lovable app, and stop it from defaulting to the unrelated Supabase project you saw in the Connectors panel.

## Why it's happening
"Connectors" is a workspace-level integrations panel (Slack, Stripe, Resend, etc.). The Supabase project link is a separate, project-level integration. The Connectors flow is the wrong entry point for attaching a Supabase project.

## Steps you take in the Lovable UI

1. **Disconnect the wrong Supabase project first** (if one is currently linked)
   - Desktop: nav above the preview → **Cloud** → settings / connected project → **Disconnect**.
   - Mobile: bottom-right **…** → **Cloud** → Disconnect.

2. **Connect the correct project from the chat input — not Connectors**
   - Desktop: chat input **+** button → **Supabase** → **Connect existing project** → sign in → pick `rycxmlkuelbeoqxcjzdq`.
   - Mobile: **+** in chat input → **Supabase** → **Connect existing project**.

3. **Verify** that Cloud → Database shows the `rycxmlkuelbeoqxcjzdq` project.

## If the dialog still shows the wrong project
- Sign out of Supabase inside the dialog and sign back in with the account that owns `rycxmlkuelbeoqxcjzdq`.
- Confirm your Supabase user has access to that project's organization.
- If it still won't switch, send a screenshot of the dialog.

## What I'll do once it's connected (next turn, in build mode)
- Inspect existing tables/columns in your Supabase project.
- Confirm scope for the coaches portal (roster, schedule, attendance, drills).
- Scaffold routes, components, and any needed migrations against the real schema.

Approve this and I'll wait for the connection, then start the coaches portal build.