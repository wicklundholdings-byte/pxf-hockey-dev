-- ============================================================================
-- PXF Hockey — Public Booking + Registration Flow
-- Paste this into Supabase SQL Editor (run as a single transaction).
-- Idempotent: safe to re-run.
-- ============================================================================

begin;

-- ---------------------------------------------------------------------------
-- 1. ROLES (enum + user_roles table; roles MUST be separate from profiles)
-- ---------------------------------------------------------------------------
do $$ begin
  create type public.app_role as enum ('parent', 'coach', 'association_admin', 'admin');
exception when duplicate_object then null; end $$;

create table if not exists public.user_roles (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  role public.app_role not null,
  created_at timestamptz not null default now(),
  unique (user_id, role)
);

alter table public.user_roles enable row level security;

create or replace function public.has_role(_user_id uuid, _role public.app_role)
returns boolean language sql stable security definer set search_path = public as $$
  select exists (select 1 from public.user_roles where user_id = _user_id and role = _role)
$$;

drop policy if exists "users read own roles" on public.user_roles;
create policy "users read own roles" on public.user_roles
  for select to authenticated using (user_id = auth.uid());

grant select on public.user_roles to authenticated;
grant all    on public.user_roles to service_role;

-- ---------------------------------------------------------------------------
-- 2. PROFILES — ensure shape needed for parent accounts and public coach lookup
--    NOTE: keeps existing data. Only adds missing columns.
-- ---------------------------------------------------------------------------
create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  created_at timestamptz not null default now()
);

alter table public.profiles add column if not exists first_name text;
alter table public.profiles add column if not exists last_name  text;
alter table public.profiles add column if not exists email      text;
alter table public.profiles add column if not exists phone      text;
alter table public.profiles add column if not exists username   text unique; -- used in /book/[username]
alter table public.profiles add column if not exists avatar_url text;
alter table public.profiles add column if not exists updated_at timestamptz not null default now();

alter table public.profiles enable row level security;

-- public can read minimal coach profile (used by /book/[username])
drop policy if exists "public read coach profiles" on public.profiles;
create policy "public read coach profiles" on public.profiles
  for select to anon, authenticated
  using (public.has_role(id, 'coach') or public.has_role(id, 'association_admin'));

drop policy if exists "users read own profile" on public.profiles;
create policy "users read own profile" on public.profiles
  for select to authenticated using (id = auth.uid());

drop policy if exists "users insert own profile" on public.profiles;
create policy "users insert own profile" on public.profiles
  for insert to authenticated with check (id = auth.uid());

drop policy if exists "users update own profile" on public.profiles;
create policy "users update own profile" on public.profiles
  for update to authenticated using (id = auth.uid());

grant select                          on public.profiles to anon;
grant select, insert, update          on public.profiles to authenticated;
grant all                             on public.profiles to service_role;

-- auto-create profile + assign 'parent' role on signup
create or replace function public.handle_new_user()
returns trigger language plpgsql security definer set search_path = public as $$
begin
  insert into public.profiles (id, email, first_name, last_name, phone)
  values (
    new.id,
    new.email,
    new.raw_user_meta_data->>'first_name',
    new.raw_user_meta_data->>'last_name',
    new.raw_user_meta_data->>'phone'
  )
  on conflict (id) do nothing;

  insert into public.user_roles (user_id, role)
  values (new.id, coalesce((new.raw_user_meta_data->>'role')::public.app_role, 'parent'))
  on conflict do nothing;

  return new;
end $$;

drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created
  after insert on auth.users
  for each row execute function public.handle_new_user();

-- ---------------------------------------------------------------------------
-- 3. CAMPS / TEAMS / PRIVATE_SESSIONS — add public-read grants + spot tracking
--    Assumes existing columns include: id uuid, coach_id uuid, status text,
--    name text, capacity int. Add others if missing.
-- ---------------------------------------------------------------------------
alter table public.camps            add column if not exists spots_taken int not null default 0;
alter table public.teams            add column if not exists spots_taken int not null default 0;
alter table public.private_sessions add column if not exists spots_taken int not null default 0;

alter table public.camps            enable row level security;
alter table public.teams            enable row level security;
alter table public.private_sessions enable row level security;

-- public-read active listings
drop policy if exists "public read active camps" on public.camps;
create policy "public read active camps" on public.camps
  for select to anon, authenticated using (status = 'active');

drop policy if exists "coach manages own camps" on public.camps;
create policy "coach manages own camps" on public.camps
  for all to authenticated using (coach_id = auth.uid()) with check (coach_id = auth.uid());

drop policy if exists "public read active teams" on public.teams;
create policy "public read active teams" on public.teams
  for select to anon, authenticated using (status = 'active');

drop policy if exists "coach manages own teams" on public.teams;
create policy "coach manages own teams" on public.teams
  for all to authenticated using (coach_id = auth.uid()) with check (coach_id = auth.uid());

drop policy if exists "public read active privates" on public.private_sessions;
create policy "public read active privates" on public.private_sessions
  for select to anon, authenticated using (status = 'active');

drop policy if exists "coach manages own privates" on public.private_sessions;
create policy "coach manages own privates" on public.private_sessions
  for all to authenticated using (coach_id = auth.uid()) with check (coach_id = auth.uid());

grant select on public.camps,            public.teams,            public.private_sessions to anon;
grant select, insert, update, delete on public.camps, public.teams, public.private_sessions to authenticated;
grant all on public.camps, public.teams, public.private_sessions to service_role;

-- enable Realtime for spot updates on the public page
alter publication supabase_realtime add table public.camps;
alter publication supabase_realtime add table public.teams;
alter publication supabase_realtime add table public.private_sessions;

-- ---------------------------------------------------------------------------
-- 4. ATHLETES — owned by parent
-- ---------------------------------------------------------------------------
do $$ begin create type public.athlete_position as enum ('forward','defence','goalie'); exception when duplicate_object then null; end $$;

create table if not exists public.athletes (
  id           uuid primary key default gen_random_uuid(),
  parent_id    uuid not null references auth.users(id) on delete cascade,
  first_name   text not null,
  last_name    text not null,
  dob          date not null,
  position     public.athlete_position,
  jersey_number int,
  created_at   timestamptz not null default now(),
  updated_at   timestamptz not null default now()
);

create index if not exists athletes_parent_id_idx on public.athletes(parent_id);

alter table public.athletes enable row level security;

drop policy if exists "parent manages own athletes" on public.athletes;
create policy "parent manages own athletes" on public.athletes
  for all to authenticated
  using (parent_id = auth.uid()) with check (parent_id = auth.uid());

-- coaches can read athletes registered into their offerings (via registrations)
drop policy if exists "coach reads registered athletes" on public.athletes;
create policy "coach reads registered athletes" on public.athletes
  for select to authenticated using (
    exists (
      select 1 from public.camp_registrations r
      where r.athlete_id = athletes.id and r.coach_id = auth.uid()
    )
  );

grant select, insert, update, delete on public.athletes to authenticated;
grant all on public.athletes to service_role;

-- ---------------------------------------------------------------------------
-- 5. CAMP_REGISTRATIONS — single table for camps / teams / privates
-- ---------------------------------------------------------------------------
do $$ begin create type public.registration_kind   as enum ('camp','team','private'); exception when duplicate_object then null; end $$;
do $$ begin create type public.registration_status as enum ('pending','confirmed','cancelled','refunded'); exception when duplicate_object then null; end $$;
do $$ begin create type public.payment_status      as enum ('unpaid','partial','paid','refunded','failed'); exception when duplicate_object then null; end $$;

create table if not exists public.camp_registrations (
  id              uuid primary key default gen_random_uuid(),
  parent_id       uuid not null references auth.users(id) on delete cascade,
  athlete_id      uuid not null references public.athletes(id) on delete restrict,
  coach_id        uuid not null references auth.users(id) on delete restrict,
  listing_kind    public.registration_kind not null,
  listing_id      uuid not null, -- FK enforced in app layer (camps/teams/private_sessions)
  status          public.registration_status not null default 'pending',
  payment_status  public.payment_status      not null default 'unpaid',
  amount_cents    int not null default 0,
  paid_cents      int not null default 0,
  payment_plan    text, -- 'full' | 'installments'
  stripe_payment_intent_id text,
  notes           text,
  created_at      timestamptz not null default now(),
  updated_at      timestamptz not null default now(),
  unique (athlete_id, listing_kind, listing_id)
);

create index if not exists camp_reg_coach_idx   on public.camp_registrations(coach_id, created_at desc);
create index if not exists camp_reg_parent_idx  on public.camp_registrations(parent_id, created_at desc);
create index if not exists camp_reg_listing_idx on public.camp_registrations(listing_kind, listing_id);

alter table public.camp_registrations enable row level security;

drop policy if exists "parent reads own registrations" on public.camp_registrations;
create policy "parent reads own registrations" on public.camp_registrations
  for select to authenticated using (parent_id = auth.uid());

drop policy if exists "parent creates own registrations" on public.camp_registrations;
create policy "parent creates own registrations" on public.camp_registrations
  for insert to authenticated with check (
    parent_id = auth.uid()
    and exists (select 1 from public.athletes a where a.id = athlete_id and a.parent_id = auth.uid())
  );

drop policy if exists "parent cancels own registrations" on public.camp_registrations;
create policy "parent cancels own registrations" on public.camp_registrations
  for update to authenticated using (parent_id = auth.uid()) with check (parent_id = auth.uid());

drop policy if exists "coach reads own roster" on public.camp_registrations;
create policy "coach reads own roster" on public.camp_registrations
  for select to authenticated using (coach_id = auth.uid());

drop policy if exists "coach updates own roster" on public.camp_registrations;
create policy "coach updates own roster" on public.camp_registrations
  for update to authenticated using (coach_id = auth.uid()) with check (coach_id = auth.uid());

grant select, insert, update on public.camp_registrations to authenticated;
grant all on public.camp_registrations to service_role;

-- spot counter trigger
create or replace function public.bump_listing_spots()
returns trigger language plpgsql security definer set search_path = public as $$
declare
  delta int := 0;
  tgt   text;
begin
  if TG_OP = 'INSERT' and NEW.status in ('pending','confirmed') then delta := 1;
  elsif TG_OP = 'DELETE' and OLD.status in ('pending','confirmed') then delta := -1;
  elsif TG_OP = 'UPDATE' then
    if OLD.status in ('pending','confirmed') and NEW.status not in ('pending','confirmed') then delta := -1;
    elsif OLD.status not in ('pending','confirmed') and NEW.status in ('pending','confirmed') then delta := 1;
    end if;
  end if;

  if delta = 0 then return coalesce(NEW, OLD); end if;

  tgt := coalesce(NEW.listing_kind, OLD.listing_kind)::text;
  if tgt = 'camp' then
    update public.camps set spots_taken = greatest(0, spots_taken + delta) where id = coalesce(NEW.listing_id, OLD.listing_id);
  elsif tgt = 'team' then
    update public.teams set spots_taken = greatest(0, spots_taken + delta) where id = coalesce(NEW.listing_id, OLD.listing_id);
  elsif tgt = 'private' then
    update public.private_sessions set spots_taken = greatest(0, spots_taken + delta) where id = coalesce(NEW.listing_id, OLD.listing_id);
  end if;

  return coalesce(NEW, OLD);
end $$;

drop trigger if exists trg_bump_spots on public.camp_registrations;
create trigger trg_bump_spots
  after insert or update or delete on public.camp_registrations
  for each row execute function public.bump_listing_spots();

alter publication supabase_realtime add table public.camp_registrations;

-- ---------------------------------------------------------------------------
-- 6. NOTIFICATIONS — in-app coach notifications
-- ---------------------------------------------------------------------------
create table if not exists public.notifications (
  id          uuid primary key default gen_random_uuid(),
  user_id     uuid not null references auth.users(id) on delete cascade,
  kind        text not null, -- 'new_registration', 'payment_received', etc.
  title       text not null,
  body        text,
  link        text,
  read_at     timestamptz,
  created_at  timestamptz not null default now(),
  metadata    jsonb not null default '{}'::jsonb
);

create index if not exists notifications_user_idx on public.notifications(user_id, created_at desc);

alter table public.notifications enable row level security;

drop policy if exists "user reads own notifications" on public.notifications;
create policy "user reads own notifications" on public.notifications
  for select to authenticated using (user_id = auth.uid());

drop policy if exists "user updates own notifications" on public.notifications;
create policy "user updates own notifications" on public.notifications
  for update to authenticated using (user_id = auth.uid()) with check (user_id = auth.uid());

drop policy if exists "anyone authenticated creates notifications" on public.notifications;
create policy "anyone authenticated creates notifications" on public.notifications
  for insert to authenticated with check (true);

grant select, insert, update on public.notifications to authenticated;
grant all on public.notifications to service_role;

alter publication supabase_realtime add table public.notifications;

-- auto-notify coach on new registration
create or replace function public.notify_coach_on_registration()
returns trigger language plpgsql security definer set search_path = public as $$
declare
  athlete_name text;
begin
  select a.first_name || ' ' || a.last_name into athlete_name from public.athletes a where a.id = NEW.athlete_id;
  insert into public.notifications (user_id, kind, title, body, link, metadata)
  values (
    NEW.coach_id,
    'new_registration',
    'New registration',
    coalesce(athlete_name, 'An athlete') || ' just registered.',
    '/operations',
    jsonb_build_object(
      'registration_id', NEW.id,
      'athlete_id', NEW.athlete_id,
      'listing_kind', NEW.listing_kind,
      'listing_id', NEW.listing_id
    )
  );
  return NEW;
end $$;

drop trigger if exists trg_notify_coach on public.camp_registrations;
create trigger trg_notify_coach
  after insert on public.camp_registrations
  for each row execute function public.notify_coach_on_registration();

commit;

-- ============================================================================
-- DONE. Verify:
--   select count(*) from public.camps;          -- should now be readable from anon
--   select count(*) from public.athletes;       -- should be 0
--   select count(*) from public.camp_registrations;
-- ============================================================================
